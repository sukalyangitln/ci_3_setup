<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-06-29 00:00:04 --> Total execution time: 0.0493
DEBUG - 2022-06-29 00:00:19 --> Total execution time: 0.0426
DEBUG - 2022-06-29 00:00:26 --> Total execution time: 0.0487
DEBUG - 2022-06-29 00:00:27 --> Total execution time: 0.0511
DEBUG - 2022-06-29 00:01:00 --> Total execution time: 0.5348
DEBUG - 2022-06-29 00:02:35 --> Total execution time: 0.1659
DEBUG - 2022-06-29 00:02:37 --> Total execution time: 0.1158
DEBUG - 2022-06-29 00:02:47 --> Total execution time: 0.0719
DEBUG - 2022-06-29 00:03:04 --> Total execution time: 0.1079
DEBUG - 2022-06-29 00:03:12 --> Total execution time: 0.0655
DEBUG - 2022-06-29 00:03:52 --> Total execution time: 0.0497
DEBUG - 2022-06-29 00:03:59 --> Total execution time: 0.0599
DEBUG - 2022-06-29 00:04:09 --> Total execution time: 0.0397
DEBUG - 2022-06-29 00:04:09 --> Total execution time: 0.0417
DEBUG - 2022-06-29 00:04:10 --> Total execution time: 0.0337
DEBUG - 2022-06-29 00:04:10 --> Total execution time: 0.0556
DEBUG - 2022-06-29 00:04:12 --> Total execution time: 0.0392
DEBUG - 2022-06-29 00:04:13 --> Total execution time: 0.0405
DEBUG - 2022-06-29 00:04:45 --> Total execution time: 0.0634
DEBUG - 2022-06-29 00:05:47 --> Total execution time: 0.0478
DEBUG - 2022-06-29 00:06:01 --> Total execution time: 0.2393
DEBUG - 2022-06-29 00:06:03 --> Total execution time: 0.0769
DEBUG - 2022-06-29 00:06:09 --> Total execution time: 0.0722
DEBUG - 2022-06-29 00:06:14 --> Total execution time: 0.2724
DEBUG - 2022-06-29 00:06:34 --> Total execution time: 0.0659
DEBUG - 2022-06-29 00:06:35 --> Total execution time: 0.0701
DEBUG - 2022-06-29 00:06:47 --> Total execution time: 0.0958
DEBUG - 2022-06-29 00:06:55 --> Total execution time: 0.0753
DEBUG - 2022-06-29 00:06:57 --> Total execution time: 0.0986
DEBUG - 2022-06-29 00:07:42 --> Total execution time: 0.0321
DEBUG - 2022-06-29 00:07:49 --> Total execution time: 0.0441
DEBUG - 2022-06-29 00:08:01 --> Total execution time: 0.0539
DEBUG - 2022-06-29 00:08:08 --> Total execution time: 0.0533
DEBUG - 2022-06-29 00:08:15 --> Total execution time: 0.1230
DEBUG - 2022-06-29 00:08:20 --> Total execution time: 0.0604
DEBUG - 2022-06-29 00:08:26 --> Total execution time: 0.0656
DEBUG - 2022-06-29 00:08:27 --> Total execution time: 0.0536
DEBUG - 2022-06-29 00:08:50 --> Total execution time: 0.0594
DEBUG - 2022-06-29 00:09:09 --> Total execution time: 0.0891
DEBUG - 2022-06-29 00:09:11 --> Total execution time: 0.0733
DEBUG - 2022-06-29 00:09:15 --> Total execution time: 0.0770
DEBUG - 2022-06-29 00:09:17 --> Total execution time: 0.0506
DEBUG - 2022-06-29 00:09:18 --> Total execution time: 0.2763
DEBUG - 2022-06-29 00:09:19 --> Total execution time: 0.0483
DEBUG - 2022-06-29 00:09:31 --> Total execution time: 0.0559
DEBUG - 2022-06-29 00:09:36 --> Total execution time: 0.0463
DEBUG - 2022-06-29 00:10:02 --> Total execution time: 0.0954
DEBUG - 2022-06-29 00:10:59 --> Total execution time: 0.0526
DEBUG - 2022-06-29 00:11:21 --> Total execution time: 0.1113
DEBUG - 2022-06-29 00:11:34 --> Total execution time: 0.0451
DEBUG - 2022-06-29 00:13:39 --> Total execution time: 0.4614
DEBUG - 2022-06-29 00:13:52 --> Total execution time: 0.0535
DEBUG - 2022-06-29 00:19:30 --> Total execution time: 0.0835
DEBUG - 2022-06-29 00:19:31 --> Total execution time: 0.0386
DEBUG - 2022-06-29 00:21:52 --> Total execution time: 0.1113
DEBUG - 2022-06-29 00:24:30 --> Total execution time: 0.1990
DEBUG - 2022-06-29 00:24:36 --> Total execution time: 0.0765
DEBUG - 2022-06-29 00:24:38 --> Total execution time: 0.0484
DEBUG - 2022-06-29 00:24:46 --> Total execution time: 0.0518
DEBUG - 2022-06-29 00:24:49 --> Total execution time: 0.0546
DEBUG - 2022-06-29 00:24:51 --> Total execution time: 0.0510
DEBUG - 2022-06-29 00:26:00 --> Total execution time: 0.0364
DEBUG - 2022-06-29 00:30:03 --> Total execution time: 0.1986
DEBUG - 2022-06-29 00:37:53 --> Total execution time: 0.0523
DEBUG - 2022-06-29 00:40:06 --> Total execution time: 0.2287
DEBUG - 2022-06-29 00:40:14 --> Total execution time: 0.0559
DEBUG - 2022-06-29 00:40:18 --> Total execution time: 0.0609
DEBUG - 2022-06-29 00:41:21 --> Total execution time: 0.0523
DEBUG - 2022-06-29 00:41:29 --> Total execution time: 0.0715
DEBUG - 2022-06-29 00:44:00 --> Total execution time: 0.0546
DEBUG - 2022-06-29 00:54:00 --> Total execution time: 0.0487
DEBUG - 2022-06-29 00:57:20 --> Total execution time: 0.1564
DEBUG - 2022-06-29 00:57:22 --> Total execution time: 0.0432
DEBUG - 2022-06-29 01:04:19 --> Total execution time: 0.0389
DEBUG - 2022-06-29 01:04:19 --> Total execution time: 0.0504
DEBUG - 2022-06-29 01:04:24 --> Total execution time: 0.0484
DEBUG - 2022-06-29 01:04:32 --> Total execution time: 0.0636
DEBUG - 2022-06-29 01:04:36 --> Total execution time: 0.0629
DEBUG - 2022-06-29 01:04:40 --> Total execution time: 0.0608
DEBUG - 2022-06-29 01:04:45 --> Total execution time: 0.0440
DEBUG - 2022-06-29 01:05:33 --> Total execution time: 0.0498
DEBUG - 2022-06-29 01:05:36 --> Total execution time: 0.0498
DEBUG - 2022-06-29 01:05:44 --> Total execution time: 0.0604
DEBUG - 2022-06-29 01:05:52 --> Total execution time: 0.0508
DEBUG - 2022-06-29 01:10:08 --> Total execution time: 0.1160
DEBUG - 2022-06-29 01:10:10 --> Total execution time: 0.0537
DEBUG - 2022-06-29 01:25:21 --> Total execution time: 0.0574
DEBUG - 2022-06-29 01:25:21 --> Total execution time: 0.1895
DEBUG - 2022-06-29 01:25:54 --> Total execution time: 0.0477
DEBUG - 2022-06-29 01:30:02 --> Total execution time: 0.1512
DEBUG - 2022-06-29 01:36:02 --> Total execution time: 0.1723
DEBUG - 2022-06-29 01:36:04 --> Total execution time: 0.0515
DEBUG - 2022-06-29 01:36:07 --> Total execution time: 0.0505
DEBUG - 2022-06-29 01:36:12 --> Total execution time: 0.0529
DEBUG - 2022-06-29 01:36:17 --> Total execution time: 0.1154
DEBUG - 2022-06-29 01:36:45 --> Total execution time: 0.0404
DEBUG - 2022-06-29 01:36:48 --> Total execution time: 0.0313
DEBUG - 2022-06-29 01:36:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 01:36:54 --> Total execution time: 0.0781
DEBUG - 2022-06-29 01:36:58 --> Total execution time: 0.0800
DEBUG - 2022-06-29 01:36:59 --> Total execution time: 0.0524
DEBUG - 2022-06-29 01:37:00 --> Total execution time: 0.0582
DEBUG - 2022-06-29 01:37:02 --> Total execution time: 0.0545
DEBUG - 2022-06-29 01:37:10 --> Total execution time: 0.0553
DEBUG - 2022-06-29 01:37:11 --> Total execution time: 0.0497
DEBUG - 2022-06-29 01:37:11 --> Total execution time: 0.0657
DEBUG - 2022-06-29 01:37:12 --> Total execution time: 0.0513
DEBUG - 2022-06-29 01:37:21 --> Total execution time: 0.0683
DEBUG - 2022-06-29 01:37:38 --> Total execution time: 0.0565
DEBUG - 2022-06-29 01:37:45 --> Total execution time: 0.0741
DEBUG - 2022-06-29 01:37:49 --> Total execution time: 0.0480
DEBUG - 2022-06-29 01:38:00 --> Total execution time: 0.0650
DEBUG - 2022-06-29 01:38:01 --> Total execution time: 0.0736
DEBUG - 2022-06-29 01:38:08 --> Total execution time: 0.0662
DEBUG - 2022-06-29 01:38:29 --> Total execution time: 0.0864
DEBUG - 2022-06-29 01:38:32 --> Total execution time: 0.0497
DEBUG - 2022-06-29 01:38:43 --> Total execution time: 0.0596
DEBUG - 2022-06-29 01:38:45 --> Total execution time: 0.0502
DEBUG - 2022-06-29 01:38:53 --> Total execution time: 0.0695
DEBUG - 2022-06-29 01:39:12 --> Total execution time: 0.0509
DEBUG - 2022-06-29 01:39:14 --> Total execution time: 0.0471
DEBUG - 2022-06-29 01:39:17 --> Total execution time: 0.0496
DEBUG - 2022-06-29 01:39:31 --> Total execution time: 0.0544
DEBUG - 2022-06-29 01:39:32 --> Total execution time: 0.0753
DEBUG - 2022-06-29 01:39:49 --> Total execution time: 0.1040
DEBUG - 2022-06-29 01:40:02 --> Total execution time: 0.1021
DEBUG - 2022-06-29 01:40:22 --> Total execution time: 0.0764
DEBUG - 2022-06-29 01:40:32 --> Total execution time: 0.0725
DEBUG - 2022-06-29 01:40:39 --> Total execution time: 0.0737
DEBUG - 2022-06-29 01:40:51 --> Total execution time: 0.0706
DEBUG - 2022-06-29 01:40:56 --> Total execution time: 0.0490
DEBUG - 2022-06-29 01:41:03 --> Total execution time: 0.0524
DEBUG - 2022-06-29 01:41:16 --> Total execution time: 0.0508
DEBUG - 2022-06-29 01:41:34 --> Total execution time: 0.0504
DEBUG - 2022-06-29 01:42:10 --> Total execution time: 0.1104
DEBUG - 2022-06-29 01:42:30 --> Total execution time: 0.0537
DEBUG - 2022-06-29 01:46:10 --> Total execution time: 0.1133
DEBUG - 2022-06-29 01:46:16 --> Total execution time: 0.0676
DEBUG - 2022-06-29 01:46:19 --> Total execution time: 0.0485
DEBUG - 2022-06-29 01:46:35 --> Total execution time: 0.0554
DEBUG - 2022-06-29 01:46:53 --> Total execution time: 0.0575
DEBUG - 2022-06-29 01:47:04 --> Total execution time: 0.0528
DEBUG - 2022-06-29 01:47:05 --> Total execution time: 0.0505
DEBUG - 2022-06-29 01:47:14 --> Total execution time: 0.1157
DEBUG - 2022-06-29 01:47:35 --> Total execution time: 0.0495
DEBUG - 2022-06-29 01:47:42 --> Total execution time: 0.0518
DEBUG - 2022-06-29 01:49:13 --> Total execution time: 0.0512
DEBUG - 2022-06-29 01:49:58 --> Total execution time: 0.0511
DEBUG - 2022-06-29 01:50:01 --> Total execution time: 0.0411
DEBUG - 2022-06-29 01:50:09 --> Total execution time: 0.0475
DEBUG - 2022-06-29 01:51:07 --> Total execution time: 0.0543
DEBUG - 2022-06-29 01:51:16 --> Total execution time: 0.0567
DEBUG - 2022-06-29 01:51:21 --> Total execution time: 0.0474
DEBUG - 2022-06-29 01:51:23 --> Total execution time: 0.0529
DEBUG - 2022-06-29 01:51:26 --> Total execution time: 0.0472
DEBUG - 2022-06-29 01:51:40 --> Total execution time: 0.0763
DEBUG - 2022-06-29 01:51:48 --> Total execution time: 0.0475
DEBUG - 2022-06-29 01:53:25 --> Total execution time: 0.1197
DEBUG - 2022-06-29 01:53:52 --> Total execution time: 0.1103
DEBUG - 2022-06-29 01:54:03 --> Total execution time: 0.0466
DEBUG - 2022-06-29 01:54:07 --> Total execution time: 0.0466
DEBUG - 2022-06-29 01:54:12 --> Total execution time: 0.0465
DEBUG - 2022-06-29 01:54:14 --> Total execution time: 0.0547
DEBUG - 2022-06-29 01:54:15 --> Total execution time: 0.1269
DEBUG - 2022-06-29 01:56:08 --> Total execution time: 0.0521
DEBUG - 2022-06-29 01:58:43 --> Total execution time: 0.1076
DEBUG - 2022-06-29 02:05:43 --> Total execution time: 0.1201
DEBUG - 2022-06-29 02:13:23 --> Total execution time: 0.0796
DEBUG - 2022-06-29 02:13:23 --> Total execution time: 0.2560
DEBUG - 2022-06-29 02:23:33 --> Total execution time: 0.1770
DEBUG - 2022-06-29 02:24:18 --> Total execution time: 0.0462
DEBUG - 2022-06-29 02:24:45 --> Total execution time: 0.0539
DEBUG - 2022-06-29 02:25:58 --> Total execution time: 0.0552
DEBUG - 2022-06-29 02:26:23 --> Total execution time: 0.0432
DEBUG - 2022-06-29 02:26:53 --> Total execution time: 0.0435
DEBUG - 2022-06-29 02:27:09 --> Total execution time: 0.0491
DEBUG - 2022-06-29 02:28:35 --> Total execution time: 0.0503
DEBUG - 2022-06-29 02:28:44 --> Total execution time: 0.0481
DEBUG - 2022-06-29 02:28:53 --> Total execution time: 0.0515
DEBUG - 2022-06-29 02:28:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 02:28:54 --> Total execution time: 0.0448
DEBUG - 2022-06-29 02:30:03 --> Total execution time: 0.0948
DEBUG - 2022-06-29 02:30:45 --> Total execution time: 0.0537
DEBUG - 2022-06-29 02:30:52 --> Total execution time: 0.0522
DEBUG - 2022-06-29 02:30:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 02:30:53 --> Total execution time: 0.0671
DEBUG - 2022-06-29 02:38:31 --> Total execution time: 0.1820
DEBUG - 2022-06-29 02:38:59 --> Total execution time: 0.0752
DEBUG - 2022-06-29 02:38:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 02:39:00 --> Total execution time: 0.0522
DEBUG - 2022-06-29 02:40:15 --> Total execution time: 0.0606
DEBUG - 2022-06-29 02:40:29 --> Total execution time: 0.0451
DEBUG - 2022-06-29 02:46:15 --> Total execution time: 0.1012
DEBUG - 2022-06-29 02:47:31 --> Total execution time: 0.1089
DEBUG - 2022-06-29 02:47:35 --> Total execution time: 0.0632
DEBUG - 2022-06-29 02:47:42 --> Total execution time: 0.0657
DEBUG - 2022-06-29 02:47:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 02:47:43 --> Total execution time: 0.0516
DEBUG - 2022-06-29 03:12:33 --> Total execution time: 0.1425
DEBUG - 2022-06-29 03:12:48 --> Total execution time: 0.0378
DEBUG - 2022-06-29 03:15:22 --> Total execution time: 0.0412
DEBUG - 2022-06-29 03:15:36 --> Total execution time: 0.0326
DEBUG - 2022-06-29 03:30:04 --> Total execution time: 0.1556
DEBUG - 2022-06-29 03:34:05 --> Total execution time: 0.0392
DEBUG - 2022-06-29 03:34:09 --> Total execution time: 0.0263
DEBUG - 2022-06-29 03:34:39 --> Total execution time: 0.0754
DEBUG - 2022-06-29 03:34:44 --> Total execution time: 0.0493
DEBUG - 2022-06-29 03:35:50 --> Total execution time: 0.0658
DEBUG - 2022-06-29 03:35:54 --> Total execution time: 0.0620
DEBUG - 2022-06-29 03:36:25 --> Total execution time: 0.0509
DEBUG - 2022-06-29 03:45:55 --> Total execution time: 0.1217
DEBUG - 2022-06-29 03:57:01 --> Total execution time: 0.3400
DEBUG - 2022-06-29 04:01:12 --> Total execution time: 0.0934
DEBUG - 2022-06-29 04:01:22 --> Total execution time: 0.0383
DEBUG - 2022-06-29 04:04:37 --> Total execution time: 0.1013
DEBUG - 2022-06-29 04:08:39 --> Total execution time: 0.1697
DEBUG - 2022-06-29 04:08:52 --> Total execution time: 0.0817
DEBUG - 2022-06-29 04:09:04 --> Total execution time: 0.0800
DEBUG - 2022-06-29 04:09:07 --> Total execution time: 0.0663
DEBUG - 2022-06-29 04:09:25 --> Total execution time: 0.0445
DEBUG - 2022-06-29 04:09:30 --> Total execution time: 0.0639
DEBUG - 2022-06-29 04:10:03 --> Total execution time: 0.0469
DEBUG - 2022-06-29 04:30:03 --> Total execution time: 0.1512
DEBUG - 2022-06-29 04:30:25 --> Total execution time: 0.1343
DEBUG - 2022-06-29 04:39:40 --> Total execution time: 0.2004
DEBUG - 2022-06-29 04:42:37 --> Total execution time: 0.0443
DEBUG - 2022-06-29 04:42:40 --> Total execution time: 0.0467
DEBUG - 2022-06-29 05:02:17 --> Total execution time: 0.1710
DEBUG - 2022-06-29 05:02:49 --> Total execution time: 0.0526
DEBUG - 2022-06-29 05:04:07 --> Total execution time: 0.0471
DEBUG - 2022-06-29 05:09:03 --> Total execution time: 0.1342
DEBUG - 2022-06-29 05:21:41 --> Total execution time: 0.1098
DEBUG - 2022-06-29 05:21:44 --> Total execution time: 0.0678
DEBUG - 2022-06-29 05:29:29 --> Total execution time: 0.1056
DEBUG - 2022-06-29 05:30:02 --> Total execution time: 0.0508
DEBUG - 2022-06-29 05:30:34 --> Total execution time: 0.0679
DEBUG - 2022-06-29 05:30:55 --> Total execution time: 0.0450
DEBUG - 2022-06-29 05:31:12 --> Total execution time: 0.0345
DEBUG - 2022-06-29 05:31:36 --> Total execution time: 0.0475
DEBUG - 2022-06-29 05:31:52 --> Total execution time: 0.0437
DEBUG - 2022-06-29 05:37:52 --> Total execution time: 0.0449
DEBUG - 2022-06-29 05:52:02 --> Total execution time: 0.1171
DEBUG - 2022-06-29 05:52:15 --> Total execution time: 0.0385
DEBUG - 2022-06-29 05:56:20 --> Total execution time: 0.0797
DEBUG - 2022-06-29 05:56:20 --> Total execution time: 0.0323
DEBUG - 2022-06-29 06:02:05 --> Total execution time: 0.0562
DEBUG - 2022-06-29 06:03:38 --> Total execution time: 0.0933
DEBUG - 2022-06-29 06:03:59 --> Total execution time: 0.0770
DEBUG - 2022-06-29 06:04:04 --> Total execution time: 0.0676
DEBUG - 2022-06-29 06:09:36 --> Total execution time: 0.1034
DEBUG - 2022-06-29 06:11:35 --> Total execution time: 0.0484
DEBUG - 2022-06-29 06:27:35 --> Total execution time: 0.1608
DEBUG - 2022-06-29 06:27:35 --> Total execution time: 0.0359
DEBUG - 2022-06-29 06:30:02 --> Total execution time: 0.0612
DEBUG - 2022-06-29 06:30:36 --> Total execution time: 0.0511
DEBUG - 2022-06-29 06:30:41 --> Total execution time: 0.0437
DEBUG - 2022-06-29 06:30:42 --> Total execution time: 0.0469
DEBUG - 2022-06-29 06:30:46 --> Total execution time: 0.0508
DEBUG - 2022-06-29 06:30:54 --> Total execution time: 0.0853
DEBUG - 2022-06-29 06:31:07 --> Total execution time: 0.1207
DEBUG - 2022-06-29 06:31:15 --> Total execution time: 0.0702
DEBUG - 2022-06-29 06:31:22 --> Total execution time: 0.0508
DEBUG - 2022-06-29 06:31:26 --> Total execution time: 0.0786
DEBUG - 2022-06-29 06:31:30 --> Total execution time: 0.0809
DEBUG - 2022-06-29 06:33:01 --> Total execution time: 0.0853
DEBUG - 2022-06-29 06:33:06 --> Total execution time: 0.0927
DEBUG - 2022-06-29 06:34:38 --> Total execution time: 0.1241
DEBUG - 2022-06-29 06:34:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 06:35:00 --> Total execution time: 0.0751
DEBUG - 2022-06-29 06:35:19 --> Total execution time: 0.0812
DEBUG - 2022-06-29 06:35:40 --> Total execution time: 0.1333
DEBUG - 2022-06-29 06:36:33 --> Total execution time: 0.0723
DEBUG - 2022-06-29 06:36:38 --> Total execution time: 0.1098
DEBUG - 2022-06-29 06:37:06 --> Total execution time: 0.0489
DEBUG - 2022-06-29 06:37:09 --> Total execution time: 0.0481
DEBUG - 2022-06-29 06:38:03 --> Total execution time: 0.0544
DEBUG - 2022-06-29 06:41:57 --> Total execution time: 0.0950
DEBUG - 2022-06-29 06:44:41 --> Total execution time: 0.1088
DEBUG - 2022-06-29 06:47:32 --> Total execution time: 0.0461
DEBUG - 2022-06-29 06:47:53 --> Total execution time: 0.0526
DEBUG - 2022-06-29 06:48:01 --> Total execution time: 0.0647
DEBUG - 2022-06-29 06:48:07 --> Total execution time: 0.0565
DEBUG - 2022-06-29 06:53:06 --> Total execution time: 0.0884
DEBUG - 2022-06-29 06:53:14 --> Total execution time: 0.0471
DEBUG - 2022-06-29 06:53:37 --> Total execution time: 0.0475
DEBUG - 2022-06-29 06:55:11 --> Total execution time: 0.0453
DEBUG - 2022-06-29 06:55:13 --> Total execution time: 0.0441
DEBUG - 2022-06-29 06:55:24 --> Total execution time: 0.0590
DEBUG - 2022-06-29 06:56:18 --> Total execution time: 0.0673
DEBUG - 2022-06-29 06:56:34 --> Total execution time: 0.0506
DEBUG - 2022-06-29 06:56:43 --> Total execution time: 0.0518
DEBUG - 2022-06-29 06:57:12 --> Total execution time: 0.0747
DEBUG - 2022-06-29 06:57:34 --> Total execution time: 0.0598
DEBUG - 2022-06-29 06:58:10 --> Total execution time: 0.0323
DEBUG - 2022-06-29 06:58:12 --> Total execution time: 0.0444
DEBUG - 2022-06-29 06:59:36 --> Total execution time: 0.0477
DEBUG - 2022-06-29 07:00:23 --> Total execution time: 0.1239
DEBUG - 2022-06-29 07:00:38 --> Total execution time: 0.0510
DEBUG - 2022-06-29 07:00:49 --> Total execution time: 0.0471
DEBUG - 2022-06-29 07:00:54 --> Total execution time: 0.0449
DEBUG - 2022-06-29 07:01:00 --> Total execution time: 0.0470
DEBUG - 2022-06-29 07:01:08 --> Total execution time: 0.0852
DEBUG - 2022-06-29 07:02:15 --> Total execution time: 0.1236
DEBUG - 2022-06-29 07:02:20 --> Total execution time: 0.0435
DEBUG - 2022-06-29 07:02:21 --> Total execution time: 0.0512
DEBUG - 2022-06-29 07:02:24 --> Total execution time: 0.0530
DEBUG - 2022-06-29 07:02:27 --> Total execution time: 0.0618
DEBUG - 2022-06-29 07:02:36 --> Total execution time: 0.0694
DEBUG - 2022-06-29 07:02:40 --> Total execution time: 0.0689
DEBUG - 2022-06-29 07:02:49 --> Total execution time: 0.0491
DEBUG - 2022-06-29 07:02:52 --> Total execution time: 0.0503
DEBUG - 2022-06-29 07:02:57 --> Total execution time: 0.0472
DEBUG - 2022-06-29 07:03:02 --> Total execution time: 0.0843
DEBUG - 2022-06-29 07:03:09 --> Total execution time: 0.1292
DEBUG - 2022-06-29 07:03:10 --> Total execution time: 0.0517
DEBUG - 2022-06-29 07:03:11 --> Total execution time: 0.0572
DEBUG - 2022-06-29 07:03:20 --> Total execution time: 0.0504
DEBUG - 2022-06-29 07:03:38 --> Total execution time: 0.0483
DEBUG - 2022-06-29 07:03:39 --> Total execution time: 0.0459
DEBUG - 2022-06-29 07:03:44 --> Total execution time: 0.0862
DEBUG - 2022-06-29 07:11:14 --> Total execution time: 0.1362
DEBUG - 2022-06-29 07:11:19 --> Total execution time: 0.1197
DEBUG - 2022-06-29 07:16:05 --> Total execution time: 0.1182
DEBUG - 2022-06-29 07:16:14 --> Total execution time: 0.0706
DEBUG - 2022-06-29 07:16:19 --> Total execution time: 0.1171
DEBUG - 2022-06-29 07:16:27 --> Total execution time: 0.0513
DEBUG - 2022-06-29 07:16:27 --> Total execution time: 0.0735
DEBUG - 2022-06-29 07:16:38 --> Total execution time: 0.0761
DEBUG - 2022-06-29 07:16:44 --> Total execution time: 0.0711
DEBUG - 2022-06-29 07:16:45 --> Total execution time: 0.0557
DEBUG - 2022-06-29 07:16:47 --> Total execution time: 0.0678
DEBUG - 2022-06-29 07:16:50 --> Total execution time: 0.0671
DEBUG - 2022-06-29 07:16:53 --> Total execution time: 0.1210
DEBUG - 2022-06-29 07:16:53 --> Total execution time: 0.0555
DEBUG - 2022-06-29 07:16:55 --> Total execution time: 0.0477
DEBUG - 2022-06-29 07:16:56 --> Total execution time: 0.0498
DEBUG - 2022-06-29 07:20:25 --> Total execution time: 0.1000
DEBUG - 2022-06-29 07:26:19 --> Total execution time: 0.1083
DEBUG - 2022-06-29 07:26:22 --> Total execution time: 0.0439
DEBUG - 2022-06-29 07:26:36 --> Total execution time: 0.0649
DEBUG - 2022-06-29 07:26:40 --> Total execution time: 0.0739
DEBUG - 2022-06-29 07:29:40 --> Total execution time: 0.1872
DEBUG - 2022-06-29 07:29:45 --> Total execution time: 0.0842
DEBUG - 2022-06-29 07:29:49 --> Total execution time: 0.0515
DEBUG - 2022-06-29 07:29:58 --> Total execution time: 0.0557
DEBUG - 2022-06-29 07:29:59 --> Total execution time: 0.0658
DEBUG - 2022-06-29 07:30:02 --> Total execution time: 0.1132
DEBUG - 2022-06-29 07:30:03 --> Total execution time: 0.1044
DEBUG - 2022-06-29 07:30:05 --> Total execution time: 0.2258
DEBUG - 2022-06-29 07:30:05 --> Total execution time: 0.1215
DEBUG - 2022-06-29 07:30:05 --> Total execution time: 0.1580
DEBUG - 2022-06-29 07:30:30 --> Total execution time: 0.0547
DEBUG - 2022-06-29 07:31:03 --> Total execution time: 0.0657
DEBUG - 2022-06-29 07:32:39 --> Total execution time: 0.0449
DEBUG - 2022-06-29 07:34:34 --> Total execution time: 0.0326
DEBUG - 2022-06-29 07:34:56 --> Total execution time: 0.0504
DEBUG - 2022-06-29 07:36:12 --> Total execution time: 0.0508
DEBUG - 2022-06-29 07:36:35 --> Total execution time: 0.0336
DEBUG - 2022-06-29 07:36:46 --> Total execution time: 0.0427
DEBUG - 2022-06-29 07:36:56 --> Total execution time: 0.0456
DEBUG - 2022-06-29 07:37:19 --> Total execution time: 0.0490
DEBUG - 2022-06-29 07:37:38 --> Total execution time: 0.0679
DEBUG - 2022-06-29 07:38:04 --> Total execution time: 0.0559
DEBUG - 2022-06-29 07:38:12 --> Total execution time: 0.0688
DEBUG - 2022-06-29 07:38:24 --> Total execution time: 0.1143
DEBUG - 2022-06-29 07:41:44 --> Total execution time: 0.0853
DEBUG - 2022-06-29 07:41:57 --> Total execution time: 0.0344
DEBUG - 2022-06-29 07:42:06 --> Total execution time: 0.0337
DEBUG - 2022-06-29 07:42:13 --> Total execution time: 0.0303
DEBUG - 2022-06-29 07:42:31 --> Total execution time: 0.0602
DEBUG - 2022-06-29 07:42:42 --> Total execution time: 0.0618
DEBUG - 2022-06-29 07:42:51 --> Total execution time: 0.0537
DEBUG - 2022-06-29 07:43:04 --> Total execution time: 0.0719
DEBUG - 2022-06-29 07:45:32 --> Total execution time: 0.1718
DEBUG - 2022-06-29 07:46:25 --> Total execution time: 0.0440
DEBUG - 2022-06-29 07:50:44 --> Total execution time: 0.1694
DEBUG - 2022-06-29 07:50:47 --> Total execution time: 0.0494
DEBUG - 2022-06-29 07:50:54 --> Total execution time: 0.0664
DEBUG - 2022-06-29 07:51:05 --> Total execution time: 0.1492
DEBUG - 2022-06-29 07:51:43 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 07:51:43 --> Total execution time: 0.0784
DEBUG - 2022-06-29 07:52:31 --> Total execution time: 0.0746
DEBUG - 2022-06-29 07:52:35 --> Total execution time: 0.0803
DEBUG - 2022-06-29 07:52:38 --> Total execution time: 0.0537
DEBUG - 2022-06-29 07:54:55 --> Total execution time: 0.0899
DEBUG - 2022-06-29 07:54:56 --> Total execution time: 0.0470
DEBUG - 2022-06-29 07:55:53 --> Total execution time: 0.0499
DEBUG - 2022-06-29 07:59:45 --> Total execution time: 0.0976
DEBUG - 2022-06-29 07:59:59 --> Total execution time: 0.0364
DEBUG - 2022-06-29 08:00:43 --> Total execution time: 0.0612
DEBUG - 2022-06-29 08:01:38 --> Total execution time: 2.0881
DEBUG - 2022-06-29 08:04:31 --> Total execution time: 0.0485
DEBUG - 2022-06-29 08:04:46 --> Total execution time: 0.0393
DEBUG - 2022-06-29 08:04:55 --> Total execution time: 0.0468
DEBUG - 2022-06-29 08:05:00 --> Total execution time: 0.0478
DEBUG - 2022-06-29 08:05:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 08:05:01 --> Total execution time: 0.0487
DEBUG - 2022-06-29 08:06:35 --> Total execution time: 0.0447
DEBUG - 2022-06-29 08:07:42 --> Total execution time: 0.0456
DEBUG - 2022-06-29 08:07:47 --> Total execution time: 0.0438
DEBUG - 2022-06-29 08:08:00 --> Total execution time: 0.0622
DEBUG - 2022-06-29 08:08:12 --> Total execution time: 0.0566
DEBUG - 2022-06-29 08:08:19 --> Total execution time: 0.0464
DEBUG - 2022-06-29 08:08:23 --> Total execution time: 0.0478
DEBUG - 2022-06-29 08:08:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 08:08:24 --> Total execution time: 0.0624
DEBUG - 2022-06-29 08:10:01 --> Total execution time: 0.1670
DEBUG - 2022-06-29 08:10:07 --> Total execution time: 0.0478
DEBUG - 2022-06-29 08:10:43 --> Total execution time: 0.0397
DEBUG - 2022-06-29 08:10:55 --> Total execution time: 0.0486
DEBUG - 2022-06-29 08:10:58 --> Total execution time: 0.0631
DEBUG - 2022-06-29 08:11:03 --> Total execution time: 0.0490
DEBUG - 2022-06-29 08:11:16 --> Total execution time: 0.0455
DEBUG - 2022-06-29 08:11:41 --> Total execution time: 0.0380
DEBUG - 2022-06-29 08:12:04 --> Total execution time: 0.0538
DEBUG - 2022-06-29 08:12:19 --> Total execution time: 0.0786
DEBUG - 2022-06-29 08:12:28 --> Total execution time: 0.0582
DEBUG - 2022-06-29 08:12:36 --> Total execution time: 0.0568
DEBUG - 2022-06-29 08:12:40 --> Total execution time: 0.1242
DEBUG - 2022-06-29 08:13:11 --> Total execution time: 0.0573
DEBUG - 2022-06-29 08:13:15 --> Total execution time: 0.0663
DEBUG - 2022-06-29 08:13:21 --> Total execution time: 0.0649
DEBUG - 2022-06-29 08:13:26 --> Total execution time: 0.0520
DEBUG - 2022-06-29 08:13:29 --> Total execution time: 0.0443
DEBUG - 2022-06-29 08:14:37 --> Total execution time: 0.0482
DEBUG - 2022-06-29 08:15:01 --> Total execution time: 0.0902
DEBUG - 2022-06-29 08:15:08 --> Total execution time: 0.0483
DEBUG - 2022-06-29 08:15:08 --> Total execution time: 0.0451
DEBUG - 2022-06-29 08:15:16 --> Total execution time: 0.0557
DEBUG - 2022-06-29 08:15:26 --> Total execution time: 0.0483
DEBUG - 2022-06-29 08:15:30 --> Total execution time: 0.0489
DEBUG - 2022-06-29 08:16:32 --> Total execution time: 0.0450
DEBUG - 2022-06-29 08:16:37 --> Total execution time: 0.0392
DEBUG - 2022-06-29 08:16:55 --> Total execution time: 0.0577
DEBUG - 2022-06-29 08:16:57 --> Total execution time: 0.0450
DEBUG - 2022-06-29 08:17:25 --> Total execution time: 0.0451
DEBUG - 2022-06-29 08:17:46 --> Total execution time: 0.0436
DEBUG - 2022-06-29 08:18:08 --> Total execution time: 0.0446
DEBUG - 2022-06-29 08:18:10 --> Total execution time: 0.0338
DEBUG - 2022-06-29 08:18:17 --> Total execution time: 0.0464
DEBUG - 2022-06-29 08:18:31 --> Total execution time: 0.0546
DEBUG - 2022-06-29 08:18:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 08:18:32 --> Total execution time: 0.0596
DEBUG - 2022-06-29 08:18:33 --> Total execution time: 0.0593
DEBUG - 2022-06-29 08:18:35 --> Total execution time: 0.0530
DEBUG - 2022-06-29 08:18:37 --> Total execution time: 0.0485
DEBUG - 2022-06-29 08:19:36 --> Total execution time: 0.0522
DEBUG - 2022-06-29 08:21:46 --> Total execution time: 0.2164
DEBUG - 2022-06-29 08:21:47 --> Total execution time: 0.0578
DEBUG - 2022-06-29 08:22:00 --> Total execution time: 0.0488
DEBUG - 2022-06-29 08:22:17 --> Total execution time: 0.0443
DEBUG - 2022-06-29 08:22:41 --> Total execution time: 0.0462
DEBUG - 2022-06-29 08:24:26 --> Total execution time: 0.1133
DEBUG - 2022-06-29 08:24:37 --> Total execution time: 0.0566
DEBUG - 2022-06-29 08:25:23 --> Total execution time: 0.0466
DEBUG - 2022-06-29 08:25:35 --> Total execution time: 0.1332
DEBUG - 2022-06-29 08:25:39 --> Total execution time: 0.0517
DEBUG - 2022-06-29 08:25:44 --> Total execution time: 0.0838
DEBUG - 2022-06-29 08:26:03 --> Total execution time: 0.0355
DEBUG - 2022-06-29 08:30:02 --> Total execution time: 0.1567
DEBUG - 2022-06-29 08:31:00 --> Total execution time: 0.0543
DEBUG - 2022-06-29 08:33:28 --> Total execution time: 0.1742
DEBUG - 2022-06-29 08:35:06 --> Total execution time: 0.1122
DEBUG - 2022-06-29 08:35:21 --> Total execution time: 0.0457
DEBUG - 2022-06-29 08:35:42 --> Total execution time: 0.0472
DEBUG - 2022-06-29 08:36:00 --> Total execution time: 0.1245
DEBUG - 2022-06-29 08:36:08 --> Total execution time: 0.0609
DEBUG - 2022-06-29 08:36:23 --> Total execution time: 0.0538
DEBUG - 2022-06-29 08:36:27 --> Total execution time: 0.0553
DEBUG - 2022-06-29 08:36:43 --> Total execution time: 0.0455
DEBUG - 2022-06-29 08:37:32 --> Total execution time: 0.0379
DEBUG - 2022-06-29 08:39:19 --> Total execution time: 0.0486
DEBUG - 2022-06-29 08:39:50 --> Total execution time: 0.1163
DEBUG - 2022-06-29 08:40:05 --> Total execution time: 0.0475
DEBUG - 2022-06-29 08:40:26 --> Total execution time: 0.0457
DEBUG - 2022-06-29 08:41:12 --> Total execution time: 0.0483
DEBUG - 2022-06-29 08:41:13 --> Total execution time: 0.0441
DEBUG - 2022-06-29 08:41:32 --> Total execution time: 0.0458
DEBUG - 2022-06-29 08:41:32 --> Total execution time: 0.0428
DEBUG - 2022-06-29 08:42:36 --> Total execution time: 0.1339
DEBUG - 2022-06-29 08:46:21 --> Total execution time: 0.1074
DEBUG - 2022-06-29 08:47:05 --> Total execution time: 0.1222
DEBUG - 2022-06-29 08:47:07 --> Total execution time: 0.0577
DEBUG - 2022-06-29 08:47:19 --> Total execution time: 0.0444
DEBUG - 2022-06-29 08:49:44 --> Total execution time: 0.1126
DEBUG - 2022-06-29 08:53:10 --> Total execution time: 0.1650
DEBUG - 2022-06-29 08:53:15 --> Total execution time: 0.0521
DEBUG - 2022-06-29 08:53:18 --> Total execution time: 0.0515
DEBUG - 2022-06-29 08:53:32 --> Total execution time: 0.0552
DEBUG - 2022-06-29 08:53:33 --> Total execution time: 0.0468
DEBUG - 2022-06-29 08:53:36 --> Total execution time: 0.0644
DEBUG - 2022-06-29 08:53:52 --> Total execution time: 0.0581
DEBUG - 2022-06-29 08:53:53 --> Total execution time: 0.0494
DEBUG - 2022-06-29 08:53:59 --> Total execution time: 0.0496
DEBUG - 2022-06-29 08:54:02 --> Total execution time: 0.0588
DEBUG - 2022-06-29 08:54:12 --> Total execution time: 0.0491
DEBUG - 2022-06-29 09:00:25 --> Total execution time: 0.1151
DEBUG - 2022-06-29 09:00:26 --> Total execution time: 0.0418
DEBUG - 2022-06-29 09:03:53 --> Total execution time: 0.1818
DEBUG - 2022-06-29 09:04:01 --> Total execution time: 0.0935
DEBUG - 2022-06-29 09:04:11 --> Total execution time: 0.0656
DEBUG - 2022-06-29 09:04:19 --> Total execution time: 0.0742
DEBUG - 2022-06-29 09:07:26 --> Total execution time: 0.0483
DEBUG - 2022-06-29 09:07:41 --> Total execution time: 0.0461
DEBUG - 2022-06-29 09:07:48 --> Total execution time: 0.0541
DEBUG - 2022-06-29 09:07:53 --> Total execution time: 0.0812
DEBUG - 2022-06-29 09:08:01 --> Total execution time: 0.0643
DEBUG - 2022-06-29 09:09:20 --> Total execution time: 0.0478
DEBUG - 2022-06-29 09:09:23 --> Total execution time: 0.0342
DEBUG - 2022-06-29 09:09:34 --> Total execution time: 0.0556
DEBUG - 2022-06-29 09:09:46 --> Total execution time: 1.9655
DEBUG - 2022-06-29 09:10:48 --> Total execution time: 1.5060
DEBUG - 2022-06-29 09:11:32 --> Total execution time: 1.4602
DEBUG - 2022-06-29 09:12:10 --> Total execution time: 1.5044
DEBUG - 2022-06-29 09:12:12 --> Total execution time: 2.2670
DEBUG - 2022-06-29 09:12:12 --> Total execution time: 1.4353
DEBUG - 2022-06-29 09:12:29 --> Total execution time: 0.1224
DEBUG - 2022-06-29 09:12:29 --> Total execution time: 0.0710
DEBUG - 2022-06-29 09:12:59 --> Total execution time: 1.6218
DEBUG - 2022-06-29 09:13:38 --> Total execution time: 0.0533
DEBUG - 2022-06-29 09:14:12 --> Total execution time: 0.0638
DEBUG - 2022-06-29 09:15:46 --> Total execution time: 0.0528
DEBUG - 2022-06-29 09:15:47 --> Total execution time: 0.0508
DEBUG - 2022-06-29 09:15:58 --> Total execution time: 1.4846
DEBUG - 2022-06-29 09:17:31 --> Total execution time: 0.0351
DEBUG - 2022-06-29 09:19:42 --> Total execution time: 0.0477
DEBUG - 2022-06-29 09:22:53 --> Total execution time: 0.0323
DEBUG - 2022-06-29 09:22:58 --> Total execution time: 0.0508
DEBUG - 2022-06-29 09:23:02 --> Total execution time: 0.0309
DEBUG - 2022-06-29 09:23:08 --> Total execution time: 0.0341
DEBUG - 2022-06-29 09:23:56 --> Total execution time: 0.0548
DEBUG - 2022-06-29 09:23:59 --> Total execution time: 0.1258
DEBUG - 2022-06-29 09:25:32 --> Total execution time: 0.0640
DEBUG - 2022-06-29 09:25:42 --> Total execution time: 0.0606
DEBUG - 2022-06-29 09:26:18 --> Total execution time: 0.0663
DEBUG - 2022-06-29 09:26:24 --> Total execution time: 0.0480
DEBUG - 2022-06-29 09:27:27 --> Total execution time: 0.1389
DEBUG - 2022-06-29 09:27:28 --> Total execution time: 0.0823
DEBUG - 2022-06-29 09:27:46 --> Total execution time: 0.0685
DEBUG - 2022-06-29 09:28:11 --> Total execution time: 0.0615
DEBUG - 2022-06-29 09:28:17 --> Total execution time: 0.0808
DEBUG - 2022-06-29 09:28:17 --> Total execution time: 0.0702
DEBUG - 2022-06-29 09:28:21 --> Total execution time: 0.0508
DEBUG - 2022-06-29 09:28:24 --> Total execution time: 0.0504
DEBUG - 2022-06-29 09:28:38 --> Total execution time: 0.0442
DEBUG - 2022-06-29 09:28:55 --> Total execution time: 0.0447
DEBUG - 2022-06-29 09:29:50 --> Total execution time: 0.0479
DEBUG - 2022-06-29 09:30:02 --> Total execution time: 0.1262
DEBUG - 2022-06-29 09:30:42 --> Total execution time: 0.0622
DEBUG - 2022-06-29 09:34:31 --> Total execution time: 0.1348
DEBUG - 2022-06-29 09:34:39 --> Total execution time: 0.0322
DEBUG - 2022-06-29 09:34:47 --> Total execution time: 0.0521
DEBUG - 2022-06-29 09:34:53 --> Total execution time: 0.0585
DEBUG - 2022-06-29 09:35:10 --> Total execution time: 0.0379
DEBUG - 2022-06-29 09:35:37 --> Total execution time: 0.1153
DEBUG - 2022-06-29 09:35:39 --> Total execution time: 0.0445
DEBUG - 2022-06-29 09:35:43 --> Total execution time: 0.0546
DEBUG - 2022-06-29 09:36:08 --> Total execution time: 0.0585
DEBUG - 2022-06-29 09:36:11 --> Total execution time: 0.0423
DEBUG - 2022-06-29 09:36:18 --> Total execution time: 0.0468
DEBUG - 2022-06-29 09:36:26 --> Total execution time: 0.0402
DEBUG - 2022-06-29 09:36:26 --> Total execution time: 0.0483
DEBUG - 2022-06-29 09:36:38 --> Total execution time: 0.0532
DEBUG - 2022-06-29 09:36:54 --> Total execution time: 0.0524
DEBUG - 2022-06-29 09:36:58 --> Total execution time: 0.0536
DEBUG - 2022-06-29 09:37:00 --> Total execution time: 0.0460
DEBUG - 2022-06-29 09:37:03 --> Total execution time: 0.0412
DEBUG - 2022-06-29 09:37:06 --> Total execution time: 0.0454
DEBUG - 2022-06-29 09:37:09 --> Total execution time: 0.0442
DEBUG - 2022-06-29 09:37:18 --> Total execution time: 0.0718
DEBUG - 2022-06-29 09:37:21 --> Total execution time: 0.0542
DEBUG - 2022-06-29 09:37:23 --> Total execution time: 0.0556
DEBUG - 2022-06-29 09:37:29 --> Total execution time: 0.0257
DEBUG - 2022-06-29 09:37:32 --> Total execution time: 0.0444
DEBUG - 2022-06-29 09:37:36 --> Total execution time: 0.0415
DEBUG - 2022-06-29 09:37:46 --> Total execution time: 0.0562
DEBUG - 2022-06-29 09:37:48 --> Total execution time: 0.0411
DEBUG - 2022-06-29 09:37:53 --> Total execution time: 0.0421
DEBUG - 2022-06-29 09:38:07 --> Total execution time: 0.0933
DEBUG - 2022-06-29 09:38:31 --> Total execution time: 0.0661
DEBUG - 2022-06-29 09:39:15 --> Total execution time: 0.0539
DEBUG - 2022-06-29 09:39:34 --> Total execution time: 0.0453
DEBUG - 2022-06-29 09:39:44 --> Total execution time: 0.0518
DEBUG - 2022-06-29 09:39:44 --> Total execution time: 0.0859
DEBUG - 2022-06-29 09:39:54 --> Total execution time: 0.0382
DEBUG - 2022-06-29 09:39:59 --> Total execution time: 0.0583
DEBUG - 2022-06-29 09:40:01 --> Total execution time: 0.0767
DEBUG - 2022-06-29 09:40:04 --> Total execution time: 0.0520
DEBUG - 2022-06-29 09:40:07 --> Total execution time: 0.0818
DEBUG - 2022-06-29 09:40:20 --> Total execution time: 0.0495
DEBUG - 2022-06-29 09:47:28 --> Total execution time: 0.1002
DEBUG - 2022-06-29 09:47:28 --> Total execution time: 0.0497
DEBUG - 2022-06-29 09:47:34 --> Total execution time: 0.1366
DEBUG - 2022-06-29 09:47:37 --> Total execution time: 0.0562
DEBUG - 2022-06-29 09:47:41 --> Total execution time: 0.0454
DEBUG - 2022-06-29 09:47:45 --> Total execution time: 0.0501
DEBUG - 2022-06-29 09:48:05 --> Total execution time: 0.0528
DEBUG - 2022-06-29 09:48:31 --> Total execution time: 0.0522
DEBUG - 2022-06-29 09:48:41 --> Total execution time: 0.0500
DEBUG - 2022-06-29 09:48:49 --> Total execution time: 0.0678
DEBUG - 2022-06-29 09:48:52 --> Total execution time: 0.0535
DEBUG - 2022-06-29 09:49:01 --> Total execution time: 0.0799
DEBUG - 2022-06-29 09:49:11 --> Total execution time: 0.0709
DEBUG - 2022-06-29 09:49:15 --> Total execution time: 0.0490
DEBUG - 2022-06-29 09:49:20 --> Total execution time: 0.0450
DEBUG - 2022-06-29 09:50:32 --> Total execution time: 0.0387
DEBUG - 2022-06-29 09:50:32 --> Total execution time: 0.0494
DEBUG - 2022-06-29 09:50:38 --> Total execution time: 0.0528
DEBUG - 2022-06-29 09:50:42 --> Total execution time: 0.0551
DEBUG - 2022-06-29 09:50:45 --> Total execution time: 0.0600
DEBUG - 2022-06-29 09:50:49 --> Total execution time: 0.0619
DEBUG - 2022-06-29 09:50:55 --> Total execution time: 0.0443
DEBUG - 2022-06-29 09:50:58 --> Total execution time: 0.0543
DEBUG - 2022-06-29 09:53:13 --> Total execution time: 0.1036
DEBUG - 2022-06-29 09:53:16 --> Total execution time: 0.0593
DEBUG - 2022-06-29 10:02:55 --> Total execution time: 0.2005
DEBUG - 2022-06-29 10:03:25 --> Total execution time: 0.1287
DEBUG - 2022-06-29 10:04:03 --> Total execution time: 0.0419
DEBUG - 2022-06-29 10:04:15 --> Total execution time: 0.0601
DEBUG - 2022-06-29 10:04:15 --> Total execution time: 0.0558
DEBUG - 2022-06-29 10:04:16 --> Total execution time: 0.0467
DEBUG - 2022-06-29 10:04:28 --> Total execution time: 0.0517
DEBUG - 2022-06-29 10:04:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 10:04:29 --> Total execution time: 0.0446
DEBUG - 2022-06-29 10:04:55 --> Total execution time: 0.0965
DEBUG - 2022-06-29 10:04:57 --> Total execution time: 0.1390
DEBUG - 2022-06-29 10:04:58 --> Total execution time: 0.1208
DEBUG - 2022-06-29 10:05:02 --> Total execution time: 0.1004
DEBUG - 2022-06-29 10:05:07 --> Total execution time: 0.0764
DEBUG - 2022-06-29 10:06:20 --> Total execution time: 0.0519
DEBUG - 2022-06-29 10:07:09 --> Total execution time: 0.0580
DEBUG - 2022-06-29 10:07:27 --> Total execution time: 0.0553
DEBUG - 2022-06-29 10:08:02 --> Total execution time: 0.0546
DEBUG - 2022-06-29 10:10:22 --> Total execution time: 0.0779
DEBUG - 2022-06-29 10:10:26 --> Total execution time: 0.0641
DEBUG - 2022-06-29 10:10:29 --> Total execution time: 0.0781
DEBUG - 2022-06-29 10:10:49 --> Total execution time: 0.0551
DEBUG - 2022-06-29 10:14:53 --> Total execution time: 0.1352
DEBUG - 2022-06-29 10:14:56 --> Total execution time: 0.0492
DEBUG - 2022-06-29 10:15:20 --> Total execution time: 0.0499
DEBUG - 2022-06-29 10:15:24 --> Total execution time: 0.0527
DEBUG - 2022-06-29 10:15:43 --> Total execution time: 0.0526
DEBUG - 2022-06-29 10:15:59 --> Total execution time: 0.0514
DEBUG - 2022-06-29 10:16:04 --> Total execution time: 0.0445
DEBUG - 2022-06-29 10:19:41 --> Total execution time: 0.0429
DEBUG - 2022-06-29 10:24:46 --> Total execution time: 0.1931
DEBUG - 2022-06-29 10:24:51 --> Total execution time: 0.0729
DEBUG - 2022-06-29 10:24:59 --> Total execution time: 0.0538
DEBUG - 2022-06-29 10:25:02 --> Total execution time: 0.0554
DEBUG - 2022-06-29 10:25:05 --> Total execution time: 0.0892
DEBUG - 2022-06-29 10:25:13 --> Total execution time: 0.0560
DEBUG - 2022-06-29 10:25:15 --> Total execution time: 0.0611
DEBUG - 2022-06-29 10:25:19 --> Total execution time: 0.1380
DEBUG - 2022-06-29 10:28:59 --> Total execution time: 0.1087
DEBUG - 2022-06-29 10:29:50 --> Total execution time: 0.1688
DEBUG - 2022-06-29 10:29:54 --> Total execution time: 0.0503
DEBUG - 2022-06-29 10:29:59 --> Total execution time: 0.1111
DEBUG - 2022-06-29 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:30:02 --> Total execution time: 0.0575
DEBUG - 2022-06-29 00:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:00:15 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:30:15 --> Total execution time: 0.0395
DEBUG - 2022-06-29 00:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:03:34 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:33:34 --> Total execution time: 0.1683
DEBUG - 2022-06-29 10:33:34 --> Total execution time: 0.1268
DEBUG - 2022-06-29 00:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:33:41 --> Total execution time: 0.0519
DEBUG - 2022-06-29 00:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:33:49 --> Total execution time: 0.0696
DEBUG - 2022-06-29 00:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:33:52 --> Total execution time: 0.0587
DEBUG - 2022-06-29 00:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:34:00 --> Total execution time: 0.0637
DEBUG - 2022-06-29 00:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:34:05 --> Total execution time: 0.0503
DEBUG - 2022-06-29 00:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 00:04:31 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-29 00:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:04:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 00:04:37 --> 404 Page Not Found: Category/technology
DEBUG - 2022-06-29 00:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:05:27 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:35:27 --> Total execution time: 0.0473
DEBUG - 2022-06-29 00:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:06:01 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:36:01 --> Total execution time: 0.0524
DEBUG - 2022-06-29 00:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:06:10 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:36:10 --> Total execution time: 0.0365
DEBUG - 2022-06-29 00:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:06:13 --> Total execution time: 0.0400
DEBUG - 2022-06-29 00:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:06:15 --> Total execution time: 0.0705
DEBUG - 2022-06-29 00:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:06:15 --> Total execution time: 0.1225
DEBUG - 2022-06-29 00:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:36:54 --> Total execution time: 0.0685
DEBUG - 2022-06-29 00:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:07:04 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:37:04 --> Total execution time: 0.0516
DEBUG - 2022-06-29 00:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:10:06 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:40:06 --> Total execution time: 0.1270
DEBUG - 2022-06-29 00:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:10:12 --> Total execution time: 0.0443
DEBUG - 2022-06-29 00:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:10:13 --> Total execution time: 0.0501
DEBUG - 2022-06-29 00:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:10:13 --> Total execution time: 0.1271
DEBUG - 2022-06-29 00:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:11:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 00:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:41:39 --> Total execution time: 2.0488
DEBUG - 2022-06-29 00:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:11:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 00:11:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 00:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:12:23 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:42:23 --> Total execution time: 0.0581
DEBUG - 2022-06-29 00:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:42:44 --> Total execution time: 0.1199
DEBUG - 2022-06-29 00:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:43:25 --> Total execution time: 0.1544
DEBUG - 2022-06-29 00:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:14:25 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:44:25 --> Total execution time: 0.0454
DEBUG - 2022-06-29 00:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:14:26 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:44:26 --> Total execution time: 0.0500
DEBUG - 2022-06-29 00:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:44:30 --> Total execution time: 0.0337
DEBUG - 2022-06-29 00:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:45:00 --> Total execution time: 0.0599
DEBUG - 2022-06-29 00:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:45:06 --> Total execution time: 0.0863
DEBUG - 2022-06-29 00:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:45:10 --> Total execution time: 0.0633
DEBUG - 2022-06-29 00:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:15:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 00:15:15 --> 404 Page Not Found: Membership-account/membership-checkout
DEBUG - 2022-06-29 00:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:15:26 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:45:26 --> Total execution time: 0.0616
DEBUG - 2022-06-29 00:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:45:48 --> Total execution time: 0.0834
DEBUG - 2022-06-29 00:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:45:52 --> Total execution time: 0.0633
DEBUG - 2022-06-29 00:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:45:54 --> Total execution time: 0.0564
DEBUG - 2022-06-29 00:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:47:00 --> Total execution time: 0.0466
DEBUG - 2022-06-29 00:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:49:23 --> Total execution time: 0.1543
DEBUG - 2022-06-29 00:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:49:40 --> Total execution time: 0.0495
DEBUG - 2022-06-29 00:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:49:44 --> Total execution time: 0.0459
DEBUG - 2022-06-29 00:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:50:13 --> Total execution time: 0.0572
DEBUG - 2022-06-29 00:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:51:16 --> Total execution time: 0.0494
DEBUG - 2022-06-29 00:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:51:19 --> Total execution time: 0.0677
DEBUG - 2022-06-29 00:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:51:23 --> Total execution time: 0.0543
DEBUG - 2022-06-29 00:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:51:29 --> Total execution time: 0.0538
DEBUG - 2022-06-29 00:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:51:41 --> Total execution time: 0.0562
DEBUG - 2022-06-29 00:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:51:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 00:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:51:42 --> Total execution time: 0.0455
DEBUG - 2022-06-29 00:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:52:12 --> Total execution time: 0.0437
DEBUG - 2022-06-29 00:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:52:16 --> Total execution time: 0.0460
DEBUG - 2022-06-29 00:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:52:23 --> Total execution time: 0.0510
DEBUG - 2022-06-29 00:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:52:28 --> Total execution time: 0.0439
DEBUG - 2022-06-29 00:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:52:31 --> Total execution time: 0.0481
DEBUG - 2022-06-29 00:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:52:33 --> Total execution time: 0.0816
DEBUG - 2022-06-29 00:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:52:38 --> Total execution time: 0.2786
DEBUG - 2022-06-29 00:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:52:42 --> Total execution time: 0.0690
DEBUG - 2022-06-29 00:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:52:43 --> Total execution time: 0.0490
DEBUG - 2022-06-29 00:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:52:44 --> Total execution time: 0.0649
DEBUG - 2022-06-29 00:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:23:57 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:53:57 --> Total execution time: 0.0632
DEBUG - 2022-06-29 00:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:54:07 --> Total execution time: 0.0539
DEBUG - 2022-06-29 00:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:54:28 --> Total execution time: 0.0489
DEBUG - 2022-06-29 00:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:54:36 --> Total execution time: 0.0799
DEBUG - 2022-06-29 00:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:55:04 --> Total execution time: 0.1160
DEBUG - 2022-06-29 00:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:55:27 --> Total execution time: 0.0475
DEBUG - 2022-06-29 00:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:56:01 --> Total execution time: 0.1415
DEBUG - 2022-06-29 00:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:56:08 --> Total execution time: 0.0509
DEBUG - 2022-06-29 00:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:56:12 --> Total execution time: 0.0461
DEBUG - 2022-06-29 00:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:56:22 --> Total execution time: 0.0568
DEBUG - 2022-06-29 00:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:56:24 --> Total execution time: 0.1245
DEBUG - 2022-06-29 00:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:56:34 --> Total execution time: 0.0781
DEBUG - 2022-06-29 00:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:26:38 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:56:38 --> Total execution time: 0.0350
DEBUG - 2022-06-29 00:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:56:47 --> Total execution time: 0.0493
DEBUG - 2022-06-29 00:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:56:49 --> Total execution time: 0.0710
DEBUG - 2022-06-29 00:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:56:55 --> Total execution time: 0.0449
DEBUG - 2022-06-29 00:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:56:59 --> Total execution time: 0.0491
DEBUG - 2022-06-29 00:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:57:06 --> Total execution time: 0.0542
DEBUG - 2022-06-29 00:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:57:09 --> Total execution time: 0.0676
DEBUG - 2022-06-29 00:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:57:20 --> Total execution time: 0.0884
DEBUG - 2022-06-29 00:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:57:22 --> Total execution time: 0.2265
DEBUG - 2022-06-29 00:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:57:24 --> Total execution time: 0.0715
DEBUG - 2022-06-29 00:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:57:33 --> Total execution time: 0.0484
DEBUG - 2022-06-29 10:57:33 --> Total execution time: 0.0766
DEBUG - 2022-06-29 00:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:57:36 --> Total execution time: 0.0577
DEBUG - 2022-06-29 00:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:57:37 --> Total execution time: 0.0508
DEBUG - 2022-06-29 00:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:57:38 --> Total execution time: 0.0740
DEBUG - 2022-06-29 00:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:27:50 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:57:50 --> Total execution time: 0.0512
DEBUG - 2022-06-29 00:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:27:59 --> Total execution time: 0.0499
DEBUG - 2022-06-29 00:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:28:00 --> Total execution time: 0.0484
DEBUG - 2022-06-29 00:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:28:00 --> Total execution time: 0.0728
DEBUG - 2022-06-29 00:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:30:11 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:00:11 --> Total execution time: 0.0447
DEBUG - 2022-06-29 00:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:30:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 00:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:00:29 --> Total execution time: 0.1434
DEBUG - 2022-06-29 11:00:30 --> Total execution time: 2.2068
DEBUG - 2022-06-29 00:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:30:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 00:30:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 00:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:01:07 --> Total execution time: 0.0313
DEBUG - 2022-06-29 00:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:31:09 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:01:09 --> Total execution time: 0.0498
DEBUG - 2022-06-29 00:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:01:13 --> Total execution time: 0.0425
DEBUG - 2022-06-29 00:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:01:21 --> Total execution time: 0.0614
DEBUG - 2022-06-29 00:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:01:26 --> Total execution time: 0.0516
DEBUG - 2022-06-29 00:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:01:44 --> Total execution time: 1.5339
DEBUG - 2022-06-29 00:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:01:45 --> Total execution time: 0.0579
DEBUG - 2022-06-29 00:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:01:52 --> Total execution time: 0.0498
DEBUG - 2022-06-29 00:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:02:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 00:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:02:16 --> Total execution time: 0.0532
DEBUG - 2022-06-29 00:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:02:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 11:02:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 11:02:17 --> Total execution time: 0.2221
DEBUG - 2022-06-29 00:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:02:19 --> Total execution time: 0.0481
DEBUG - 2022-06-29 00:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:32:28 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:02:28 --> Total execution time: 0.0453
DEBUG - 2022-06-29 00:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:02:30 --> Total execution time: 0.0699
DEBUG - 2022-06-29 00:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:02:34 --> Total execution time: 0.0644
DEBUG - 2022-06-29 00:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:02:38 --> Total execution time: 0.0454
DEBUG - 2022-06-29 00:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:02:59 --> Total execution time: 0.0483
DEBUG - 2022-06-29 00:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:03:02 --> Total execution time: 0.0612
DEBUG - 2022-06-29 00:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:03:12 --> Total execution time: 0.0555
DEBUG - 2022-06-29 00:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:03:16 --> Total execution time: 0.1029
DEBUG - 2022-06-29 00:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:03:22 --> Total execution time: 0.0589
DEBUG - 2022-06-29 00:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:26 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:03:26 --> Total execution time: 0.0331
DEBUG - 2022-06-29 00:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 00:33:31 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
DEBUG - 2022-06-29 00:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 00:33:33 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
DEBUG - 2022-06-29 00:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 00:33:34 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-06-29 00:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:03:34 --> Total execution time: 0.1001
DEBUG - 2022-06-29 00:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 00:33:36 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-06-29 00:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:03:41 --> Total execution time: 0.0523
DEBUG - 2022-06-29 00:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:03:42 --> Total execution time: 0.0656
DEBUG - 2022-06-29 00:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:03:43 --> Total execution time: 0.0427
DEBUG - 2022-06-29 00:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:03:44 --> Total execution time: 0.0924
DEBUG - 2022-06-29 00:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:34:37 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:04:37 --> Total execution time: 0.0542
DEBUG - 2022-06-29 00:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:35:02 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:05:02 --> Total execution time: 0.0436
DEBUG - 2022-06-29 00:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:06:28 --> Total execution time: 0.0439
DEBUG - 2022-06-29 00:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:36:46 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:06:46 --> Total execution time: 0.0531
DEBUG - 2022-06-29 00:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:06:50 --> Total execution time: 0.0352
DEBUG - 2022-06-29 00:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:36:58 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:06:58 --> Total execution time: 0.0489
DEBUG - 2022-06-29 00:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:07:16 --> Total execution time: 0.1239
DEBUG - 2022-06-29 00:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:07:30 --> Total execution time: 0.0737
DEBUG - 2022-06-29 00:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:07:35 --> Total execution time: 0.0645
DEBUG - 2022-06-29 00:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:07:39 --> Total execution time: 0.0565
DEBUG - 2022-06-29 00:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:07:52 --> Total execution time: 0.1429
DEBUG - 2022-06-29 00:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:08:00 --> Total execution time: 0.0535
DEBUG - 2022-06-29 00:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:08:10 --> Total execution time: 0.0685
DEBUG - 2022-06-29 00:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:08:12 --> Total execution time: 0.0625
DEBUG - 2022-06-29 00:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:08:15 --> Total execution time: 0.0645
DEBUG - 2022-06-29 00:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:08:38 --> Total execution time: 0.0450
DEBUG - 2022-06-29 00:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:39:12 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:09:12 --> Total execution time: 0.2863
DEBUG - 2022-06-29 00:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:09:12 --> Total execution time: 0.2552
DEBUG - 2022-06-29 00:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:39:38 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:09:38 --> Total execution time: 0.1140
DEBUG - 2022-06-29 00:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:09:48 --> Total execution time: 0.0511
DEBUG - 2022-06-29 00:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:09:55 --> Total execution time: 0.0790
DEBUG - 2022-06-29 00:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:10:02 --> Total execution time: 0.1074
DEBUG - 2022-06-29 00:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:10:15 --> Total execution time: 0.0323
DEBUG - 2022-06-29 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:11:33 --> Total execution time: 0.1110
DEBUG - 2022-06-29 00:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:11:36 --> Total execution time: 0.0564
DEBUG - 2022-06-29 00:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:11:39 --> Total execution time: 0.0576
DEBUG - 2022-06-29 00:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:11:41 --> Total execution time: 0.0550
DEBUG - 2022-06-29 00:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:11:42 --> Total execution time: 0.0467
DEBUG - 2022-06-29 00:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:11:59 --> Total execution time: 0.0648
DEBUG - 2022-06-29 00:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:12:03 --> Total execution time: 0.0527
DEBUG - 2022-06-29 00:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:12:06 --> Total execution time: 0.0842
DEBUG - 2022-06-29 00:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:12:08 --> Total execution time: 0.0431
DEBUG - 2022-06-29 00:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:12:11 --> Total execution time: 0.0698
DEBUG - 2022-06-29 00:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:42:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 00:42:46 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-29 00:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:45:17 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:15:17 --> Total execution time: 0.1991
DEBUG - 2022-06-29 00:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:15:22 --> Total execution time: 0.0959
DEBUG - 2022-06-29 00:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:15:36 --> Total execution time: 0.0770
DEBUG - 2022-06-29 00:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:15:45 --> Total execution time: 0.1167
DEBUG - 2022-06-29 00:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:15:50 --> Total execution time: 0.0818
DEBUG - 2022-06-29 00:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:15:56 --> Total execution time: 0.0774
DEBUG - 2022-06-29 00:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:16:02 --> Total execution time: 0.0561
DEBUG - 2022-06-29 00:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:16:06 --> Total execution time: 0.0539
DEBUG - 2022-06-29 00:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:16:10 --> Total execution time: 0.0568
DEBUG - 2022-06-29 00:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:46:10 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:16:10 --> Total execution time: 0.0581
DEBUG - 2022-06-29 00:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:16:38 --> Total execution time: 0.0587
DEBUG - 2022-06-29 00:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:46:39 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:16:39 --> Total execution time: 0.0579
DEBUG - 2022-06-29 00:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:16:44 --> Total execution time: 0.0672
DEBUG - 2022-06-29 00:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:16:58 --> Total execution time: 0.0678
DEBUG - 2022-06-29 00:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:17:02 --> Total execution time: 0.0489
DEBUG - 2022-06-29 00:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:17:06 --> Total execution time: 0.0711
DEBUG - 2022-06-29 00:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:17:11 --> Total execution time: 0.0516
DEBUG - 2022-06-29 00:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:17:13 --> Total execution time: 0.0927
DEBUG - 2022-06-29 00:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:17:20 --> Total execution time: 0.0993
DEBUG - 2022-06-29 00:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:17:21 --> Total execution time: 0.1564
DEBUG - 2022-06-29 00:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:17:29 --> Total execution time: 0.1379
DEBUG - 2022-06-29 00:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:17:35 --> Total execution time: 0.1171
DEBUG - 2022-06-29 00:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:47:49 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:17:49 --> Total execution time: 0.0427
DEBUG - 2022-06-29 00:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:47:54 --> Total execution time: 0.0611
DEBUG - 2022-06-29 00:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:47:55 --> Total execution time: 0.0710
DEBUG - 2022-06-29 00:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:47:55 --> Total execution time: 0.1318
DEBUG - 2022-06-29 00:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:18:57 --> Total execution time: 0.1393
DEBUG - 2022-06-29 00:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:19:08 --> Total execution time: 0.0516
DEBUG - 2022-06-29 00:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:49:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 00:49:14 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-29 00:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:19:15 --> Total execution time: 0.1191
DEBUG - 2022-06-29 00:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:19:19 --> Total execution time: 0.0618
DEBUG - 2022-06-29 00:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:19:32 --> Total execution time: 0.0716
DEBUG - 2022-06-29 00:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:49:37 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:19:37 --> Total execution time: 0.0355
DEBUG - 2022-06-29 00:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:19:38 --> Total execution time: 0.0557
DEBUG - 2022-06-29 00:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:19:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 00:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:19:39 --> Total execution time: 0.0460
DEBUG - 2022-06-29 00:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:19:41 --> Total execution time: 0.0323
DEBUG - 2022-06-29 00:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:19:50 --> Total execution time: 0.0516
DEBUG - 2022-06-29 00:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:19:53 --> Total execution time: 0.0501
DEBUG - 2022-06-29 00:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:50:18 --> Total execution time: 0.0504
DEBUG - 2022-06-29 00:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:50:19 --> Total execution time: 0.0623
DEBUG - 2022-06-29 00:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:50:20 --> Total execution time: 0.0545
DEBUG - 2022-06-29 00:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:50:20 --> Total execution time: 0.0908
DEBUG - 2022-06-29 00:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:20:36 --> Total execution time: 0.1551
DEBUG - 2022-06-29 00:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:20:41 --> Total execution time: 0.0396
DEBUG - 2022-06-29 00:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:20:43 --> Total execution time: 0.0545
DEBUG - 2022-06-29 00:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:51:02 --> Total execution time: 0.0890
DEBUG - 2022-06-29 00:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:51:03 --> Total execution time: 0.0520
DEBUG - 2022-06-29 00:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:51:03 --> Total execution time: 0.0877
DEBUG - 2022-06-29 00:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:21:09 --> Total execution time: 0.0868
DEBUG - 2022-06-29 00:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:21:32 --> Total execution time: 0.0557
DEBUG - 2022-06-29 00:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:51:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 00:51:38 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-29 00:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:21:43 --> Total execution time: 0.0580
DEBUG - 2022-06-29 00:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:21:46 --> Total execution time: 0.0475
DEBUG - 2022-06-29 00:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:21:50 --> Total execution time: 0.0849
DEBUG - 2022-06-29 00:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:22:02 --> Total execution time: 0.0565
DEBUG - 2022-06-29 00:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:22:13 --> Total execution time: 0.1528
DEBUG - 2022-06-29 00:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:22:17 --> Total execution time: 0.0701
DEBUG - 2022-06-29 00:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:22:22 --> Total execution time: 0.0940
DEBUG - 2022-06-29 00:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:22:22 --> Total execution time: 0.0971
DEBUG - 2022-06-29 00:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:22:30 --> Total execution time: 0.0425
DEBUG - 2022-06-29 00:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:22:43 --> Total execution time: 0.0401
DEBUG - 2022-06-29 00:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:52:44 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:22:44 --> Total execution time: 0.0474
DEBUG - 2022-06-29 00:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:52:59 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:22:59 --> Total execution time: 0.0391
DEBUG - 2022-06-29 00:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:23:00 --> Total execution time: 0.1654
DEBUG - 2022-06-29 00:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:23:12 --> Total execution time: 1.9858
DEBUG - 2022-06-29 00:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:53:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 00:53:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 00:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:53:43 --> Total execution time: 0.0482
DEBUG - 2022-06-29 00:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:53:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 00:53:45 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-29 00:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:53:55 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:23:55 --> Total execution time: 0.1177
DEBUG - 2022-06-29 00:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:23:58 --> Total execution time: 0.0474
DEBUG - 2022-06-29 00:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:24:05 --> Total execution time: 0.0964
DEBUG - 2022-06-29 00:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:24:11 --> Total execution time: 0.0638
DEBUG - 2022-06-29 00:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:24:26 --> Total execution time: 0.0847
DEBUG - 2022-06-29 00:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:54:26 --> Total execution time: 0.0491
DEBUG - 2022-06-29 00:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:54:26 --> Total execution time: 0.0955
DEBUG - 2022-06-29 00:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:24:51 --> Total execution time: 0.0304
DEBUG - 2022-06-29 00:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:24:57 --> Total execution time: 0.1321
DEBUG - 2022-06-29 00:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:24:58 --> Total execution time: 0.0480
DEBUG - 2022-06-29 00:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:25:18 --> Total execution time: 0.0489
DEBUG - 2022-06-29 00:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:25:31 --> Total execution time: 0.0564
DEBUG - 2022-06-29 00:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:25:35 --> Total execution time: 0.0813
DEBUG - 2022-06-29 00:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:55:38 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:25:38 --> Total execution time: 0.0772
DEBUG - 2022-06-29 00:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:25:45 --> Total execution time: 1.6856
DEBUG - 2022-06-29 00:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:56:00 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:26:00 --> Total execution time: 0.1371
DEBUG - 2022-06-29 00:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:26:05 --> Total execution time: 0.0554
DEBUG - 2022-06-29 00:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:56:12 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:26:12 --> Total execution time: 0.0530
DEBUG - 2022-06-29 00:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:56:14 --> Total execution time: 0.0493
DEBUG - 2022-06-29 00:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:26:15 --> Total execution time: 0.0513
DEBUG - 2022-06-29 00:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:56:16 --> Total execution time: 0.0706
DEBUG - 2022-06-29 00:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:56:16 --> Total execution time: 0.1354
DEBUG - 2022-06-29 00:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:26:23 --> Total execution time: 0.0668
DEBUG - 2022-06-29 00:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:26:26 --> Total execution time: 0.0799
DEBUG - 2022-06-29 00:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:26:33 --> Total execution time: 0.0546
DEBUG - 2022-06-29 00:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:26:48 --> Total execution time: 0.0477
DEBUG - 2022-06-29 00:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:27:06 --> Total execution time: 0.0883
DEBUG - 2022-06-29 00:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:27:09 --> Total execution time: 0.0646
DEBUG - 2022-06-29 00:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:27:09 --> Total execution time: 0.0795
DEBUG - 2022-06-29 00:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:57:12 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:27:12 --> Total execution time: 0.0621
DEBUG - 2022-06-29 00:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:27:24 --> Total execution time: 1.4888
DEBUG - 2022-06-29 00:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:27:38 --> Total execution time: 1.5336
DEBUG - 2022-06-29 00:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:27:41 --> Total execution time: 0.0625
DEBUG - 2022-06-29 00:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:27:50 --> Total execution time: 0.0571
DEBUG - 2022-06-29 00:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:28:03 --> Total execution time: 0.1260
DEBUG - 2022-06-29 00:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:28:03 --> Total execution time: 0.0994
DEBUG - 2022-06-29 00:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:28:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 00:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:28:17 --> Total execution time: 0.1195
DEBUG - 2022-06-29 00:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:58:32 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:28:32 --> Total execution time: 0.0471
DEBUG - 2022-06-29 00:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:28:36 --> Total execution time: 1.5182
DEBUG - 2022-06-29 00:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:28:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 00:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:28:38 --> Total execution time: 0.0387
DEBUG - 2022-06-29 00:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:58:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 00:58:42 --> 404 Page Not Found: Category/features
DEBUG - 2022-06-29 00:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:59:01 --> Total execution time: 0.0671
DEBUG - 2022-06-29 00:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 00:59:09 --> Total execution time: 0.1011
DEBUG - 2022-06-29 00:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:59:55 --> No URI present. Default controller set.
DEBUG - 2022-06-29 00:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:29:55 --> Total execution time: 0.0438
DEBUG - 2022-06-29 00:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 00:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 00:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:29:58 --> Total execution time: 0.1157
DEBUG - 2022-06-29 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:30:02 --> Total execution time: 0.0647
DEBUG - 2022-06-29 01:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:30:34 --> Total execution time: 0.0818
DEBUG - 2022-06-29 01:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:30:45 --> Total execution time: 0.0313
DEBUG - 2022-06-29 01:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:31:02 --> Total execution time: 0.0692
DEBUG - 2022-06-29 01:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:31:17 --> Total execution time: 0.0939
DEBUG - 2022-06-29 01:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:31:47 --> Total execution time: 0.0841
DEBUG - 2022-06-29 01:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:01:53 --> No URI present. Default controller set.
DEBUG - 2022-06-29 01:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:31:53 --> Total execution time: 0.0663
DEBUG - 2022-06-29 01:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:31:57 --> Total execution time: 0.0882
DEBUG - 2022-06-29 01:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:32:00 --> Total execution time: 0.0569
DEBUG - 2022-06-29 01:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:32:57 --> Total execution time: 0.0559
DEBUG - 2022-06-29 01:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:33:00 --> Total execution time: 0.0480
DEBUG - 2022-06-29 01:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:33:01 --> Total execution time: 0.0497
DEBUG - 2022-06-29 01:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:33:03 --> Total execution time: 0.0625
DEBUG - 2022-06-29 01:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:33:07 --> Total execution time: 0.0800
DEBUG - 2022-06-29 01:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:33:08 --> Total execution time: 0.0539
DEBUG - 2022-06-29 01:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:33:08 --> Total execution time: 0.0486
DEBUG - 2022-06-29 01:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:33:09 --> Total execution time: 0.0500
DEBUG - 2022-06-29 01:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:33:09 --> Total execution time: 0.0522
DEBUG - 2022-06-29 01:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:33:12 --> Total execution time: 0.0490
DEBUG - 2022-06-29 01:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:33:13 --> Total execution time: 0.0530
DEBUG - 2022-06-29 01:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:33:19 --> Total execution time: 0.0543
DEBUG - 2022-06-29 01:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:34:00 --> Total execution time: 0.0500
DEBUG - 2022-06-29 01:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:34:00 --> Total execution time: 0.0614
DEBUG - 2022-06-29 01:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:34:06 --> Total execution time: 0.1166
DEBUG - 2022-06-29 01:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:34:13 --> Total execution time: 0.1268
DEBUG - 2022-06-29 01:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:34:20 --> Total execution time: 0.0589
DEBUG - 2022-06-29 01:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:34:22 --> Total execution time: 0.0574
DEBUG - 2022-06-29 01:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:34:33 --> Total execution time: 0.0443
DEBUG - 2022-06-29 01:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:39:00 --> Total execution time: 0.0679
DEBUG - 2022-06-29 01:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:40:09 --> Total execution time: 0.0411
DEBUG - 2022-06-29 01:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:40:18 --> Total execution time: 0.0580
DEBUG - 2022-06-29 01:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:41:12 --> Total execution time: 0.0747
DEBUG - 2022-06-29 01:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:41:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 01:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:41:13 --> Total execution time: 0.0462
DEBUG - 2022-06-29 01:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:41:13 --> Total execution time: 0.0670
DEBUG - 2022-06-29 01:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:41:16 --> Total execution time: 0.0962
DEBUG - 2022-06-29 01:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:41:23 --> Total execution time: 0.0565
DEBUG - 2022-06-29 01:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:41:31 --> Total execution time: 0.0576
DEBUG - 2022-06-29 01:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:43:48 --> Total execution time: 0.1372
DEBUG - 2022-06-29 01:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:44:07 --> Total execution time: 0.1322
DEBUG - 2022-06-29 01:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:44:26 --> Total execution time: 0.1254
DEBUG - 2022-06-29 01:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:44:41 --> Total execution time: 0.0464
DEBUG - 2022-06-29 01:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:15:14 --> No URI present. Default controller set.
DEBUG - 2022-06-29 01:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:45:14 --> Total execution time: 0.1237
DEBUG - 2022-06-29 01:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:45:20 --> Total execution time: 0.0513
DEBUG - 2022-06-29 01:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:45:46 --> Total execution time: 0.0618
DEBUG - 2022-06-29 01:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:45:53 --> Total execution time: 0.0808
DEBUG - 2022-06-29 01:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:45:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 01:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:45:54 --> Total execution time: 0.0543
DEBUG - 2022-06-29 01:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 01:16:08 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-29 01:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:47:48 --> Total execution time: 0.0778
DEBUG - 2022-06-29 01:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:49:07 --> Total execution time: 0.0612
DEBUG - 2022-06-29 01:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:49:24 --> Total execution time: 0.1041
DEBUG - 2022-06-29 01:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:49:35 --> Total execution time: 0.0529
DEBUG - 2022-06-29 01:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:49:39 --> Total execution time: 0.0479
DEBUG - 2022-06-29 01:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:49:39 --> Total execution time: 0.0438
DEBUG - 2022-06-29 01:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:49:40 --> Total execution time: 0.0443
DEBUG - 2022-06-29 01:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:49:53 --> Total execution time: 0.0514
DEBUG - 2022-06-29 01:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:49:54 --> Total execution time: 0.0485
DEBUG - 2022-06-29 01:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:19:55 --> No URI present. Default controller set.
DEBUG - 2022-06-29 01:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:49:55 --> Total execution time: 0.0518
DEBUG - 2022-06-29 01:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:19:55 --> No URI present. Default controller set.
DEBUG - 2022-06-29 01:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:49:55 --> Total execution time: 0.0384
DEBUG - 2022-06-29 01:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:49:58 --> Total execution time: 0.0407
DEBUG - 2022-06-29 01:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:50:06 --> Total execution time: 0.0458
DEBUG - 2022-06-29 01:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:50:18 --> Total execution time: 0.0508
DEBUG - 2022-06-29 01:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:50:19 --> Total execution time: 0.0244
DEBUG - 2022-06-29 01:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:50:22 --> Total execution time: 0.0663
DEBUG - 2022-06-29 01:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:50:33 --> Total execution time: 0.0732
DEBUG - 2022-06-29 01:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:50:47 --> Total execution time: 0.0474
DEBUG - 2022-06-29 01:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:51:12 --> Total execution time: 0.0704
DEBUG - 2022-06-29 01:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:51:16 --> Total execution time: 0.0541
DEBUG - 2022-06-29 01:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:51:25 --> Total execution time: 0.0532
DEBUG - 2022-06-29 01:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:51:26 --> Total execution time: 0.0782
DEBUG - 2022-06-29 01:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:51:26 --> Total execution time: 0.0487
DEBUG - 2022-06-29 01:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:51:26 --> Total execution time: 0.0506
DEBUG - 2022-06-29 01:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:51:27 --> Total execution time: 0.0492
DEBUG - 2022-06-29 01:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:21:46 --> No URI present. Default controller set.
DEBUG - 2022-06-29 01:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:51:46 --> Total execution time: 0.0373
DEBUG - 2022-06-29 01:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 01:21:52 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-29 01:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:56:40 --> Total execution time: 0.1030
DEBUG - 2022-06-29 01:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:56:48 --> Total execution time: 0.0568
DEBUG - 2022-06-29 01:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:56:53 --> Total execution time: 0.0544
DEBUG - 2022-06-29 01:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:56:54 --> Total execution time: 0.0479
DEBUG - 2022-06-29 01:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:56:59 --> Total execution time: 0.0545
DEBUG - 2022-06-29 01:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:57:07 --> Total execution time: 0.0645
DEBUG - 2022-06-29 01:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:57:10 --> Total execution time: 0.0483
DEBUG - 2022-06-29 01:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:27:15 --> Total execution time: 0.0270
DEBUG - 2022-06-29 01:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:57:55 --> Total execution time: 0.1425
DEBUG - 2022-06-29 01:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:31:54 --> No URI present. Default controller set.
DEBUG - 2022-06-29 01:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:01:54 --> Total execution time: 0.0948
DEBUG - 2022-06-29 01:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:02:03 --> Total execution time: 0.0552
DEBUG - 2022-06-29 01:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:02:19 --> Total execution time: 0.1272
DEBUG - 2022-06-29 01:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:02:23 --> Total execution time: 0.0652
DEBUG - 2022-06-29 01:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:02:29 --> Total execution time: 0.0562
DEBUG - 2022-06-29 01:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:02:30 --> Total execution time: 0.0381
DEBUG - 2022-06-29 01:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:02:35 --> Total execution time: 0.0512
DEBUG - 2022-06-29 01:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:02:49 --> Total execution time: 0.0458
DEBUG - 2022-06-29 01:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:05:42 --> Total execution time: 0.1813
DEBUG - 2022-06-29 01:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:05:48 --> Total execution time: 0.0604
DEBUG - 2022-06-29 01:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:05:48 --> Total execution time: 0.0697
DEBUG - 2022-06-29 01:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:05:54 --> Total execution time: 0.1092
DEBUG - 2022-06-29 01:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:07:04 --> Total execution time: 0.1191
DEBUG - 2022-06-29 01:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:07:26 --> Total execution time: 0.0581
DEBUG - 2022-06-29 01:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:07:31 --> Total execution time: 0.0780
DEBUG - 2022-06-29 01:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:07:34 --> Total execution time: 0.0609
DEBUG - 2022-06-29 01:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:07:51 --> Total execution time: 0.0572
DEBUG - 2022-06-29 01:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:41:05 --> Total execution time: 0.2415
DEBUG - 2022-06-29 01:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:11:10 --> Total execution time: 0.0493
DEBUG - 2022-06-29 01:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:11:16 --> Total execution time: 0.0805
DEBUG - 2022-06-29 01:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:11:18 --> Total execution time: 0.0874
DEBUG - 2022-06-29 01:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:11:37 --> Total execution time: 0.0606
DEBUG - 2022-06-29 01:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:11:39 --> Total execution time: 0.0430
DEBUG - 2022-06-29 01:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:11:45 --> Total execution time: 0.0723
DEBUG - 2022-06-29 01:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:11:52 --> Total execution time: 0.0571
DEBUG - 2022-06-29 01:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:11:54 --> Total execution time: 0.0452
DEBUG - 2022-06-29 01:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:11:57 --> Total execution time: 0.0392
DEBUG - 2022-06-29 01:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:11:59 --> Total execution time: 0.0524
DEBUG - 2022-06-29 01:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:12:54 --> Total execution time: 0.1153
DEBUG - 2022-06-29 01:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:15:36 --> Total execution time: 0.1208
DEBUG - 2022-06-29 01:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:15:43 --> Total execution time: 0.0706
DEBUG - 2022-06-29 01:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:15:49 --> Total execution time: 0.0973
DEBUG - 2022-06-29 01:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:15:54 --> Total execution time: 0.0900
DEBUG - 2022-06-29 01:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:16:11 --> Total execution time: 0.0539
DEBUG - 2022-06-29 01:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:16:19 --> Total execution time: 0.0529
DEBUG - 2022-06-29 01:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:46:21 --> No URI present. Default controller set.
DEBUG - 2022-06-29 01:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:16:21 --> Total execution time: 0.0441
DEBUG - 2022-06-29 01:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:46:24 --> Total execution time: 0.0439
DEBUG - 2022-06-29 01:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:16:28 --> Total execution time: 0.0524
DEBUG - 2022-06-29 01:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:16:33 --> Total execution time: 0.0668
DEBUG - 2022-06-29 01:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:17:23 --> Total execution time: 0.1225
DEBUG - 2022-06-29 01:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:17:34 --> Total execution time: 0.0639
DEBUG - 2022-06-29 01:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:17:40 --> Total execution time: 0.0704
DEBUG - 2022-06-29 01:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:17:51 --> Total execution time: 0.1075
DEBUG - 2022-06-29 01:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:18:00 --> Total execution time: 0.0489
DEBUG - 2022-06-29 01:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:48:11 --> No URI present. Default controller set.
DEBUG - 2022-06-29 01:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:18:11 --> Total execution time: 0.0572
DEBUG - 2022-06-29 01:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:48:19 --> Total execution time: 0.0538
DEBUG - 2022-06-29 01:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:48:25 --> Total execution time: 0.0491
DEBUG - 2022-06-29 01:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:48:32 --> Total execution time: 0.0489
DEBUG - 2022-06-29 01:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:48:46 --> Total execution time: 0.0459
DEBUG - 2022-06-29 01:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:20:06 --> Total execution time: 0.0483
DEBUG - 2022-06-29 01:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:20:31 --> Total execution time: 0.0495
DEBUG - 2022-06-29 01:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:51:17 --> Total execution time: 0.0537
DEBUG - 2022-06-29 01:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:51:19 --> Total execution time: 0.0676
DEBUG - 2022-06-29 01:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:51:19 --> Total execution time: 0.1288
DEBUG - 2022-06-29 01:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:21:41 --> Total execution time: 0.0569
DEBUG - 2022-06-29 01:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:51:41 --> No URI present. Default controller set.
DEBUG - 2022-06-29 01:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:21:41 --> Total execution time: 0.0506
DEBUG - 2022-06-29 01:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:21:46 --> Total execution time: 0.0713
DEBUG - 2022-06-29 01:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:51:49 --> Total execution time: 0.0510
DEBUG - 2022-06-29 01:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:21:52 --> Total execution time: 0.0512
DEBUG - 2022-06-29 01:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:51:58 --> Total execution time: 0.0655
DEBUG - 2022-06-29 01:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:51:58 --> Total execution time: 0.0913
DEBUG - 2022-06-29 01:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:21:58 --> Total execution time: 0.0532
DEBUG - 2022-06-29 01:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:22:07 --> Total execution time: 0.0948
DEBUG - 2022-06-29 01:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:22:12 --> Total execution time: 0.0497
DEBUG - 2022-06-29 01:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:52:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 01:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:22:47 --> Total execution time: 1.9588
DEBUG - 2022-06-29 01:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:52:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 01:52:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 01:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:23:15 --> Total execution time: 0.1233
DEBUG - 2022-06-29 01:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:23:24 --> Total execution time: 0.0564
DEBUG - 2022-06-29 01:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:23:27 --> Total execution time: 0.0516
DEBUG - 2022-06-29 01:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:23:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 01:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:23:40 --> Total execution time: 0.0544
DEBUG - 2022-06-29 01:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:53:44 --> No URI present. Default controller set.
DEBUG - 2022-06-29 01:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:23:44 --> Total execution time: 0.0372
DEBUG - 2022-06-29 01:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:23:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 12:23:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 12:23:46 --> Total execution time: 0.2098
DEBUG - 2022-06-29 01:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:23:49 --> Total execution time: 0.0371
DEBUG - 2022-06-29 01:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:24:01 --> Total execution time: 0.0599
DEBUG - 2022-06-29 01:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:24:03 --> Total execution time: 0.0573
DEBUG - 2022-06-29 01:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:24:04 --> Total execution time: 0.0708
DEBUG - 2022-06-29 01:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:24:11 --> Total execution time: 0.2575
DEBUG - 2022-06-29 01:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:54:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 01:54:41 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-29 01:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:24:45 --> Total execution time: 0.1560
DEBUG - 2022-06-29 01:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:54:51 --> No URI present. Default controller set.
DEBUG - 2022-06-29 01:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:24:51 --> Total execution time: 0.0688
DEBUG - 2022-06-29 01:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:24:52 --> Total execution time: 0.0715
DEBUG - 2022-06-29 01:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:24:56 --> Total execution time: 0.0846
DEBUG - 2022-06-29 01:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:24:58 --> Total execution time: 0.0668
DEBUG - 2022-06-29 01:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:55:02 --> Total execution time: 0.0397
DEBUG - 2022-06-29 01:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:25:05 --> Total execution time: 0.0568
DEBUG - 2022-06-29 01:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:55:09 --> Total execution time: 0.0767
DEBUG - 2022-06-29 01:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:55:15 --> Total execution time: 0.0518
DEBUG - 2022-06-29 01:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:25:16 --> Total execution time: 0.0493
DEBUG - 2022-06-29 01:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:25:16 --> Total execution time: 0.1348
DEBUG - 2022-06-29 01:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:25:17 --> Total execution time: 0.0514
DEBUG - 2022-06-29 01:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:55:23 --> Total execution time: 0.0491
DEBUG - 2022-06-29 01:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:55:25 --> Total execution time: 0.0460
DEBUG - 2022-06-29 01:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:25 --> No URI present. Default controller set.
DEBUG - 2022-06-29 01:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:25:25 --> Total execution time: 0.1226
DEBUG - 2022-06-29 01:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:25:26 --> Total execution time: 0.0492
DEBUG - 2022-06-29 01:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:55:29 --> Total execution time: 0.0635
DEBUG - 2022-06-29 01:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:25:30 --> Total execution time: 0.0594
DEBUG - 2022-06-29 01:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:55:31 --> Total execution time: 0.0510
DEBUG - 2022-06-29 01:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:25:32 --> Total execution time: 0.0511
DEBUG - 2022-06-29 01:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:25:35 --> Total execution time: 0.0597
DEBUG - 2022-06-29 01:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:25:37 --> Total execution time: 0.0543
DEBUG - 2022-06-29 01:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:25:38 --> Total execution time: 0.0498
DEBUG - 2022-06-29 01:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:25:38 --> Total execution time: 0.0607
DEBUG - 2022-06-29 01:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:25:40 --> Total execution time: 0.0777
DEBUG - 2022-06-29 01:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:25:53 --> Total execution time: 0.0751
DEBUG - 2022-06-29 01:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:25:56 --> Total execution time: 0.0662
DEBUG - 2022-06-29 01:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:26:00 --> Total execution time: 0.0554
DEBUG - 2022-06-29 01:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:26:08 --> Total execution time: 0.0775
DEBUG - 2022-06-29 01:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:26:16 --> Total execution time: 0.0710
DEBUG - 2022-06-29 01:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:26:20 --> Total execution time: 0.0544
DEBUG - 2022-06-29 01:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:26:23 --> Total execution time: 0.0954
DEBUG - 2022-06-29 01:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:26:28 --> Total execution time: 0.1166
DEBUG - 2022-06-29 01:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:26:29 --> Total execution time: 0.0541
DEBUG - 2022-06-29 01:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:26:37 --> Total execution time: 0.0459
DEBUG - 2022-06-29 01:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:26:38 --> Total execution time: 0.0586
DEBUG - 2022-06-29 01:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:26:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 01:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:26:39 --> Total execution time: 0.0569
DEBUG - 2022-06-29 01:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:26:45 --> Total execution time: 0.0567
DEBUG - 2022-06-29 01:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:26:51 --> Total execution time: 0.0656
DEBUG - 2022-06-29 01:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:26:57 --> Total execution time: 0.0610
DEBUG - 2022-06-29 01:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:26:58 --> Total execution time: 0.0625
DEBUG - 2022-06-29 01:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:26:58 --> Total execution time: 0.0801
DEBUG - 2022-06-29 01:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:27:10 --> Total execution time: 0.1535
DEBUG - 2022-06-29 01:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:27:26 --> Total execution time: 0.0743
DEBUG - 2022-06-29 01:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:27:37 --> Total execution time: 0.0595
DEBUG - 2022-06-29 01:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:57:37 --> No URI present. Default controller set.
DEBUG - 2022-06-29 01:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:27:37 --> Total execution time: 0.1360
DEBUG - 2022-06-29 01:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:27:46 --> Total execution time: 0.0479
DEBUG - 2022-06-29 01:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:27:46 --> Total execution time: 0.0499
DEBUG - 2022-06-29 01:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:57:46 --> No URI present. Default controller set.
DEBUG - 2022-06-29 01:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:27:46 --> Total execution time: 0.1147
DEBUG - 2022-06-29 01:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:27:50 --> Total execution time: 0.0669
DEBUG - 2022-06-29 01:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:27:58 --> Total execution time: 0.0508
DEBUG - 2022-06-29 01:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:28:07 --> Total execution time: 0.0534
DEBUG - 2022-06-29 01:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:58:13 --> Total execution time: 0.0476
DEBUG - 2022-06-29 01:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:58:15 --> Total execution time: 0.0680
DEBUG - 2022-06-29 01:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:58:15 --> Total execution time: 0.1132
DEBUG - 2022-06-29 01:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 01:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 01:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 01:58:21 --> Total execution time: 0.0500
DEBUG - 2022-06-29 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:30:03 --> Total execution time: 0.0850
DEBUG - 2022-06-29 02:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:30:12 --> Total execution time: 0.3138
DEBUG - 2022-06-29 02:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:30:51 --> Total execution time: 0.0761
DEBUG - 2022-06-29 02:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:00:54 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:30:54 --> Total execution time: 0.0622
DEBUG - 2022-06-29 02:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:00:54 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:30:54 --> Total execution time: 0.0328
DEBUG - 2022-06-29 02:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:30:57 --> Total execution time: 0.0916
DEBUG - 2022-06-29 02:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:31:04 --> Total execution time: 0.0592
DEBUG - 2022-06-29 02:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:01:17 --> Total execution time: 0.0456
DEBUG - 2022-06-29 02:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:31:18 --> Total execution time: 0.0558
DEBUG - 2022-06-29 02:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:01:18 --> Total execution time: 0.0529
DEBUG - 2022-06-29 02:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:01:18 --> Total execution time: 0.1174
DEBUG - 2022-06-29 02:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:31:19 --> Total execution time: 0.1271
DEBUG - 2022-06-29 02:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:31:21 --> Total execution time: 0.0579
DEBUG - 2022-06-29 02:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:31:23 --> Total execution time: 0.0811
DEBUG - 2022-06-29 02:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:31:31 --> Total execution time: 0.0612
DEBUG - 2022-06-29 02:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:31:31 --> Total execution time: 0.0506
DEBUG - 2022-06-29 02:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:31:47 --> Total execution time: 0.1259
DEBUG - 2022-06-29 02:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:31:48 --> Total execution time: 0.0568
DEBUG - 2022-06-29 02:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:31:57 --> Total execution time: 0.0485
DEBUG - 2022-06-29 02:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:32:05 --> Total execution time: 0.0582
DEBUG - 2022-06-29 02:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:32:05 --> Total execution time: 0.0610
DEBUG - 2022-06-29 02:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:32:06 --> Total execution time: 0.0514
DEBUG - 2022-06-29 02:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:32:12 --> Total execution time: 0.0503
DEBUG - 2022-06-29 02:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:32:20 --> Total execution time: 0.0512
DEBUG - 2022-06-29 02:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:32:28 --> Total execution time: 0.1058
DEBUG - 2022-06-29 02:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:32:35 --> Total execution time: 0.0744
DEBUG - 2022-06-29 02:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:32:53 --> Total execution time: 0.0944
DEBUG - 2022-06-29 02:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:32:55 --> Total execution time: 0.0506
DEBUG - 2022-06-29 02:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:32:59 --> Total execution time: 0.0659
DEBUG - 2022-06-29 02:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:33:02 --> Total execution time: 0.0541
DEBUG - 2022-06-29 02:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:03:51 --> Total execution time: 0.0449
DEBUG - 2022-06-29 02:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:03:52 --> Total execution time: 0.0472
DEBUG - 2022-06-29 02:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:03:53 --> Total execution time: 0.0971
DEBUG - 2022-06-29 02:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:04:05 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:34:05 --> Total execution time: 0.0379
DEBUG - 2022-06-29 02:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:04:06 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:34:06 --> Total execution time: 0.0434
DEBUG - 2022-06-29 02:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:04:08 --> Total execution time: 0.0521
DEBUG - 2022-06-29 02:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:04:09 --> Total execution time: 0.0590
DEBUG - 2022-06-29 02:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:04:09 --> Total execution time: 0.0872
DEBUG - 2022-06-29 02:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:34:16 --> Total execution time: 0.0524
DEBUG - 2022-06-29 02:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:34:35 --> Total execution time: 0.0417
DEBUG - 2022-06-29 02:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:35:32 --> Total execution time: 0.0492
DEBUG - 2022-06-29 02:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:35:46 --> Total execution time: 0.0584
DEBUG - 2022-06-29 02:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:05:55 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:35:55 --> Total execution time: 0.0377
DEBUG - 2022-06-29 02:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:05:57 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:35:57 --> Total execution time: 0.0486
DEBUG - 2022-06-29 02:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:36:30 --> Total execution time: 0.0466
DEBUG - 2022-06-29 02:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:36:37 --> Total execution time: 0.0632
DEBUG - 2022-06-29 02:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:36:39 --> Total execution time: 0.0563
DEBUG - 2022-06-29 02:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:36:41 --> Total execution time: 0.0507
DEBUG - 2022-06-29 02:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:36:45 --> Total execution time: 0.0668
DEBUG - 2022-06-29 02:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:36:52 --> Total execution time: 0.0563
DEBUG - 2022-06-29 02:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:07:02 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:37:02 --> Total execution time: 0.1536
DEBUG - 2022-06-29 02:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:37:07 --> Total execution time: 0.0586
DEBUG - 2022-06-29 02:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:37:07 --> Total execution time: 0.0453
DEBUG - 2022-06-29 02:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:37:15 --> Total execution time: 0.0607
DEBUG - 2022-06-29 02:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:37:30 --> Total execution time: 0.1117
DEBUG - 2022-06-29 02:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:37:40 --> Total execution time: 0.0490
DEBUG - 2022-06-29 02:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:37:49 --> Total execution time: 0.0674
DEBUG - 2022-06-29 02:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:08:24 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:38:24 --> Total execution time: 0.0577
DEBUG - 2022-06-29 02:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:08:24 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:38:24 --> Total execution time: 0.0338
DEBUG - 2022-06-29 02:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:08:27 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:38:27 --> Total execution time: 0.0336
DEBUG - 2022-06-29 02:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:38:36 --> Total execution time: 0.0438
DEBUG - 2022-06-29 02:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:38:37 --> Total execution time: 0.0537
DEBUG - 2022-06-29 02:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:38:56 --> Total execution time: 0.1308
DEBUG - 2022-06-29 02:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:08:57 --> Total execution time: 0.0519
DEBUG - 2022-06-29 02:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:08:58 --> Total execution time: 0.0582
DEBUG - 2022-06-29 02:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:08:58 --> Total execution time: 0.0980
DEBUG - 2022-06-29 02:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:08:59 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:38:59 --> Total execution time: 0.0517
DEBUG - 2022-06-29 02:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:09:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 02:09:29 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-29 02:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:09:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 02:09:29 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 02:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 02:09:48 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-29 02:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:40:17 --> Total execution time: 0.1151
DEBUG - 2022-06-29 02:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:40:38 --> Total execution time: 0.1409
DEBUG - 2022-06-29 02:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:40:40 --> Total execution time: 0.0860
DEBUG - 2022-06-29 02:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:40:50 --> Total execution time: 0.0880
DEBUG - 2022-06-29 02:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:40:57 --> Total execution time: 0.0473
DEBUG - 2022-06-29 12:40:57 --> Total execution time: 0.0746
DEBUG - 2022-06-29 02:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:41:06 --> Total execution time: 0.0851
DEBUG - 2022-06-29 02:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:41:10 --> Total execution time: 0.0774
DEBUG - 2022-06-29 02:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:41:12 --> Total execution time: 0.0838
DEBUG - 2022-06-29 02:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:41:24 --> Total execution time: 0.0769
DEBUG - 2022-06-29 02:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:41:29 --> Total execution time: 0.0458
DEBUG - 2022-06-29 02:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:41:35 --> Total execution time: 0.0803
DEBUG - 2022-06-29 02:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:41:38 --> Total execution time: 0.1195
DEBUG - 2022-06-29 02:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:41:45 --> Total execution time: 0.0785
DEBUG - 2022-06-29 02:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:41:46 --> Total execution time: 0.0483
DEBUG - 2022-06-29 02:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:41:48 --> Total execution time: 0.1494
DEBUG - 2022-06-29 02:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:41:57 --> Total execution time: 0.0765
DEBUG - 2022-06-29 02:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:42:03 --> Total execution time: 0.0833
DEBUG - 2022-06-29 02:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:42:09 --> Total execution time: 0.0762
DEBUG - 2022-06-29 02:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:42:18 --> Total execution time: 0.0892
DEBUG - 2022-06-29 02:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:42:39 --> Total execution time: 0.0991
DEBUG - 2022-06-29 02:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:42:39 --> Total execution time: 0.0770
DEBUG - 2022-06-29 02:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:42:40 --> Total execution time: 0.0726
DEBUG - 2022-06-29 02:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:42:40 --> Total execution time: 0.0887
DEBUG - 2022-06-29 02:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:42:41 --> Total execution time: 0.0622
DEBUG - 2022-06-29 02:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:42:42 --> Total execution time: 0.0676
DEBUG - 2022-06-29 02:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:42:49 --> Total execution time: 0.0824
DEBUG - 2022-06-29 02:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:42:49 --> Total execution time: 0.1531
DEBUG - 2022-06-29 02:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:42:50 --> Total execution time: 0.0951
DEBUG - 2022-06-29 02:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:42:50 --> Total execution time: 0.0927
DEBUG - 2022-06-29 02:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:45:08 --> Total execution time: 0.1412
DEBUG - 2022-06-29 02:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:45:11 --> Total execution time: 0.0952
DEBUG - 2022-06-29 02:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:45:28 --> Total execution time: 0.1297
DEBUG - 2022-06-29 02:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:45:42 --> Total execution time: 0.0483
DEBUG - 2022-06-29 02:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:45:43 --> Total execution time: 0.0523
DEBUG - 2022-06-29 02:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:45:45 --> Total execution time: 0.1481
DEBUG - 2022-06-29 02:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:45:48 --> Total execution time: 0.0918
DEBUG - 2022-06-29 02:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:46:13 --> Total execution time: 0.0354
DEBUG - 2022-06-29 02:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:46:15 --> Total execution time: 0.0447
DEBUG - 2022-06-29 02:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:47:13 --> Total execution time: 0.1276
DEBUG - 2022-06-29 02:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:51:09 --> Total execution time: 0.0503
DEBUG - 2022-06-29 02:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:21:24 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:51:24 --> Total execution time: 0.0460
DEBUG - 2022-06-29 02:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:21:26 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:51:26 --> Total execution time: 0.0347
DEBUG - 2022-06-29 02:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:52:14 --> Total execution time: 0.0523
DEBUG - 2022-06-29 02:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:52:26 --> Total execution time: 0.1248
DEBUG - 2022-06-29 02:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:53:10 --> Total execution time: 0.0642
DEBUG - 2022-06-29 02:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:23:39 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:53:39 --> Total execution time: 0.0523
DEBUG - 2022-06-29 02:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:54:03 --> Total execution time: 0.0523
DEBUG - 2022-06-29 02:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:25:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 02:25:33 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-29 02:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:56:26 --> Total execution time: 0.1180
DEBUG - 2022-06-29 02:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:28:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 02:28:04 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-29 02:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:58:14 --> Total execution time: 0.1272
DEBUG - 2022-06-29 02:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:28:22 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:58:22 --> Total execution time: 0.0468
DEBUG - 2022-06-29 02:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:58:25 --> Total execution time: 0.0366
DEBUG - 2022-06-29 02:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:58:40 --> Total execution time: 0.0538
DEBUG - 2022-06-29 02:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:58:46 --> Total execution time: 0.0659
DEBUG - 2022-06-29 02:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:58:59 --> Total execution time: 0.0674
DEBUG - 2022-06-29 02:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 02:29:04 --> 404 Page Not Found: Wp-loadphp/index
DEBUG - 2022-06-29 02:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:29:04 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:59:04 --> Total execution time: 0.1194
DEBUG - 2022-06-29 02:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 02:29:20 --> 404 Page Not Found: Old-indexphp/index
DEBUG - 2022-06-29 02:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 02:30:10 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-29 02:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:00:25 --> Total execution time: 0.1289
DEBUG - 2022-06-29 02:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:00:35 --> Total execution time: 0.0528
DEBUG - 2022-06-29 02:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:00:43 --> Total execution time: 0.0569
DEBUG - 2022-06-29 02:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:00:47 --> Total execution time: 0.0629
DEBUG - 2022-06-29 02:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:31:04 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:01:04 --> Total execution time: 0.1167
DEBUG - 2022-06-29 02:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:31:04 --> Total execution time: 0.0690
DEBUG - 2022-06-29 02:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:31:05 --> Total execution time: 0.0572
DEBUG - 2022-06-29 02:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:31:05 --> Total execution time: 0.0664
DEBUG - 2022-06-29 02:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:01:06 --> Total execution time: 0.0591
DEBUG - 2022-06-29 02:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:01:07 --> Total execution time: 0.0662
DEBUG - 2022-06-29 02:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:31:10 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:01:10 --> Total execution time: 0.0488
DEBUG - 2022-06-29 02:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:33:04 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:03:04 --> Total execution time: 0.0409
DEBUG - 2022-06-29 02:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:33:04 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:03:04 --> Total execution time: 0.0338
DEBUG - 2022-06-29 02:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:07:49 --> Total execution time: 0.2422
DEBUG - 2022-06-29 02:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:08:47 --> Total execution time: 0.1300
DEBUG - 2022-06-29 02:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:08:55 --> Total execution time: 0.0725
DEBUG - 2022-06-29 02:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:13:21 --> Total execution time: 0.1600
DEBUG - 2022-06-29 02:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:15:54 --> Total execution time: 0.1975
DEBUG - 2022-06-29 02:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:15:57 --> Total execution time: 0.0559
DEBUG - 2022-06-29 02:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:16:02 --> Total execution time: 0.0774
DEBUG - 2022-06-29 02:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:16:04 --> Total execution time: 0.0465
DEBUG - 2022-06-29 02:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:16:45 --> Total execution time: 0.0513
DEBUG - 2022-06-29 02:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:17:17 --> Total execution time: 0.1048
DEBUG - 2022-06-29 02:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:17:34 --> Total execution time: 0.0562
DEBUG - 2022-06-29 02:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:17:39 --> Total execution time: 0.1219
DEBUG - 2022-06-29 02:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:17:45 --> Total execution time: 0.1432
DEBUG - 2022-06-29 02:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:18:04 --> Total execution time: 0.0576
DEBUG - 2022-06-29 02:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:18:09 --> Total execution time: 0.1006
DEBUG - 2022-06-29 02:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:18:26 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 02:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:18:26 --> Total execution time: 0.0922
DEBUG - 2022-06-29 02:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:18:33 --> Total execution time: 0.1230
DEBUG - 2022-06-29 02:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:18:41 --> Total execution time: 0.0632
DEBUG - 2022-06-29 02:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:18:46 --> Total execution time: 0.0784
DEBUG - 2022-06-29 02:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:18:50 --> Total execution time: 0.1149
DEBUG - 2022-06-29 02:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:19:12 --> Total execution time: 0.0509
DEBUG - 2022-06-29 02:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:19:23 --> Total execution time: 0.0824
DEBUG - 2022-06-29 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:19:26 --> Total execution time: 0.0469
DEBUG - 2022-06-29 02:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:19:28 --> Total execution time: 0.0582
DEBUG - 2022-06-29 02:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:19:47 --> Total execution time: 0.0747
DEBUG - 2022-06-29 02:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:20:08 --> Total execution time: 0.0801
DEBUG - 2022-06-29 02:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:20:17 --> Total execution time: 0.0873
DEBUG - 2022-06-29 02:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:50:21 --> No URI present. Default controller set.
DEBUG - 2022-06-29 02:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:20:21 --> Total execution time: 0.0389
DEBUG - 2022-06-29 02:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:20:32 --> Total execution time: 0.0825
DEBUG - 2022-06-29 02:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:20:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 02:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:20:52 --> Total execution time: 0.0867
DEBUG - 2022-06-29 02:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:20:55 --> Total execution time: 0.0780
DEBUG - 2022-06-29 02:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:21:08 --> Total execution time: 0.0732
DEBUG - 2022-06-29 02:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:21:20 --> Total execution time: 0.0934
DEBUG - 2022-06-29 02:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:21:23 --> Total execution time: 0.0935
DEBUG - 2022-06-29 02:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:21:25 --> Total execution time: 0.0517
DEBUG - 2022-06-29 02:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:22:02 --> Total execution time: 0.0506
DEBUG - 2022-06-29 02:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 02:53:03 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-29 02:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:23:41 --> Total execution time: 0.0498
DEBUG - 2022-06-29 02:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:24:06 --> Total execution time: 0.0471
DEBUG - 2022-06-29 02:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:24:06 --> Total execution time: 0.1500
DEBUG - 2022-06-29 02:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:54:08 --> Total execution time: 0.0502
DEBUG - 2022-06-29 02:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:24:12 --> Total execution time: 0.0501
DEBUG - 2022-06-29 02:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:24:18 --> Total execution time: 0.0712
DEBUG - 2022-06-29 02:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:54:24 --> Total execution time: 0.0453
DEBUG - 2022-06-29 02:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 02:54:25 --> Total execution time: 0.0632
DEBUG - 2022-06-29 02:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:24:27 --> Total execution time: 0.0579
DEBUG - 2022-06-29 02:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:24:33 --> Total execution time: 0.0749
DEBUG - 2022-06-29 02:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:25:42 --> Total execution time: 0.0553
DEBUG - 2022-06-29 02:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:25:51 --> Total execution time: 0.1274
DEBUG - 2022-06-29 02:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:25:53 --> Total execution time: 0.0821
DEBUG - 2022-06-29 02:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:25:56 --> Total execution time: 0.0529
DEBUG - 2022-06-29 02:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:25:59 --> Total execution time: 0.0537
DEBUG - 2022-06-29 02:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:26:04 --> Total execution time: 0.0534
DEBUG - 2022-06-29 02:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 02:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 02:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:26:11 --> Total execution time: 0.0530
DEBUG - 2022-06-29 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:30:02 --> Total execution time: 0.2332
DEBUG - 2022-06-29 03:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:01:50 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:31:50 --> Total execution time: 0.1293
DEBUG - 2022-06-29 03:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:03:00 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:33:00 --> Total execution time: 0.0354
DEBUG - 2022-06-29 03:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:33:26 --> Total execution time: 0.0518
DEBUG - 2022-06-29 03:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:33:48 --> Total execution time: 0.0595
DEBUG - 2022-06-29 03:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:34:13 --> Total execution time: 0.0839
DEBUG - 2022-06-29 03:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:34:22 --> Total execution time: 0.0518
DEBUG - 2022-06-29 03:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:04:26 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:34:26 --> Total execution time: 0.0366
DEBUG - 2022-06-29 03:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:34:29 --> Total execution time: 0.0392
DEBUG - 2022-06-29 03:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:34:38 --> Total execution time: 0.0615
DEBUG - 2022-06-29 03:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:34:52 --> Total execution time: 0.0544
DEBUG - 2022-06-29 03:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:35:00 --> Total execution time: 0.0538
DEBUG - 2022-06-29 03:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:35:04 --> Total execution time: 0.0568
DEBUG - 2022-06-29 03:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:35:19 --> Total execution time: 0.0475
DEBUG - 2022-06-29 03:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:35:42 --> Total execution time: 0.0867
DEBUG - 2022-06-29 03:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:36:01 --> Total execution time: 0.0733
DEBUG - 2022-06-29 03:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:36:37 --> Total execution time: 0.0911
DEBUG - 2022-06-29 03:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:37:00 --> Total execution time: 0.0494
DEBUG - 2022-06-29 03:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:37:29 --> Total execution time: 0.0620
DEBUG - 2022-06-29 03:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:38:25 --> Total execution time: 0.0650
DEBUG - 2022-06-29 03:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:38:31 --> Total execution time: 0.1436
DEBUG - 2022-06-29 03:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:38:35 --> Total execution time: 0.1275
DEBUG - 2022-06-29 03:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:39:30 --> Total execution time: 0.0490
DEBUG - 2022-06-29 03:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:39:37 --> Total execution time: 0.0516
DEBUG - 2022-06-29 03:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:39:44 --> Total execution time: 0.0556
DEBUG - 2022-06-29 03:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:39:53 --> Total execution time: 0.0728
DEBUG - 2022-06-29 03:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:39:56 --> Total execution time: 0.0588
DEBUG - 2022-06-29 03:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:20:35 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:50:36 --> Total execution time: 0.1525
DEBUG - 2022-06-29 03:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:20:42 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:50:42 --> Total execution time: 0.0347
DEBUG - 2022-06-29 03:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:50:44 --> Total execution time: 0.0328
DEBUG - 2022-06-29 03:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:21:16 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:51:16 --> Total execution time: 0.0746
DEBUG - 2022-06-29 03:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:21:27 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:51:27 --> Total execution time: 0.0351
DEBUG - 2022-06-29 03:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:51:27 --> Total execution time: 0.0445
DEBUG - 2022-06-29 03:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:51:28 --> Total execution time: 0.0662
DEBUG - 2022-06-29 03:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:51:36 --> Total execution time: 0.0856
DEBUG - 2022-06-29 03:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:51:41 --> Total execution time: 0.0860
DEBUG - 2022-06-29 03:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:51:50 --> Total execution time: 0.0872
DEBUG - 2022-06-29 03:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:51:54 --> Total execution time: 0.0833
DEBUG - 2022-06-29 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:52:22 --> Total execution time: 0.0506
DEBUG - 2022-06-29 03:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:52:29 --> Total execution time: 0.0614
DEBUG - 2022-06-29 03:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:52:33 --> Total execution time: 0.0921
DEBUG - 2022-06-29 03:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:52:41 --> Total execution time: 0.0459
DEBUG - 2022-06-29 03:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:54:05 --> Total execution time: 0.1327
DEBUG - 2022-06-29 03:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:56:02 --> Total execution time: 0.1442
DEBUG - 2022-06-29 03:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:56:07 --> Total execution time: 0.0878
DEBUG - 2022-06-29 03:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:58:31 --> Total execution time: 0.4282
DEBUG - 2022-06-29 03:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:58:31 --> Total execution time: 0.2162
DEBUG - 2022-06-29 03:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:58:33 --> Total execution time: 0.1052
DEBUG - 2022-06-29 03:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:28:37 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:58:38 --> Total execution time: 0.1302
DEBUG - 2022-06-29 03:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:29:49 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:59:49 --> Total execution time: 0.0357
DEBUG - 2022-06-29 03:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:59:51 --> Total execution time: 0.0325
DEBUG - 2022-06-29 03:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:59:59 --> Total execution time: 0.0732
DEBUG - 2022-06-29 03:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:01:14 --> Total execution time: 0.0515
DEBUG - 2022-06-29 03:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:01:21 --> Total execution time: 0.0684
DEBUG - 2022-06-29 03:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:32:18 --> Total execution time: 0.0563
DEBUG - 2022-06-29 03:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:32:19 --> Total execution time: 0.0587
DEBUG - 2022-06-29 03:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:02:21 --> Total execution time: 0.0621
DEBUG - 2022-06-29 03:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:02:42 --> Total execution time: 0.0482
DEBUG - 2022-06-29 03:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:02:57 --> Total execution time: 0.0557
DEBUG - 2022-06-29 03:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:03:50 --> Total execution time: 0.0506
DEBUG - 2022-06-29 03:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:03:55 --> Total execution time: 0.1065
DEBUG - 2022-06-29 03:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:34:11 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:04:11 --> Total execution time: 0.0405
DEBUG - 2022-06-29 03:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:04:17 --> Total execution time: 0.0355
DEBUG - 2022-06-29 03:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:04:19 --> Total execution time: 0.0419
DEBUG - 2022-06-29 03:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:04:19 --> Total execution time: 0.0346
DEBUG - 2022-06-29 03:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:04:20 --> Total execution time: 0.0420
DEBUG - 2022-06-29 03:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:04:23 --> Total execution time: 0.1399
DEBUG - 2022-06-29 03:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:04:36 --> Total execution time: 0.0457
DEBUG - 2022-06-29 03:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:04:40 --> Total execution time: 0.1116
DEBUG - 2022-06-29 03:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:04:54 --> Total execution time: 0.0639
DEBUG - 2022-06-29 03:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:04:56 --> Total execution time: 0.0332
DEBUG - 2022-06-29 03:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:05:08 --> Total execution time: 0.1277
DEBUG - 2022-06-29 03:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:05:10 --> Total execution time: 0.0306
DEBUG - 2022-06-29 03:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:05:24 --> Total execution time: 0.0536
DEBUG - 2022-06-29 03:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:05:26 --> Total execution time: 0.0449
DEBUG - 2022-06-29 03:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:05:46 --> Total execution time: 0.0487
DEBUG - 2022-06-29 03:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:05:53 --> Total execution time: 0.0448
DEBUG - 2022-06-29 03:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:05:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 03:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:05:58 --> Total execution time: 0.1037
DEBUG - 2022-06-29 03:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:06:01 --> Total execution time: 0.0780
DEBUG - 2022-06-29 03:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:06:04 --> Total execution time: 0.0562
DEBUG - 2022-06-29 03:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:06:07 --> Total execution time: 0.0499
DEBUG - 2022-06-29 03:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:08:04 --> Total execution time: 0.0693
DEBUG - 2022-06-29 03:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:08:05 --> Total execution time: 0.0591
DEBUG - 2022-06-29 03:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:09:05 --> Total execution time: 0.0624
DEBUG - 2022-06-29 03:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:09:38 --> Total execution time: 0.0701
DEBUG - 2022-06-29 03:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:12:00 --> Total execution time: 0.1370
DEBUG - 2022-06-29 03:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:13:31 --> Total execution time: 0.0581
DEBUG - 2022-06-29 03:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:44:09 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:14:09 --> Total execution time: 0.0626
DEBUG - 2022-06-29 03:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:14:22 --> Total execution time: 0.1248
DEBUG - 2022-06-29 03:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:14:38 --> Total execution time: 0.0682
DEBUG - 2022-06-29 03:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:14:44 --> Total execution time: 0.0562
DEBUG - 2022-06-29 03:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:14:47 --> Total execution time: 0.0546
DEBUG - 2022-06-29 03:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:15:03 --> Total execution time: 0.0546
DEBUG - 2022-06-29 03:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:15:21 --> Total execution time: 0.0565
DEBUG - 2022-06-29 03:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:15:27 --> Total execution time: 0.0908
DEBUG - 2022-06-29 03:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:15:37 --> Total execution time: 0.1222
DEBUG - 2022-06-29 03:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:45:48 --> Total execution time: 0.0389
DEBUG - 2022-06-29 03:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:15:49 --> Total execution time: 0.0798
DEBUG - 2022-06-29 03:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:45:50 --> Total execution time: 0.0545
DEBUG - 2022-06-29 03:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:45:50 --> Total execution time: 0.0689
DEBUG - 2022-06-29 03:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:16:03 --> Total execution time: 0.0521
DEBUG - 2022-06-29 03:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:46:03 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:16:03 --> Total execution time: 0.0507
DEBUG - 2022-06-29 03:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:16:08 --> Total execution time: 0.0510
DEBUG - 2022-06-29 03:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:16:10 --> Total execution time: 0.0606
DEBUG - 2022-06-29 03:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:16:15 --> Total execution time: 0.0838
DEBUG - 2022-06-29 03:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:16:16 --> Total execution time: 0.0700
DEBUG - 2022-06-29 03:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:46:36 --> Total execution time: 0.0598
DEBUG - 2022-06-29 03:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:47:04 --> Total execution time: 0.0519
DEBUG - 2022-06-29 03:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:47:10 --> Total execution time: 0.0472
DEBUG - 2022-06-29 03:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:47:11 --> Total execution time: 0.0768
DEBUG - 2022-06-29 03:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:47:11 --> Total execution time: 0.1037
DEBUG - 2022-06-29 03:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:47:52 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:17:52 --> Total execution time: 0.0535
DEBUG - 2022-06-29 03:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:18:11 --> Total execution time: 0.0661
DEBUG - 2022-06-29 03:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:18:13 --> Total execution time: 0.0834
DEBUG - 2022-06-29 03:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:18:27 --> Total execution time: 0.0657
DEBUG - 2022-06-29 03:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:18:35 --> Total execution time: 0.0531
DEBUG - 2022-06-29 03:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:18:51 --> Total execution time: 0.0522
DEBUG - 2022-06-29 03:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:18:52 --> Total execution time: 0.0493
DEBUG - 2022-06-29 03:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:19:04 --> Total execution time: 0.0505
DEBUG - 2022-06-29 03:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:49:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 03:49:05 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-29 03:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:49:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 03:49:09 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-29 03:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:19:14 --> Total execution time: 0.0564
DEBUG - 2022-06-29 03:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:19:21 --> Total execution time: 0.0577
DEBUG - 2022-06-29 03:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:19:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 03:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:19:22 --> Total execution time: 0.0568
DEBUG - 2022-06-29 03:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:49:39 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:19:39 --> Total execution time: 0.0346
DEBUG - 2022-06-29 03:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:49:43 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:19:43 --> Total execution time: 0.0424
DEBUG - 2022-06-29 03:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:19:49 --> Total execution time: 0.0476
DEBUG - 2022-06-29 03:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:20:00 --> Total execution time: 0.0786
DEBUG - 2022-06-29 03:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:20:33 --> Total execution time: 0.0552
DEBUG - 2022-06-29 03:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:20:48 --> Total execution time: 0.1226
DEBUG - 2022-06-29 03:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:21:37 --> Total execution time: 0.0745
DEBUG - 2022-06-29 03:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:21:47 --> Total execution time: 0.0872
DEBUG - 2022-06-29 03:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:22:01 --> Total execution time: 0.0913
DEBUG - 2022-06-29 03:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:22:28 --> Total execution time: 0.0470
DEBUG - 2022-06-29 03:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:23:18 --> Total execution time: 0.0918
DEBUG - 2022-06-29 03:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:23:36 --> Total execution time: 0.0633
DEBUG - 2022-06-29 03:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:23:36 --> Total execution time: 0.0458
DEBUG - 2022-06-29 03:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:23:45 --> Total execution time: 0.1461
DEBUG - 2022-06-29 03:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:23:49 --> Total execution time: 0.0649
DEBUG - 2022-06-29 03:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:53:53 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:23:53 --> Total execution time: 0.1278
DEBUG - 2022-06-29 03:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:23:55 --> Total execution time: 0.0934
DEBUG - 2022-06-29 03:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:23:55 --> Total execution time: 0.0613
DEBUG - 2022-06-29 03:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:23:58 --> Total execution time: 0.1478
DEBUG - 2022-06-29 03:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:54:00 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:24:00 --> Total execution time: 0.0784
DEBUG - 2022-06-29 03:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:24:10 --> Total execution time: 0.0969
DEBUG - 2022-06-29 03:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:24:18 --> Total execution time: 0.0557
DEBUG - 2022-06-29 03:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:54:22 --> Total execution time: 0.0519
DEBUG - 2022-06-29 03:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:24:23 --> Total execution time: 0.0577
DEBUG - 2022-06-29 03:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:24:27 --> Total execution time: 0.0846
DEBUG - 2022-06-29 03:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:54:39 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:24:39 --> Total execution time: 0.0385
DEBUG - 2022-06-29 03:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:24:43 --> Total execution time: 0.0566
DEBUG - 2022-06-29 03:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:54:48 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:24:48 --> Total execution time: 0.0505
DEBUG - 2022-06-29 03:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:24:57 --> Total execution time: 0.0960
DEBUG - 2022-06-29 03:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:25:09 --> Total execution time: 0.0496
DEBUG - 2022-06-29 03:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:25:11 --> Total execution time: 0.0299
DEBUG - 2022-06-29 03:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:25:42 --> Total execution time: 0.0803
DEBUG - 2022-06-29 03:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:25:44 --> Total execution time: 0.0769
DEBUG - 2022-06-29 03:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:25:46 --> Total execution time: 0.0447
DEBUG - 2022-06-29 03:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:55:46 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:25:46 --> Total execution time: 0.0357
DEBUG - 2022-06-29 03:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:55:47 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:25:47 --> Total execution time: 0.0481
DEBUG - 2022-06-29 03:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:55:53 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:25:53 --> Total execution time: 0.0604
DEBUG - 2022-06-29 03:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:26:05 --> Total execution time: 0.0359
DEBUG - 2022-06-29 03:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:26:11 --> Total execution time: 0.0698
DEBUG - 2022-06-29 03:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:26:44 --> Total execution time: 0.0475
DEBUG - 2022-06-29 03:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:26:49 --> Total execution time: 0.0525
DEBUG - 2022-06-29 03:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:26:58 --> Total execution time: 0.1378
DEBUG - 2022-06-29 03:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:27:08 --> Total execution time: 0.0528
DEBUG - 2022-06-29 03:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:27:18 --> Total execution time: 0.0481
DEBUG - 2022-06-29 03:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:27:22 --> Total execution time: 0.0571
DEBUG - 2022-06-29 03:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:27:45 --> Total execution time: 0.0407
DEBUG - 2022-06-29 03:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:27:47 --> Total execution time: 0.0623
DEBUG - 2022-06-29 03:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:57:50 --> No URI present. Default controller set.
DEBUG - 2022-06-29 03:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:27:50 --> Total execution time: 0.1229
DEBUG - 2022-06-29 03:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:27:59 --> Total execution time: 0.0600
DEBUG - 2022-06-29 03:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:28:10 --> Total execution time: 0.0586
DEBUG - 2022-06-29 03:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 03:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:28:50 --> Total execution time: 0.0414
DEBUG - 2022-06-29 03:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:29:04 --> Total execution time: 0.0702
DEBUG - 2022-06-29 03:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:29:06 --> Total execution time: 0.0501
DEBUG - 2022-06-29 03:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:29:15 --> Total execution time: 0.0463
DEBUG - 2022-06-29 03:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 03:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 03:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:29:47 --> Total execution time: 0.0551
DEBUG - 2022-06-29 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:30:02 --> Total execution time: 0.0712
DEBUG - 2022-06-29 04:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:30:40 --> Total execution time: 0.1245
DEBUG - 2022-06-29 04:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:30:52 --> Total execution time: 0.0840
DEBUG - 2022-06-29 04:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:32:48 --> Total execution time: 0.0576
DEBUG - 2022-06-29 04:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:03:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 04:03:42 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-29 04:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:33:54 --> Total execution time: 0.1389
DEBUG - 2022-06-29 04:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:35:03 --> Total execution time: 0.0377
DEBUG - 2022-06-29 04:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:05:20 --> Total execution time: 0.0616
DEBUG - 2022-06-29 04:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:35:27 --> Total execution time: 0.1141
DEBUG - 2022-06-29 04:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:05:45 --> Total execution time: 0.0471
DEBUG - 2022-06-29 04:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:05:51 --> Total execution time: 0.0474
DEBUG - 2022-06-29 04:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:05:57 --> Total execution time: 0.0768
DEBUG - 2022-06-29 04:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:05:59 --> Total execution time: 0.0542
DEBUG - 2022-06-29 04:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:06:00 --> Total execution time: 0.0458
DEBUG - 2022-06-29 04:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:36:02 --> Total execution time: 0.0514
DEBUG - 2022-06-29 04:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:36:03 --> Total execution time: 0.0635
DEBUG - 2022-06-29 04:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:06:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 04:06:12 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-29 04:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:06:26 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:36:26 --> Total execution time: 0.0592
DEBUG - 2022-06-29 04:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:06:26 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:36:26 --> Total execution time: 0.0339
DEBUG - 2022-06-29 04:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:06:28 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:36:29 --> Total execution time: 0.0378
DEBUG - 2022-06-29 04:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:06:36 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:36:36 --> Total execution time: 0.0492
DEBUG - 2022-06-29 04:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:06:48 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:36:48 --> Total execution time: 0.0527
DEBUG - 2022-06-29 04:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:06:52 --> Total execution time: 0.0518
DEBUG - 2022-06-29 04:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:06:54 --> Total execution time: 0.0545
DEBUG - 2022-06-29 04:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:06:54 --> Total execution time: 0.1153
DEBUG - 2022-06-29 04:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:06:59 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:36:59 --> Total execution time: 0.0624
DEBUG - 2022-06-29 04:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:08:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 04:08:21 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-29 04:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:39:01 --> Total execution time: 0.0515
DEBUG - 2022-06-29 04:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:09:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 04:09:26 --> 404 Page Not Found: User/update-thumbnail
DEBUG - 2022-06-29 04:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:09:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 04:09:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 04:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:39:31 --> Total execution time: 0.1142
DEBUG - 2022-06-29 04:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:39:48 --> Total execution time: 0.0598
DEBUG - 2022-06-29 04:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:10:37 --> Total execution time: 0.0629
DEBUG - 2022-06-29 04:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:10:39 --> Total execution time: 0.0545
DEBUG - 2022-06-29 04:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:10:39 --> Total execution time: 0.0928
DEBUG - 2022-06-29 04:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:40:54 --> Total execution time: 0.0448
DEBUG - 2022-06-29 04:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:10:56 --> Total execution time: 0.0484
DEBUG - 2022-06-29 04:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:10:58 --> Total execution time: 0.0684
DEBUG - 2022-06-29 04:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:10:58 --> Total execution time: 0.0978
DEBUG - 2022-06-29 04:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:41:00 --> Total execution time: 0.0473
DEBUG - 2022-06-29 04:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:41:22 --> Total execution time: 0.0685
DEBUG - 2022-06-29 04:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:41:23 --> Total execution time: 0.0449
DEBUG - 2022-06-29 04:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:41:24 --> Total execution time: 0.0762
DEBUG - 2022-06-29 04:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:41:36 --> Total execution time: 0.0563
DEBUG - 2022-06-29 04:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:41:37 --> Total execution time: 0.0463
DEBUG - 2022-06-29 04:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:41:53 --> Total execution time: 0.0538
DEBUG - 2022-06-29 04:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:42:26 --> Total execution time: 0.0692
DEBUG - 2022-06-29 04:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:44:10 --> Total execution time: 0.0527
DEBUG - 2022-06-29 04:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:47:33 --> Total execution time: 0.1195
DEBUG - 2022-06-29 04:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:47:34 --> Total execution time: 0.0493
DEBUG - 2022-06-29 04:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:47:52 --> Total execution time: 0.0751
DEBUG - 2022-06-29 04:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:18:21 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:48:21 --> Total execution time: 0.0376
DEBUG - 2022-06-29 04:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:18:22 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:48:22 --> Total execution time: 0.0602
DEBUG - 2022-06-29 04:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:18:56 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:48:56 --> Total execution time: 0.0362
DEBUG - 2022-06-29 04:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:06 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:19:06 --> Total execution time: 0.0412
DEBUG - 2022-06-29 04:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:49:06 --> Total execution time: 0.0407
DEBUG - 2022-06-29 04:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:07 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:49:07 --> Total execution time: 0.0338
DEBUG - 2022-06-29 04:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:19:08 --> Total execution time: 0.0586
DEBUG - 2022-06-29 04:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:19:08 --> Total execution time: 0.0980
DEBUG - 2022-06-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:13 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:49:13 --> Total execution time: 0.0473
DEBUG - 2022-06-29 04:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:49:16 --> Total execution time: 0.0372
DEBUG - 2022-06-29 04:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:19 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:49:19 --> Total execution time: 0.0650
DEBUG - 2022-06-29 04:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:19:21 --> Total execution time: 0.0492
DEBUG - 2022-06-29 04:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:49:36 --> Total execution time: 0.0568
DEBUG - 2022-06-29 04:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:49:49 --> Total execution time: 0.0616
DEBUG - 2022-06-29 04:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:19:50 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 04:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:49:52 --> Total execution time: 1.8866
DEBUG - 2022-06-29 04:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:49:53 --> Total execution time: 0.0637
DEBUG - 2022-06-29 04:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 04:19:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 04:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:49:56 --> Total execution time: 0.0640
DEBUG - 2022-06-29 04:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:50:03 --> Total execution time: 0.0540
DEBUG - 2022-06-29 04:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:20:07 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:50:07 --> Total execution time: 0.0965
DEBUG - 2022-06-29 04:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:50:07 --> Total execution time: 0.1601
DEBUG - 2022-06-29 04:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:50:15 --> Total execution time: 0.0485
DEBUG - 2022-06-29 04:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:20:16 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:50:16 --> Total execution time: 0.0478
DEBUG - 2022-06-29 04:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:50:22 --> Total execution time: 0.0473
DEBUG - 2022-06-29 04:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:50:24 --> Total execution time: 0.0826
DEBUG - 2022-06-29 04:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:50:28 --> Total execution time: 0.0518
DEBUG - 2022-06-29 04:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:50:40 --> Total execution time: 0.0465
DEBUG - 2022-06-29 04:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:50:51 --> Total execution time: 0.0643
DEBUG - 2022-06-29 04:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:50:56 --> Total execution time: 0.0782
DEBUG - 2022-06-29 04:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:51:01 --> Total execution time: 0.0541
DEBUG - 2022-06-29 04:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:51:04 --> Total execution time: 0.0487
DEBUG - 2022-06-29 04:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:52:10 --> Total execution time: 0.0583
DEBUG - 2022-06-29 04:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:52:28 --> Total execution time: 0.0537
DEBUG - 2022-06-29 04:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:52:38 --> Total execution time: 0.0684
DEBUG - 2022-06-29 04:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:52:49 --> Total execution time: 0.0556
DEBUG - 2022-06-29 04:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:52:59 --> Total execution time: 0.1161
DEBUG - 2022-06-29 14:52:59 --> Total execution time: 0.1221
DEBUG - 2022-06-29 04:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:23:06 --> Total execution time: 0.0687
DEBUG - 2022-06-29 04:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:53:10 --> Total execution time: 0.0612
DEBUG - 2022-06-29 04:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:53:23 --> Total execution time: 0.0638
DEBUG - 2022-06-29 04:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:53:29 --> Total execution time: 0.0653
DEBUG - 2022-06-29 04:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:53:44 --> Total execution time: 0.0643
DEBUG - 2022-06-29 04:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:54:02 --> Total execution time: 0.0520
DEBUG - 2022-06-29 04:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:24:14 --> Total execution time: 0.0514
DEBUG - 2022-06-29 04:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:54:19 --> Total execution time: 0.0472
DEBUG - 2022-06-29 04:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:25:21 --> Total execution time: 0.1293
DEBUG - 2022-06-29 04:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:55:24 --> Total execution time: 0.0778
DEBUG - 2022-06-29 04:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:55:41 --> Total execution time: 0.0508
DEBUG - 2022-06-29 04:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:55:46 --> Total execution time: 0.0535
DEBUG - 2022-06-29 04:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:56:22 --> Total execution time: 0.0850
DEBUG - 2022-06-29 04:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:56:42 --> Total execution time: 0.0522
DEBUG - 2022-06-29 04:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:58:17 --> Total execution time: 0.0533
DEBUG - 2022-06-29 04:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:58:44 --> Total execution time: 0.0652
DEBUG - 2022-06-29 04:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:59:10 --> Total execution time: 0.0449
DEBUG - 2022-06-29 04:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:59:52 --> Total execution time: 0.0625
DEBUG - 2022-06-29 04:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:00:56 --> Total execution time: 0.0726
DEBUG - 2022-06-29 04:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:00:59 --> Total execution time: 0.1135
DEBUG - 2022-06-29 04:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:01:07 --> Total execution time: 0.1365
DEBUG - 2022-06-29 04:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:31:42 --> Total execution time: 0.0482
DEBUG - 2022-06-29 04:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:31:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 04:31:48 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-29 04:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:31:57 --> Total execution time: 0.0820
DEBUG - 2022-06-29 04:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:02:10 --> Total execution time: 0.0525
DEBUG - 2022-06-29 04:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:02:32 --> Total execution time: 0.1212
DEBUG - 2022-06-29 04:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:02:36 --> Total execution time: 0.0520
DEBUG - 2022-06-29 04:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:32:45 --> Total execution time: 0.0434
DEBUG - 2022-06-29 04:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:02:47 --> Total execution time: 0.0634
DEBUG - 2022-06-29 04:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:02:52 --> Total execution time: 0.0868
DEBUG - 2022-06-29 04:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:03:05 --> Total execution time: 0.0581
DEBUG - 2022-06-29 04:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:33:15 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:03:15 --> Total execution time: 0.0425
DEBUG - 2022-06-29 04:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:03:40 --> Total execution time: 0.0488
DEBUG - 2022-06-29 04:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:03:58 --> Total execution time: 0.1019
DEBUG - 2022-06-29 04:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:04:00 --> Total execution time: 0.0490
DEBUG - 2022-06-29 04:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:35:31 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:05:31 --> Total execution time: 0.0393
DEBUG - 2022-06-29 04:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:41:05 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:11:05 --> Total execution time: 0.1968
DEBUG - 2022-06-29 04:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:11:05 --> Total execution time: 0.0671
DEBUG - 2022-06-29 04:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:11:12 --> Total execution time: 0.0598
DEBUG - 2022-06-29 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:11:22 --> Total execution time: 0.0536
DEBUG - 2022-06-29 04:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:11:27 --> Total execution time: 0.0577
DEBUG - 2022-06-29 04:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:11:31 --> Total execution time: 0.0631
DEBUG - 2022-06-29 04:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:11:45 --> Total execution time: 0.0471
DEBUG - 2022-06-29 04:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:12:09 --> Total execution time: 0.1338
DEBUG - 2022-06-29 04:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:13:48 --> Total execution time: 0.0333
DEBUG - 2022-06-29 04:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:18:25 --> Total execution time: 0.1625
DEBUG - 2022-06-29 04:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:18:28 --> Total execution time: 0.1222
DEBUG - 2022-06-29 04:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:48:38 --> Total execution time: 0.1185
DEBUG - 2022-06-29 04:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:18:41 --> Total execution time: 0.0591
DEBUG - 2022-06-29 04:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:50:04 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:20:04 --> Total execution time: 0.0433
DEBUG - 2022-06-29 04:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:50:04 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:20:04 --> Total execution time: 0.0348
DEBUG - 2022-06-29 04:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:20:09 --> Total execution time: 0.0433
DEBUG - 2022-06-29 04:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:24:11 --> Total execution time: 0.1433
DEBUG - 2022-06-29 04:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:54:37 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:24:37 --> Total execution time: 0.0546
DEBUG - 2022-06-29 04:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:24:40 --> Total execution time: 0.0522
DEBUG - 2022-06-29 04:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 04:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:25:02 --> Total execution time: 0.1126
DEBUG - 2022-06-29 04:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:25:09 --> Total execution time: 0.0921
DEBUG - 2022-06-29 04:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:55:21 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:25:21 --> Total execution time: 0.0371
DEBUG - 2022-06-29 04:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:55:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 04:55:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 04:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:56:12 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:26:12 --> Total execution time: 0.0333
DEBUG - 2022-06-29 04:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:26:43 --> Total execution time: 0.0529
DEBUG - 2022-06-29 04:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:27:39 --> Total execution time: 0.1167
DEBUG - 2022-06-29 04:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:28:04 --> Total execution time: 0.0694
DEBUG - 2022-06-29 04:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:28:04 --> Total execution time: 0.0578
DEBUG - 2022-06-29 04:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:58:10 --> No URI present. Default controller set.
DEBUG - 2022-06-29 04:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:28:10 --> Total execution time: 0.0490
DEBUG - 2022-06-29 04:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:28:35 --> Total execution time: 0.0440
DEBUG - 2022-06-29 04:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:29:00 --> Total execution time: 0.1480
DEBUG - 2022-06-29 04:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:29:04 --> Total execution time: 0.0674
DEBUG - 2022-06-29 04:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:29:11 --> Total execution time: 0.0447
DEBUG - 2022-06-29 04:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 04:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 04:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:29:44 --> Total execution time: 0.0457
DEBUG - 2022-06-29 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:30:02 --> Total execution time: 0.0649
DEBUG - 2022-06-29 05:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:30:03 --> Total execution time: 0.1229
DEBUG - 2022-06-29 05:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:30:09 --> Total execution time: 0.0812
DEBUG - 2022-06-29 05:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:30:43 --> Total execution time: 0.0531
DEBUG - 2022-06-29 05:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:31:03 --> Total execution time: 0.0557
DEBUG - 2022-06-29 05:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:31:24 --> Total execution time: 0.0711
DEBUG - 2022-06-29 05:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:31:45 --> Total execution time: 0.0515
DEBUG - 2022-06-29 05:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:31:53 --> Total execution time: 0.0466
DEBUG - 2022-06-29 05:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:31:53 --> Total execution time: 0.0468
DEBUG - 2022-06-29 05:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:32:13 --> Total execution time: 0.0484
DEBUG - 2022-06-29 05:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:32:28 --> Total execution time: 0.0442
DEBUG - 2022-06-29 05:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:32:56 --> Total execution time: 0.0851
DEBUG - 2022-06-29 05:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:32:56 --> Total execution time: 0.1402
DEBUG - 2022-06-29 05:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:33:00 --> Total execution time: 0.0521
DEBUG - 2022-06-29 05:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:33:03 --> Total execution time: 0.0676
DEBUG - 2022-06-29 05:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:33:59 --> Total execution time: 0.0685
DEBUG - 2022-06-29 05:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:34:00 --> Total execution time: 0.0436
DEBUG - 2022-06-29 05:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:34:02 --> Total execution time: 0.0472
DEBUG - 2022-06-29 05:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:34:06 --> Total execution time: 0.0457
DEBUG - 2022-06-29 05:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:34:09 --> Total execution time: 0.0478
DEBUG - 2022-06-29 05:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:34:12 --> Total execution time: 0.0472
DEBUG - 2022-06-29 05:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:34:14 --> Total execution time: 0.0506
DEBUG - 2022-06-29 05:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:34:17 --> Total execution time: 0.0458
DEBUG - 2022-06-29 05:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:34:20 --> Total execution time: 0.0450
DEBUG - 2022-06-29 05:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:34:24 --> Total execution time: 0.0459
DEBUG - 2022-06-29 05:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:34:28 --> Total execution time: 0.0468
DEBUG - 2022-06-29 05:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:34:31 --> Total execution time: 0.0534
DEBUG - 2022-06-29 05:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:34:49 --> Total execution time: 0.0546
DEBUG - 2022-06-29 05:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:35:18 --> Total execution time: 0.1138
DEBUG - 2022-06-29 05:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:35:28 --> Total execution time: 0.0482
DEBUG - 2022-06-29 05:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:35:51 --> Total execution time: 0.0518
DEBUG - 2022-06-29 05:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:35:52 --> Total execution time: 0.0523
DEBUG - 2022-06-29 05:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:36:15 --> Total execution time: 0.0437
DEBUG - 2022-06-29 05:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:06:37 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:36:37 --> Total execution time: 0.0484
DEBUG - 2022-06-29 05:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:36:37 --> Total execution time: 0.0387
DEBUG - 2022-06-29 05:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:36:54 --> Total execution time: 0.0520
DEBUG - 2022-06-29 05:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:37:10 --> Total execution time: 0.0660
DEBUG - 2022-06-29 05:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:37:54 --> Total execution time: 0.0797
DEBUG - 2022-06-29 05:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:38:12 --> Total execution time: 0.0664
DEBUG - 2022-06-29 05:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:38:18 --> Total execution time: 0.0464
DEBUG - 2022-06-29 05:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:38:38 --> Total execution time: 0.0521
DEBUG - 2022-06-29 05:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:39:12 --> Total execution time: 0.0479
DEBUG - 2022-06-29 05:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:39:30 --> Total execution time: 0.0580
DEBUG - 2022-06-29 05:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:39:38 --> Total execution time: 0.0702
DEBUG - 2022-06-29 05:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:39:52 --> Total execution time: 0.0862
DEBUG - 2022-06-29 05:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:12:12 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:42:12 --> Total execution time: 0.1326
DEBUG - 2022-06-29 05:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:12:50 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:42:50 --> Total execution time: 0.0387
DEBUG - 2022-06-29 05:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:13:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:13:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 05:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:14:46 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:44:47 --> Total execution time: 0.1198
DEBUG - 2022-06-29 05:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:15:08 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:45:08 --> Total execution time: 0.0578
DEBUG - 2022-06-29 05:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:15:27 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:45:27 --> Total execution time: 0.1206
DEBUG - 2022-06-29 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:45:28 --> Total execution time: 0.0305
DEBUG - 2022-06-29 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:15:28 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:45:28 --> Total execution time: 0.0516
DEBUG - 2022-06-29 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:15:28 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:45:28 --> Total execution time: 0.0558
DEBUG - 2022-06-29 05:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:45:30 --> Total execution time: 0.0826
DEBUG - 2022-06-29 05:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:16:11 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:46:11 --> Total execution time: 0.0503
DEBUG - 2022-06-29 05:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:46:18 --> Total execution time: 0.0677
DEBUG - 2022-06-29 05:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:46:27 --> Total execution time: 0.0719
DEBUG - 2022-06-29 05:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:46:44 --> Total execution time: 0.0527
DEBUG - 2022-06-29 05:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:46:48 --> Total execution time: 0.0830
DEBUG - 2022-06-29 05:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:46:56 --> Total execution time: 0.0596
DEBUG - 2022-06-29 05:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:47:01 --> Total execution time: 0.0602
DEBUG - 2022-06-29 05:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:47:15 --> Total execution time: 0.1387
DEBUG - 2022-06-29 05:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:23 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:47:23 --> Total execution time: 0.0526
DEBUG - 2022-06-29 05:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:47:30 --> Total execution time: 0.0602
DEBUG - 2022-06-29 05:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:47:31 --> Total execution time: 0.0368
DEBUG - 2022-06-29 05:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:32 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:47:32 --> Total execution time: 0.0520
DEBUG - 2022-06-29 05:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:47:34 --> Total execution time: 0.0302
DEBUG - 2022-06-29 05:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:47:34 --> Total execution time: 0.0261
DEBUG - 2022-06-29 05:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:47:36 --> Total execution time: 0.0454
DEBUG - 2022-06-29 05:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:47:40 --> Total execution time: 0.0376
DEBUG - 2022-06-29 05:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:47:41 --> Total execution time: 0.0431
DEBUG - 2022-06-29 05:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:47:42 --> Total execution time: 0.0442
DEBUG - 2022-06-29 05:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:47:44 --> Total execution time: 0.0495
DEBUG - 2022-06-29 05:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:47:49 --> Total execution time: 0.0571
DEBUG - 2022-06-29 05:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:47:49 --> Total execution time: 0.0761
DEBUG - 2022-06-29 05:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:48:00 --> Total execution time: 0.0609
DEBUG - 2022-06-29 05:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:48:18 --> Total execution time: 0.0811
DEBUG - 2022-06-29 05:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:48:34 --> Total execution time: 0.0351
DEBUG - 2022-06-29 05:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:48:38 --> Total execution time: 0.0575
DEBUG - 2022-06-29 05:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:48:39 --> Total execution time: 0.0462
DEBUG - 2022-06-29 05:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:48:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 05:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:48:40 --> Total execution time: 0.0489
DEBUG - 2022-06-29 05:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:19:02 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:49:02 --> Total execution time: 0.0377
DEBUG - 2022-06-29 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:22:09 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:52:09 --> Total execution time: 0.1315
DEBUG - 2022-06-29 05:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:22:37 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:52:37 --> Total execution time: 0.0351
DEBUG - 2022-06-29 05:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:22:52 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:52:52 --> Total execution time: 0.0461
DEBUG - 2022-06-29 05:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:52:59 --> Total execution time: 0.0698
DEBUG - 2022-06-29 05:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:23:06 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:53:06 --> Total execution time: 0.0514
DEBUG - 2022-06-29 05:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:53:09 --> Total execution time: 0.0695
DEBUG - 2022-06-29 05:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:23:32 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:53:32 --> Total execution time: 0.1214
DEBUG - 2022-06-29 05:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:53:38 --> Total execution time: 0.0734
DEBUG - 2022-06-29 05:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:53:40 --> Total execution time: 0.0469
DEBUG - 2022-06-29 05:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:53:40 --> Total execution time: 0.0561
DEBUG - 2022-06-29 05:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:53:47 --> Total execution time: 0.1272
DEBUG - 2022-06-29 05:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:53:54 --> Total execution time: 0.0518
DEBUG - 2022-06-29 05:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:23:56 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:53:56 --> Total execution time: 0.0491
DEBUG - 2022-06-29 05:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:54:03 --> Total execution time: 0.0828
DEBUG - 2022-06-29 05:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:24:13 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:54:13 --> Total execution time: 0.0522
DEBUG - 2022-06-29 05:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:54:13 --> Total execution time: 0.0612
DEBUG - 2022-06-29 05:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:54:24 --> Total execution time: 0.0615
DEBUG - 2022-06-29 05:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:54:34 --> Total execution time: 0.0495
DEBUG - 2022-06-29 05:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:54:35 --> Total execution time: 0.0501
DEBUG - 2022-06-29 05:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:54:37 --> Total execution time: 0.0467
DEBUG - 2022-06-29 05:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:24:38 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:54:38 --> Total execution time: 0.1445
DEBUG - 2022-06-29 05:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:54:39 --> Total execution time: 0.0449
DEBUG - 2022-06-29 05:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:25:19 --> 404 Page Not Found: Course/clickbank-mastery
DEBUG - 2022-06-29 05:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:25:49 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:55:49 --> Total execution time: 0.0463
DEBUG - 2022-06-29 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:55:52 --> Total execution time: 0.0514
DEBUG - 2022-06-29 05:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:55:59 --> Total execution time: 0.0493
DEBUG - 2022-06-29 05:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:56:11 --> Total execution time: 0.0826
DEBUG - 2022-06-29 05:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:56:17 --> Total execution time: 0.0679
DEBUG - 2022-06-29 05:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:56:29 --> Total execution time: 0.0522
DEBUG - 2022-06-29 05:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:56:35 --> Total execution time: 0.0521
DEBUG - 2022-06-29 05:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:02:53 --> Total execution time: 0.0475
DEBUG - 2022-06-29 05:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:03 --> Total execution time: 0.0796
DEBUG - 2022-06-29 05:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:13 --> Total execution time: 0.0622
DEBUG - 2022-06-29 05:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:17 --> Total execution time: 0.0738
DEBUG - 2022-06-29 05:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:22 --> Total execution time: 0.0641
DEBUG - 2022-06-29 05:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:26 --> Total execution time: 0.0901
DEBUG - 2022-06-29 05:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:33 --> Total execution time: 0.0559
DEBUG - 2022-06-29 05:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:39 --> Total execution time: 0.0668
DEBUG - 2022-06-29 05:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:41 --> Total execution time: 0.0779
DEBUG - 2022-06-29 05:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:42 --> Total execution time: 0.0490
DEBUG - 2022-06-29 05:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:44 --> Total execution time: 0.0611
DEBUG - 2022-06-29 05:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:45 --> Total execution time: 0.1127
DEBUG - 2022-06-29 05:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:33:45 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:45 --> Total execution time: 0.0551
DEBUG - 2022-06-29 05:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:34:51 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:04:52 --> Total execution time: 0.0784
DEBUG - 2022-06-29 05:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:04:57 --> Total execution time: 0.0518
DEBUG - 2022-06-29 05:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:05:12 --> Total execution time: 0.0624
DEBUG - 2022-06-29 05:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:05:25 --> Total execution time: 0.0712
DEBUG - 2022-06-29 05:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:35:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:35:30 --> 404 Page Not Found: Wp-admin/admin-ajax.php
DEBUG - 2022-06-29 05:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:35:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:35:32 --> 404 Page Not Found: Wp-configtxt/index
DEBUG - 2022-06-29 05:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:05:37 --> Total execution time: 0.0681
DEBUG - 2022-06-29 05:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:05:41 --> Total execution time: 0.0617
DEBUG - 2022-06-29 05:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:05:49 --> Total execution time: 0.0617
DEBUG - 2022-06-29 05:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:05:56 --> Total execution time: 0.0674
DEBUG - 2022-06-29 05:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:05:59 --> Total execution time: 0.1183
DEBUG - 2022-06-29 05:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:06:07 --> Total execution time: 0.0575
DEBUG - 2022-06-29 05:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:06:15 --> Total execution time: 0.0518
DEBUG - 2022-06-29 05:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:06:19 --> Total execution time: 0.0562
DEBUG - 2022-06-29 05:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:06:23 --> Total execution time: 0.0531
DEBUG - 2022-06-29 05:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:06:27 --> Total execution time: 0.0520
DEBUG - 2022-06-29 05:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:06:31 --> Total execution time: 0.0591
DEBUG - 2022-06-29 05:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:06:35 --> Total execution time: 0.0648
DEBUG - 2022-06-29 05:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:06:46 --> Total execution time: 0.1254
DEBUG - 2022-06-29 05:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:07:01 --> Total execution time: 0.0612
DEBUG - 2022-06-29 05:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:07:16 --> Total execution time: 0.0575
DEBUG - 2022-06-29 05:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:07:19 --> Total execution time: 0.0590
DEBUG - 2022-06-29 05:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:07:31 --> Total execution time: 0.0752
DEBUG - 2022-06-29 05:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:37:40 --> Total execution time: 0.0646
DEBUG - 2022-06-29 05:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:07:49 --> Total execution time: 0.0546
DEBUG - 2022-06-29 05:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:07:53 --> Total execution time: 0.0702
DEBUG - 2022-06-29 05:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:08:05 --> Total execution time: 0.0576
DEBUG - 2022-06-29 05:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:09:09 --> Total execution time: 0.0669
DEBUG - 2022-06-29 05:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:39:42 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:09:42 --> Total execution time: 0.0445
DEBUG - 2022-06-29 05:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:10:20 --> Total execution time: 0.1161
DEBUG - 2022-06-29 05:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:40:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:40:31 --> 404 Page Not Found: Course/clickbank-mastery
DEBUG - 2022-06-29 05:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:40:33 --> 404 Page Not Found: Course/clickbank-mastery
DEBUG - 2022-06-29 05:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:40:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:40:34 --> 404 Page Not Found: Course/clickbank-mastery
DEBUG - 2022-06-29 05:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:40:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:40:34 --> 404 Page Not Found: Course/clickbank-mastery
DEBUG - 2022-06-29 05:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:40:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:40:34 --> 404 Page Not Found: Course/clickbank-mastery
DEBUG - 2022-06-29 05:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:40:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:40:34 --> 404 Page Not Found: Lp-profile/courses
DEBUG - 2022-06-29 05:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:40:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:40:34 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-06-29 05:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:40:35 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-06-29 05:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:11:23 --> Total execution time: 0.0550
DEBUG - 2022-06-29 05:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:42:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:42:55 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-29 05:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:44:27 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:14:27 --> Total execution time: 0.1196
DEBUG - 2022-06-29 05:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:45:00 --> Total execution time: 0.0369
DEBUG - 2022-06-29 05:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:45:01 --> Total execution time: 0.0921
DEBUG - 2022-06-29 05:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:45:01 --> Total execution time: 0.1870
DEBUG - 2022-06-29 05:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:15:21 --> Total execution time: 0.0481
DEBUG - 2022-06-29 05:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:15:24 --> Total execution time: 0.0298
DEBUG - 2022-06-29 05:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:45:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:45:27 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-29 05:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:45:30 --> Total execution time: 0.0515
DEBUG - 2022-06-29 05:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:45:31 --> Total execution time: 0.0803
DEBUG - 2022-06-29 05:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:45:32 --> Total execution time: 0.1502
DEBUG - 2022-06-29 05:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:45:34 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:15:34 --> Total execution time: 0.0632
DEBUG - 2022-06-29 05:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:47:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:47:34 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-29 05:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:48:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:48:06 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-29 05:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:48:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 05:48:11 --> 404 Page Not Found: About-us/esalestrix.in
DEBUG - 2022-06-29 05:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:19:11 --> Total execution time: 0.1200
DEBUG - 2022-06-29 05:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:19:12 --> Total execution time: 0.0519
DEBUG - 2022-06-29 05:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:19:15 --> Total execution time: 0.0581
DEBUG - 2022-06-29 05:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:19:30 --> Total execution time: 0.0564
DEBUG - 2022-06-29 05:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:19:34 --> Total execution time: 0.0560
DEBUG - 2022-06-29 05:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:19:54 --> Total execution time: 0.0668
DEBUG - 2022-06-29 05:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:20:23 --> Total execution time: 0.0607
DEBUG - 2022-06-29 05:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:20:26 --> Total execution time: 0.0573
DEBUG - 2022-06-29 05:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 05:50:56 --> Total execution time: 0.0600
DEBUG - 2022-06-29 05:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:20:59 --> Total execution time: 0.0780
DEBUG - 2022-06-29 05:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:21:07 --> Total execution time: 0.0702
DEBUG - 2022-06-29 05:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:21:07 --> Total execution time: 0.0430
DEBUG - 2022-06-29 05:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:21:18 --> Total execution time: 0.0674
DEBUG - 2022-06-29 05:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:21:26 --> Total execution time: 0.0545
DEBUG - 2022-06-29 05:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:21:29 --> Total execution time: 0.0743
DEBUG - 2022-06-29 05:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:21:33 --> Total execution time: 0.0536
DEBUG - 2022-06-29 05:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:51:37 --> No URI present. Default controller set.
DEBUG - 2022-06-29 05:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:21:37 --> Total execution time: 0.0401
DEBUG - 2022-06-29 05:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:21:45 --> Total execution time: 0.0513
DEBUG - 2022-06-29 05:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:22:30 --> Total execution time: 0.0654
DEBUG - 2022-06-29 05:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:22:34 --> Total execution time: 0.0495
DEBUG - 2022-06-29 05:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:22:41 --> Total execution time: 0.0662
DEBUG - 2022-06-29 05:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:22:41 --> Total execution time: 0.0567
DEBUG - 2022-06-29 05:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:24:27 --> Total execution time: 0.1244
DEBUG - 2022-06-29 05:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:24:36 --> Total execution time: 0.0906
DEBUG - 2022-06-29 05:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:24:52 --> Total execution time: 0.0681
DEBUG - 2022-06-29 05:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:25:03 --> Total execution time: 0.0685
DEBUG - 2022-06-29 05:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:25:10 --> Total execution time: 0.0548
DEBUG - 2022-06-29 05:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:25:18 --> Total execution time: 0.0697
DEBUG - 2022-06-29 05:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:25:21 --> Total execution time: 0.0642
DEBUG - 2022-06-29 05:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 05:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 05:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:25:56 --> Total execution time: 0.0623
DEBUG - 2022-06-29 06:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:30:03 --> Total execution time: 0.2661
DEBUG - 2022-06-29 06:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:31:51 --> Total execution time: 0.1282
DEBUG - 2022-06-29 06:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:32:13 --> Total execution time: 0.0800
DEBUG - 2022-06-29 06:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:32:52 --> Total execution time: 0.1246
DEBUG - 2022-06-29 06:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:33:22 --> Total execution time: 0.1445
DEBUG - 2022-06-29 06:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:33:28 --> Total execution time: 0.0706
DEBUG - 2022-06-29 06:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:33:47 --> Total execution time: 0.0930
DEBUG - 2022-06-29 06:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:35:01 --> Total execution time: 0.1609
DEBUG - 2022-06-29 06:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:06:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 06:06:31 --> 404 Page Not Found: My-account/index
DEBUG - 2022-06-29 06:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:06:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 06:06:32 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 06:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:06:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 06:06:46 --> 404 Page Not Found: My-account/index
DEBUG - 2022-06-29 06:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:06:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 06:06:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 06:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:37:11 --> Total execution time: 0.1033
DEBUG - 2022-06-29 06:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:37:19 --> Total execution time: 0.0576
DEBUG - 2022-06-29 06:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:07:23 --> Total execution time: 0.0957
DEBUG - 2022-06-29 06:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:07:25 --> Total execution time: 0.0709
DEBUG - 2022-06-29 06:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:07:25 --> Total execution time: 0.1065
DEBUG - 2022-06-29 06:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:39:19 --> Total execution time: 0.1310
DEBUG - 2022-06-29 06:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:39:27 --> Total execution time: 0.1004
DEBUG - 2022-06-29 06:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:10:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 06:10:56 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-29 06:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:41:45 --> Total execution time: 0.0658
DEBUG - 2022-06-29 06:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:41:54 --> Total execution time: 0.0582
DEBUG - 2022-06-29 06:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:41:58 --> Total execution time: 0.1069
DEBUG - 2022-06-29 06:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:42:55 --> Total execution time: 0.1471
DEBUG - 2022-06-29 06:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:12:55 --> No URI present. Default controller set.
DEBUG - 2022-06-29 06:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:42:55 --> Total execution time: 0.0610
DEBUG - 2022-06-29 06:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:43:04 --> Total execution time: 0.0537
DEBUG - 2022-06-29 06:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:43:08 --> Total execution time: 0.0778
DEBUG - 2022-06-29 06:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:43:16 --> Total execution time: 0.0536
DEBUG - 2022-06-29 06:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:43:35 --> Total execution time: 0.0626
DEBUG - 2022-06-29 06:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:43:44 --> Total execution time: 0.0475
DEBUG - 2022-06-29 06:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:44:41 --> Total execution time: 0.0501
DEBUG - 2022-06-29 06:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:47:02 --> Total execution time: 0.0629
DEBUG - 2022-06-29 06:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:47:12 --> Total execution time: 0.0563
DEBUG - 2022-06-29 06:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:47:14 --> Total execution time: 0.0669
DEBUG - 2022-06-29 06:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:47:19 --> Total execution time: 0.1255
DEBUG - 2022-06-29 06:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:47:54 --> Total execution time: 0.1235
DEBUG - 2022-06-29 06:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:20:17 --> No URI present. Default controller set.
DEBUG - 2022-06-29 06:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:50:17 --> Total execution time: 0.0390
DEBUG - 2022-06-29 06:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:50:18 --> Total execution time: 0.0625
DEBUG - 2022-06-29 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:50:23 --> Total execution time: 0.0392
DEBUG - 2022-06-29 06:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:50:36 --> Total execution time: 0.0649
DEBUG - 2022-06-29 06:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:50:36 --> Total execution time: 0.0529
DEBUG - 2022-06-29 06:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:50:54 --> Total execution time: 0.0526
DEBUG - 2022-06-29 06:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:51:03 --> Total execution time: 0.0610
DEBUG - 2022-06-29 06:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:51:03 --> Total execution time: 0.0792
DEBUG - 2022-06-29 06:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:51:12 --> Total execution time: 0.0485
DEBUG - 2022-06-29 06:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:55:08 --> Total execution time: 0.0533
DEBUG - 2022-06-29 06:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:57:53 --> Total execution time: 0.2387
DEBUG - 2022-06-29 06:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:29:23 --> Total execution time: 0.0448
DEBUG - 2022-06-29 06:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:29:24 --> Total execution time: 0.0595
DEBUG - 2022-06-29 06:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:29:24 --> Total execution time: 0.1093
DEBUG - 2022-06-29 06:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:29:43 --> No URI present. Default controller set.
DEBUG - 2022-06-29 06:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:59:43 --> Total execution time: 0.0403
DEBUG - 2022-06-29 06:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:00:02 --> Total execution time: 0.1545
DEBUG - 2022-06-29 06:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:00:07 --> Total execution time: 0.0811
DEBUG - 2022-06-29 06:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:00:13 --> Total execution time: 0.0583
DEBUG - 2022-06-29 06:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:00:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 06:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:00:14 --> Total execution time: 0.0547
DEBUG - 2022-06-29 06:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:06:07 --> Total execution time: 0.1849
DEBUG - 2022-06-29 06:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:36:47 --> No URI present. Default controller set.
DEBUG - 2022-06-29 06:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:06:47 --> Total execution time: 0.0447
DEBUG - 2022-06-29 06:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:07:12 --> Total execution time: 0.0522
DEBUG - 2022-06-29 06:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:07:20 --> Total execution time: 0.1036
DEBUG - 2022-06-29 06:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:07:28 --> Total execution time: 0.0645
DEBUG - 2022-06-29 06:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:07:31 --> Total execution time: 0.0539
DEBUG - 2022-06-29 06:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:07:43 --> Total execution time: 0.0448
DEBUG - 2022-06-29 06:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:38:58 --> No URI present. Default controller set.
DEBUG - 2022-06-29 06:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:08:58 --> Total execution time: 0.0605
DEBUG - 2022-06-29 06:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:38:59 --> Total execution time: 0.0348
DEBUG - 2022-06-29 06:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:39:02 --> Total execution time: 0.0479
DEBUG - 2022-06-29 06:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:39:02 --> Total execution time: 0.1164
DEBUG - 2022-06-29 06:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:39:28 --> No URI present. Default controller set.
DEBUG - 2022-06-29 06:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:09:28 --> Total execution time: 0.0347
DEBUG - 2022-06-29 06:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:09:31 --> Total execution time: 0.0332
DEBUG - 2022-06-29 06:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:09:36 --> Total execution time: 0.0635
DEBUG - 2022-06-29 06:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:09:39 --> Total execution time: 0.0719
DEBUG - 2022-06-29 06:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:12:00 --> Total execution time: 0.2572
DEBUG - 2022-06-29 06:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:42:13 --> No URI present. Default controller set.
DEBUG - 2022-06-29 06:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:12:13 --> Total execution time: 0.0611
DEBUG - 2022-06-29 06:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:42:27 --> No URI present. Default controller set.
DEBUG - 2022-06-29 06:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:12:27 --> Total execution time: 0.0424
DEBUG - 2022-06-29 06:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:15:23 --> Total execution time: 0.1823
DEBUG - 2022-06-29 06:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:15:25 --> Total execution time: 0.0620
DEBUG - 2022-06-29 06:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:15:28 --> Total execution time: 0.0469
DEBUG - 2022-06-29 06:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:15:28 --> Total execution time: 0.0519
DEBUG - 2022-06-29 06:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:16:00 --> Total execution time: 0.0369
DEBUG - 2022-06-29 06:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:46:42 --> No URI present. Default controller set.
DEBUG - 2022-06-29 06:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:16:42 --> Total execution time: 0.0342
DEBUG - 2022-06-29 06:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:16:46 --> Total execution time: 0.0598
DEBUG - 2022-06-29 06:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:16:54 --> Total execution time: 0.0618
DEBUG - 2022-06-29 06:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:17:03 --> Total execution time: 0.0862
DEBUG - 2022-06-29 06:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:47:41 --> No URI present. Default controller set.
DEBUG - 2022-06-29 06:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:17:41 --> Total execution time: 0.0378
DEBUG - 2022-06-29 06:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:47:42 --> No URI present. Default controller set.
DEBUG - 2022-06-29 06:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:17:42 --> Total execution time: 0.0414
DEBUG - 2022-06-29 06:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:17:47 --> Total execution time: 0.0492
DEBUG - 2022-06-29 06:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:18:10 --> Total execution time: 0.0453
DEBUG - 2022-06-29 06:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:18:23 --> Total execution time: 0.0634
DEBUG - 2022-06-29 06:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:19:41 --> Total execution time: 0.0539
DEBUG - 2022-06-29 06:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:21:13 --> Total execution time: 0.0658
DEBUG - 2022-06-29 06:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:21:19 --> Total execution time: 0.0853
DEBUG - 2022-06-29 06:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:21:35 --> Total execution time: 0.0799
DEBUG - 2022-06-29 06:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:22:22 --> Total execution time: 0.0540
DEBUG - 2022-06-29 06:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:22:35 --> Total execution time: 0.0509
DEBUG - 2022-06-29 06:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:22:39 --> Total execution time: 0.0550
DEBUG - 2022-06-29 06:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:22:44 --> Total execution time: 0.1411
DEBUG - 2022-06-29 06:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:23:04 --> Total execution time: 0.0551
DEBUG - 2022-06-29 06:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:23:13 --> Total execution time: 0.0633
DEBUG - 2022-06-29 06:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:23:15 --> Total execution time: 0.0451
DEBUG - 2022-06-29 06:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 06:53:18 --> Total execution time: 0.0635
DEBUG - 2022-06-29 06:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:23:28 --> Total execution time: 0.0512
DEBUG - 2022-06-29 06:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:23:36 --> Total execution time: 0.0855
DEBUG - 2022-06-29 06:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:23:44 --> Total execution time: 0.0647
DEBUG - 2022-06-29 06:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:24:02 --> Total execution time: 0.1056
DEBUG - 2022-06-29 06:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:54:06 --> No URI present. Default controller set.
DEBUG - 2022-06-29 06:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:24:06 --> Total execution time: 0.0513
DEBUG - 2022-06-29 06:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:24:39 --> Total execution time: 0.0466
DEBUG - 2022-06-29 06:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:25:00 --> Total execution time: 0.1272
DEBUG - 2022-06-29 06:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:27:42 --> Total execution time: 0.1895
DEBUG - 2022-06-29 06:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:28:06 --> Total execution time: 0.1196
DEBUG - 2022-06-29 06:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:28:16 --> Total execution time: 0.0449
DEBUG - 2022-06-29 06:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:28:30 --> Total execution time: 0.0506
DEBUG - 2022-06-29 06:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:28:41 --> Total execution time: 0.0445
DEBUG - 2022-06-29 06:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 06:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 06:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:28:45 --> Total execution time: 0.0385
DEBUG - 2022-06-29 07:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:30:04 --> Total execution time: 0.0664
DEBUG - 2022-06-29 07:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 07:00:43 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-29 07:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:00:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 07:00:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 07:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:34:13 --> Total execution time: 0.1253
DEBUG - 2022-06-29 07:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:35:22 --> Total execution time: 0.0440
DEBUG - 2022-06-29 07:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:35:40 --> Total execution time: 0.0788
DEBUG - 2022-06-29 07:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:35:52 --> Total execution time: 0.0841
DEBUG - 2022-06-29 07:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:36:10 --> Total execution time: 0.0791
DEBUG - 2022-06-29 07:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:38:52 --> Total execution time: 0.0533
DEBUG - 2022-06-29 07:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:39:16 --> Total execution time: 0.0573
DEBUG - 2022-06-29 07:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:40:14 --> Total execution time: 0.0484
DEBUG - 2022-06-29 07:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:40:28 --> Total execution time: 0.0519
DEBUG - 2022-06-29 07:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:40:32 --> Total execution time: 0.0553
DEBUG - 2022-06-29 07:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:41:36 --> Total execution time: 0.0574
DEBUG - 2022-06-29 07:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:41:55 --> Total execution time: 0.0453
DEBUG - 2022-06-29 07:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:42:02 --> Total execution time: 0.0653
DEBUG - 2022-06-29 07:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:13:41 --> No URI present. Default controller set.
DEBUG - 2022-06-29 07:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:43:41 --> Total execution time: 0.0437
DEBUG - 2022-06-29 07:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:43:44 --> Total execution time: 0.0257
DEBUG - 2022-06-29 07:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:15:36 --> No URI present. Default controller set.
DEBUG - 2022-06-29 07:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:45:36 --> Total execution time: 0.0390
DEBUG - 2022-06-29 07:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:45:41 --> Total execution time: 0.0307
DEBUG - 2022-06-29 07:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:45:59 --> Total execution time: 0.0766
DEBUG - 2022-06-29 07:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:46:11 --> Total execution time: 0.0474
DEBUG - 2022-06-29 07:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:46:17 --> Total execution time: 0.0530
DEBUG - 2022-06-29 07:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:46:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 07:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:46:18 --> Total execution time: 0.0382
DEBUG - 2022-06-29 07:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:47:35 --> Total execution time: 0.0494
DEBUG - 2022-06-29 07:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:47:39 --> Total execution time: 0.1524
DEBUG - 2022-06-29 07:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:47:52 --> Total execution time: 0.0450
DEBUG - 2022-06-29 07:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:48:14 --> Total execution time: 0.0447
DEBUG - 2022-06-29 07:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:18:14 --> No URI present. Default controller set.
DEBUG - 2022-06-29 07:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:48:14 --> Total execution time: 0.0464
DEBUG - 2022-06-29 07:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:18:15 --> No URI present. Default controller set.
DEBUG - 2022-06-29 07:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:48:15 --> Total execution time: 0.0618
DEBUG - 2022-06-29 07:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:18:15 --> No URI present. Default controller set.
DEBUG - 2022-06-29 07:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:48:15 --> Total execution time: 0.0516
DEBUG - 2022-06-29 07:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:48:38 --> Total execution time: 0.0539
DEBUG - 2022-06-29 07:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:50:37 --> Total execution time: 0.1324
DEBUG - 2022-06-29 07:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:51:17 --> Total execution time: 0.0534
DEBUG - 2022-06-29 07:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:51:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 07:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:51:18 --> Total execution time: 0.0487
DEBUG - 2022-06-29 07:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:23:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 07:23:20 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-29 07:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:25:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 07:25:58 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-29 07:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:56:52 --> Total execution time: 0.1737
DEBUG - 2022-06-29 07:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:27:03 --> No URI present. Default controller set.
DEBUG - 2022-06-29 07:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:57:03 --> Total execution time: 0.0888
DEBUG - 2022-06-29 07:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:57:07 --> Total execution time: 0.0527
DEBUG - 2022-06-29 07:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:57:16 --> Total execution time: 0.0462
DEBUG - 2022-06-29 07:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:57:25 --> Total execution time: 0.0500
DEBUG - 2022-06-29 07:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:57:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 07:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:57:29 --> Total execution time: 0.0492
DEBUG - 2022-06-29 07:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 07:28:07 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-29 07:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:00:58 --> Total execution time: 0.0543
DEBUG - 2022-06-29 07:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:00:59 --> Total execution time: 0.0454
DEBUG - 2022-06-29 07:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:31:02 --> No URI present. Default controller set.
DEBUG - 2022-06-29 07:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:01:02 --> Total execution time: 0.0493
DEBUG - 2022-06-29 07:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:02:26 --> Total execution time: 0.0343
DEBUG - 2022-06-29 07:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:02:36 --> Total execution time: 0.0629
DEBUG - 2022-06-29 07:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:02:46 --> Total execution time: 0.1684
DEBUG - 2022-06-29 07:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:02:54 --> Total execution time: 0.0884
DEBUG - 2022-06-29 07:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:03:02 --> Total execution time: 0.0612
DEBUG - 2022-06-29 07:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:03:26 --> Total execution time: 0.1685
DEBUG - 2022-06-29 07:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:33:27 --> Total execution time: 0.0971
DEBUG - 2022-06-29 07:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:03:28 --> Total execution time: 0.1192
DEBUG - 2022-06-29 07:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:04:21 --> Total execution time: 0.0569
DEBUG - 2022-06-29 07:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:05:25 --> Total execution time: 0.0703
DEBUG - 2022-06-29 07:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:05:33 --> Total execution time: 0.0530
DEBUG - 2022-06-29 07:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:35:46 --> No URI present. Default controller set.
DEBUG - 2022-06-29 07:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:05:46 --> Total execution time: 0.0376
DEBUG - 2022-06-29 07:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:05:49 --> Total execution time: 0.0337
DEBUG - 2022-06-29 07:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:05:56 --> Total execution time: 0.0438
DEBUG - 2022-06-29 07:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:06:00 --> Total execution time: 0.0527
DEBUG - 2022-06-29 07:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:06:03 --> Total execution time: 0.0525
DEBUG - 2022-06-29 07:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:06:09 --> Total execution time: 0.0554
DEBUG - 2022-06-29 07:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:06:12 --> Total execution time: 0.0586
DEBUG - 2022-06-29 07:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:06:27 --> Total execution time: 0.0527
DEBUG - 2022-06-29 07:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:06:54 --> Total execution time: 0.0597
DEBUG - 2022-06-29 07:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:36:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 07:36:55 --> 404 Page Not Found: Wp-includes/ID3
DEBUG - 2022-06-29 07:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:36:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 07:36:55 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-29 07:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:07:19 --> Total execution time: 0.0606
DEBUG - 2022-06-29 07:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:09:19 --> Total execution time: 0.1040
DEBUG - 2022-06-29 07:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:10:12 --> Total execution time: 0.0600
DEBUG - 2022-06-29 07:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:10:26 --> Total execution time: 0.0725
DEBUG - 2022-06-29 07:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:10:32 --> Total execution time: 0.0529
DEBUG - 2022-06-29 07:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:10:34 --> Total execution time: 0.0584
DEBUG - 2022-06-29 07:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:10:37 --> Total execution time: 0.0675
DEBUG - 2022-06-29 07:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:10:37 --> Total execution time: 0.0485
DEBUG - 2022-06-29 07:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:10:55 --> Total execution time: 0.1277
DEBUG - 2022-06-29 07:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:41:36 --> No URI present. Default controller set.
DEBUG - 2022-06-29 07:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:11:36 --> Total execution time: 0.0638
DEBUG - 2022-06-29 07:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:11:40 --> Total execution time: 0.0719
DEBUG - 2022-06-29 07:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:11:45 --> Total execution time: 0.0983
DEBUG - 2022-06-29 07:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:11:47 --> Total execution time: 0.0747
DEBUG - 2022-06-29 07:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:11:50 --> Total execution time: 0.0634
DEBUG - 2022-06-29 07:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:12:28 --> Total execution time: 0.2146
DEBUG - 2022-06-29 07:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:12:32 --> Total execution time: 0.0679
DEBUG - 2022-06-29 07:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:13:13 --> Total execution time: 0.1040
DEBUG - 2022-06-29 07:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:13:27 --> Total execution time: 0.0794
DEBUG - 2022-06-29 07:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:14:46 --> Total execution time: 0.0688
DEBUG - 2022-06-29 07:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:15:22 --> Total execution time: 0.0461
DEBUG - 2022-06-29 07:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:45:30 --> No URI present. Default controller set.
DEBUG - 2022-06-29 07:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:15:30 --> Total execution time: 0.0443
DEBUG - 2022-06-29 07:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:16:12 --> Total execution time: 0.0540
DEBUG - 2022-06-29 07:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:16:32 --> Total execution time: 0.0451
DEBUG - 2022-06-29 07:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:18:44 --> Total execution time: 0.0751
DEBUG - 2022-06-29 07:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:18:53 --> Total execution time: 0.1077
DEBUG - 2022-06-29 07:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:19:44 --> Total execution time: 0.0480
DEBUG - 2022-06-29 07:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:19:48 --> Total execution time: 0.0453
DEBUG - 2022-06-29 07:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:19:50 --> Total execution time: 0.0504
DEBUG - 2022-06-29 07:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:19:52 --> Total execution time: 0.0446
DEBUG - 2022-06-29 07:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:19:58 --> Total execution time: 0.0552
DEBUG - 2022-06-29 07:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:20:32 --> Total execution time: 0.1198
DEBUG - 2022-06-29 07:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:20:55 --> Total execution time: 0.0553
DEBUG - 2022-06-29 07:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:51:10 --> Total execution time: 0.0377
DEBUG - 2022-06-29 07:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:21:15 --> Total execution time: 0.0452
DEBUG - 2022-06-29 07:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:21:19 --> Total execution time: 0.0760
DEBUG - 2022-06-29 07:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:21:21 --> Total execution time: 0.0745
DEBUG - 2022-06-29 07:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:21:38 --> Total execution time: 0.0563
DEBUG - 2022-06-29 07:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:21:40 --> Total execution time: 0.0477
DEBUG - 2022-06-29 07:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:21:56 --> Total execution time: 0.0643
DEBUG - 2022-06-29 07:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:22:01 --> Total execution time: 0.1267
DEBUG - 2022-06-29 07:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:52:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 07:52:07 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-29 07:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:23:11 --> Total execution time: 0.0608
DEBUG - 2022-06-29 07:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:23:12 --> Total execution time: 0.0505
DEBUG - 2022-06-29 07:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:53:29 --> No URI present. Default controller set.
DEBUG - 2022-06-29 07:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:23:29 --> Total execution time: 0.0483
DEBUG - 2022-06-29 07:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:23:31 --> Total execution time: 0.0560
DEBUG - 2022-06-29 07:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:23:35 --> Total execution time: 0.0620
DEBUG - 2022-06-29 07:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:23:39 --> Total execution time: 0.0759
DEBUG - 2022-06-29 07:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:23:40 --> Total execution time: 0.0834
DEBUG - 2022-06-29 07:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:23:42 --> Total execution time: 0.0500
DEBUG - 2022-06-29 07:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:23:44 --> Total execution time: 0.0453
DEBUG - 2022-06-29 07:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:23:57 --> Total execution time: 0.0441
DEBUG - 2022-06-29 07:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:23:58 --> Total execution time: 0.0556
DEBUG - 2022-06-29 07:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:24:03 --> Total execution time: 0.0825
DEBUG - 2022-06-29 07:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:24:04 --> Total execution time: 0.0477
DEBUG - 2022-06-29 07:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:24:12 --> Total execution time: 0.0754
DEBUG - 2022-06-29 07:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:24:17 --> Total execution time: 0.0738
DEBUG - 2022-06-29 07:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:24:17 --> Total execution time: 0.0589
DEBUG - 2022-06-29 07:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:24:20 --> Total execution time: 0.0717
DEBUG - 2022-06-29 07:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 07:54:20 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-29 07:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 07:54:21 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-29 07:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:54:46 --> No URI present. Default controller set.
DEBUG - 2022-06-29 07:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:24:46 --> Total execution time: 0.1345
DEBUG - 2022-06-29 07:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:24:54 --> Total execution time: 0.1426
DEBUG - 2022-06-29 07:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:25:16 --> Total execution time: 0.0585
DEBUG - 2022-06-29 07:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:25:20 --> Total execution time: 0.0722
DEBUG - 2022-06-29 07:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:25:34 --> Total execution time: 0.0664
DEBUG - 2022-06-29 07:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:26:13 --> Total execution time: 0.0840
DEBUG - 2022-06-29 07:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:26:20 --> Total execution time: 0.0360
DEBUG - 2022-06-29 07:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:26:20 --> Total execution time: 0.0295
DEBUG - 2022-06-29 07:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:26:24 --> Total execution time: 0.0530
DEBUG - 2022-06-29 07:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:26:50 --> Total execution time: 0.0547
DEBUG - 2022-06-29 07:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:26:58 --> Total execution time: 0.0977
DEBUG - 2022-06-29 07:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:27:06 --> Total execution time: 0.0562
DEBUG - 2022-06-29 07:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:27:18 --> Total execution time: 0.0574
DEBUG - 2022-06-29 07:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:57:22 --> No URI present. Default controller set.
DEBUG - 2022-06-29 07:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:27:22 --> Total execution time: 0.1161
DEBUG - 2022-06-29 07:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:27:22 --> Total execution time: 0.0889
DEBUG - 2022-06-29 07:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:27:28 --> Total execution time: 0.0726
DEBUG - 2022-06-29 07:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 07:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:27:33 --> Total execution time: 0.1416
DEBUG - 2022-06-29 07:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:27:37 --> Total execution time: 0.1229
DEBUG - 2022-06-29 07:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:27:39 --> Total execution time: 0.0640
DEBUG - 2022-06-29 07:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:27:40 --> Total execution time: 0.1038
DEBUG - 2022-06-29 07:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:27:42 --> Total execution time: 0.0469
DEBUG - 2022-06-29 07:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 07:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 07:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:27:43 --> Total execution time: 0.1870
DEBUG - 2022-06-29 08:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:30:03 --> Total execution time: 0.2709
DEBUG - 2022-06-29 08:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:31:39 --> Total execution time: 0.0886
DEBUG - 2022-06-29 08:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:32:12 --> Total execution time: 0.0587
DEBUG - 2022-06-29 08:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:34:10 --> Total execution time: 0.0531
DEBUG - 2022-06-29 08:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:34:15 --> Total execution time: 0.0565
DEBUG - 2022-06-29 08:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:34:17 --> Total execution time: 0.1174
DEBUG - 2022-06-29 08:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:35:18 --> Total execution time: 0.0562
DEBUG - 2022-06-29 08:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:35:29 --> Total execution time: 0.0521
DEBUG - 2022-06-29 08:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:35:55 --> Total execution time: 0.1209
DEBUG - 2022-06-29 08:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:35:56 --> Total execution time: 0.0612
DEBUG - 2022-06-29 08:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:36:48 --> Total execution time: 0.0855
DEBUG - 2022-06-29 08:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:37:35 --> Total execution time: 0.0467
DEBUG - 2022-06-29 08:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:38:36 --> Total execution time: 0.0517
DEBUG - 2022-06-29 08:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:09:00 --> No URI present. Default controller set.
DEBUG - 2022-06-29 08:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:39:00 --> Total execution time: 0.0434
DEBUG - 2022-06-29 08:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:39:15 --> Total execution time: 0.0627
DEBUG - 2022-06-29 08:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:39:20 --> Total execution time: 0.1123
DEBUG - 2022-06-29 08:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:39:37 --> Total execution time: 0.0558
DEBUG - 2022-06-29 08:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:39:48 --> Total execution time: 0.0763
DEBUG - 2022-06-29 08:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:40:00 --> Total execution time: 0.0433
DEBUG - 2022-06-29 08:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:40:28 --> Total execution time: 0.0525
DEBUG - 2022-06-29 08:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:40:45 --> Total execution time: 0.0685
DEBUG - 2022-06-29 08:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:42:16 --> Total execution time: 0.0451
DEBUG - 2022-06-29 08:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:42:36 --> Total execution time: 0.1182
DEBUG - 2022-06-29 08:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:42:39 --> Total execution time: 0.0415
DEBUG - 2022-06-29 08:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:42:43 --> Total execution time: 0.0448
DEBUG - 2022-06-29 08:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:13:03 --> No URI present. Default controller set.
DEBUG - 2022-06-29 08:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:43:03 --> Total execution time: 0.0452
DEBUG - 2022-06-29 08:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:43:09 --> Total execution time: 0.0321
DEBUG - 2022-06-29 08:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:43:25 --> Total execution time: 0.0533
DEBUG - 2022-06-29 08:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:43:34 --> Total execution time: 0.0622
DEBUG - 2022-06-29 08:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:43:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 08:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:43:35 --> Total execution time: 0.0851
DEBUG - 2022-06-29 08:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:43:41 --> Total execution time: 0.0325
DEBUG - 2022-06-29 08:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:14:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 08:14:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 08:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:14:21 --> No URI present. Default controller set.
DEBUG - 2022-06-29 08:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:44:21 --> Total execution time: 0.0369
DEBUG - 2022-06-29 08:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:44:25 --> Total execution time: 0.0579
DEBUG - 2022-06-29 08:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:44:37 --> Total execution time: 0.0456
DEBUG - 2022-06-29 08:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:44:47 --> Total execution time: 0.0794
DEBUG - 2022-06-29 08:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:44:52 --> Total execution time: 0.0457
DEBUG - 2022-06-29 08:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:44:58 --> Total execution time: 0.0446
DEBUG - 2022-06-29 08:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:45:08 --> Total execution time: 0.0519
DEBUG - 2022-06-29 18:45:08 --> Total execution time: 0.1021
DEBUG - 2022-06-29 08:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:45:12 --> Total execution time: 0.1231
DEBUG - 2022-06-29 08:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:45:15 --> Total execution time: 0.1677
DEBUG - 2022-06-29 08:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:45:23 --> Total execution time: 0.0735
DEBUG - 2022-06-29 08:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:45:37 --> Total execution time: 0.0535
DEBUG - 2022-06-29 08:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:45:41 --> Total execution time: 0.0854
DEBUG - 2022-06-29 08:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:45:56 --> Total execution time: 0.0909
DEBUG - 2022-06-29 08:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:46:05 --> Total execution time: 0.1523
DEBUG - 2022-06-29 08:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:46:12 --> Total execution time: 0.0529
DEBUG - 2022-06-29 08:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:46:47 --> Total execution time: 0.0493
DEBUG - 2022-06-29 08:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:46:48 --> Total execution time: 0.1076
DEBUG - 2022-06-29 08:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:46:54 --> Total execution time: 0.0796
DEBUG - 2022-06-29 08:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:47:34 --> Total execution time: 0.0691
DEBUG - 2022-06-29 08:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:17:57 --> No URI present. Default controller set.
DEBUG - 2022-06-29 08:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:47:57 --> Total execution time: 0.0402
DEBUG - 2022-06-29 08:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:48:10 --> Total execution time: 0.0564
DEBUG - 2022-06-29 08:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:48:15 --> Total execution time: 0.0813
DEBUG - 2022-06-29 08:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:48:26 --> Total execution time: 0.0753
DEBUG - 2022-06-29 08:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:48:59 --> Total execution time: 0.0473
DEBUG - 2022-06-29 08:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:49:01 --> Total execution time: 0.1209
DEBUG - 2022-06-29 08:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:49:01 --> Total execution time: 0.0474
DEBUG - 2022-06-29 08:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:49:03 --> Total execution time: 0.1314
DEBUG - 2022-06-29 08:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:49:05 --> Total execution time: 0.0659
DEBUG - 2022-06-29 08:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:49:47 --> Total execution time: 0.0578
DEBUG - 2022-06-29 08:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:49:49 --> Total execution time: 0.0538
DEBUG - 2022-06-29 08:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 08:21:00 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-29 08:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:51:55 --> Total execution time: 0.0581
DEBUG - 2022-06-29 08:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:53:17 --> Total execution time: 0.1201
DEBUG - 2022-06-29 08:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:53:29 --> Total execution time: 0.0657
DEBUG - 2022-06-29 08:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:23:32 --> No URI present. Default controller set.
DEBUG - 2022-06-29 08:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:53:32 --> Total execution time: 0.0621
DEBUG - 2022-06-29 08:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:53:37 --> Total execution time: 0.0911
DEBUG - 2022-06-29 08:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:53:38 --> Total execution time: 0.0683
DEBUG - 2022-06-29 08:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:53:38 --> Total execution time: 0.0736
DEBUG - 2022-06-29 08:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:53:38 --> Total execution time: 0.0944
DEBUG - 2022-06-29 08:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:53:38 --> Total execution time: 0.0903
DEBUG - 2022-06-29 08:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:12 --> No URI present. Default controller set.
DEBUG - 2022-06-29 08:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:54:12 --> Total execution time: 0.0491
DEBUG - 2022-06-29 08:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:24:20 --> Total execution time: 0.0716
DEBUG - 2022-06-29 08:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:24:21 --> Total execution time: 0.0513
DEBUG - 2022-06-29 08:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:24:21 --> Total execution time: 0.1111
DEBUG - 2022-06-29 08:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:54:30 --> Total execution time: 0.0855
DEBUG - 2022-06-29 08:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:31 --> No URI present. Default controller set.
DEBUG - 2022-06-29 08:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:54:31 --> Total execution time: 0.0560
DEBUG - 2022-06-29 08:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:54:37 --> Total execution time: 0.1642
DEBUG - 2022-06-29 08:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:54:39 --> Total execution time: 0.0693
DEBUG - 2022-06-29 08:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:54:40 --> Total execution time: 0.0549
DEBUG - 2022-06-29 08:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:54:54 --> Total execution time: 0.0612
DEBUG - 2022-06-29 08:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:54:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 08:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:24:57 --> Total execution time: 0.0725
DEBUG - 2022-06-29 08:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:54:57 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 08:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:54:58 --> Total execution time: 0.0787
DEBUG - 2022-06-29 08:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:24:58 --> Total execution time: 0.0533
DEBUG - 2022-06-29 08:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:24:59 --> Total execution time: 0.0919
DEBUG - 2022-06-29 08:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:55:04 --> Total execution time: 0.1431
DEBUG - 2022-06-29 08:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:55:06 --> Total execution time: 0.0880
DEBUG - 2022-06-29 08:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:55:09 --> Total execution time: 0.0993
DEBUG - 2022-06-29 08:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:55:10 --> Total execution time: 0.0529
DEBUG - 2022-06-29 08:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:55:13 --> Total execution time: 0.1275
DEBUG - 2022-06-29 08:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:55:16 --> Total execution time: 0.0555
DEBUG - 2022-06-29 08:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:25:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 08:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:56:16 --> Total execution time: 0.0582
DEBUG - 2022-06-29 08:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:56:28 --> Total execution time: 0.0680
DEBUG - 2022-06-29 08:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:57:26 --> Total execution time: 0.0501
DEBUG - 2022-06-29 08:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:57:43 --> Total execution time: 0.0542
DEBUG - 2022-06-29 08:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:57:54 --> Total execution time: 0.0549
DEBUG - 2022-06-29 08:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:58:09 --> Total execution time: 0.0713
DEBUG - 2022-06-29 08:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:58:11 --> Total execution time: 0.0532
DEBUG - 2022-06-29 08:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:58:34 --> Total execution time: 0.0471
DEBUG - 2022-06-29 08:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:58:40 --> Total execution time: 0.0449
DEBUG - 2022-06-29 08:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:58:44 --> Total execution time: 0.0690
DEBUG - 2022-06-29 08:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:28:52 --> No URI present. Default controller set.
DEBUG - 2022-06-29 08:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:58:52 --> Total execution time: 0.0361
DEBUG - 2022-06-29 08:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:28:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 08:28:54 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
DEBUG - 2022-06-29 08:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:28:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 08:28:54 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
DEBUG - 2022-06-29 08:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 08:28:55 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-06-29 08:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 08:28:55 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-06-29 08:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:58:56 --> Total execution time: 0.0540
DEBUG - 2022-06-29 08:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:59:00 --> Total execution time: 0.0600
DEBUG - 2022-06-29 08:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:59:05 --> Total execution time: 0.0600
DEBUG - 2022-06-29 08:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:59:09 --> Total execution time: 0.0550
DEBUG - 2022-06-29 08:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:59:16 --> Total execution time: 0.0625
DEBUG - 2022-06-29 08:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:29:22 --> Total execution time: 0.0475
DEBUG - 2022-06-29 08:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:29:29 --> Total execution time: 0.0738
DEBUG - 2022-06-29 08:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:59:29 --> Total execution time: 0.0512
DEBUG - 2022-06-29 08:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:59:32 --> Total execution time: 0.0445
DEBUG - 2022-06-29 08:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:00:06 --> Total execution time: 0.0999
DEBUG - 2022-06-29 08:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:00:16 --> Total execution time: 0.1142
DEBUG - 2022-06-29 08:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:30:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 08:30:19 --> 404 Page Not Found: User/update-thumbnail
DEBUG - 2022-06-29 08:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:00:44 --> Total execution time: 0.0594
DEBUG - 2022-06-29 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:00:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:00:54 --> Total execution time: 0.0987
DEBUG - 2022-06-29 08:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:00:57 --> Total execution time: 0.1436
DEBUG - 2022-06-29 08:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:01:06 --> Total execution time: 0.1115
DEBUG - 2022-06-29 08:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:31:12 --> Total execution time: 0.0737
DEBUG - 2022-06-29 08:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:01:17 --> Total execution time: 0.1016
DEBUG - 2022-06-29 08:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:31:20 --> Total execution time: 0.0516
DEBUG - 2022-06-29 08:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:31:27 --> Total execution time: 0.0508
DEBUG - 2022-06-29 08:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:01:28 --> Total execution time: 0.0631
DEBUG - 2022-06-29 08:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:01:31 --> Total execution time: 0.1364
DEBUG - 2022-06-29 08:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:31:37 --> Total execution time: 0.0492
DEBUG - 2022-06-29 08:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:31:57 --> Total execution time: 0.0462
DEBUG - 2022-06-29 08:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:32:35 --> Total execution time: 0.0491
DEBUG - 2022-06-29 08:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:32:49 --> Total execution time: 0.0569
DEBUG - 2022-06-29 08:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:32:50 --> Total execution time: 0.0542
DEBUG - 2022-06-29 08:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:32:53 --> Total execution time: 0.0464
DEBUG - 2022-06-29 08:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:32:54 --> Total execution time: 0.0612
DEBUG - 2022-06-29 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:32:59 --> Total execution time: 0.0645
DEBUG - 2022-06-29 08:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:33:04 --> Total execution time: 0.0712
DEBUG - 2022-06-29 08:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:33:07 --> Total execution time: 0.0374
DEBUG - 2022-06-29 08:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:03:09 --> Total execution time: 0.1021
DEBUG - 2022-06-29 08:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:03:11 --> Total execution time: 0.0925
DEBUG - 2022-06-29 08:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:03:12 --> Total execution time: 0.4797
DEBUG - 2022-06-29 08:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:03:13 --> Total execution time: 0.5624
DEBUG - 2022-06-29 08:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:33:13 --> Total execution time: 0.0399
DEBUG - 2022-06-29 08:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:33:16 --> No URI present. Default controller set.
DEBUG - 2022-06-29 08:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:03:16 --> Total execution time: 0.1163
DEBUG - 2022-06-29 08:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:03:33 --> Total execution time: 0.0561
DEBUG - 2022-06-29 08:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:03:39 --> Total execution time: 0.0587
DEBUG - 2022-06-29 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:03:46 --> Total execution time: 0.0503
DEBUG - 2022-06-29 08:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:04:10 --> Total execution time: 0.0574
DEBUG - 2022-06-29 08:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:04:16 --> Total execution time: 0.0542
DEBUG - 2022-06-29 08:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:04:18 --> Total execution time: 0.0507
DEBUG - 2022-06-29 08:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:04:18 --> Total execution time: 0.0533
DEBUG - 2022-06-29 08:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:04:19 --> Total execution time: 0.0616
DEBUG - 2022-06-29 08:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:04:19 --> Total execution time: 0.0492
DEBUG - 2022-06-29 08:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:04:27 --> Total execution time: 0.0758
DEBUG - 2022-06-29 08:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:34:41 --> No URI present. Default controller set.
DEBUG - 2022-06-29 08:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:04:41 --> Total execution time: 0.0477
DEBUG - 2022-06-29 08:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:05:20 --> Total execution time: 0.0493
DEBUG - 2022-06-29 08:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:06:54 --> Total execution time: 2.0476
DEBUG - 2022-06-29 08:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 08:36:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 08:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:07:16 --> Total execution time: 0.0452
DEBUG - 2022-06-29 08:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:07:29 --> Total execution time: 0.1196
DEBUG - 2022-06-29 08:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:07:41 --> Total execution time: 0.0807
DEBUG - 2022-06-29 08:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:07:49 --> Total execution time: 0.0525
DEBUG - 2022-06-29 08:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:07:54 --> Total execution time: 0.0623
DEBUG - 2022-06-29 08:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:08:12 --> Total execution time: 0.0767
DEBUG - 2022-06-29 08:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:08:13 --> Total execution time: 0.1197
DEBUG - 2022-06-29 08:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:08:38 --> Total execution time: 0.0719
DEBUG - 2022-06-29 08:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:08:40 --> Total execution time: 1.5991
DEBUG - 2022-06-29 08:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:38:53 --> No URI present. Default controller set.
DEBUG - 2022-06-29 08:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:08:53 --> Total execution time: 0.1188
DEBUG - 2022-06-29 08:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:09:11 --> Total execution time: 0.0518
DEBUG - 2022-06-29 08:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:09:17 --> Total execution time: 0.0455
DEBUG - 2022-06-29 08:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:09:19 --> Total execution time: 0.0367
DEBUG - 2022-06-29 08:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:09:22 --> Total execution time: 0.0568
DEBUG - 2022-06-29 08:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:09:44 --> Total execution time: 0.0679
DEBUG - 2022-06-29 08:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:09:53 --> Total execution time: 0.0705
DEBUG - 2022-06-29 08:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:10:14 --> Total execution time: 0.0622
DEBUG - 2022-06-29 08:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:10:24 --> Total execution time: 0.0688
DEBUG - 2022-06-29 08:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:10:35 --> Total execution time: 0.0732
DEBUG - 2022-06-29 08:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:12:03 --> Total execution time: 0.0571
DEBUG - 2022-06-29 08:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:12:03 --> Total execution time: 0.0542
DEBUG - 2022-06-29 08:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:12:06 --> Total execution time: 0.0514
DEBUG - 2022-06-29 08:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:12:12 --> Total execution time: 0.0669
DEBUG - 2022-06-29 08:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:12:22 --> Total execution time: 0.0673
DEBUG - 2022-06-29 08:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:12:26 --> Total execution time: 0.0494
DEBUG - 2022-06-29 08:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:12:40 --> Total execution time: 0.1229
DEBUG - 2022-06-29 08:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:13:43 --> Total execution time: 0.0716
DEBUG - 2022-06-29 08:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:13:55 --> Total execution time: 0.0489
DEBUG - 2022-06-29 08:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:14:35 --> Total execution time: 0.0868
DEBUG - 2022-06-29 08:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:14:52 --> Total execution time: 0.1375
DEBUG - 2022-06-29 08:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:14:55 --> Total execution time: 0.0791
DEBUG - 2022-06-29 08:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:14:59 --> Total execution time: 0.0821
DEBUG - 2022-06-29 08:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:15:42 --> Total execution time: 0.0624
DEBUG - 2022-06-29 08:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:15:51 --> Total execution time: 0.0773
DEBUG - 2022-06-29 08:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:15:54 --> Total execution time: 0.0561
DEBUG - 2022-06-29 08:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:16:02 --> Total execution time: 0.0510
DEBUG - 2022-06-29 08:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:16:03 --> Total execution time: 0.0590
DEBUG - 2022-06-29 08:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:16:36 --> Total execution time: 0.0571
DEBUG - 2022-06-29 08:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:16:37 --> Total execution time: 0.1227
DEBUG - 2022-06-29 08:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:17:09 --> Total execution time: 0.0571
DEBUG - 2022-06-29 08:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:17:12 --> Total execution time: 0.0467
DEBUG - 2022-06-29 08:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:17:28 --> Total execution time: 0.0493
DEBUG - 2022-06-29 08:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:19:57 --> Total execution time: 0.1301
DEBUG - 2022-06-29 08:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:50:16 --> No URI present. Default controller set.
DEBUG - 2022-06-29 08:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:20:16 --> Total execution time: 0.0350
DEBUG - 2022-06-29 08:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:20:26 --> Total execution time: 0.0361
DEBUG - 2022-06-29 08:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:50:51 --> No URI present. Default controller set.
DEBUG - 2022-06-29 08:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:20:51 --> Total execution time: 0.0919
DEBUG - 2022-06-29 08:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:20:54 --> Total execution time: 0.0875
DEBUG - 2022-06-29 08:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:21:04 --> Total execution time: 0.0728
DEBUG - 2022-06-29 08:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:21:11 --> Total execution time: 0.0704
DEBUG - 2022-06-29 08:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:21:20 --> Total execution time: 0.1905
DEBUG - 2022-06-29 08:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:21:23 --> Total execution time: 0.0541
DEBUG - 2022-06-29 08:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:21:24 --> Total execution time: 0.0510
DEBUG - 2022-06-29 08:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:51:29 --> No URI present. Default controller set.
DEBUG - 2022-06-29 08:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:21:29 --> Total execution time: 0.1044
DEBUG - 2022-06-29 08:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:21:39 --> Total execution time: 0.0949
DEBUG - 2022-06-29 08:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:21:41 --> Total execution time: 0.0721
DEBUG - 2022-06-29 08:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:22:22 --> Total execution time: 0.0793
DEBUG - 2022-06-29 08:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:22:35 --> Total execution time: 0.0569
DEBUG - 2022-06-29 08:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:22:36 --> Total execution time: 0.0531
DEBUG - 2022-06-29 08:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:22:43 --> Total execution time: 0.0698
DEBUG - 2022-06-29 08:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:52:43 --> No URI present. Default controller set.
DEBUG - 2022-06-29 08:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:22:43 --> Total execution time: 0.0585
DEBUG - 2022-06-29 08:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:23:27 --> Total execution time: 0.0561
DEBUG - 2022-06-29 08:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:24:07 --> Total execution time: 0.0467
DEBUG - 2022-06-29 08:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:26:04 --> Total execution time: 0.0473
DEBUG - 2022-06-29 08:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:26:59 --> Total execution time: 0.0451
DEBUG - 2022-06-29 08:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:27:05 --> Total execution time: 0.0724
DEBUG - 2022-06-29 08:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:57:08 --> No URI present. Default controller set.
DEBUG - 2022-06-29 08:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:27:08 --> Total execution time: 0.0400
DEBUG - 2022-06-29 08:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:27:08 --> Total execution time: 0.0590
DEBUG - 2022-06-29 08:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:27:19 --> Total execution time: 0.0526
DEBUG - 2022-06-29 08:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:27:25 --> Total execution time: 0.0584
DEBUG - 2022-06-29 08:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:57:32 --> Total execution time: 0.0499
DEBUG - 2022-06-29 08:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:27:34 --> Total execution time: 0.0669
DEBUG - 2022-06-29 08:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:27:53 --> Total execution time: 0.0545
DEBUG - 2022-06-29 08:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:28:04 --> Total execution time: 0.0541
DEBUG - 2022-06-29 08:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:58:11 --> Total execution time: 0.0381
DEBUG - 2022-06-29 08:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:58:15 --> Total execution time: 0.0407
DEBUG - 2022-06-29 08:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:58:22 --> Total execution time: 0.0543
DEBUG - 2022-06-29 08:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:28:23 --> Total execution time: 0.0559
DEBUG - 2022-06-29 08:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:58:30 --> Total execution time: 0.0530
DEBUG - 2022-06-29 08:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:58:32 --> Total execution time: 0.0380
DEBUG - 2022-06-29 08:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:28:33 --> Total execution time: 0.0591
DEBUG - 2022-06-29 08:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:28:44 --> Total execution time: 0.0609
DEBUG - 2022-06-29 08:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:28:44 --> Total execution time: 0.0448
DEBUG - 2022-06-29 08:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:58:55 --> Total execution time: 0.0407
DEBUG - 2022-06-29 08:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:29:09 --> Total execution time: 0.0566
DEBUG - 2022-06-29 08:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:29:16 --> Total execution time: 0.0684
DEBUG - 2022-06-29 08:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:29:23 --> Total execution time: 0.0645
DEBUG - 2022-06-29 08:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:59:28 --> Total execution time: 0.0562
DEBUG - 2022-06-29 08:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:59:31 --> Total execution time: 0.0482
DEBUG - 2022-06-29 08:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:59:34 --> Total execution time: 0.0434
DEBUG - 2022-06-29 08:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 08:59:48 --> Total execution time: 0.0383
DEBUG - 2022-06-29 08:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 08:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 08:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:29:52 --> Total execution time: 0.0508
DEBUG - 2022-06-29 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:30:02 --> Total execution time: 0.0533
DEBUG - 2022-06-29 09:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:30:05 --> Total execution time: 0.1086
DEBUG - 2022-06-29 09:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:00:13 --> Total execution time: 0.0454
DEBUG - 2022-06-29 09:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:30:15 --> Total execution time: 0.0543
DEBUG - 2022-06-29 09:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:30:19 --> Total execution time: 0.0600
DEBUG - 2022-06-29 09:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:30:23 --> Total execution time: 0.0490
DEBUG - 2022-06-29 09:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:30:26 --> Total execution time: 0.0508
DEBUG - 2022-06-29 09:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:30:57 --> Total execution time: 0.0710
DEBUG - 2022-06-29 09:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:31:07 --> Total execution time: 0.0567
DEBUG - 2022-06-29 09:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:31:12 --> Total execution time: 0.0830
DEBUG - 2022-06-29 09:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:01:15 --> Total execution time: 0.0453
DEBUG - 2022-06-29 09:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:31:17 --> Total execution time: 0.0565
DEBUG - 2022-06-29 09:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:31:22 --> Total execution time: 0.0486
DEBUG - 2022-06-29 09:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:31:30 --> Total execution time: 0.0588
DEBUG - 2022-06-29 09:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:31:40 --> Total execution time: 0.0680
DEBUG - 2022-06-29 09:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:31:43 --> Total execution time: 0.0586
DEBUG - 2022-06-29 09:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:44 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:31:44 --> Total execution time: 0.0414
DEBUG - 2022-06-29 09:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:44 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:31:44 --> Total execution time: 0.0338
DEBUG - 2022-06-29 09:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:46 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:31:46 --> Total execution time: 0.0342
DEBUG - 2022-06-29 09:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:31:47 --> Total execution time: 0.0314
DEBUG - 2022-06-29 09:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:31:47 --> Total execution time: 0.0328
DEBUG - 2022-06-29 09:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:31:52 --> Total execution time: 0.0725
DEBUG - 2022-06-29 09:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:02:04 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:32:04 --> Total execution time: 0.0433
DEBUG - 2022-06-29 09:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:32:25 --> Total execution time: 0.0526
DEBUG - 2022-06-29 09:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:32:38 --> Total execution time: 0.0525
DEBUG - 2022-06-29 09:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:32:49 --> Total execution time: 0.0527
DEBUG - 2022-06-29 09:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:03:53 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:33:53 --> Total execution time: 0.0398
DEBUG - 2022-06-29 09:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:03:54 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:33:54 --> Total execution time: 0.0465
DEBUG - 2022-06-29 09:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:34:01 --> Total execution time: 0.0769
DEBUG - 2022-06-29 09:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:34:05 --> Total execution time: 0.0605
DEBUG - 2022-06-29 09:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:34:11 --> Total execution time: 0.0526
DEBUG - 2022-06-29 09:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:34:47 --> Total execution time: 0.0578
DEBUG - 2022-06-29 09:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:34:59 --> Total execution time: 0.0459
DEBUG - 2022-06-29 09:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:35:11 --> Total execution time: 0.0593
DEBUG - 2022-06-29 09:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:05:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 09:05:43 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-29 09:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:05:53 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:35:53 --> Total execution time: 0.0335
DEBUG - 2022-06-29 09:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:36:00 --> Total execution time: 0.1637
DEBUG - 2022-06-29 09:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:36:34 --> Total execution time: 0.1164
DEBUG - 2022-06-29 09:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:36:41 --> Total execution time: 0.0505
DEBUG - 2022-06-29 09:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 09:08:39 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-29 09:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:39:13 --> Total execution time: 0.1655
DEBUG - 2022-06-29 09:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:39:20 --> Total execution time: 0.0498
DEBUG - 2022-06-29 09:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:39:29 --> Total execution time: 0.0787
DEBUG - 2022-06-29 09:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:40:04 --> Total execution time: 0.0518
DEBUG - 2022-06-29 09:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:10:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 09:10:28 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-29 09:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:41:53 --> Total execution time: 0.0359
DEBUG - 2022-06-29 09:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:43:08 --> Total execution time: 0.0482
DEBUG - 2022-06-29 09:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:44:14 --> Total execution time: 0.1372
DEBUG - 2022-06-29 09:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:44:31 --> Total execution time: 0.1657
DEBUG - 2022-06-29 09:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:44:41 --> Total execution time: 0.1405
DEBUG - 2022-06-29 09:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:44:48 --> Total execution time: 0.0714
DEBUG - 2022-06-29 09:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:44:56 --> Total execution time: 0.0633
DEBUG - 2022-06-29 09:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:44:59 --> Total execution time: 0.0541
DEBUG - 2022-06-29 09:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:45:03 --> Total execution time: 0.0935
DEBUG - 2022-06-29 09:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:45:05 --> Total execution time: 0.0825
DEBUG - 2022-06-29 09:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:45:10 --> Total execution time: 0.0649
DEBUG - 2022-06-29 09:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:46:05 --> Total execution time: 0.0707
DEBUG - 2022-06-29 09:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:21:15 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:51:15 --> Total execution time: 0.2063
DEBUG - 2022-06-29 09:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:51:22 --> Total execution time: 0.0747
DEBUG - 2022-06-29 09:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:51:52 --> Total execution time: 0.0571
DEBUG - 2022-06-29 09:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:52:03 --> Total execution time: 0.0545
DEBUG - 2022-06-29 09:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:52:16 --> Total execution time: 0.0461
DEBUG - 2022-06-29 09:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:54:10 --> Total execution time: 0.0823
DEBUG - 2022-06-29 09:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:57:17 --> Total execution time: 0.1854
DEBUG - 2022-06-29 09:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:57:20 --> Total execution time: 0.0779
DEBUG - 2022-06-29 09:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:57:24 --> Total execution time: 0.0711
DEBUG - 2022-06-29 09:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:57:31 --> Total execution time: 0.0524
DEBUG - 2022-06-29 09:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:30:36 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:00:36 --> Total execution time: 0.0921
DEBUG - 2022-06-29 09:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:00:51 --> Total execution time: 0.0586
DEBUG - 2022-06-29 09:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:00:53 --> Total execution time: 0.0445
DEBUG - 2022-06-29 09:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:00:53 --> Total execution time: 0.1255
DEBUG - 2022-06-29 09:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:00:57 --> Total execution time: 0.0807
DEBUG - 2022-06-29 09:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:00:59 --> Total execution time: 0.0862
DEBUG - 2022-06-29 09:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:01:05 --> Total execution time: 0.0475
DEBUG - 2022-06-29 09:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:01:22 --> Total execution time: 0.0513
DEBUG - 2022-06-29 09:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:01:31 --> Total execution time: 0.0499
DEBUG - 2022-06-29 09:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:01:32 --> Total execution time: 0.0542
DEBUG - 2022-06-29 09:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:01:37 --> Total execution time: 0.0588
DEBUG - 2022-06-29 09:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:01:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 09:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:01:38 --> Total execution time: 0.0467
DEBUG - 2022-06-29 09:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:31:48 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:01:48 --> Total execution time: 0.0386
DEBUG - 2022-06-29 09:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:01:51 --> Total execution time: 0.0301
DEBUG - 2022-06-29 09:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:02:03 --> Total execution time: 0.0551
DEBUG - 2022-06-29 09:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:02:10 --> Total execution time: 0.0701
DEBUG - 2022-06-29 09:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:02:20 --> Total execution time: 0.0605
DEBUG - 2022-06-29 09:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:02:32 --> Total execution time: 0.0561
DEBUG - 2022-06-29 09:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:02:38 --> Total execution time: 0.0507
DEBUG - 2022-06-29 09:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:02:42 --> Total execution time: 0.0522
DEBUG - 2022-06-29 09:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:02:48 --> Total execution time: 0.1194
DEBUG - 2022-06-29 09:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:02:52 --> Total execution time: 0.0503
DEBUG - 2022-06-29 09:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:02:55 --> Total execution time: 0.0466
DEBUG - 2022-06-29 09:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:02:55 --> Total execution time: 0.0576
DEBUG - 2022-06-29 09:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:02:58 --> Total execution time: 0.0625
DEBUG - 2022-06-29 09:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:02:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 09:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:02:59 --> Total execution time: 0.0551
DEBUG - 2022-06-29 09:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:03:08 --> Total execution time: 0.0489
DEBUG - 2022-06-29 09:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:03:12 --> Total execution time: 0.0505
DEBUG - 2022-06-29 09:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:03:16 --> Total execution time: 0.0641
DEBUG - 2022-06-29 09:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:03:31 --> Total execution time: 0.0441
DEBUG - 2022-06-29 09:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:03:43 --> Total execution time: 0.0674
DEBUG - 2022-06-29 09:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:33:45 --> Total execution time: 0.0450
DEBUG - 2022-06-29 09:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:33:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 09:33:55 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-29 09:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:04:31 --> Total execution time: 0.0788
DEBUG - 2022-06-29 09:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:04:33 --> Total execution time: 0.0571
DEBUG - 2022-06-29 09:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:04:36 --> Total execution time: 0.0447
DEBUG - 2022-06-29 09:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:34:38 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:04:38 --> Total execution time: 0.0331
DEBUG - 2022-06-29 09:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:04:45 --> Total execution time: 0.0452
DEBUG - 2022-06-29 09:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:04:55 --> Total execution time: 0.0487
DEBUG - 2022-06-29 09:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:04:56 --> Total execution time: 0.0453
DEBUG - 2022-06-29 09:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:05:05 --> Total execution time: 0.0629
DEBUG - 2022-06-29 09:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:05:06 --> Total execution time: 0.0482
DEBUG - 2022-06-29 09:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:05:15 --> Total execution time: 0.0506
DEBUG - 2022-06-29 09:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:05:16 --> Total execution time: 0.0466
DEBUG - 2022-06-29 09:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:05:22 --> Total execution time: 0.0611
DEBUG - 2022-06-29 09:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:05:29 --> Total execution time: 0.1277
DEBUG - 2022-06-29 09:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:05:30 --> Total execution time: 0.0465
DEBUG - 2022-06-29 09:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:05:37 --> Total execution time: 0.0439
DEBUG - 2022-06-29 09:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:05:38 --> Total execution time: 0.0539
DEBUG - 2022-06-29 09:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:05:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 09:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:05:40 --> Total execution time: 0.0435
DEBUG - 2022-06-29 09:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:05:46 --> Total execution time: 0.0454
DEBUG - 2022-06-29 09:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:06:01 --> Total execution time: 0.1195
DEBUG - 2022-06-29 09:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:06:11 --> Total execution time: 0.0490
DEBUG - 2022-06-29 09:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:06:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 09:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:06:12 --> Total execution time: 0.0548
DEBUG - 2022-06-29 09:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:06:20 --> Total execution time: 0.0498
DEBUG - 2022-06-29 09:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:06:24 --> Total execution time: 0.0451
DEBUG - 2022-06-29 09:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:36:33 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:06:33 --> Total execution time: 0.0333
DEBUG - 2022-06-29 09:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:36:41 --> Total execution time: 0.0537
DEBUG - 2022-06-29 09:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:36:42 --> Total execution time: 0.0626
DEBUG - 2022-06-29 09:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:36:42 --> Total execution time: 0.1173
DEBUG - 2022-06-29 09:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:39:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 09:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:09:25 --> Total execution time: 2.0438
DEBUG - 2022-06-29 09:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:39:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 09:39:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 09:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:40:08 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:10:08 --> Total execution time: 0.0536
DEBUG - 2022-06-29 09:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:10:18 --> Total execution time: 0.0555
DEBUG - 2022-06-29 09:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:10:32 --> Total execution time: 0.0487
DEBUG - 2022-06-29 09:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:40:44 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:10:44 --> Total execution time: 0.0473
DEBUG - 2022-06-29 09:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:11:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 09:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:11:56 --> Total execution time: 0.0507
DEBUG - 2022-06-29 09:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:11:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 20:11:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 20:11:57 --> Total execution time: 0.1879
DEBUG - 2022-06-29 09:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:12:00 --> Total execution time: 0.0607
DEBUG - 2022-06-29 09:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:12:05 --> Total execution time: 0.1047
DEBUG - 2022-06-29 09:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:12:10 --> Total execution time: 0.0521
DEBUG - 2022-06-29 09:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:12:15 --> Total execution time: 0.0539
DEBUG - 2022-06-29 09:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:13:02 --> Total execution time: 0.0310
DEBUG - 2022-06-29 09:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:14:19 --> Total execution time: 0.0494
DEBUG - 2022-06-29 09:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:14:24 --> Total execution time: 0.0440
DEBUG - 2022-06-29 09:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:14:32 --> Total execution time: 0.0447
DEBUG - 2022-06-29 09:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:14:37 --> Total execution time: 0.0852
DEBUG - 2022-06-29 09:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:14:44 --> Total execution time: 0.0493
DEBUG - 2022-06-29 09:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:15:10 --> Total execution time: 0.1112
DEBUG - 2022-06-29 09:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:15:11 --> Total execution time: 0.2791
DEBUG - 2022-06-29 09:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:15:20 --> Total execution time: 0.0569
DEBUG - 2022-06-29 09:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:15:21 --> Total execution time: 0.0444
DEBUG - 2022-06-29 09:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:15:26 --> Total execution time: 0.0517
DEBUG - 2022-06-29 09:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:46:12 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:16:12 --> Total execution time: 0.0381
DEBUG - 2022-06-29 09:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:46:14 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:16:14 --> Total execution time: 0.0472
DEBUG - 2022-06-29 09:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:17:04 --> Total execution time: 0.1123
DEBUG - 2022-06-29 09:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:17:19 --> Total execution time: 0.0479
DEBUG - 2022-06-29 09:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:17:23 --> Total execution time: 0.2266
DEBUG - 2022-06-29 09:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:17:25 --> Total execution time: 0.0473
DEBUG - 2022-06-29 09:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:17:30 --> Total execution time: 0.0443
DEBUG - 2022-06-29 09:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:47:52 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:17:52 --> Total execution time: 0.0469
DEBUG - 2022-06-29 09:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:47:58 --> Total execution time: 0.0464
DEBUG - 2022-06-29 09:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:48:03 --> Total execution time: 0.0818
DEBUG - 2022-06-29 09:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:48:03 --> Total execution time: 0.1209
DEBUG - 2022-06-29 09:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:48:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 09:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:18:40 --> Total execution time: 1.5175
DEBUG - 2022-06-29 09:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:48:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 09:48:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 09:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:52:51 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:22:51 --> Total execution time: 0.1842
DEBUG - 2022-06-29 09:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:22:53 --> Total execution time: 1.6111
DEBUG - 2022-06-29 09:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:53:55 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:23:55 --> Total execution time: 0.0461
DEBUG - 2022-06-29 09:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:24:02 --> Total execution time: 1.5653
DEBUG - 2022-06-29 09:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 09:54:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 09:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:24:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 09:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:24:41 --> Total execution time: 0.0472
DEBUG - 2022-06-29 09:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:24:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 20:24:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 20:24:43 --> Total execution time: 0.2061
DEBUG - 2022-06-29 09:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:24:46 --> Total execution time: 0.0483
DEBUG - 2022-06-29 09:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 09:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:24:50 --> Total execution time: 0.0446
DEBUG - 2022-06-29 09:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:56:12 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:26:12 --> Total execution time: 0.0328
DEBUG - 2022-06-29 09:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:29:26 --> Total execution time: 0.1112
DEBUG - 2022-06-29 09:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 09:59:55 --> No URI present. Default controller set.
DEBUG - 2022-06-29 09:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 09:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:29:55 --> Total execution time: 0.0479
DEBUG - 2022-06-29 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:30:02 --> Total execution time: 0.0717
DEBUG - 2022-06-29 10:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:00:03 --> Total execution time: 0.0584
DEBUG - 2022-06-29 10:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:00:04 --> Total execution time: 0.0797
DEBUG - 2022-06-29 10:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:00:04 --> Total execution time: 0.1099
DEBUG - 2022-06-29 10:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:01:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 10:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:31:50 --> Total execution time: 1.8521
DEBUG - 2022-06-29 10:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 10:01:52 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 10:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:04:32 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:34:32 --> Total execution time: 0.1169
DEBUG - 2022-06-29 10:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:04:33 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:34:33 --> Total execution time: 0.0339
DEBUG - 2022-06-29 10:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:34:37 --> Total execution time: 0.0340
DEBUG - 2022-06-29 10:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:05:52 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:35:52 --> Total execution time: 0.0439
DEBUG - 2022-06-29 10:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:05:53 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:35:53 --> Total execution time: 0.1174
DEBUG - 2022-06-29 10:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:05:55 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:35:55 --> Total execution time: 0.0563
DEBUG - 2022-06-29 10:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:35:59 --> Total execution time: 0.0374
DEBUG - 2022-06-29 10:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:36:02 --> Total execution time: 0.0514
DEBUG - 2022-06-29 10:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:36:37 --> Total execution time: 0.0575
DEBUG - 2022-06-29 10:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:06:41 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:36:41 --> Total execution time: 0.0448
DEBUG - 2022-06-29 10:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:36:56 --> Total execution time: 0.0387
DEBUG - 2022-06-29 10:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:37:33 --> Total execution time: 0.0876
DEBUG - 2022-06-29 10:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:07:36 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:37:36 --> Total execution time: 0.0356
DEBUG - 2022-06-29 10:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:37:42 --> Total execution time: 0.0816
DEBUG - 2022-06-29 10:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:07:59 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:37:59 --> Total execution time: 0.0410
DEBUG - 2022-06-29 10:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:38:01 --> Total execution time: 0.0393
DEBUG - 2022-06-29 10:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:09:49 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:39:49 --> Total execution time: 0.0347
DEBUG - 2022-06-29 10:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:10:43 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:40:43 --> Total execution time: 0.0328
DEBUG - 2022-06-29 10:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:40:48 --> Total execution time: 0.0322
DEBUG - 2022-06-29 10:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:40:55 --> Total execution time: 0.0488
DEBUG - 2022-06-29 10:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:41:09 --> Total execution time: 0.0600
DEBUG - 2022-06-29 10:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:41:15 --> Total execution time: 0.0831
DEBUG - 2022-06-29 10:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:41:27 --> Total execution time: 0.0734
DEBUG - 2022-06-29 10:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:41:30 --> Total execution time: 0.0468
DEBUG - 2022-06-29 10:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:41:53 --> Total execution time: 0.0514
DEBUG - 2022-06-29 10:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:42:05 --> Total execution time: 0.0702
DEBUG - 2022-06-29 10:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:42:05 --> Total execution time: 0.1060
DEBUG - 2022-06-29 10:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:42:17 --> Total execution time: 0.0744
DEBUG - 2022-06-29 10:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:42:23 --> Total execution time: 0.0572
DEBUG - 2022-06-29 10:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:42:25 --> Total execution time: 0.0446
DEBUG - 2022-06-29 10:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:42:39 --> Total execution time: 0.0612
DEBUG - 2022-06-29 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:43:55 --> Total execution time: 0.0509
DEBUG - 2022-06-29 10:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:44:04 --> Total execution time: 0.0625
DEBUG - 2022-06-29 10:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:44:11 --> Total execution time: 0.0581
DEBUG - 2022-06-29 10:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:44:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 10:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:44:13 --> Total execution time: 0.0479
DEBUG - 2022-06-29 10:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:15:17 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:45:18 --> Total execution time: 0.1097
DEBUG - 2022-06-29 10:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:46:27 --> Total execution time: 0.0327
DEBUG - 2022-06-29 10:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:16:37 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:46:37 --> Total execution time: 0.0479
DEBUG - 2022-06-29 10:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:16:56 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:46:56 --> Total execution time: 0.0391
DEBUG - 2022-06-29 10:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:47:12 --> Total execution time: 0.0313
DEBUG - 2022-06-29 10:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:47:17 --> Total execution time: 0.0452
DEBUG - 2022-06-29 10:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:47:28 --> Total execution time: 0.0718
DEBUG - 2022-06-29 10:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:47:37 --> Total execution time: 0.0698
DEBUG - 2022-06-29 10:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:47:48 --> Total execution time: 0.0541
DEBUG - 2022-06-29 10:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:17:55 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:47:55 --> Total execution time: 0.0831
DEBUG - 2022-06-29 10:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:18:01 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:48:01 --> Total execution time: 0.1059
DEBUG - 2022-06-29 10:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:48:12 --> Total execution time: 0.0526
DEBUG - 2022-06-29 10:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:18:40 --> Total execution time: 0.0470
DEBUG - 2022-06-29 10:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:48:45 --> Total execution time: 0.0496
DEBUG - 2022-06-29 10:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:48:53 --> Total execution time: 0.0489
DEBUG - 2022-06-29 10:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:20:28 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:50:28 --> Total execution time: 0.0359
DEBUG - 2022-06-29 10:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:50:45 --> Total execution time: 2.0370
DEBUG - 2022-06-29 10:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 10:20:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 10:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:51:04 --> Total execution time: 0.0635
DEBUG - 2022-06-29 10:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:51:10 --> Total execution time: 0.0512
DEBUG - 2022-06-29 10:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:51:13 --> Total execution time: 0.0464
DEBUG - 2022-06-29 10:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:51:19 --> Total execution time: 0.0445
DEBUG - 2022-06-29 10:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:51:21 --> Total execution time: 0.0471
DEBUG - 2022-06-29 10:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:51:29 --> Total execution time: 0.0593
DEBUG - 2022-06-29 10:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:51:29 --> Total execution time: 0.0657
DEBUG - 2022-06-29 10:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:51:31 --> Total execution time: 0.0946
DEBUG - 2022-06-29 10:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:21:38 --> Total execution time: 0.0748
DEBUG - 2022-06-29 10:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:51:39 --> Total execution time: 0.0475
DEBUG - 2022-06-29 10:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:51:41 --> Total execution time: 0.0854
DEBUG - 2022-06-29 10:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:51:43 --> Total execution time: 0.0715
DEBUG - 2022-06-29 10:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:51:47 --> Total execution time: 0.0874
DEBUG - 2022-06-29 10:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:52:40 --> Total execution time: 0.0481
DEBUG - 2022-06-29 10:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:52:48 --> Total execution time: 0.0547
DEBUG - 2022-06-29 10:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:53:56 --> Total execution time: 0.1500
DEBUG - 2022-06-29 10:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:53:58 --> Total execution time: 0.0855
DEBUG - 2022-06-29 10:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:54:15 --> Total execution time: 0.0743
DEBUG - 2022-06-29 10:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:54:46 --> Total execution time: 0.0618
DEBUG - 2022-06-29 10:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:54:47 --> Total execution time: 0.0579
DEBUG - 2022-06-29 10:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:54:52 --> Total execution time: 0.0506
DEBUG - 2022-06-29 10:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:54:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 10:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:54:55 --> Total execution time: 0.0498
DEBUG - 2022-06-29 10:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:54:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 20:54:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 20:54:56 --> Total execution time: 0.1969
DEBUG - 2022-06-29 10:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:55:42 --> Total execution time: 0.0862
DEBUG - 2022-06-29 10:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:55:44 --> Total execution time: 0.0740
DEBUG - 2022-06-29 10:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:55:57 --> Total execution time: 0.0388
DEBUG - 2022-06-29 10:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:56:02 --> Total execution time: 0.1128
DEBUG - 2022-06-29 10:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:56:05 --> Total execution time: 0.0458
DEBUG - 2022-06-29 10:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:56:11 --> Total execution time: 0.0466
DEBUG - 2022-06-29 10:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:56:18 --> Total execution time: 0.0534
DEBUG - 2022-06-29 10:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:56:23 --> Total execution time: 0.0508
DEBUG - 2022-06-29 10:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:56:36 --> Total execution time: 0.0644
DEBUG - 2022-06-29 10:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:56:47 --> Total execution time: 0.0812
DEBUG - 2022-06-29 10:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:56:54 --> Total execution time: 0.0649
DEBUG - 2022-06-29 10:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:56:56 --> Total execution time: 0.0754
DEBUG - 2022-06-29 10:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:57:13 --> Total execution time: 0.0501
DEBUG - 2022-06-29 10:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:57:19 --> Total execution time: 0.0726
DEBUG - 2022-06-29 10:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:57:21 --> Total execution time: 0.0437
DEBUG - 2022-06-29 10:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:57:29 --> Total execution time: 0.0518
DEBUG - 2022-06-29 10:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:57:31 --> Total execution time: 0.0943
DEBUG - 2022-06-29 10:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:57:31 --> Total execution time: 0.1861
DEBUG - 2022-06-29 10:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:57:31 --> Total execution time: 0.0699
DEBUG - 2022-06-29 10:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:57:39 --> Total execution time: 0.0767
DEBUG - 2022-06-29 10:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:57:40 --> Total execution time: 0.0713
DEBUG - 2022-06-29 10:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:57:40 --> Total execution time: 0.0726
DEBUG - 2022-06-29 10:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:57:41 --> Total execution time: 0.0668
DEBUG - 2022-06-29 10:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:58:06 --> Total execution time: 0.0885
DEBUG - 2022-06-29 10:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:58:33 --> Total execution time: 0.0492
DEBUG - 2022-06-29 10:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:58:51 --> Total execution time: 0.0470
DEBUG - 2022-06-29 10:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:59:00 --> Total execution time: 0.1105
DEBUG - 2022-06-29 10:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:59:25 --> Total execution time: 0.0520
DEBUG - 2022-06-29 10:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:29:47 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:59:47 --> Total execution time: 0.1152
DEBUG - 2022-06-29 10:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:00:00 --> Total execution time: 0.1145
DEBUG - 2022-06-29 10:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:00:00 --> Total execution time: 0.0508
DEBUG - 2022-06-29 10:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:00:07 --> Total execution time: 0.0456
DEBUG - 2022-06-29 10:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:30:13 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:00:13 --> Total execution time: 0.1095
DEBUG - 2022-06-29 10:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:00:27 --> Total execution time: 0.0490
DEBUG - 2022-06-29 10:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:00:32 --> Total execution time: 0.0455
DEBUG - 2022-06-29 10:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:00:37 --> Total execution time: 0.0503
DEBUG - 2022-06-29 10:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:00:42 --> Total execution time: 0.0433
DEBUG - 2022-06-29 10:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:01:00 --> Total execution time: 0.0509
DEBUG - 2022-06-29 10:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:01:25 --> Total execution time: 0.0599
DEBUG - 2022-06-29 10:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:01:37 --> Total execution time: 0.4946
DEBUG - 2022-06-29 10:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:01:54 --> Total execution time: 0.0447
DEBUG - 2022-06-29 10:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:32:38 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:02:38 --> Total execution time: 0.0512
DEBUG - 2022-06-29 10:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:02:41 --> Total execution time: 0.0659
DEBUG - 2022-06-29 10:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:06:16 --> Total execution time: 0.0480
DEBUG - 2022-06-29 10:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:06:22 --> Total execution time: 0.0575
DEBUG - 2022-06-29 10:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:07:09 --> Total execution time: 0.0624
DEBUG - 2022-06-29 10:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:37:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 10:37:17 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-29 10:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:07:19 --> Total execution time: 0.1542
DEBUG - 2022-06-29 10:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:37:23 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:07:23 --> Total execution time: 0.0506
DEBUG - 2022-06-29 10:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:07:28 --> Total execution time: 0.0699
DEBUG - 2022-06-29 10:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 10:37:34 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-29 10:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:07:42 --> Total execution time: 0.0495
DEBUG - 2022-06-29 10:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:07:45 --> Total execution time: 0.0454
DEBUG - 2022-06-29 10:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:07:48 --> Total execution time: 0.0454
DEBUG - 2022-06-29 10:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:08:02 --> Total execution time: 0.2103
DEBUG - 2022-06-29 10:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:08:04 --> Total execution time: 0.0782
DEBUG - 2022-06-29 10:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:39:51 --> Total execution time: 0.0497
DEBUG - 2022-06-29 10:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:10:01 --> Total execution time: 0.0741
DEBUG - 2022-06-29 10:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:45:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 10:45:44 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-29 10:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:17:00 --> Total execution time: 0.0544
DEBUG - 2022-06-29 10:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:17:05 --> Total execution time: 0.0584
DEBUG - 2022-06-29 10:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:48:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 10:48:14 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-29 10:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:50:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 10:50:29 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-29 10:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:23:23 --> Total execution time: 0.0491
DEBUG - 2022-06-29 10:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:23:42 --> Total execution time: 0.0513
DEBUG - 2022-06-29 10:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:23:47 --> Total execution time: 0.0901
DEBUG - 2022-06-29 10:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:53:57 --> Total execution time: 0.0529
DEBUG - 2022-06-29 10:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:54:19 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:24:19 --> Total execution time: 0.0374
DEBUG - 2022-06-29 10:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:55:04 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:25:04 --> Total execution time: 0.0364
DEBUG - 2022-06-29 10:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:25:19 --> Total execution time: 0.0454
DEBUG - 2022-06-29 10:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:55:25 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:25:25 --> Total execution time: 0.0739
DEBUG - 2022-06-29 10:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:25:41 --> Total execution time: 0.0435
DEBUG - 2022-06-29 10:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:26:09 --> Total execution time: 0.0588
DEBUG - 2022-06-29 10:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:56:15 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:26:15 --> Total execution time: 0.0342
DEBUG - 2022-06-29 10:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:56:20 --> Total execution time: 0.0909
DEBUG - 2022-06-29 10:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:26:22 --> Total execution time: 0.0456
DEBUG - 2022-06-29 10:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:26:35 --> Total execution time: 0.0547
DEBUG - 2022-06-29 10:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:56:38 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:26:39 --> Total execution time: 0.1112
DEBUG - 2022-06-29 10:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:26:42 --> Total execution time: 0.0559
DEBUG - 2022-06-29 10:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:26:45 --> Total execution time: 0.0707
DEBUG - 2022-06-29 10:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:26:53 --> Total execution time: 0.0564
DEBUG - 2022-06-29 10:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:27:01 --> Total execution time: 0.0467
DEBUG - 2022-06-29 10:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:27:55 --> Total execution time: 0.0444
DEBUG - 2022-06-29 10:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 10:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:28:30 --> Total execution time: 0.0456
DEBUG - 2022-06-29 10:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:28:51 --> Total execution time: 0.0450
DEBUG - 2022-06-29 10:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:29:21 --> Total execution time: 0.0471
DEBUG - 2022-06-29 10:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:29:22 --> Total execution time: 0.0457
DEBUG - 2022-06-29 10:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:59:38 --> No URI present. Default controller set.
DEBUG - 2022-06-29 10:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:29:38 --> Total execution time: 0.0349
DEBUG - 2022-06-29 10:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:29:52 --> Total execution time: 0.0470
DEBUG - 2022-06-29 10:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 10:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 10:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:29:57 --> Total execution time: 0.0441
DEBUG - 2022-06-29 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:30:02 --> Total execution time: 0.0407
DEBUG - 2022-06-29 11:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:30:29 --> Total execution time: 0.0577
DEBUG - 2022-06-29 11:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:30:42 --> Total execution time: 0.0490
DEBUG - 2022-06-29 11:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:30:49 --> Total execution time: 0.0684
DEBUG - 2022-06-29 11:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:31:01 --> Total execution time: 0.1292
DEBUG - 2022-06-29 11:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:31:06 --> Total execution time: 0.0481
DEBUG - 2022-06-29 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:31:11 --> Total execution time: 0.0544
DEBUG - 2022-06-29 11:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:01:16 --> Total execution time: 0.0450
DEBUG - 2022-06-29 11:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:31:18 --> Total execution time: 0.0491
DEBUG - 2022-06-29 11:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:01:25 --> Total execution time: 0.0393
DEBUG - 2022-06-29 11:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:31:41 --> Total execution time: 0.0505
DEBUG - 2022-06-29 11:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:31:43 --> Total execution time: 0.0505
DEBUG - 2022-06-29 11:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:31:47 --> Total execution time: 0.0670
DEBUG - 2022-06-29 11:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:31:55 --> Total execution time: 0.0636
DEBUG - 2022-06-29 11:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:31:56 --> Total execution time: 0.0870
DEBUG - 2022-06-29 11:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:32:03 --> Total execution time: 0.0437
DEBUG - 2022-06-29 11:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:32:12 --> Total execution time: 0.0734
DEBUG - 2022-06-29 11:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:32:15 --> Total execution time: 0.0493
DEBUG - 2022-06-29 11:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:32:16 --> Total execution time: 0.0699
DEBUG - 2022-06-29 11:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:32:20 --> Total execution time: 0.0434
DEBUG - 2022-06-29 11:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:32:21 --> Total execution time: 0.0810
DEBUG - 2022-06-29 11:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:32:25 --> Total execution time: 0.0557
DEBUG - 2022-06-29 11:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:32:59 --> Total execution time: 0.0444
DEBUG - 2022-06-29 11:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:03:16 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:33:16 --> Total execution time: 0.0446
DEBUG - 2022-06-29 11:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:33:46 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 11:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:33:47 --> Total execution time: 0.0781
DEBUG - 2022-06-29 11:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:33:47 --> Total execution time: 0.0502
DEBUG - 2022-06-29 11:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:33:56 --> Total execution time: 0.0682
DEBUG - 2022-06-29 11:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:34:04 --> Total execution time: 0.0466
DEBUG - 2022-06-29 11:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:04:05 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:34:05 --> Total execution time: 0.0345
DEBUG - 2022-06-29 11:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:04:10 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:34:10 --> Total execution time: 0.0497
DEBUG - 2022-06-29 11:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:34:45 --> Total execution time: 0.0443
DEBUG - 2022-06-29 11:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:34:56 --> Total execution time: 0.1127
DEBUG - 2022-06-29 11:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:34:59 --> Total execution time: 0.0515
DEBUG - 2022-06-29 11:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:35:01 --> Total execution time: 0.0510
DEBUG - 2022-06-29 11:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:35:04 --> Total execution time: 0.0486
DEBUG - 2022-06-29 11:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:35:05 --> Total execution time: 0.0497
DEBUG - 2022-06-29 11:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:35:09 --> Total execution time: 0.0566
DEBUG - 2022-06-29 11:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:35:15 --> Total execution time: 0.0923
DEBUG - 2022-06-29 11:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:35:25 --> Total execution time: 0.0461
DEBUG - 2022-06-29 11:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:36:07 --> Total execution time: 0.0543
DEBUG - 2022-06-29 11:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:18 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:36:18 --> Total execution time: 0.1162
DEBUG - 2022-06-29 11:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:36:24 --> Total execution time: 0.0499
DEBUG - 2022-06-29 11:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:36:26 --> Total execution time: 0.0498
DEBUG - 2022-06-29 11:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:36:28 --> Total execution time: 0.0498
DEBUG - 2022-06-29 11:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:36:35 --> Total execution time: 0.0496
DEBUG - 2022-06-29 11:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:36:40 --> Total execution time: 0.0508
DEBUG - 2022-06-29 11:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:36:43 --> Total execution time: 0.0437
DEBUG - 2022-06-29 11:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:36:44 --> Total execution time: 0.0596
DEBUG - 2022-06-29 11:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:36:46 --> Total execution time: 0.0454
DEBUG - 2022-06-29 11:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:36:49 --> Total execution time: 0.0470
DEBUG - 2022-06-29 11:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:36:58 --> Total execution time: 0.1120
DEBUG - 2022-06-29 11:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:07:07 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:37:07 --> Total execution time: 0.0350
DEBUG - 2022-06-29 11:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:37:07 --> Total execution time: 0.0488
DEBUG - 2022-06-29 11:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:07:08 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:37:08 --> Total execution time: 0.0328
DEBUG - 2022-06-29 11:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:07:19 --> Total execution time: 0.0466
DEBUG - 2022-06-29 11:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:07:20 --> Total execution time: 0.0503
DEBUG - 2022-06-29 11:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:07:20 --> Total execution time: 0.0656
DEBUG - 2022-06-29 11:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:07:30 --> Total execution time: 0.0495
DEBUG - 2022-06-29 11:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:07:32 --> Total execution time: 0.0451
DEBUG - 2022-06-29 11:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:37:34 --> Total execution time: 0.0494
DEBUG - 2022-06-29 11:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:38:12 --> Total execution time: 0.0467
DEBUG - 2022-06-29 11:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:38:16 --> Total execution time: 0.1263
DEBUG - 2022-06-29 11:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:38:23 --> Total execution time: 0.0678
DEBUG - 2022-06-29 11:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:38:31 --> Total execution time: 0.0485
DEBUG - 2022-06-29 11:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:38:33 --> Total execution time: 0.0474
DEBUG - 2022-06-29 11:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:38:35 --> Total execution time: 0.0490
DEBUG - 2022-06-29 11:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:38:53 --> Total execution time: 0.0496
DEBUG - 2022-06-29 11:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:38:58 --> Total execution time: 0.0513
DEBUG - 2022-06-29 11:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:39:12 --> Total execution time: 0.0706
DEBUG - 2022-06-29 11:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:39:26 --> Total execution time: 0.0562
DEBUG - 2022-06-29 11:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:39:33 --> Total execution time: 0.0723
DEBUG - 2022-06-29 11:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:39:35 --> Total execution time: 0.0562
DEBUG - 2022-06-29 11:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:39:39 --> Total execution time: 0.0531
DEBUG - 2022-06-29 11:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:39:41 --> Total execution time: 0.0569
DEBUG - 2022-06-29 11:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:39:46 --> Total execution time: 0.0734
DEBUG - 2022-06-29 11:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:40:03 --> Total execution time: 0.1582
DEBUG - 2022-06-29 11:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:40:04 --> Total execution time: 0.0445
DEBUG - 2022-06-29 11:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:40:06 --> Total execution time: 0.0456
DEBUG - 2022-06-29 11:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:40:07 --> Total execution time: 0.0672
DEBUG - 2022-06-29 11:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:40:14 --> Total execution time: 0.0797
DEBUG - 2022-06-29 11:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:41:24 --> Total execution time: 0.0482
DEBUG - 2022-06-29 11:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:42:52 --> Total execution time: 0.0471
DEBUG - 2022-06-29 11:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:13:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 11:13:49 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-29 11:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:44:47 --> Total execution time: 0.0512
DEBUG - 2022-06-29 11:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:15:01 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:45:01 --> Total execution time: 0.1144
DEBUG - 2022-06-29 11:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:45:04 --> Total execution time: 0.0540
DEBUG - 2022-06-29 11:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:45:09 --> Total execution time: 0.0527
DEBUG - 2022-06-29 11:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:45:12 --> Total execution time: 0.0528
DEBUG - 2022-06-29 11:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:15:39 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:45:39 --> Total execution time: 0.0360
DEBUG - 2022-06-29 11:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:15:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 11:15:55 --> 404 Page Not Found: Assets/images
DEBUG - 2022-06-29 11:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:46:52 --> Total execution time: 0.0469
DEBUG - 2022-06-29 11:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:47:09 --> Total execution time: 0.0465
DEBUG - 2022-06-29 11:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:23:27 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:53:27 --> Total execution time: 0.1283
DEBUG - 2022-06-29 11:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:25:22 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:55:22 --> Total execution time: 0.0445
DEBUG - 2022-06-29 11:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:25:23 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:55:23 --> Total execution time: 0.0320
DEBUG - 2022-06-29 11:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:55:31 --> Total execution time: 0.0353
DEBUG - 2022-06-29 11:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:55:51 --> Total execution time: 0.0434
DEBUG - 2022-06-29 11:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:56:26 --> Total execution time: 0.0463
DEBUG - 2022-06-29 11:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:56:32 --> Total execution time: 0.0578
DEBUG - 2022-06-29 11:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:56:42 --> Total execution time: 0.0486
DEBUG - 2022-06-29 11:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:56:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 11:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:56:43 --> Total execution time: 0.0545
DEBUG - 2022-06-29 11:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:57:20 --> Total execution time: 0.0589
DEBUG - 2022-06-29 11:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:57:28 --> Total execution time: 0.0559
DEBUG - 2022-06-29 11:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:58:13 --> Total execution time: 0.0445
DEBUG - 2022-06-29 11:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:58:35 --> Total execution time: 0.0526
DEBUG - 2022-06-29 11:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:58:36 --> Total execution time: 0.1277
DEBUG - 2022-06-29 11:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:58:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 11:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:58:36 --> Total execution time: 0.0576
DEBUG - 2022-06-29 11:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:58:37 --> Total execution time: 0.0686
DEBUG - 2022-06-29 11:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:58:39 --> Total execution time: 0.0521
DEBUG - 2022-06-29 11:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:58:40 --> Total execution time: 0.0536
DEBUG - 2022-06-29 11:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:58:43 --> Total execution time: 0.0495
DEBUG - 2022-06-29 11:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:58:48 --> Total execution time: 0.0568
DEBUG - 2022-06-29 11:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:59:06 --> Total execution time: 0.0495
DEBUG - 2022-06-29 11:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:59:08 --> Total execution time: 0.0513
DEBUG - 2022-06-29 11:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:59:12 --> Total execution time: 0.0302
DEBUG - 2022-06-29 11:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:59:58 --> Total execution time: 0.0459
DEBUG - 2022-06-29 11:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:00:29 --> Total execution time: 0.0448
DEBUG - 2022-06-29 11:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:00:32 --> Total execution time: 0.1082
DEBUG - 2022-06-29 11:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:00:49 --> Total execution time: 0.0484
DEBUG - 2022-06-29 11:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:30:52 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:00:52 --> Total execution time: 0.0328
DEBUG - 2022-06-29 11:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:03 --> Total execution time: 0.0511
DEBUG - 2022-06-29 11:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:05 --> Total execution time: 0.0523
DEBUG - 2022-06-29 11:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:05 --> Total execution time: 0.0479
DEBUG - 2022-06-29 11:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:06 --> Total execution time: 0.0513
DEBUG - 2022-06-29 11:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:08 --> Total execution time: 0.0568
DEBUG - 2022-06-29 22:01:08 --> Total execution time: 0.0770
DEBUG - 2022-06-29 11:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:12 --> Total execution time: 0.0518
DEBUG - 2022-06-29 11:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:13 --> Total execution time: 0.0483
DEBUG - 2022-06-29 11:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:14 --> Total execution time: 0.0531
DEBUG - 2022-06-29 11:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:15 --> Total execution time: 0.0487
DEBUG - 2022-06-29 11:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:15 --> Total execution time: 0.0487
DEBUG - 2022-06-29 11:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:16 --> Total execution time: 0.0516
DEBUG - 2022-06-29 11:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:16 --> Total execution time: 0.0532
DEBUG - 2022-06-29 11:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:17 --> Total execution time: 0.0595
DEBUG - 2022-06-29 11:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:17 --> Total execution time: 0.0533
DEBUG - 2022-06-29 11:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:27 --> Total execution time: 0.0483
DEBUG - 2022-06-29 11:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:36 --> Total execution time: 0.0564
DEBUG - 2022-06-29 11:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 11:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:37 --> Total execution time: 0.0445
DEBUG - 2022-06-29 11:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:08:46 --> Total execution time: 0.2191
DEBUG - 2022-06-29 11:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:39:04 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:09:04 --> Total execution time: 0.1323
DEBUG - 2022-06-29 11:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:09:16 --> Total execution time: 0.0757
DEBUG - 2022-06-29 11:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:09:34 --> Total execution time: 0.0806
DEBUG - 2022-06-29 11:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:10:52 --> Total execution time: 0.0489
DEBUG - 2022-06-29 11:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:43:54 --> Total execution time: 0.0460
DEBUG - 2022-06-29 11:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:14:04 --> Total execution time: 0.0791
DEBUG - 2022-06-29 11:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:14:14 --> Total execution time: 0.0518
DEBUG - 2022-06-29 11:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:14:26 --> Total execution time: 0.0538
DEBUG - 2022-06-29 11:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:14:35 --> Total execution time: 0.0562
DEBUG - 2022-06-29 11:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:45:42 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:15:42 --> Total execution time: 0.1236
DEBUG - 2022-06-29 11:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:45:43 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:15:43 --> Total execution time: 0.0508
DEBUG - 2022-06-29 11:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:45:44 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:15:44 --> Total execution time: 0.0277
DEBUG - 2022-06-29 11:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:15:48 --> Total execution time: 0.0263
DEBUG - 2022-06-29 11:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:45:49 --> Total execution time: 0.0934
DEBUG - 2022-06-29 11:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:45:52 --> Total execution time: 0.0476
DEBUG - 2022-06-29 11:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:45:52 --> Total execution time: 0.0716
DEBUG - 2022-06-29 11:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:16:09 --> Total execution time: 0.0443
DEBUG - 2022-06-29 11:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:16:10 --> Total execution time: 0.0514
DEBUG - 2022-06-29 11:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:16:24 --> Total execution time: 0.0689
DEBUG - 2022-06-29 11:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:16:29 --> Total execution time: 0.0495
DEBUG - 2022-06-29 11:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:16:41 --> Total execution time: 0.0576
DEBUG - 2022-06-29 11:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:17:00 --> Total execution time: 0.0495
DEBUG - 2022-06-29 11:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:17:08 --> Total execution time: 0.0649
DEBUG - 2022-06-29 11:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:48:52 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:18:52 --> Total execution time: 0.1432
DEBUG - 2022-06-29 11:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:18:58 --> Total execution time: 0.0657
DEBUG - 2022-06-29 11:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:19:05 --> Total execution time: 0.0968
DEBUG - 2022-06-29 11:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:19:22 --> Total execution time: 0.0783
DEBUG - 2022-06-29 11:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:19:29 --> Total execution time: 0.0911
DEBUG - 2022-06-29 11:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:19:52 --> Total execution time: 0.1091
DEBUG - 2022-06-29 11:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:20:05 --> Total execution time: 0.0772
DEBUG - 2022-06-29 11:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:20:06 --> Total execution time: 0.1042
DEBUG - 2022-06-29 11:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:20:17 --> Total execution time: 0.0500
DEBUG - 2022-06-29 11:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:20:18 --> Total execution time: 0.0619
DEBUG - 2022-06-29 11:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:20:26 --> Total execution time: 0.0573
DEBUG - 2022-06-29 11:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:20:56 --> Total execution time: 0.0871
DEBUG - 2022-06-29 11:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:20:56 --> Total execution time: 0.0513
DEBUG - 2022-06-29 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:21:09 --> Total execution time: 0.0676
DEBUG - 2022-06-29 11:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:21:23 --> Total execution time: 0.0515
DEBUG - 2022-06-29 11:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:21:30 --> Total execution time: 0.0541
DEBUG - 2022-06-29 11:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:21:43 --> Total execution time: 0.0543
DEBUG - 2022-06-29 11:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:21:54 --> Total execution time: 0.0500
DEBUG - 2022-06-29 11:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:22:07 --> Total execution time: 0.0505
DEBUG - 2022-06-29 11:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:22:08 --> Total execution time: 0.0534
DEBUG - 2022-06-29 11:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:22:39 --> Total execution time: 0.0557
DEBUG - 2022-06-29 11:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:22:42 --> Total execution time: 0.0503
DEBUG - 2022-06-29 11:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:22:43 --> Total execution time: 0.0637
DEBUG - 2022-06-29 11:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:22:45 --> Total execution time: 0.0493
DEBUG - 2022-06-29 11:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:27:36 --> Total execution time: 0.1159
DEBUG - 2022-06-29 11:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:59:05 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:29:05 --> Total execution time: 0.0410
DEBUG - 2022-06-29 11:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:59:37 --> Total execution time: 0.1168
DEBUG - 2022-06-29 11:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:59:38 --> Total execution time: 0.0482
DEBUG - 2022-06-29 11:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 11:59:38 --> Total execution time: 0.0495
DEBUG - 2022-06-29 11:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 11:59:39 --> No URI present. Default controller set.
DEBUG - 2022-06-29 11:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 11:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:29:39 --> Total execution time: 0.0337
DEBUG - 2022-06-29 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:30:03 --> Total execution time: 0.0606
DEBUG - 2022-06-29 12:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:02:13 --> No URI present. Default controller set.
DEBUG - 2022-06-29 12:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:32:13 --> Total execution time: 0.0371
DEBUG - 2022-06-29 12:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:03:06 --> No URI present. Default controller set.
DEBUG - 2022-06-29 12:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:33:06 --> Total execution time: 0.0410
DEBUG - 2022-06-29 12:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:35:10 --> Total execution time: 0.1097
DEBUG - 2022-06-29 12:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:09:25 --> No URI present. Default controller set.
DEBUG - 2022-06-29 12:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:39:25 --> Total execution time: 0.1269
DEBUG - 2022-06-29 12:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:09:50 --> No URI present. Default controller set.
DEBUG - 2022-06-29 12:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:39:50 --> Total execution time: 0.0341
DEBUG - 2022-06-29 12:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:39:57 --> Total execution time: 0.0484
DEBUG - 2022-06-29 12:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:40:11 --> Total execution time: 0.0755
DEBUG - 2022-06-29 12:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:40:23 --> Total execution time: 0.0734
DEBUG - 2022-06-29 12:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:40:24 --> Total execution time: 0.0596
DEBUG - 2022-06-29 12:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:40:52 --> Total execution time: 0.0551
DEBUG - 2022-06-29 12:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:40:59 --> Total execution time: 0.0571
DEBUG - 2022-06-29 12:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:41:07 --> Total execution time: 0.0722
DEBUG - 2022-06-29 12:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:42:32 --> Total execution time: 0.0508
DEBUG - 2022-06-29 12:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:48:27 --> Total execution time: 0.0983
DEBUG - 2022-06-29 12:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:18:36 --> Total execution time: 0.0349
DEBUG - 2022-06-29 12:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:23:40 --> No URI present. Default controller set.
DEBUG - 2022-06-29 12:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:53:40 --> Total execution time: 0.1913
DEBUG - 2022-06-29 12:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:23:41 --> No URI present. Default controller set.
DEBUG - 2022-06-29 12:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:53:41 --> Total execution time: 0.0437
DEBUG - 2022-06-29 12:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:54:28 --> Total execution time: 0.0576
DEBUG - 2022-06-29 12:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:24:29 --> No URI present. Default controller set.
DEBUG - 2022-06-29 12:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:54:29 --> Total execution time: 0.0363
DEBUG - 2022-06-29 12:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:54:37 --> Total execution time: 0.0661
DEBUG - 2022-06-29 12:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:54:44 --> Total execution time: 0.0636
DEBUG - 2022-06-29 12:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:54:55 --> Total execution time: 0.0540
DEBUG - 2022-06-29 12:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:55:32 --> Total execution time: 0.0507
DEBUG - 2022-06-29 12:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:55:36 --> Total execution time: 0.0704
DEBUG - 2022-06-29 12:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:56:03 --> Total execution time: 0.0459
DEBUG - 2022-06-29 12:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:56:11 --> Total execution time: 0.0464
DEBUG - 2022-06-29 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:56:13 --> Total execution time: 0.0473
DEBUG - 2022-06-29 12:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:56:19 --> Total execution time: 0.0481
DEBUG - 2022-06-29 12:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:28:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:28:52 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-29 12:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:29:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:29:00 --> 404 Page Not Found: Login/index
DEBUG - 2022-06-29 12:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:31:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:31:26 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-29 12:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:01:28 --> Total execution time: 0.0676
DEBUG - 2022-06-29 12:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:32:27 --> No URI present. Default controller set.
DEBUG - 2022-06-29 12:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:02:27 --> Total execution time: 0.1145
DEBUG - 2022-06-29 12:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:33:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:33:35 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-29 12:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:03:58 --> Total execution time: 0.0325
DEBUG - 2022-06-29 12:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:34:38 --> No URI present. Default controller set.
DEBUG - 2022-06-29 12:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:04:38 --> Total execution time: 0.0336
DEBUG - 2022-06-29 12:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:34:38 --> No URI present. Default controller set.
DEBUG - 2022-06-29 12:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:04:38 --> Total execution time: 0.0362
DEBUG - 2022-06-29 12:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:35:24 --> Total execution time: 0.0515
DEBUG - 2022-06-29 12:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:35:26 --> Total execution time: 0.0484
DEBUG - 2022-06-29 12:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:35:26 --> Total execution time: 0.1243
DEBUG - 2022-06-29 12:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:35:36 --> Total execution time: 0.0554
DEBUG - 2022-06-29 12:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:36:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 12:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:06:17 --> Total execution time: 1.9627
DEBUG - 2022-06-29 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:36:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:36:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 12:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:06:36 --> Total execution time: 0.0560
DEBUG - 2022-06-29 12:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:36:47 --> No URI present. Default controller set.
DEBUG - 2022-06-29 12:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:06:47 --> Total execution time: 0.0300
DEBUG - 2022-06-29 12:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:39 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-29 12:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:39 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-29 12:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:40 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-29 12:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:41 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-29 12:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:41 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-29 12:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:42 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-29 12:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:07:42 --> Total execution time: 0.0509
DEBUG - 2022-06-29 12:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:42 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-29 12:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:43 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-29 12:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:44 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-29 12:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:44 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-29 12:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:45 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-29 12:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:47 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-29 12:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:48 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-29 12:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:48 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-29 12:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:49 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-29 12:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:50 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-29 12:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:37:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:37:50 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-29 12:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:08:14 --> Total execution time: 0.0487
DEBUG - 2022-06-29 12:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:08:21 --> Total execution time: 0.0545
DEBUG - 2022-06-29 12:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:08:24 --> Total execution time: 0.0576
DEBUG - 2022-06-29 12:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:08:38 --> Total execution time: 0.0877
DEBUG - 2022-06-29 12:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:38:51 --> No URI present. Default controller set.
DEBUG - 2022-06-29 12:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:08:51 --> Total execution time: 0.0467
DEBUG - 2022-06-29 12:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:09:55 --> Total execution time: 1.5498
DEBUG - 2022-06-29 12:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:40:02 --> No URI present. Default controller set.
DEBUG - 2022-06-29 12:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:10:02 --> Total execution time: 0.0900
DEBUG - 2022-06-29 12:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:10:40 --> Total execution time: 0.0456
DEBUG - 2022-06-29 12:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:10:51 --> Total execution time: 0.0565
DEBUG - 2022-06-29 12:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:10:53 --> Total execution time: 0.1420
DEBUG - 2022-06-29 12:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:10:57 --> Total execution time: 0.0491
DEBUG - 2022-06-29 12:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:10:58 --> Total execution time: 0.0438
DEBUG - 2022-06-29 12:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:11:05 --> Total execution time: 0.0453
DEBUG - 2022-06-29 12:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:11:06 --> Total execution time: 0.0556
DEBUG - 2022-06-29 12:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:11:06 --> Total execution time: 0.0568
DEBUG - 2022-06-29 12:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:11:11 --> Total execution time: 0.0447
DEBUG - 2022-06-29 12:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:14:23 --> Total execution time: 0.1353
DEBUG - 2022-06-29 12:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:18:17 --> Total execution time: 0.0384
DEBUG - 2022-06-29 12:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:18:26 --> Total execution time: 0.0420
DEBUG - 2022-06-29 12:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:18:35 --> Total execution time: 0.0620
DEBUG - 2022-06-29 12:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:18:39 --> Total execution time: 0.0540
DEBUG - 2022-06-29 12:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:18:43 --> Total execution time: 0.0629
DEBUG - 2022-06-29 12:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:18:59 --> Total execution time: 0.0460
DEBUG - 2022-06-29 12:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:20:25 --> Total execution time: 0.0501
DEBUG - 2022-06-29 12:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:52:15 --> No URI present. Default controller set.
DEBUG - 2022-06-29 12:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:22:15 --> Total execution time: 0.0374
DEBUG - 2022-06-29 12:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:22:18 --> Total execution time: 0.0496
DEBUG - 2022-06-29 12:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:24:49 --> Total execution time: 0.1572
DEBUG - 2022-06-29 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 12:56:49 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-29 12:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 12:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 12:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 12:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:27:01 --> Total execution time: 0.0910
DEBUG - 2022-06-29 13:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:30:03 --> Total execution time: 0.0888
DEBUG - 2022-06-29 13:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:03:49 --> No URI present. Default controller set.
DEBUG - 2022-06-29 13:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:33:49 --> Total execution time: 0.1799
DEBUG - 2022-06-29 13:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:03:49 --> No URI present. Default controller set.
DEBUG - 2022-06-29 13:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:33:49 --> Total execution time: 0.0491
DEBUG - 2022-06-29 13:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:34:00 --> Total execution time: 0.0577
DEBUG - 2022-06-29 13:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:34:07 --> Total execution time: 0.0698
DEBUG - 2022-06-29 13:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:34:12 --> Total execution time: 0.0532
DEBUG - 2022-06-29 13:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:34:18 --> Total execution time: 0.0690
DEBUG - 2022-06-29 13:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:06:22 --> No URI present. Default controller set.
DEBUG - 2022-06-29 13:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:36:22 --> Total execution time: 0.1044
DEBUG - 2022-06-29 13:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:36:29 --> Total execution time: 0.0368
DEBUG - 2022-06-29 13:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:37:00 --> Total execution time: 0.0448
DEBUG - 2022-06-29 13:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:37:11 --> Total execution time: 0.0520
DEBUG - 2022-06-29 13:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:37:48 --> Total execution time: 0.0544
DEBUG - 2022-06-29 13:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:37:52 --> Total execution time: 0.1007
DEBUG - 2022-06-29 13:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:08:23 --> Total execution time: 0.0493
DEBUG - 2022-06-29 13:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:38:54 --> Total execution time: 0.0883
DEBUG - 2022-06-29 13:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:39:13 --> Total execution time: 0.1250
DEBUG - 2022-06-29 13:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:39:23 --> Total execution time: 0.0580
DEBUG - 2022-06-29 13:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:39:40 --> Total execution time: 0.0760
DEBUG - 2022-06-29 13:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:39:45 --> Total execution time: 0.0801
DEBUG - 2022-06-29 13:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:39:47 --> Total execution time: 0.0549
DEBUG - 2022-06-29 13:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:39:51 --> Total execution time: 0.0542
DEBUG - 2022-06-29 13:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:39:56 --> Total execution time: 0.0438
DEBUG - 2022-06-29 13:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:40:00 --> Total execution time: 0.0462
DEBUG - 2022-06-29 13:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:10:04 --> No URI present. Default controller set.
DEBUG - 2022-06-29 13:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:40:04 --> Total execution time: 0.0484
DEBUG - 2022-06-29 13:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:43:42 --> Total execution time: 0.0478
DEBUG - 2022-06-29 13:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:43:46 --> Total execution time: 0.0470
DEBUG - 2022-06-29 13:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:43:56 --> Total execution time: 0.0491
DEBUG - 2022-06-29 13:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:43:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 13:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:43:57 --> Total execution time: 0.0458
DEBUG - 2022-06-29 13:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:15:56 --> No URI present. Default controller set.
DEBUG - 2022-06-29 13:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:45:56 --> Total execution time: 0.0341
DEBUG - 2022-06-29 13:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:22:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 13:22:56 --> 404 Page Not Found: Contact/index
DEBUG - 2022-06-29 13:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:22:59 --> Total execution time: 0.1001
DEBUG - 2022-06-29 13:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:23:00 --> Total execution time: 0.0521
DEBUG - 2022-06-29 13:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:23:00 --> Total execution time: 0.1086
DEBUG - 2022-06-29 13:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:23:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 13:23:15 --> 404 Page Not Found: My-account/index
DEBUG - 2022-06-29 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 13:23:16 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 13:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:23:20 --> No URI present. Default controller set.
DEBUG - 2022-06-29 13:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:53:20 --> Total execution time: 0.1164
DEBUG - 2022-06-29 13:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:23:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 13:23:22 --> 404 Page Not Found: My-account/index
DEBUG - 2022-06-29 13:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:23:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 13:23:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 13:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:53:34 --> Total execution time: 0.0508
DEBUG - 2022-06-29 13:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:53:52 --> Total execution time: 0.1457
DEBUG - 2022-06-29 13:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:26:53 --> No URI present. Default controller set.
DEBUG - 2022-06-29 13:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:56:53 --> Total execution time: 0.1292
DEBUG - 2022-06-29 13:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:27:06 --> Total execution time: 0.0486
DEBUG - 2022-06-29 13:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:27:08 --> Total execution time: 0.0548
DEBUG - 2022-06-29 13:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:27:09 --> Total execution time: 0.0977
DEBUG - 2022-06-29 13:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:57:09 --> Total execution time: 0.0500
DEBUG - 2022-06-29 13:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:59:07 --> Total execution time: 0.0561
DEBUG - 2022-06-29 13:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:29:29 --> No URI present. Default controller set.
DEBUG - 2022-06-29 13:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:59:29 --> Total execution time: 0.0579
DEBUG - 2022-06-29 13:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:29:30 --> No URI present. Default controller set.
DEBUG - 2022-06-29 13:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:59:30 --> Total execution time: 0.0508
DEBUG - 2022-06-29 13:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:37:02 --> No URI present. Default controller set.
DEBUG - 2022-06-29 13:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:39:10 --> No URI present. Default controller set.
DEBUG - 2022-06-29 13:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:59:03 --> Total execution time: 0.0460
DEBUG - 2022-06-29 13:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 13:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 13:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 13:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 14:00:00 --> 404 Page Not Found: Course-category/development
DEBUG - 2022-06-29 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:00:17 --> No URI present. Default controller set.
DEBUG - 2022-06-29 14:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:00:18 --> No URI present. Default controller set.
DEBUG - 2022-06-29 14:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:06:18 --> No URI present. Default controller set.
DEBUG - 2022-06-29 14:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:07:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 14:07:49 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-29 14:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:10:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 14:10:19 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-29 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 14:12:29 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-29 14:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:28:18 --> No URI present. Default controller set.
DEBUG - 2022-06-29 14:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:37:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 14:37:16 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-29 14:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:37:35 --> No URI present. Default controller set.
DEBUG - 2022-06-29 14:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:43:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 14:43:53 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-29 14:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:43:54 --> No URI present. Default controller set.
DEBUG - 2022-06-29 14:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:44:00 --> No URI present. Default controller set.
DEBUG - 2022-06-29 14:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:44:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 14:44:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 14:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 14:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 14:57:54 --> No URI present. Default controller set.
DEBUG - 2022-06-29 14:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 14:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:22:20 --> No URI present. Default controller set.
DEBUG - 2022-06-29 15:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:25:24 --> No URI present. Default controller set.
DEBUG - 2022-06-29 15:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:40:30 --> Total execution time: 0.0864
DEBUG - 2022-06-29 15:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:40:50 --> Total execution time: 0.0496
DEBUG - 2022-06-29 15:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:47:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 15:47:42 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-29 15:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:49:58 --> No URI present. Default controller set.
DEBUG - 2022-06-29 15:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:50:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 15:50:09 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-29 15:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:50:42 --> Total execution time: 0.0383
DEBUG - 2022-06-29 15:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:50:42 --> No URI present. Default controller set.
DEBUG - 2022-06-29 15:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:50:44 --> Total execution time: 0.0787
DEBUG - 2022-06-29 15:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:50:44 --> Total execution time: 0.1421
DEBUG - 2022-06-29 15:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:50:50 --> Total execution time: 0.0654
DEBUG - 2022-06-29 15:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:50:51 --> Total execution time: 0.0547
DEBUG - 2022-06-29 15:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:50:51 --> Total execution time: 0.1027
DEBUG - 2022-06-29 15:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:51:01 --> Total execution time: 0.1327
DEBUG - 2022-06-29 15:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:51:03 --> Total execution time: 0.0482
DEBUG - 2022-06-29 15:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:51:03 --> Total execution time: 0.1108
DEBUG - 2022-06-29 15:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 15:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 15:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 15:52:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 15:52:11 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-29 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:03:10 --> No URI present. Default controller set.
DEBUG - 2022-06-29 16:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:15:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 16:15:14 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-29 16:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:26:08 --> No URI present. Default controller set.
DEBUG - 2022-06-29 16:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:26:08 --> No URI present. Default controller set.
DEBUG - 2022-06-29 16:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 16:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 16:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 16:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:24:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 17:24:38 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-29 17:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:27:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 17:27:06 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-29 17:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:29:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 17:29:15 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-29 17:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 17:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 17:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:49:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 17:49:33 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-29 17:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:52:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 17:52:07 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-29 17:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 17:58:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 17:58:45 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-29 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 18:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 18:16:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 18:16:43 --> 404 Page Not Found: Courses/index
DEBUG - 2022-06-29 18:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 18:42:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 18:42:32 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-29 18:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 18:55:08 --> No URI present. Default controller set.
DEBUG - 2022-06-29 18:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 18:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 18:55:09 --> No URI present. Default controller set.
DEBUG - 2022-06-29 18:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 18:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 18:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 18:55:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 18:55:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 19:01:29 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-29 19:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:04:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 19:04:00 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-29 19:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 19:06:07 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-29 19:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:07:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 19:07:05 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-29 19:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 19:07:07 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-29 19:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:07:28 --> No URI present. Default controller set.
DEBUG - 2022-06-29 19:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:07:42 --> No URI present. Default controller set.
DEBUG - 2022-06-29 19:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 19:08:38 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-29 19:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:08:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 19:08:42 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-29 19:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:09:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 19:09:15 --> 404 Page Not Found: Membership-account/membership-checkout
DEBUG - 2022-06-29 19:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:09:27 --> No URI present. Default controller set.
DEBUG - 2022-06-29 19:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:29:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 19:29:14 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-29 19:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:54:00 --> No URI present. Default controller set.
DEBUG - 2022-06-29 19:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 19:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 19:55:41 --> No URI present. Default controller set.
DEBUG - 2022-06-29 19:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 19:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:01:45 --> No URI present. Default controller set.
DEBUG - 2022-06-29 20:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:05:06 --> No URI present. Default controller set.
DEBUG - 2022-06-29 20:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:06:44 --> No URI present. Default controller set.
DEBUG - 2022-06-29 20:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:07:46 --> No URI present. Default controller set.
DEBUG - 2022-06-29 20:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:08:26 --> No URI present. Default controller set.
DEBUG - 2022-06-29 20:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:08:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 20:08:26 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-06-29 20:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:16:50 --> No URI present. Default controller set.
DEBUG - 2022-06-29 20:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:20:09 --> No URI present. Default controller set.
DEBUG - 2022-06-29 20:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:20:37 --> No URI present. Default controller set.
DEBUG - 2022-06-29 20:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:20:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 20:20:41 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-29 20:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:21:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 20:21:03 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-29 20:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:38:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 20:38:47 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-29 20:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:40:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 20:40:20 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-29 20:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:41:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 20:41:12 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-29 20:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:42:21 --> No URI present. Default controller set.
DEBUG - 2022-06-29 20:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:43:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 20:43:14 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-29 20:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:49:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 20:49:35 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-06-29 20:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:49:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 20:49:37 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 20:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 20:56:05 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-06-29 20:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:59:28 --> No URI present. Default controller set.
DEBUG - 2022-06-29 20:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:59:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 20:59:28 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-06-29 20:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:59:51 --> Total execution time: 0.0497
DEBUG - 2022-06-29 20:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 20:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 20:59:52 --> Total execution time: 0.0765
DEBUG - 2022-06-29 20:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 20:59:52 --> Total execution time: 0.0809
DEBUG - 2022-06-29 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:00:09 --> No URI present. Default controller set.
DEBUG - 2022-06-29 21:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:05:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 21:05:34 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-29 21:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:06:35 --> No URI present. Default controller set.
DEBUG - 2022-06-29 21:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:09:31 --> No URI present. Default controller set.
DEBUG - 2022-06-29 21:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:09:32 --> No URI present. Default controller set.
DEBUG - 2022-06-29 21:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:11:53 --> No URI present. Default controller set.
DEBUG - 2022-06-29 21:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 21:19:47 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-29 21:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:20:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 21:20:19 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-29 21:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:22:01 --> No URI present. Default controller set.
DEBUG - 2022-06-29 21:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:22:17 --> No URI present. Default controller set.
DEBUG - 2022-06-29 21:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:36:33 --> No URI present. Default controller set.
DEBUG - 2022-06-29 21:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:43:03 --> No URI present. Default controller set.
DEBUG - 2022-06-29 21:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:43:49 --> Total execution time: 0.0621
DEBUG - 2022-06-29 21:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:43:53 --> Total execution time: 0.0555
DEBUG - 2022-06-29 21:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:43:53 --> Total execution time: 0.1191
DEBUG - 2022-06-29 21:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:44:32 --> No URI present. Default controller set.
DEBUG - 2022-06-29 21:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:45:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 21:45:10 --> 404 Page Not Found: Apple-app-site-association/index
DEBUG - 2022-06-29 21:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:45:28 --> No URI present. Default controller set.
DEBUG - 2022-06-29 21:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:46:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 21:46:18 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-06-29 21:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:53:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 21:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:53:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 21:53:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 21:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:55:09 --> No URI present. Default controller set.
DEBUG - 2022-06-29 21:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:56:05 --> No URI present. Default controller set.
DEBUG - 2022-06-29 21:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:56:57 --> No URI present. Default controller set.
DEBUG - 2022-06-29 21:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 21:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 21:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 21:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:01:27 --> No URI present. Default controller set.
DEBUG - 2022-06-29 22:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:01:53 --> No URI present. Default controller set.
DEBUG - 2022-06-29 22:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:01:56 --> No URI present. Default controller set.
DEBUG - 2022-06-29 22:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:02:21 --> No URI present. Default controller set.
DEBUG - 2022-06-29 22:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:02:22 --> No URI present. Default controller set.
DEBUG - 2022-06-29 22:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:08:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 22:08:56 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-29 22:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:09:15 --> No URI present. Default controller set.
DEBUG - 2022-06-29 22:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:09:16 --> No URI present. Default controller set.
DEBUG - 2022-06-29 22:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:13:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 22:13:24 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-29 22:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 22:15:46 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-29 22:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:15:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 22:15:53 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-29 22:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 22:17:50 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-29 22:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:22:34 --> No URI present. Default controller set.
DEBUG - 2022-06-29 22:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:22:34 --> No URI present. Default controller set.
DEBUG - 2022-06-29 22:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:23:48 --> No URI present. Default controller set.
DEBUG - 2022-06-29 22:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:24:54 --> No URI present. Default controller set.
DEBUG - 2022-06-29 22:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:27:11 --> No URI present. Default controller set.
DEBUG - 2022-06-29 22:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:33:46 --> No URI present. Default controller set.
DEBUG - 2022-06-29 22:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:35:16 --> Total execution time: 0.0380
DEBUG - 2022-06-29 22:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:37:36 --> Total execution time: 0.0619
DEBUG - 2022-06-29 22:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:37:48 --> Total execution time: 0.0468
DEBUG - 2022-06-29 22:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:37:55 --> Total execution time: 0.0547
DEBUG - 2022-06-29 22:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:38:00 --> Total execution time: 0.0482
DEBUG - 2022-06-29 22:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:38:02 --> Total execution time: 0.0547
DEBUG - 2022-06-29 22:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:38:04 --> Total execution time: 0.0470
DEBUG - 2022-06-29 22:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:38:06 --> Total execution time: 0.0613
DEBUG - 2022-06-29 22:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:40:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 22:40:05 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-29 22:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:47:11 --> No URI present. Default controller set.
DEBUG - 2022-06-29 22:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:47:19 --> Total execution time: 0.0831
DEBUG - 2022-06-29 22:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:47:20 --> Total execution time: 0.0835
DEBUG - 2022-06-29 22:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:47:20 --> Total execution time: 0.1558
DEBUG - 2022-06-29 22:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:48:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-29 22:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:48:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 22:48:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-29 22:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:51:24 --> No URI present. Default controller set.
DEBUG - 2022-06-29 22:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:53:06 --> No URI present. Default controller set.
DEBUG - 2022-06-29 22:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 22:53:46 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-06-29 22:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 22:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 22:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 22:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 22:53:56 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-06-29 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:00:48 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:04:10 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:08:17 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:22:26 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:22:50 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:22:57 --> Total execution time: 0.0666
DEBUG - 2022-06-29 23:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:22:59 --> Total execution time: 0.0453
DEBUG - 2022-06-29 23:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:22:59 --> Total execution time: 0.1123
DEBUG - 2022-06-29 23:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 23:31:50 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-29 23:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:32:29 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 23:36:13 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-29 23:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:42:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 23:42:50 --> 404 Page Not Found: Lessons/filmora-registration
DEBUG - 2022-06-29 23:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:45:05 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:45:10 --> Total execution time: 0.0691
DEBUG - 2022-06-29 23:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:45:13 --> Total execution time: 0.0762
DEBUG - 2022-06-29 23:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:45:14 --> Total execution time: 0.1072
DEBUG - 2022-06-29 23:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:47:11 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:11 --> Total execution time: 0.0462
DEBUG - 2022-06-29 23:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:12 --> Total execution time: 0.0506
DEBUG - 2022-06-29 23:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:12 --> Total execution time: 0.1083
DEBUG - 2022-06-29 23:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:25 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:28 --> Total execution time: 0.0634
DEBUG - 2022-06-29 23:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:29 --> Total execution time: 0.0517
DEBUG - 2022-06-29 23:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:29 --> Total execution time: 0.1106
DEBUG - 2022-06-29 23:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:39 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:44 --> Total execution time: 0.0484
DEBUG - 2022-06-29 23:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 23:48:45 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-29 23:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:46 --> Total execution time: 0.0559
DEBUG - 2022-06-29 23:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:48:46 --> Total execution time: 0.1080
DEBUG - 2022-06-29 23:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:50:01 --> Total execution time: 0.0624
DEBUG - 2022-06-29 23:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:50:02 --> Total execution time: 0.0557
DEBUG - 2022-06-29 23:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:50:02 --> Total execution time: 0.1276
DEBUG - 2022-06-29 23:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:50:29 --> Total execution time: 0.1152
DEBUG - 2022-06-29 23:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:50:30 --> Total execution time: 0.0458
DEBUG - 2022-06-29 23:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:50:30 --> Total execution time: 0.0513
DEBUG - 2022-06-29 23:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:50:32 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:50:36 --> Total execution time: 0.0547
DEBUG - 2022-06-29 23:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:50:37 --> Total execution time: 0.0494
DEBUG - 2022-06-29 23:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:50:37 --> Total execution time: 0.1048
DEBUG - 2022-06-29 23:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:50:43 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:50:44 --> Total execution time: 0.0480
DEBUG - 2022-06-29 23:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:50:45 --> Total execution time: 0.0526
DEBUG - 2022-06-29 23:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:50:46 --> Total execution time: 0.1043
DEBUG - 2022-06-29 23:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 23:51:11 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-29 23:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:51:24 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:51:24 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:51:28 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:51:33 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 23:53:12 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-29 23:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:56:56 --> No URI present. Default controller set.
DEBUG - 2022-06-29 23:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-29 23:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-29 23:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-29 23:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-29 23:59:21 --> 404 Page Not Found: Courses/index
