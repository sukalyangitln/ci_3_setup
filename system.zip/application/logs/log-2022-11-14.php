<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-11-14 00:01:53 --> Total execution time: 1.4867
DEBUG - 2022-11-14 00:03:29 --> Total execution time: 0.6155
DEBUG - 2022-11-14 00:10:21 --> Total execution time: 0.6615
DEBUG - 2022-11-14 00:10:23 --> Total execution time: 0.1186
DEBUG - 2022-11-14 00:20:39 --> Total execution time: 0.6413
DEBUG - 2022-11-14 00:30:04 --> Total execution time: 1.2441
DEBUG - 2022-11-14 00:36:56 --> Total execution time: 0.6300
DEBUG - 2022-11-14 00:36:58 --> Total execution time: 0.1677
DEBUG - 2022-11-14 00:37:01 --> Total execution time: 0.1678
DEBUG - 2022-11-14 00:37:05 --> Total execution time: 0.1710
DEBUG - 2022-11-14 00:49:54 --> Total execution time: 0.5646
DEBUG - 2022-11-14 00:50:00 --> Total execution time: 0.1719
DEBUG - 2022-11-14 00:50:43 --> Total execution time: 0.1915
DEBUG - 2022-11-14 00:54:16 --> Total execution time: 0.4967
DEBUG - 2022-11-14 00:54:25 --> Total execution time: 0.1102
DEBUG - 2022-11-14 00:54:40 --> Total execution time: 0.2048
DEBUG - 2022-11-14 00:54:52 --> Total execution time: 0.2417
DEBUG - 2022-11-14 01:03:39 --> Total execution time: 0.1140
DEBUG - 2022-11-14 01:15:51 --> Total execution time: 0.5675
DEBUG - 2022-11-14 01:15:55 --> Total execution time: 0.1762
DEBUG - 2022-11-14 01:15:59 --> Total execution time: 0.1674
DEBUG - 2022-11-14 01:16:34 --> Total execution time: 0.1755
DEBUG - 2022-11-14 01:16:42 --> Total execution time: 0.1678
DEBUG - 2022-11-14 01:16:53 --> Total execution time: 0.1692
DEBUG - 2022-11-14 01:17:00 --> Total execution time: 0.1757
DEBUG - 2022-11-14 01:17:04 --> Total execution time: 0.1689
DEBUG - 2022-11-14 01:17:12 --> Total execution time: 0.1747
DEBUG - 2022-11-14 01:17:17 --> Total execution time: 0.1858
DEBUG - 2022-11-14 01:17:20 --> Total execution time: 0.1691
DEBUG - 2022-11-14 01:17:45 --> Total execution time: 0.4749
DEBUG - 2022-11-14 01:18:50 --> Total execution time: 0.1746
DEBUG - 2022-11-14 01:18:54 --> Total execution time: 0.1693
DEBUG - 2022-11-14 01:18:56 --> Total execution time: 0.1742
DEBUG - 2022-11-14 01:18:58 --> Total execution time: 0.1699
DEBUG - 2022-11-14 01:19:00 --> Total execution time: 0.1769
DEBUG - 2022-11-14 01:25:59 --> Total execution time: 0.1743
DEBUG - 2022-11-14 01:26:03 --> Total execution time: 0.1737
DEBUG - 2022-11-14 01:26:05 --> Total execution time: 0.1660
DEBUG - 2022-11-14 01:26:26 --> Total execution time: 0.4569
DEBUG - 2022-11-14 01:26:34 --> Total execution time: 0.2002
DEBUG - 2022-11-14 01:26:39 --> Total execution time: 0.1642
DEBUG - 2022-11-14 01:26:44 --> Total execution time: 0.1714
DEBUG - 2022-11-14 01:26:52 --> Total execution time: 0.1622
DEBUG - 2022-11-14 01:26:58 --> Total execution time: 0.1647
DEBUG - 2022-11-14 01:27:06 --> Total execution time: 0.1613
DEBUG - 2022-11-14 01:27:15 --> Total execution time: 0.1658
DEBUG - 2022-11-14 01:27:18 --> Total execution time: 0.1720
DEBUG - 2022-11-14 01:27:27 --> Total execution time: 0.1693
DEBUG - 2022-11-14 01:27:37 --> Total execution time: 0.1650
DEBUG - 2022-11-14 01:27:43 --> Total execution time: 0.2144
DEBUG - 2022-11-14 01:27:46 --> Total execution time: 0.2476
DEBUG - 2022-11-14 01:27:54 --> Total execution time: 0.1728
DEBUG - 2022-11-14 01:27:56 --> Total execution time: 0.1985
DEBUG - 2022-11-14 01:28:11 --> Total execution time: 0.1751
DEBUG - 2022-11-14 01:28:14 --> Total execution time: 0.2063
DEBUG - 2022-11-14 01:28:18 --> Total execution time: 0.1703
DEBUG - 2022-11-14 01:28:23 --> Total execution time: 0.1733
DEBUG - 2022-11-14 01:28:26 --> Total execution time: 0.1773
DEBUG - 2022-11-14 01:28:39 --> Total execution time: 0.1901
DEBUG - 2022-11-14 01:28:42 --> Total execution time: 0.1888
DEBUG - 2022-11-14 01:28:49 --> Total execution time: 0.1746
DEBUG - 2022-11-14 01:28:57 --> Total execution time: 0.1680
DEBUG - 2022-11-14 01:28:59 --> Total execution time: 0.1668
DEBUG - 2022-11-14 01:29:11 --> Total execution time: 0.1667
DEBUG - 2022-11-14 01:29:16 --> Total execution time: 0.1682
DEBUG - 2022-11-14 01:29:18 --> Total execution time: 0.1713
DEBUG - 2022-11-14 01:29:25 --> Total execution time: 0.1721
DEBUG - 2022-11-14 01:29:36 --> Total execution time: 0.1650
DEBUG - 2022-11-14 01:29:41 --> Total execution time: 0.1674
DEBUG - 2022-11-14 01:29:50 --> Total execution time: 0.1656
DEBUG - 2022-11-14 01:29:53 --> Total execution time: 0.1833
DEBUG - 2022-11-14 01:29:57 --> Total execution time: 0.1612
DEBUG - 2022-11-14 01:30:02 --> Total execution time: 0.1807
DEBUG - 2022-11-14 01:30:07 --> Total execution time: 0.1735
DEBUG - 2022-11-14 01:30:11 --> Total execution time: 0.1928
DEBUG - 2022-11-14 01:30:15 --> Total execution time: 0.1848
DEBUG - 2022-11-14 01:30:20 --> Total execution time: 0.1708
DEBUG - 2022-11-14 01:43:08 --> Total execution time: 1.0798
DEBUG - 2022-11-14 01:44:29 --> Total execution time: 0.5845
DEBUG - 2022-11-14 02:16:00 --> Total execution time: 0.5295
DEBUG - 2022-11-14 02:30:02 --> Total execution time: 0.8682
DEBUG - 2022-11-14 02:54:07 --> Total execution time: 0.7893
DEBUG - 2022-11-14 03:20:09 --> Total execution time: 0.6261
DEBUG - 2022-11-14 03:20:16 --> Total execution time: 0.2287
DEBUG - 2022-11-14 03:20:25 --> Total execution time: 0.2277
DEBUG - 2022-11-14 03:20:33 --> Total execution time: 0.2106
DEBUG - 2022-11-14 03:20:40 --> Total execution time: 0.2014
DEBUG - 2022-11-14 03:21:01 --> Total execution time: 0.2224
DEBUG - 2022-11-14 03:30:03 --> Total execution time: 1.2468
DEBUG - 2022-11-14 03:33:49 --> Total execution time: 0.6044
DEBUG - 2022-11-14 03:36:04 --> Total execution time: 1.2506
DEBUG - 2022-11-14 03:36:11 --> Total execution time: 0.1926
DEBUG - 2022-11-14 03:36:13 --> Total execution time: 0.1868
DEBUG - 2022-11-14 03:36:17 --> Total execution time: 0.2282
DEBUG - 2022-11-14 03:36:43 --> Total execution time: 0.2957
DEBUG - 2022-11-14 03:36:51 --> Total execution time: 0.1991
DEBUG - 2022-11-14 03:37:04 --> Total execution time: 0.1955
DEBUG - 2022-11-14 03:50:55 --> Total execution time: 0.5851
DEBUG - 2022-11-14 04:02:41 --> Total execution time: 0.5033
DEBUG - 2022-11-14 04:21:57 --> Total execution time: 0.8632
DEBUG - 2022-11-14 04:30:02 --> Total execution time: 0.6267
DEBUG - 2022-11-14 04:36:42 --> Total execution time: 0.6125
DEBUG - 2022-11-14 04:36:44 --> Total execution time: 0.1155
DEBUG - 2022-11-14 04:37:49 --> Total execution time: 0.4986
DEBUG - 2022-11-14 04:37:54 --> Total execution time: 0.1794
DEBUG - 2022-11-14 04:38:11 --> Total execution time: 0.1772
DEBUG - 2022-11-14 04:38:15 --> Total execution time: 0.1745
DEBUG - 2022-11-14 04:38:25 --> Total execution time: 0.1725
DEBUG - 2022-11-14 04:38:46 --> Total execution time: 0.1725
DEBUG - 2022-11-14 04:39:08 --> Total execution time: 0.1697
DEBUG - 2022-11-14 04:47:19 --> Total execution time: 0.8998
DEBUG - 2022-11-14 04:47:19 --> Total execution time: 0.7941
DEBUG - 2022-11-14 04:47:19 --> Total execution time: 0.5574
DEBUG - 2022-11-14 05:15:32 --> Total execution time: 0.5117
DEBUG - 2022-11-14 05:16:27 --> Total execution time: 0.7462
DEBUG - 2022-11-14 05:17:46 --> Total execution time: 0.4492
DEBUG - 2022-11-14 05:21:58 --> Total execution time: 0.1134
DEBUG - 2022-11-14 05:30:03 --> Total execution time: 0.8246
DEBUG - 2022-11-14 05:33:41 --> Total execution time: 0.8528
DEBUG - 2022-11-14 05:36:09 --> Total execution time: 0.6563
DEBUG - 2022-11-14 05:53:26 --> Total execution time: 0.4863
DEBUG - 2022-11-14 05:53:36 --> Total execution time: 0.1205
DEBUG - 2022-11-14 05:53:56 --> Total execution time: 0.1352
DEBUG - 2022-11-14 05:54:13 --> Total execution time: 0.1159
DEBUG - 2022-11-14 05:57:15 --> Total execution time: 0.1131
DEBUG - 2022-11-14 05:57:56 --> Total execution time: 0.1183
DEBUG - 2022-11-14 06:10:01 --> Total execution time: 0.5493
DEBUG - 2022-11-14 06:10:26 --> Total execution time: 0.1036
DEBUG - 2022-11-14 06:10:35 --> Total execution time: 0.2070
DEBUG - 2022-11-14 06:10:36 --> Total execution time: 0.1076
DEBUG - 2022-11-14 06:10:36 --> Total execution time: 0.1725
DEBUG - 2022-11-14 06:11:03 --> Total execution time: 0.1964
DEBUG - 2022-11-14 06:11:13 --> Total execution time: 0.2117
DEBUG - 2022-11-14 06:11:42 --> Total execution time: 0.1813
DEBUG - 2022-11-14 06:11:56 --> Total execution time: 0.1843
DEBUG - 2022-11-14 06:12:13 --> Total execution time: 0.1105
DEBUG - 2022-11-14 06:12:29 --> Total execution time: 0.1760
DEBUG - 2022-11-14 06:12:36 --> Total execution time: 0.1762
DEBUG - 2022-11-14 06:12:36 --> Total execution time: 0.1761
DEBUG - 2022-11-14 06:12:37 --> Total execution time: 0.1774
DEBUG - 2022-11-14 06:12:44 --> Total execution time: 0.2097
DEBUG - 2022-11-14 06:12:49 --> Total execution time: 0.1868
DEBUG - 2022-11-14 06:13:01 --> Total execution time: 0.1752
DEBUG - 2022-11-14 06:13:20 --> Total execution time: 0.1752
DEBUG - 2022-11-14 06:21:33 --> Total execution time: 0.4858
DEBUG - 2022-11-14 06:21:40 --> Total execution time: 0.1790
DEBUG - 2022-11-14 06:21:57 --> Total execution time: 0.2086
DEBUG - 2022-11-14 06:22:05 --> Total execution time: 0.2190
DEBUG - 2022-11-14 06:22:10 --> Total execution time: 0.1157
DEBUG - 2022-11-14 06:22:10 --> Total execution time: 0.1826
DEBUG - 2022-11-14 06:22:46 --> Total execution time: 0.1701
DEBUG - 2022-11-14 06:22:55 --> Total execution time: 0.1680
DEBUG - 2022-11-14 06:24:48 --> Total execution time: 0.1688
DEBUG - 2022-11-14 06:30:03 --> Total execution time: 0.1453
DEBUG - 2022-11-14 06:35:04 --> Total execution time: 0.5598
DEBUG - 2022-11-14 06:35:47 --> Total execution time: 0.1674
DEBUG - 2022-11-14 06:43:14 --> Total execution time: 0.7297
DEBUG - 2022-11-14 06:44:02 --> Total execution time: 2.4659
DEBUG - 2022-11-14 06:45:12 --> Total execution time: 0.6675
DEBUG - 2022-11-14 06:45:58 --> Total execution time: 0.1775
DEBUG - 2022-11-14 06:46:31 --> Total execution time: 0.2314
DEBUG - 2022-11-14 06:47:09 --> Total execution time: 0.1776
DEBUG - 2022-11-14 06:47:11 --> Total execution time: 0.2195
DEBUG - 2022-11-14 06:47:46 --> Total execution time: 0.2063
DEBUG - 2022-11-14 06:49:01 --> Total execution time: 0.2358
DEBUG - 2022-11-14 06:49:06 --> Total execution time: 0.1841
DEBUG - 2022-11-14 06:49:25 --> Total execution time: 0.1689
DEBUG - 2022-11-14 06:50:25 --> Total execution time: 0.4599
DEBUG - 2022-11-14 06:50:29 --> Total execution time: 0.1752
DEBUG - 2022-11-14 06:50:37 --> Total execution time: 0.2275
DEBUG - 2022-11-14 06:51:27 --> Total execution time: 0.1728
DEBUG - 2022-11-14 06:51:31 --> Total execution time: 0.1701
DEBUG - 2022-11-14 06:52:14 --> Total execution time: 0.1174
DEBUG - 2022-11-14 06:53:37 --> Total execution time: 0.1832
DEBUG - 2022-11-14 06:53:38 --> Total execution time: 0.1715
DEBUG - 2022-11-14 06:57:42 --> Total execution time: 0.1992
DEBUG - 2022-11-14 06:58:03 --> Total execution time: 0.1042
DEBUG - 2022-11-14 06:58:14 --> Total execution time: 0.1709
DEBUG - 2022-11-14 06:58:20 --> Total execution time: 0.1829
DEBUG - 2022-11-14 06:58:42 --> Total execution time: 0.1983
DEBUG - 2022-11-14 06:58:43 --> Total execution time: 0.1961
DEBUG - 2022-11-14 06:58:47 --> Total execution time: 0.1104
DEBUG - 2022-11-14 06:58:49 --> Total execution time: 0.1759
DEBUG - 2022-11-14 06:59:04 --> Total execution time: 0.1830
DEBUG - 2022-11-14 06:59:05 --> Total execution time: 0.1703
DEBUG - 2022-11-14 06:59:22 --> Total execution time: 0.1771
DEBUG - 2022-11-14 07:07:25 --> Total execution time: 0.5243
DEBUG - 2022-11-14 07:12:09 --> Total execution time: 0.2245
DEBUG - 2022-11-14 07:14:25 --> Total execution time: 0.1172
DEBUG - 2022-11-14 07:16:05 --> Total execution time: 0.4688
DEBUG - 2022-11-14 07:17:35 --> Total execution time: 0.1608
DEBUG - 2022-11-14 07:17:43 --> Total execution time: 0.2051
DEBUG - 2022-11-14 07:17:50 --> Total execution time: 0.2620
DEBUG - 2022-11-14 07:22:38 --> Total execution time: 0.1653
DEBUG - 2022-11-14 07:23:00 --> Total execution time: 0.3424
DEBUG - 2022-11-14 07:23:01 --> Total execution time: 0.2168
DEBUG - 2022-11-14 07:24:00 --> Total execution time: 0.1673
DEBUG - 2022-11-14 07:24:04 --> Total execution time: 0.1695
DEBUG - 2022-11-14 07:30:03 --> Total execution time: 0.5560
DEBUG - 2022-11-14 07:33:27 --> Total execution time: 0.1898
DEBUG - 2022-11-14 07:34:46 --> Total execution time: 0.1150
DEBUG - 2022-11-14 07:35:13 --> Total execution time: 0.1804
DEBUG - 2022-11-14 07:35:15 --> Total execution time: 0.1613
DEBUG - 2022-11-14 07:35:39 --> Total execution time: 0.1685
DEBUG - 2022-11-14 07:35:40 --> Total execution time: 0.1639
DEBUG - 2022-11-14 07:35:50 --> Total execution time: 0.1610
DEBUG - 2022-11-14 07:35:52 --> Total execution time: 0.1142
DEBUG - 2022-11-14 07:38:11 --> Total execution time: 0.1699
DEBUG - 2022-11-14 07:40:23 --> Total execution time: 0.1709
DEBUG - 2022-11-14 07:44:03 --> Total execution time: 0.5420
DEBUG - 2022-11-14 07:44:04 --> Total execution time: 0.1122
DEBUG - 2022-11-14 07:44:16 --> Total execution time: 0.1706
DEBUG - 2022-11-14 07:44:29 --> Total execution time: 0.1828
DEBUG - 2022-11-14 07:44:29 --> Total execution time: 0.2182
DEBUG - 2022-11-14 07:44:49 --> Total execution time: 0.1642
DEBUG - 2022-11-14 07:45:00 --> Total execution time: 0.1895
DEBUG - 2022-11-14 07:45:31 --> Total execution time: 0.1821
DEBUG - 2022-11-14 07:45:56 --> Total execution time: 0.1782
DEBUG - 2022-11-14 07:46:05 --> Total execution time: 0.1921
DEBUG - 2022-11-14 07:46:06 --> Total execution time: 0.1673
DEBUG - 2022-11-14 07:47:13 --> Total execution time: 0.1705
DEBUG - 2022-11-14 07:47:19 --> Total execution time: 0.1658
DEBUG - 2022-11-14 07:47:22 --> Total execution time: 0.2102
DEBUG - 2022-11-14 07:47:32 --> Total execution time: 0.1672
DEBUG - 2022-11-14 07:47:36 --> Total execution time: 0.1971
DEBUG - 2022-11-14 07:47:42 --> Total execution time: 0.1192
DEBUG - 2022-11-14 07:47:44 --> Total execution time: 0.1657
DEBUG - 2022-11-14 07:47:53 --> Total execution time: 0.1751
DEBUG - 2022-11-14 07:47:54 --> Total execution time: 0.1747
DEBUG - 2022-11-14 07:47:58 --> Total execution time: 0.2539
DEBUG - 2022-11-14 07:47:58 --> Total execution time: 0.1891
DEBUG - 2022-11-14 07:48:02 --> Total execution time: 0.2538
DEBUG - 2022-11-14 07:48:05 --> Total execution time: 0.1846
DEBUG - 2022-11-14 07:48:12 --> Total execution time: 0.1695
DEBUG - 2022-11-14 07:48:14 --> Total execution time: 0.1833
DEBUG - 2022-11-14 07:48:15 --> Total execution time: 0.1770
DEBUG - 2022-11-14 07:48:16 --> Total execution time: 0.1746
DEBUG - 2022-11-14 07:48:30 --> Total execution time: 0.1800
DEBUG - 2022-11-14 07:48:42 --> Total execution time: 0.1754
DEBUG - 2022-11-14 07:48:42 --> Total execution time: 0.1775
DEBUG - 2022-11-14 07:48:48 --> Total execution time: 0.1786
DEBUG - 2022-11-14 07:49:05 --> Total execution time: 0.1709
DEBUG - 2022-11-14 07:49:07 --> Total execution time: 0.1707
DEBUG - 2022-11-14 07:49:18 --> Total execution time: 0.1676
DEBUG - 2022-11-14 07:49:26 --> Total execution time: 0.1778
DEBUG - 2022-11-14 07:49:31 --> Total execution time: 0.1935
DEBUG - 2022-11-14 07:49:42 --> Total execution time: 0.1662
DEBUG - 2022-11-14 07:49:58 --> Total execution time: 0.1765
DEBUG - 2022-11-14 07:50:13 --> Total execution time: 0.1754
DEBUG - 2022-11-14 07:50:30 --> Total execution time: 0.1891
DEBUG - 2022-11-14 07:50:31 --> Total execution time: 0.1670
DEBUG - 2022-11-14 07:50:37 --> Total execution time: 0.1995
DEBUG - 2022-11-14 07:50:47 --> Total execution time: 0.1739
DEBUG - 2022-11-14 07:50:54 --> Total execution time: 0.1749
DEBUG - 2022-11-14 07:51:01 --> Total execution time: 0.1947
DEBUG - 2022-11-14 07:51:06 --> Total execution time: 0.1884
DEBUG - 2022-11-14 07:51:17 --> Total execution time: 0.2510
DEBUG - 2022-11-14 07:51:18 --> Total execution time: 0.2433
DEBUG - 2022-11-14 07:52:10 --> Total execution time: 0.2215
DEBUG - 2022-11-14 07:52:46 --> Total execution time: 0.1214
DEBUG - 2022-11-14 07:52:51 --> Total execution time: 0.1681
DEBUG - 2022-11-14 07:53:39 --> Total execution time: 0.1154
DEBUG - 2022-11-14 07:54:14 --> Total execution time: 0.1242
DEBUG - 2022-11-14 07:54:18 --> Total execution time: 0.1821
DEBUG - 2022-11-14 07:54:37 --> Total execution time: 0.1670
DEBUG - 2022-11-14 07:56:27 --> Total execution time: 0.1079
DEBUG - 2022-11-14 07:57:05 --> Total execution time: 0.1089
DEBUG - 2022-11-14 07:57:06 --> Total execution time: 0.1098
DEBUG - 2022-11-14 07:57:11 --> Total execution time: 0.1657
DEBUG - 2022-11-14 07:57:17 --> Total execution time: 0.2132
DEBUG - 2022-11-14 07:57:36 --> Total execution time: 0.2248
DEBUG - 2022-11-14 07:58:04 --> Total execution time: 0.2049
DEBUG - 2022-11-14 07:58:09 --> Total execution time: 0.1105
DEBUG - 2022-11-14 07:58:39 --> Total execution time: 0.1742
DEBUG - 2022-11-14 07:58:50 --> Total execution time: 0.4725
DEBUG - 2022-11-14 07:59:02 --> Total execution time: 0.2218
DEBUG - 2022-11-14 07:59:14 --> Total execution time: 0.2086
DEBUG - 2022-11-14 07:59:32 --> Total execution time: 0.1723
DEBUG - 2022-11-14 07:59:47 --> Total execution time: 0.1095
DEBUG - 2022-11-14 07:59:50 --> Total execution time: 0.1774
DEBUG - 2022-11-14 07:59:51 --> Total execution time: 0.1840
DEBUG - 2022-11-14 08:00:04 --> Total execution time: 0.2575
DEBUG - 2022-11-14 08:00:17 --> Total execution time: 0.2567
DEBUG - 2022-11-14 08:00:30 --> Total execution time: 0.1062
DEBUG - 2022-11-14 08:01:12 --> Total execution time: 0.1851
DEBUG - 2022-11-14 08:01:25 --> Total execution time: 0.2527
DEBUG - 2022-11-14 08:03:41 --> Total execution time: 0.1127
DEBUG - 2022-11-14 08:07:28 --> Total execution time: 0.1103
DEBUG - 2022-11-14 08:11:53 --> Total execution time: 0.1273
DEBUG - 2022-11-14 08:12:09 --> Total execution time: 0.1086
DEBUG - 2022-11-14 08:13:21 --> Total execution time: 0.1770
DEBUG - 2022-11-14 08:16:40 --> Total execution time: 0.4687
DEBUG - 2022-11-14 08:19:07 --> Total execution time: 0.1812
DEBUG - 2022-11-14 08:20:09 --> Total execution time: 0.1178
DEBUG - 2022-11-14 08:22:39 --> Total execution time: 0.1682
DEBUG - 2022-11-14 08:22:58 --> Total execution time: 0.2524
DEBUG - 2022-11-14 08:23:15 --> Total execution time: 0.2258
DEBUG - 2022-11-14 08:23:22 --> Total execution time: 0.1699
DEBUG - 2022-11-14 08:23:24 --> Total execution time: 0.1847
DEBUG - 2022-11-14 08:28:51 --> Total execution time: 0.1735
DEBUG - 2022-11-14 08:28:58 --> Total execution time: 0.1712
DEBUG - 2022-11-14 08:29:08 --> Total execution time: 0.1997
DEBUG - 2022-11-14 08:29:19 --> Total execution time: 0.1841
DEBUG - 2022-11-14 08:30:02 --> Total execution time: 0.1282
DEBUG - 2022-11-14 08:32:51 --> Total execution time: 0.2119
DEBUG - 2022-11-14 08:33:02 --> Total execution time: 0.1947
DEBUG - 2022-11-14 08:33:11 --> Total execution time: 0.2738
DEBUG - 2022-11-14 08:33:20 --> Total execution time: 0.1842
DEBUG - 2022-11-14 08:33:28 --> Total execution time: 0.2849
DEBUG - 2022-11-14 08:33:38 --> Total execution time: 0.2139
DEBUG - 2022-11-14 08:33:46 --> Total execution time: 0.1757
DEBUG - 2022-11-14 08:33:59 --> Total execution time: 0.2617
DEBUG - 2022-11-14 08:38:36 --> Total execution time: 0.1855
DEBUG - 2022-11-14 08:38:38 --> Total execution time: 0.1198
DEBUG - 2022-11-14 08:41:01 --> Total execution time: 0.1333
DEBUG - 2022-11-14 08:51:10 --> Total execution time: 0.5973
DEBUG - 2022-11-14 08:51:15 --> Total execution time: 0.1682
DEBUG - 2022-11-14 08:51:24 --> Total execution time: 0.1979
DEBUG - 2022-11-14 08:51:29 --> Total execution time: 0.1976
DEBUG - 2022-11-14 08:51:39 --> Total execution time: 0.1977
DEBUG - 2022-11-14 08:52:23 --> Total execution time: 0.1955
DEBUG - 2022-11-14 08:52:47 --> Total execution time: 0.3739
DEBUG - 2022-11-14 08:52:49 --> Total execution time: 0.2689
DEBUG - 2022-11-14 08:52:56 --> Total execution time: 1.0831
DEBUG - 2022-11-14 08:53:07 --> Total execution time: 0.1750
DEBUG - 2022-11-14 08:53:26 --> Total execution time: 0.2081
DEBUG - 2022-11-14 08:54:35 --> Total execution time: 1.6111
DEBUG - 2022-11-14 08:54:36 --> Total execution time: 2.3343
DEBUG - 2022-11-14 08:55:39 --> Total execution time: 0.6190
DEBUG - 2022-11-14 08:55:50 --> Total execution time: 0.1812
DEBUG - 2022-11-14 08:56:29 --> Total execution time: 0.4710
DEBUG - 2022-11-14 08:56:47 --> Total execution time: 0.1643
DEBUG - 2022-11-14 08:57:25 --> Total execution time: 0.1788
DEBUG - 2022-11-14 08:57:28 --> Total execution time: 0.1684
DEBUG - 2022-11-14 08:57:48 --> Total execution time: 0.1718
DEBUG - 2022-11-14 08:57:58 --> Total execution time: 2.7160
DEBUG - 2022-11-14 08:58:17 --> Total execution time: 0.1949
DEBUG - 2022-11-14 08:58:25 --> Total execution time: 0.1817
DEBUG - 2022-11-14 09:01:04 --> Total execution time: 0.1083
DEBUG - 2022-11-14 09:02:35 --> Total execution time: 1.6676
DEBUG - 2022-11-14 09:03:29 --> Total execution time: 2.7187
DEBUG - 2022-11-14 09:03:56 --> Total execution time: 0.6953
DEBUG - 2022-11-14 09:04:11 --> Total execution time: 0.2250
DEBUG - 2022-11-14 09:05:11 --> Total execution time: 0.4974
DEBUG - 2022-11-14 09:05:14 --> Total execution time: 0.2010
DEBUG - 2022-11-14 09:05:15 --> Total execution time: 0.1804
DEBUG - 2022-11-14 09:05:24 --> Total execution time: 0.2630
DEBUG - 2022-11-14 09:05:31 --> Total execution time: 0.1786
DEBUG - 2022-11-14 09:07:00 --> Total execution time: 0.1653
DEBUG - 2022-11-14 09:07:08 --> Total execution time: 0.1685
DEBUG - 2022-11-14 09:07:09 --> Total execution time: 0.1715
DEBUG - 2022-11-14 09:07:09 --> Total execution time: 0.1871
DEBUG - 2022-11-14 09:07:10 --> Total execution time: 0.1650
DEBUG - 2022-11-14 09:07:12 --> Total execution time: 0.1675
DEBUG - 2022-11-14 09:07:13 --> Total execution time: 0.1669
DEBUG - 2022-11-14 09:07:14 --> Total execution time: 0.1796
DEBUG - 2022-11-14 09:07:21 --> Total execution time: 0.1781
DEBUG - 2022-11-14 09:08:03 --> Total execution time: 0.1703
DEBUG - 2022-11-14 09:08:54 --> Total execution time: 0.1749
DEBUG - 2022-11-14 09:09:55 --> Total execution time: 0.4679
DEBUG - 2022-11-14 09:10:30 --> Total execution time: 0.1122
DEBUG - 2022-11-14 09:10:38 --> Total execution time: 0.1697
DEBUG - 2022-11-14 09:11:06 --> Total execution time: 0.5026
DEBUG - 2022-11-14 09:11:25 --> Total execution time: 0.1786
DEBUG - 2022-11-14 09:11:32 --> Total execution time: 0.1700
DEBUG - 2022-11-14 09:11:43 --> Total execution time: 0.2117
DEBUG - 2022-11-14 09:11:53 --> Total execution time: 0.1678
DEBUG - 2022-11-14 09:11:53 --> Total execution time: 0.2134
DEBUG - 2022-11-14 09:12:01 --> Total execution time: 0.1835
DEBUG - 2022-11-14 09:12:04 --> Total execution time: 0.1805
DEBUG - 2022-11-14 09:12:15 --> Total execution time: 0.1950
DEBUG - 2022-11-14 09:13:40 --> Total execution time: 0.1798
DEBUG - 2022-11-14 09:14:01 --> Total execution time: 0.1807
DEBUG - 2022-11-14 09:14:02 --> Total execution time: 0.1711
DEBUG - 2022-11-14 09:14:10 --> Total execution time: 0.1823
DEBUG - 2022-11-14 09:14:33 --> Total execution time: 0.1899
DEBUG - 2022-11-14 09:15:45 --> Total execution time: 0.1292
DEBUG - 2022-11-14 09:15:48 --> Total execution time: 0.1675
DEBUG - 2022-11-14 09:16:06 --> Total execution time: 0.1759
DEBUG - 2022-11-14 09:16:11 --> Total execution time: 0.1772
DEBUG - 2022-11-14 09:16:12 --> Total execution time: 0.1642
DEBUG - 2022-11-14 09:16:14 --> Total execution time: 0.1745
DEBUG - 2022-11-14 09:17:12 --> Total execution time: 0.4297
DEBUG - 2022-11-14 09:17:13 --> Total execution time: 0.4747
DEBUG - 2022-11-14 09:17:13 --> Total execution time: 0.6213
DEBUG - 2022-11-14 09:17:20 --> Total execution time: 0.2067
DEBUG - 2022-11-14 09:17:20 --> Total execution time: 0.1655
DEBUG - 2022-11-14 09:17:26 --> Total execution time: 0.1747
DEBUG - 2022-11-14 09:17:35 --> Total execution time: 0.1777
DEBUG - 2022-11-14 09:21:38 --> Total execution time: 0.4403
DEBUG - 2022-11-14 09:22:48 --> Total execution time: 0.1712
DEBUG - 2022-11-14 09:22:50 --> Total execution time: 0.1747
DEBUG - 2022-11-14 09:23:06 --> Total execution time: 0.1966
DEBUG - 2022-11-14 09:23:08 --> Total execution time: 0.1803
DEBUG - 2022-11-14 09:23:13 --> Total execution time: 0.2350
DEBUG - 2022-11-14 09:23:16 --> Total execution time: 0.1673
DEBUG - 2022-11-14 09:23:26 --> Total execution time: 0.1675
DEBUG - 2022-11-14 09:23:26 --> Total execution time: 0.1994
DEBUG - 2022-11-14 09:23:48 --> Total execution time: 0.1654
DEBUG - 2022-11-14 09:23:52 --> Total execution time: 0.1885
DEBUG - 2022-11-14 09:23:57 --> Total execution time: 0.2080
DEBUG - 2022-11-14 09:24:09 --> Total execution time: 0.1826
DEBUG - 2022-11-14 09:24:09 --> Total execution time: 0.3451
DEBUG - 2022-11-14 09:24:18 --> Total execution time: 0.1784
DEBUG - 2022-11-14 09:24:42 --> Total execution time: 0.2284
DEBUG - 2022-11-14 09:24:45 --> Total execution time: 0.1709
DEBUG - 2022-11-14 09:24:55 --> Total execution time: 0.1696
DEBUG - 2022-11-14 09:25:13 --> Total execution time: 0.1924
DEBUG - 2022-11-14 09:25:18 --> Total execution time: 0.1777
DEBUG - 2022-11-14 09:25:38 --> Total execution time: 0.1772
DEBUG - 2022-11-14 09:25:41 --> Total execution time: 0.4615
DEBUG - 2022-11-14 09:25:45 --> Total execution time: 0.1784
DEBUG - 2022-11-14 09:25:49 --> Total execution time: 0.1910
DEBUG - 2022-11-14 09:25:55 --> Total execution time: 0.1036
DEBUG - 2022-11-14 09:26:00 --> Total execution time: 0.1083
DEBUG - 2022-11-14 09:27:00 --> Total execution time: 0.2005
DEBUG - 2022-11-14 09:27:31 --> Total execution time: 0.1665
DEBUG - 2022-11-14 09:27:56 --> Total execution time: 0.1678
DEBUG - 2022-11-14 09:28:36 --> Total execution time: 0.2338
DEBUG - 2022-11-14 09:29:00 --> Total execution time: 0.4812
DEBUG - 2022-11-14 09:29:03 --> Total execution time: 0.2456
DEBUG - 2022-11-14 09:29:08 --> Total execution time: 0.1908
DEBUG - 2022-11-14 09:29:13 --> Total execution time: 0.1826
DEBUG - 2022-11-14 09:29:40 --> Total execution time: 0.1888
DEBUG - 2022-11-14 09:29:48 --> Total execution time: 0.1677
DEBUG - 2022-11-14 09:30:00 --> Total execution time: 0.1892
DEBUG - 2022-11-14 09:30:02 --> Total execution time: 0.2392
DEBUG - 2022-11-14 09:30:03 --> Total execution time: 0.1439
DEBUG - 2022-11-14 09:30:19 --> Total execution time: 0.1770
DEBUG - 2022-11-14 09:30:58 --> Total execution time: 0.1132
DEBUG - 2022-11-14 09:31:06 --> Total execution time: 0.5248
DEBUG - 2022-11-14 09:31:19 --> Total execution time: 0.2057
DEBUG - 2022-11-14 09:31:21 --> Total execution time: 0.1129
DEBUG - 2022-11-14 09:31:25 --> Total execution time: 0.1714
DEBUG - 2022-11-14 09:31:34 --> Total execution time: 0.1086
DEBUG - 2022-11-14 09:32:01 --> Total execution time: 0.2040
DEBUG - 2022-11-14 09:32:05 --> Total execution time: 0.1897
DEBUG - 2022-11-14 09:32:09 --> Total execution time: 0.1844
DEBUG - 2022-11-14 09:32:19 --> Total execution time: 0.1635
DEBUG - 2022-11-14 09:32:23 --> Total execution time: 0.1599
DEBUG - 2022-11-14 09:32:27 --> Total execution time: 0.1693
DEBUG - 2022-11-14 09:32:29 --> Total execution time: 0.1721
DEBUG - 2022-11-14 09:32:30 --> Total execution time: 0.1833
DEBUG - 2022-11-14 09:33:23 --> Total execution time: 0.2059
DEBUG - 2022-11-14 09:33:25 --> Total execution time: 0.1899
DEBUG - 2022-11-14 09:33:38 --> Total execution time: 0.1984
DEBUG - 2022-11-14 09:33:43 --> Total execution time: 0.1893
DEBUG - 2022-11-14 09:33:47 --> Total execution time: 0.1878
DEBUG - 2022-11-14 09:33:52 --> Total execution time: 0.1981
DEBUG - 2022-11-14 09:34:01 --> Total execution time: 0.1970
DEBUG - 2022-11-14 09:34:08 --> Total execution time: 0.1798
DEBUG - 2022-11-14 09:34:17 --> Total execution time: 0.1710
DEBUG - 2022-11-14 09:34:53 --> Total execution time: 0.2266
DEBUG - 2022-11-14 09:35:56 --> Total execution time: 0.1759
DEBUG - 2022-11-14 09:36:27 --> Total execution time: 0.2489
DEBUG - 2022-11-14 09:36:27 --> Total execution time: 0.7715
DEBUG - 2022-11-14 09:36:32 --> Total execution time: 0.1090
DEBUG - 2022-11-14 09:36:33 --> Total execution time: 0.1762
DEBUG - 2022-11-14 09:36:37 --> Total execution time: 0.1808
DEBUG - 2022-11-14 09:36:55 --> Total execution time: 0.1852
DEBUG - 2022-11-14 09:36:57 --> Total execution time: 0.3169
DEBUG - 2022-11-14 09:37:12 --> Total execution time: 0.2322
DEBUG - 2022-11-14 09:37:46 --> Total execution time: 0.4432
DEBUG - 2022-11-14 09:38:14 --> Total execution time: 0.1718
DEBUG - 2022-11-14 09:38:56 --> Total execution time: 0.3157
DEBUG - 2022-11-14 09:39:07 --> Total execution time: 0.2891
DEBUG - 2022-11-14 09:39:16 --> Total execution time: 0.2104
DEBUG - 2022-11-14 09:39:41 --> Total execution time: 0.1792
DEBUG - 2022-11-14 09:39:56 --> Total execution time: 0.6315
DEBUG - 2022-11-14 09:40:14 --> Total execution time: 0.1853
DEBUG - 2022-11-14 09:40:22 --> Total execution time: 0.1719
DEBUG - 2022-11-14 09:42:06 --> Total execution time: 0.4464
DEBUG - 2022-11-14 09:42:10 --> Total execution time: 0.1067
DEBUG - 2022-11-14 09:42:29 --> Total execution time: 0.1801
DEBUG - 2022-11-14 09:42:46 --> Total execution time: 0.1668
DEBUG - 2022-11-14 09:42:49 --> Total execution time: 0.2065
DEBUG - 2022-11-14 09:42:54 --> Total execution time: 0.2109
DEBUG - 2022-11-14 09:43:29 --> Total execution time: 0.1926
DEBUG - 2022-11-14 09:43:36 --> Total execution time: 0.1692
DEBUG - 2022-11-14 09:43:54 --> Total execution time: 0.1783
DEBUG - 2022-11-14 09:44:00 --> Total execution time: 0.1867
DEBUG - 2022-11-14 09:44:02 --> Total execution time: 0.2068
DEBUG - 2022-11-14 09:44:07 --> Total execution time: 0.1979
DEBUG - 2022-11-14 09:44:23 --> Total execution time: 0.2218
DEBUG - 2022-11-14 09:48:20 --> Total execution time: 0.9282
DEBUG - 2022-11-14 09:49:25 --> Total execution time: 1.0973
DEBUG - 2022-11-14 09:49:31 --> Total execution time: 0.4551
DEBUG - 2022-11-14 09:49:39 --> Total execution time: 0.1829
DEBUG - 2022-11-14 09:49:47 --> Total execution time: 0.1901
DEBUG - 2022-11-14 09:49:51 --> Total execution time: 0.1744
DEBUG - 2022-11-14 09:49:59 --> Total execution time: 0.1696
DEBUG - 2022-11-14 09:50:13 --> Total execution time: 0.1917
DEBUG - 2022-11-14 09:50:19 --> Total execution time: 0.1738
DEBUG - 2022-11-14 09:50:26 --> Total execution time: 0.1920
DEBUG - 2022-11-14 09:50:27 --> Total execution time: 0.1788
DEBUG - 2022-11-14 09:50:39 --> Total execution time: 0.1970
DEBUG - 2022-11-14 09:50:40 --> Total execution time: 0.4661
DEBUG - 2022-11-14 09:50:42 --> Total execution time: 0.1745
DEBUG - 2022-11-14 09:50:47 --> Total execution time: 0.2166
DEBUG - 2022-11-14 09:50:49 --> Total execution time: 0.1736
DEBUG - 2022-11-14 09:50:51 --> Total execution time: 0.1802
DEBUG - 2022-11-14 09:50:51 --> Total execution time: 0.2316
DEBUG - 2022-11-14 09:50:57 --> Total execution time: 0.1679
DEBUG - 2022-11-14 09:51:02 --> Total execution time: 0.2260
DEBUG - 2022-11-14 09:51:22 --> Total execution time: 0.2720
DEBUG - 2022-11-14 09:51:22 --> Total execution time: 0.2906
DEBUG - 2022-11-14 09:51:22 --> Total execution time: 0.3856
DEBUG - 2022-11-14 09:51:38 --> Total execution time: 0.1214
DEBUG - 2022-11-14 09:51:59 --> Total execution time: 0.1848
DEBUG - 2022-11-14 09:52:10 --> Total execution time: 2.3331
DEBUG - 2022-11-14 09:54:01 --> Total execution time: 0.1204
DEBUG - 2022-11-14 09:54:02 --> Total execution time: 0.2941
DEBUG - 2022-11-14 09:54:04 --> Total execution time: 0.3474
DEBUG - 2022-11-14 09:54:07 --> Total execution time: 0.1675
DEBUG - 2022-11-14 09:54:13 --> Total execution time: 0.1488
DEBUG - 2022-11-14 09:54:17 --> Total execution time: 0.1844
DEBUG - 2022-11-14 09:54:18 --> Total execution time: 0.1763
DEBUG - 2022-11-14 09:54:18 --> Total execution time: 0.1840
DEBUG - 2022-11-14 09:54:26 --> Total execution time: 0.2047
DEBUG - 2022-11-14 09:54:29 --> Total execution time: 0.1707
DEBUG - 2022-11-14 09:54:39 --> Total execution time: 0.1716
DEBUG - 2022-11-14 09:54:48 --> Total execution time: 0.1846
DEBUG - 2022-11-14 09:54:49 --> Total execution time: 0.4770
DEBUG - 2022-11-14 09:54:58 --> Total execution time: 0.1852
DEBUG - 2022-11-14 09:55:02 --> Total execution time: 0.2172
DEBUG - 2022-11-14 09:55:05 --> Total execution time: 0.1870
DEBUG - 2022-11-14 09:55:08 --> Total execution time: 0.2020
DEBUG - 2022-11-14 09:55:28 --> Total execution time: 0.5318
DEBUG - 2022-11-14 09:55:48 --> Total execution time: 0.1846
DEBUG - 2022-11-14 09:56:09 --> Total execution time: 0.1118
DEBUG - 2022-11-14 09:56:12 --> Total execution time: 0.4642
DEBUG - 2022-11-14 09:56:34 --> Total execution time: 0.2407
DEBUG - 2022-11-14 09:56:50 --> Total execution time: 0.1827
DEBUG - 2022-11-14 09:56:57 --> Total execution time: 0.2106
DEBUG - 2022-11-14 09:57:07 --> Total execution time: 1.8750
DEBUG - 2022-11-14 09:57:08 --> Total execution time: 0.1756
DEBUG - 2022-11-14 09:57:50 --> Total execution time: 0.5527
DEBUG - 2022-11-14 09:57:54 --> Total execution time: 0.1733
DEBUG - 2022-11-14 09:58:03 --> Total execution time: 2.0646
DEBUG - 2022-11-14 09:59:53 --> Total execution time: 1.5721
DEBUG - 2022-11-14 10:00:00 --> Total execution time: 1.7453
DEBUG - 2022-11-14 10:00:15 --> Total execution time: 0.1977
DEBUG - 2022-11-14 10:00:22 --> Total execution time: 0.1937
DEBUG - 2022-11-14 10:00:32 --> Total execution time: 0.1822
DEBUG - 2022-11-14 10:01:18 --> Total execution time: 0.3672
DEBUG - 2022-11-14 10:02:23 --> Total execution time: 3.7421
DEBUG - 2022-11-14 10:02:33 --> Total execution time: 0.3174
DEBUG - 2022-11-14 10:02:33 --> Total execution time: 0.1847
DEBUG - 2022-11-14 10:02:42 --> Total execution time: 0.1930
DEBUG - 2022-11-14 10:03:02 --> Total execution time: 0.5413
DEBUG - 2022-11-14 10:03:48 --> Total execution time: 0.1834
DEBUG - 2022-11-14 10:05:23 --> Total execution time: 0.1715
DEBUG - 2022-11-14 10:05:29 --> Total execution time: 0.1909
DEBUG - 2022-11-14 10:05:45 --> Total execution time: 0.1816
DEBUG - 2022-11-14 10:05:49 --> Total execution time: 0.4764
DEBUG - 2022-11-14 10:06:01 --> Total execution time: 0.1935
DEBUG - 2022-11-14 10:06:07 --> Total execution time: 0.2087
DEBUG - 2022-11-14 10:06:15 --> Total execution time: 0.1794
DEBUG - 2022-11-14 10:06:56 --> Total execution time: 0.2199
DEBUG - 2022-11-14 10:10:51 --> Total execution time: 3.1153
DEBUG - 2022-11-14 10:11:46 --> Total execution time: 1.0762
DEBUG - 2022-11-14 10:11:52 --> Total execution time: 0.2027
DEBUG - 2022-11-14 10:11:58 --> Total execution time: 0.2425
DEBUG - 2022-11-14 10:12:37 --> Total execution time: 0.1775
DEBUG - 2022-11-14 10:14:16 --> Total execution time: 0.2278
DEBUG - 2022-11-14 10:14:28 --> Total execution time: 0.2109
DEBUG - 2022-11-14 10:14:35 --> Total execution time: 0.2703
DEBUG - 2022-11-14 10:14:35 --> Total execution time: 0.1703
DEBUG - 2022-11-14 10:14:59 --> Total execution time: 0.1203
DEBUG - 2022-11-14 10:15:02 --> Total execution time: 0.1360
DEBUG - 2022-11-14 10:15:02 --> Total execution time: 0.1324
DEBUG - 2022-11-14 10:15:28 --> Total execution time: 0.1247
DEBUG - 2022-11-14 10:15:29 --> Total execution time: 0.1812
DEBUG - 2022-11-14 10:15:36 --> Total execution time: 0.1887
DEBUG - 2022-11-14 10:15:45 --> Total execution time: 0.5071
DEBUG - 2022-11-14 10:15:47 --> Total execution time: 0.2088
DEBUG - 2022-11-14 10:16:15 --> Total execution time: 0.2997
DEBUG - 2022-11-14 10:16:15 --> Total execution time: 0.1944
DEBUG - 2022-11-14 10:16:39 --> Total execution time: 0.1868
DEBUG - 2022-11-14 10:16:55 --> Total execution time: 0.1874
DEBUG - 2022-11-14 10:17:58 --> Total execution time: 0.9862
DEBUG - 2022-11-14 10:18:05 --> Total execution time: 0.1878
DEBUG - 2022-11-14 10:18:28 --> Total execution time: 0.1770
DEBUG - 2022-11-14 10:18:55 --> Total execution time: 0.1513
DEBUG - 2022-11-14 10:21:03 --> Total execution time: 2.8663
DEBUG - 2022-11-14 10:21:16 --> Total execution time: 2.0584
DEBUG - 2022-11-14 10:21:24 --> Total execution time: 0.3039
DEBUG - 2022-11-14 10:21:30 --> Total execution time: 0.1771
DEBUG - 2022-11-14 10:23:25 --> Total execution time: 0.7600
DEBUG - 2022-11-14 10:27:19 --> Total execution time: 0.5820
DEBUG - 2022-11-14 10:27:21 --> Total execution time: 0.4840
DEBUG - 2022-11-14 10:27:30 --> Total execution time: 0.1870
DEBUG - 2022-11-14 10:29:25 --> Total execution time: 0.1415
DEBUG - 2022-11-14 10:29:37 --> Total execution time: 0.1754
DEBUG - 2022-11-14 10:29:39 --> Total execution time: 0.4769
DEBUG - 2022-11-14 10:29:43 --> Total execution time: 0.2593
DEBUG - 2022-11-14 10:29:45 --> Total execution time: 0.1667
DEBUG - 2022-11-14 10:30:03 --> Total execution time: 0.1748
DEBUG - 2022-11-14 10:30:03 --> Total execution time: 0.2334
DEBUG - 2022-11-14 10:30:07 --> Total execution time: 0.4662
DEBUG - 2022-11-14 10:30:33 --> Total execution time: 0.2223
DEBUG - 2022-11-14 10:30:51 --> Total execution time: 0.1285
DEBUG - 2022-11-14 10:30:53 --> Total execution time: 0.1184
DEBUG - 2022-11-14 10:30:53 --> Total execution time: 0.1386
DEBUG - 2022-11-14 10:31:01 --> Total execution time: 0.1352
DEBUG - 2022-11-14 10:31:50 --> Total execution time: 0.1081
DEBUG - 2022-11-14 10:32:04 --> Total execution time: 0.5053
DEBUG - 2022-11-14 10:33:34 --> Total execution time: 0.1790
DEBUG - 2022-11-14 10:35:15 --> Total execution time: 0.1062
DEBUG - 2022-11-14 10:35:27 --> Total execution time: 0.4487
DEBUG - 2022-11-14 10:40:32 --> Total execution time: 0.1255
DEBUG - 2022-11-14 10:40:33 --> Total execution time: 0.1251
DEBUG - 2022-11-14 10:40:41 --> Total execution time: 0.1663
DEBUG - 2022-11-14 10:40:50 --> Total execution time: 0.1785
DEBUG - 2022-11-14 10:41:44 --> Total execution time: 0.1752
DEBUG - 2022-11-14 10:42:46 --> Total execution time: 0.1694
DEBUG - 2022-11-14 10:42:51 --> Total execution time: 0.2477
DEBUG - 2022-11-14 10:43:14 --> Total execution time: 0.3037
DEBUG - 2022-11-14 10:43:43 --> Total execution time: 0.2096
DEBUG - 2022-11-14 10:43:46 --> Total execution time: 0.1803
DEBUG - 2022-11-14 10:43:55 --> Total execution time: 0.2401
DEBUG - 2022-11-14 10:43:56 --> Total execution time: 0.2691
DEBUG - 2022-11-14 10:43:56 --> Total execution time: 0.2252
DEBUG - 2022-11-14 10:44:14 --> Total execution time: 0.1221
DEBUG - 2022-11-14 10:44:18 --> Total execution time: 0.1243
DEBUG - 2022-11-14 10:44:20 --> Total execution time: 0.1200
DEBUG - 2022-11-14 10:48:15 --> Total execution time: 2.8874
DEBUG - 2022-11-14 10:48:47 --> Total execution time: 0.1155
DEBUG - 2022-11-14 10:48:48 --> Total execution time: 0.1206
DEBUG - 2022-11-14 10:49:11 --> Total execution time: 0.1802
DEBUG - 2022-11-14 10:49:37 --> Total execution time: 0.2104
DEBUG - 2022-11-14 10:50:11 --> Total execution time: 0.2114
DEBUG - 2022-11-14 10:50:41 --> Total execution time: 0.2051
DEBUG - 2022-11-14 10:50:43 --> Total execution time: 0.1159
DEBUG - 2022-11-14 10:50:43 --> Total execution time: 0.2080
DEBUG - 2022-11-14 10:50:43 --> Total execution time: 0.1633
DEBUG - 2022-11-14 10:50:44 --> Total execution time: 0.1302
DEBUG - 2022-11-14 10:52:15 --> Total execution time: 0.1835
DEBUG - 2022-11-14 10:56:26 --> Total execution time: 0.1807
DEBUG - 2022-11-14 10:57:49 --> Total execution time: 0.6462
DEBUG - 2022-11-14 10:58:34 --> Total execution time: 0.1662
DEBUG - 2022-11-14 10:58:44 --> Total execution time: 0.1727
DEBUG - 2022-11-14 10:58:53 --> Total execution time: 0.1718
DEBUG - 2022-11-14 10:59:23 --> Total execution time: 0.2735
DEBUG - 2022-11-14 10:59:41 --> Total execution time: 0.2018
DEBUG - 2022-11-14 10:59:54 --> Total execution time: 0.1865
DEBUG - 2022-11-14 11:01:43 --> Total execution time: 0.4762
DEBUG - 2022-11-14 11:01:44 --> Total execution time: 0.1871
DEBUG - 2022-11-14 11:03:27 --> Total execution time: 1.0655
DEBUG - 2022-11-14 11:03:42 --> Total execution time: 0.1303
DEBUG - 2022-11-14 11:03:52 --> Total execution time: 0.1750
DEBUG - 2022-11-14 11:08:28 --> Total execution time: 0.7972
DEBUG - 2022-11-14 11:08:32 --> Total execution time: 0.1183
DEBUG - 2022-11-14 11:08:38 --> Total execution time: 0.2008
DEBUG - 2022-11-14 11:08:39 --> Total execution time: 0.1894
DEBUG - 2022-11-14 11:08:45 --> Total execution time: 0.2917
DEBUG - 2022-11-14 11:08:50 --> Total execution time: 0.2352
DEBUG - 2022-11-14 11:08:59 --> Total execution time: 0.2099
DEBUG - 2022-11-14 11:09:00 --> Total execution time: 0.1822
DEBUG - 2022-11-14 11:09:42 --> Total execution time: 0.1882
DEBUG - 2022-11-14 11:09:48 --> Total execution time: 0.1840
DEBUG - 2022-11-14 11:09:57 --> Total execution time: 0.2025
DEBUG - 2022-11-14 11:10:15 --> Total execution time: 0.1248
DEBUG - 2022-11-14 11:10:23 --> Total execution time: 0.1774
DEBUG - 2022-11-14 11:10:30 --> Total execution time: 0.1939
DEBUG - 2022-11-14 11:10:48 --> Total execution time: 0.1924
DEBUG - 2022-11-14 11:10:54 --> Total execution time: 0.2086
DEBUG - 2022-11-14 11:11:02 --> Total execution time: 0.1770
DEBUG - 2022-11-14 11:11:07 --> Total execution time: 0.1740
DEBUG - 2022-11-14 11:11:33 --> Total execution time: 0.1854
DEBUG - 2022-11-14 11:11:38 --> Total execution time: 0.1938
DEBUG - 2022-11-14 11:11:52 --> Total execution time: 0.1892
DEBUG - 2022-11-14 11:11:59 --> Total execution time: 0.6437
DEBUG - 2022-11-14 11:12:15 --> Total execution time: 0.2102
DEBUG - 2022-11-14 11:12:27 --> Total execution time: 0.1729
DEBUG - 2022-11-14 11:12:42 --> Total execution time: 0.2701
DEBUG - 2022-11-14 11:13:01 --> Total execution time: 0.5309
DEBUG - 2022-11-14 11:13:05 --> Total execution time: 0.1766
DEBUG - 2022-11-14 11:13:31 --> Total execution time: 0.3988
DEBUG - 2022-11-14 11:13:37 --> Total execution time: 0.8521
DEBUG - 2022-11-14 11:14:18 --> Total execution time: 0.2205
DEBUG - 2022-11-14 11:14:23 --> Total execution time: 0.1706
DEBUG - 2022-11-14 11:14:33 --> Total execution time: 0.1691
DEBUG - 2022-11-14 11:14:33 --> Total execution time: 0.1779
DEBUG - 2022-11-14 11:14:45 --> Total execution time: 0.2353
DEBUG - 2022-11-14 11:14:53 --> Total execution time: 0.9255
DEBUG - 2022-11-14 11:15:02 --> Total execution time: 0.3024
DEBUG - 2022-11-14 11:15:08 --> Total execution time: 0.1762
DEBUG - 2022-11-14 11:15:21 --> Total execution time: 1.5154
DEBUG - 2022-11-14 11:16:21 --> Total execution time: 5.5691
DEBUG - 2022-11-14 11:16:25 --> Total execution time: 0.2473
DEBUG - 2022-11-14 11:18:26 --> Total execution time: 3.4118
DEBUG - 2022-11-14 11:19:00 --> Total execution time: 0.1154
DEBUG - 2022-11-14 11:19:59 --> Total execution time: 2.2527
DEBUG - 2022-11-14 11:20:08 --> Total execution time: 0.5882
DEBUG - 2022-11-14 11:20:23 --> Total execution time: 0.1786
DEBUG - 2022-11-14 11:20:37 --> Total execution time: 0.1806
DEBUG - 2022-11-14 11:20:45 --> Total execution time: 0.2027
DEBUG - 2022-11-14 11:20:47 --> Total execution time: 0.4152
DEBUG - 2022-11-14 11:21:49 --> Total execution time: 0.7538
DEBUG - 2022-11-14 11:21:52 --> Total execution time: 0.1749
DEBUG - 2022-11-14 11:23:02 --> Total execution time: 0.1157
DEBUG - 2022-11-14 11:23:08 --> Total execution time: 0.1671
DEBUG - 2022-11-14 11:23:25 --> Total execution time: 0.1787
DEBUG - 2022-11-14 11:23:33 --> Total execution time: 0.1834
DEBUG - 2022-11-14 11:23:39 --> Total execution time: 0.2390
DEBUG - 2022-11-14 11:23:45 --> Total execution time: 0.4922
DEBUG - 2022-11-14 11:23:50 --> Total execution time: 0.1677
DEBUG - 2022-11-14 11:23:58 --> Total execution time: 0.1688
DEBUG - 2022-11-14 11:24:04 --> Total execution time: 0.1043
DEBUG - 2022-11-14 04:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:14:48 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:44:49 --> Total execution time: 0.6052
DEBUG - 2022-11-14 04:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:44:55 --> Total execution time: 0.1740
DEBUG - 2022-11-14 04:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:45:02 --> Total execution time: 0.1748
DEBUG - 2022-11-14 04:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:15:23 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:45:23 --> Total execution time: 0.1424
DEBUG - 2022-11-14 04:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:15:24 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:45:24 --> Total execution time: 0.1635
DEBUG - 2022-11-14 04:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:45:29 --> Total execution time: 0.3392
DEBUG - 2022-11-14 04:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:15:32 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:45:32 --> Total execution time: 0.1286
DEBUG - 2022-11-14 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:15:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 04:15:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 04:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:15:36 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:45:36 --> Total execution time: 0.1285
DEBUG - 2022-11-14 04:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:45:39 --> Total execution time: 0.2550
DEBUG - 2022-11-14 04:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:45:51 --> Total execution time: 0.1844
DEBUG - 2022-11-14 04:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:45:52 --> Total execution time: 0.1808
DEBUG - 2022-11-14 04:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:15:52 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:45:52 --> Total execution time: 0.1099
DEBUG - 2022-11-14 04:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:46:00 --> Total execution time: 0.2051
DEBUG - 2022-11-14 04:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:48:36 --> Total execution time: 0.1805
DEBUG - 2022-11-14 04:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:48:46 --> Total execution time: 0.2077
DEBUG - 2022-11-14 04:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:18:49 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:48:49 --> Total execution time: 0.1216
DEBUG - 2022-11-14 04:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:48:54 --> Total execution time: 0.2411
DEBUG - 2022-11-14 04:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:48:57 --> Total execution time: 0.1814
DEBUG - 2022-11-14 04:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 15:49:02 --> Total execution time: 0.1848
DEBUG - 2022-11-14 04:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:49:02 --> Total execution time: 0.1778
DEBUG - 2022-11-14 04:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:49:53 --> Total execution time: 0.2196
DEBUG - 2022-11-14 04:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:50:00 --> Total execution time: 0.2100
DEBUG - 2022-11-14 04:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:50:08 --> Total execution time: 0.1951
DEBUG - 2022-11-14 04:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:50:18 --> Total execution time: 0.2032
DEBUG - 2022-11-14 04:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:50:30 --> Total execution time: 0.1881
DEBUG - 2022-11-14 04:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:20:38 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:50:39 --> Total execution time: 0.6110
DEBUG - 2022-11-14 04:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:50:41 --> Total execution time: 0.2750
DEBUG - 2022-11-14 04:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:20:42 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:50:42 --> Total execution time: 0.1303
DEBUG - 2022-11-14 04:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:20:43 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:50:43 --> Total execution time: 0.1111
DEBUG - 2022-11-14 04:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:50:50 --> Total execution time: 0.5706
DEBUG - 2022-11-14 04:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:50:57 --> Total execution time: 0.1995
DEBUG - 2022-11-14 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:20:59 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:50:59 --> Total execution time: 0.1182
DEBUG - 2022-11-14 04:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:00 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:01 --> Total execution time: 0.1240
DEBUG - 2022-11-14 04:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:05 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:05 --> Total execution time: 0.1347
DEBUG - 2022-11-14 04:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:05 --> Total execution time: 0.1904
DEBUG - 2022-11-14 04:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:06 --> Total execution time: 0.5079
DEBUG - 2022-11-14 04:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:07 --> Total execution time: 0.3943
DEBUG - 2022-11-14 04:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:16 --> Total execution time: 0.2034
DEBUG - 2022-11-14 04:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:16 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:17 --> Total execution time: 0.1813
DEBUG - 2022-11-14 04:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:19 --> Total execution time: 0.1735
DEBUG - 2022-11-14 04:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:23 --> Total execution time: 0.6367
DEBUG - 2022-11-14 04:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:25 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:25 --> Total execution time: 0.1187
DEBUG - 2022-11-14 04:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:25 --> Total execution time: 0.2090
DEBUG - 2022-11-14 04:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:29 --> Total execution time: 0.1929
DEBUG - 2022-11-14 04:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:30 --> Total execution time: 0.1805
DEBUG - 2022-11-14 04:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:34 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:34 --> Total execution time: 0.2002
DEBUG - 2022-11-14 04:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:34 --> Total execution time: 0.2050
DEBUG - 2022-11-14 04:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:35 --> Total execution time: 0.1839
DEBUG - 2022-11-14 04:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:35 --> Total execution time: 0.2067
DEBUG - 2022-11-14 04:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:45 --> Total execution time: 0.1941
DEBUG - 2022-11-14 04:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:51 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:51 --> Total execution time: 0.1103
DEBUG - 2022-11-14 04:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:21:55 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:55 --> Total execution time: 0.1098
DEBUG - 2022-11-14 04:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:52:01 --> Total execution time: 0.1813
DEBUG - 2022-11-14 04:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:52:08 --> Total execution time: 0.4213
DEBUG - 2022-11-14 04:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:52:17 --> Total execution time: 0.3403
DEBUG - 2022-11-14 04:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:52:20 --> Total execution time: 0.3356
DEBUG - 2022-11-14 04:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:52:40 --> Total execution time: 0.2137
DEBUG - 2022-11-14 04:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:52:40 --> Total execution time: 0.4135
DEBUG - 2022-11-14 04:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:52:54 --> Total execution time: 0.1869
DEBUG - 2022-11-14 04:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:52:54 --> Total execution time: 0.2208
DEBUG - 2022-11-14 04:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:53:02 --> Total execution time: 0.2044
DEBUG - 2022-11-14 04:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:53:13 --> Total execution time: 0.1847
DEBUG - 2022-11-14 04:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:23:14 --> Total execution time: 0.2080
DEBUG - 2022-11-14 04:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:53:21 --> Total execution time: 0.1771
DEBUG - 2022-11-14 04:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:53:27 --> Total execution time: 0.2004
DEBUG - 2022-11-14 04:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:53:28 --> Total execution time: 0.1739
DEBUG - 2022-11-14 04:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:53:34 --> Total execution time: 0.1849
DEBUG - 2022-11-14 04:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:53:34 --> Total execution time: 0.1749
DEBUG - 2022-11-14 04:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:35 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:53:35 --> Total execution time: 0.2004
DEBUG - 2022-11-14 04:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:53:36 --> Total execution time: 0.2099
DEBUG - 2022-11-14 04:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:53:44 --> Total execution time: 0.3519
DEBUG - 2022-11-14 04:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:53:49 --> Total execution time: 0.1968
DEBUG - 2022-11-14 04:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:53:59 --> Total execution time: 0.2728
DEBUG - 2022-11-14 04:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:24:07 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:54:08 --> Total execution time: 0.4686
DEBUG - 2022-11-14 04:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:54:13 --> Total execution time: 0.1821
DEBUG - 2022-11-14 04:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:54:28 --> Total execution time: 0.1989
DEBUG - 2022-11-14 04:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:54:32 --> Total execution time: 0.2909
DEBUG - 2022-11-14 04:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:54:34 --> Total execution time: 0.2145
DEBUG - 2022-11-14 04:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:54:35 --> Total execution time: 0.1996
DEBUG - 2022-11-14 04:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:24:37 --> Total execution time: 0.1701
DEBUG - 2022-11-14 04:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:54:39 --> Total execution time: 0.2536
DEBUG - 2022-11-14 04:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:24:39 --> Total execution time: 0.2774
DEBUG - 2022-11-14 04:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:24:40 --> Total execution time: 0.2280
DEBUG - 2022-11-14 04:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:54:46 --> Total execution time: 0.2286
DEBUG - 2022-11-14 04:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:24:53 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:54:53 --> Total execution time: 0.1159
DEBUG - 2022-11-14 04:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:06 --> Total execution time: 0.1824
DEBUG - 2022-11-14 04:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:07 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:07 --> Total execution time: 0.1997
DEBUG - 2022-11-14 04:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:11 --> Total execution time: 0.2323
DEBUG - 2022-11-14 04:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:12 --> Total execution time: 0.1726
DEBUG - 2022-11-14 04:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:12 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:13 --> Total execution time: 0.1208
DEBUG - 2022-11-14 04:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:15 --> Total execution time: 0.1721
DEBUG - 2022-11-14 04:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:16 --> Total execution time: 0.1669
DEBUG - 2022-11-14 04:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:17 --> Total execution time: 0.1961
DEBUG - 2022-11-14 04:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:18 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:18 --> Total execution time: 0.1704
DEBUG - 2022-11-14 04:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 04:25:22 --> 404 Page Not Found: Rae-dunn-boggin-set-403039html/index
DEBUG - 2022-11-14 04:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 04:25:22 --> 404 Page Not Found: Hot-wheels-ssth-64-nova-wagon-gasser-char1-79525html/index
DEBUG - 2022-11-14 04:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:25 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:25 --> Total execution time: 0.1920
DEBUG - 2022-11-14 04:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:26 --> Total execution time: 0.2010
DEBUG - 2022-11-14 15:55:26 --> Total execution time: 2.2060
DEBUG - 2022-11-14 04:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:28 --> Total execution time: 0.1971
DEBUG - 2022-11-14 04:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 04:25:31 --> 404 Page Not Found: Reserved-for-yuto8-tripowin-x-hbb-olina-wireless-earbuds-bnib-881194html/index
DEBUG - 2022-11-14 04:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:25:32 --> Total execution time: 0.1807
DEBUG - 2022-11-14 04:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:34 --> Total execution time: 0.2009
DEBUG - 2022-11-14 04:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:25:34 --> Total execution time: 0.2320
DEBUG - 2022-11-14 04:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:25:34 --> Total execution time: 0.1857
DEBUG - 2022-11-14 04:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:39 --> Total execution time: 0.1687
DEBUG - 2022-11-14 04:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 04:25:41 --> 404 Page Not Found: Hot-wheels-ssth-64-nova-wagon-gasser-char1-79525html/index
DEBUG - 2022-11-14 04:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 04:25:41 --> 404 Page Not Found: Rae-dunn-boggin-set-403039html/index
DEBUG - 2022-11-14 04:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:44 --> Total execution time: 0.1971
DEBUG - 2022-11-14 04:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:45 --> Total execution time: 0.1775
DEBUG - 2022-11-14 04:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:50 --> Total execution time: 0.1819
DEBUG - 2022-11-14 04:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:55:50 --> Total execution time: 0.1864
DEBUG - 2022-11-14 04:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:25:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 04:25:51 --> 404 Page Not Found: Reserved-for-yuto8-tripowin-x-hbb-olina-wireless-earbuds-bnib-881194html/index
DEBUG - 2022-11-14 04:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:56:05 --> Total execution time: 0.1677
DEBUG - 2022-11-14 04:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:56:06 --> Total execution time: 0.1838
DEBUG - 2022-11-14 04:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:56:13 --> Total execution time: 0.2044
DEBUG - 2022-11-14 04:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:26:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 04:26:17 --> 404 Page Not Found: New-creator-brick-bank-building-blocks-set-673393html/index
DEBUG - 2022-11-14 04:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:56:17 --> Total execution time: 0.1952
DEBUG - 2022-11-14 04:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:56:22 --> Total execution time: 0.1991
DEBUG - 2022-11-14 04:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:56:33 --> Total execution time: 1.8858
DEBUG - 2022-11-14 04:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 04:26:38 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 04:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:56:52 --> Total execution time: 0.1696
DEBUG - 2022-11-14 04:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:57:09 --> Total execution time: 0.1865
DEBUG - 2022-11-14 04:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:57:11 --> Total execution time: 0.3436
DEBUG - 2022-11-14 04:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:57:15 --> Total execution time: 0.1729
DEBUG - 2022-11-14 04:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:57:27 --> Total execution time: 0.2187
DEBUG - 2022-11-14 04:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:57:34 --> Total execution time: 0.1701
DEBUG - 2022-11-14 04:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:57:39 --> Total execution time: 0.1820
DEBUG - 2022-11-14 04:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:57:41 --> Total execution time: 0.1818
DEBUG - 2022-11-14 04:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:57:48 --> Total execution time: 0.2171
DEBUG - 2022-11-14 04:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:57:58 --> Total execution time: 0.5032
DEBUG - 2022-11-14 04:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:28:09 --> Total execution time: 0.1970
DEBUG - 2022-11-14 04:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:28:17 --> Total execution time: 0.2311
DEBUG - 2022-11-14 04:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:58:32 --> Total execution time: 0.3021
DEBUG - 2022-11-14 04:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:59:25 --> Total execution time: 0.2076
DEBUG - 2022-11-14 04:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:59:45 --> Total execution time: 0.1828
DEBUG - 2022-11-14 04:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:59:53 --> Total execution time: 0.2001
DEBUG - 2022-11-14 04:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:31:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 04:31:09 --> 404 Page Not Found: Bonfoto-b690a-camera-tripod-for-travellightweight-aluminum-portable-dslr-tripod-214834html/index
DEBUG - 2022-11-14 04:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:01:16 --> Total execution time: 0.2976
DEBUG - 2022-11-14 04:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:01:19 --> Total execution time: 0.2364
DEBUG - 2022-11-14 04:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:01:40 --> Total execution time: 0.1776
DEBUG - 2022-11-14 04:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:02:01 --> Total execution time: 0.5034
DEBUG - 2022-11-14 04:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:02:10 --> Total execution time: 0.2039
DEBUG - 2022-11-14 04:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:02:25 --> Total execution time: 0.1838
DEBUG - 2022-11-14 04:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:02:34 --> Total execution time: 0.1888
DEBUG - 2022-11-14 04:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:02:41 --> Total execution time: 0.2219
DEBUG - 2022-11-14 04:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:32:48 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:02:48 --> Total execution time: 0.4790
DEBUG - 2022-11-14 04:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:32:49 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:02:49 --> Total execution time: 0.1884
DEBUG - 2022-11-14 04:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:02:50 --> Total execution time: 0.1879
DEBUG - 2022-11-14 04:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:32:50 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:02:51 --> Total execution time: 0.4455
DEBUG - 2022-11-14 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:03:02 --> Total execution time: 0.3187
DEBUG - 2022-11-14 04:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:03:21 --> Total execution time: 0.1755
DEBUG - 2022-11-14 04:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:03:44 --> Total execution time: 0.1910
DEBUG - 2022-11-14 04:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:03:50 --> Total execution time: 0.4910
DEBUG - 2022-11-14 04:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:03:54 --> Total execution time: 0.1820
DEBUG - 2022-11-14 04:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:03:58 --> Total execution time: 0.1809
DEBUG - 2022-11-14 04:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:04:04 --> Total execution time: 0.1848
DEBUG - 2022-11-14 04:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:04:29 --> Total execution time: 0.1862
DEBUG - 2022-11-14 04:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:04:45 --> Total execution time: 0.1868
DEBUG - 2022-11-14 04:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 04:34:51 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 04:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:37:20 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:07:20 --> Total execution time: 0.1770
DEBUG - 2022-11-14 04:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:07:26 --> Total execution time: 2.3476
DEBUG - 2022-11-14 04:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:08:42 --> Total execution time: 0.1843
DEBUG - 2022-11-14 04:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:38:51 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:08:51 --> Total execution time: 0.1119
DEBUG - 2022-11-14 04:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:38:52 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:08:52 --> Total execution time: 0.1401
DEBUG - 2022-11-14 04:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:08:52 --> Total execution time: 0.1862
DEBUG - 2022-11-14 04:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:09:00 --> Total execution time: 0.1172
DEBUG - 2022-11-14 04:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:09:04 --> Total execution time: 0.2399
DEBUG - 2022-11-14 04:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:09:08 --> Total execution time: 0.1750
DEBUG - 2022-11-14 04:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:09:32 --> Total execution time: 0.4936
DEBUG - 2022-11-14 04:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:09:32 --> Total execution time: 0.4512
DEBUG - 2022-11-14 04:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:10:01 --> Total execution time: 0.1795
DEBUG - 2022-11-14 04:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:10:10 --> Total execution time: 0.3091
DEBUG - 2022-11-14 04:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:10:35 --> Total execution time: 0.1681
DEBUG - 2022-11-14 04:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:10:39 --> Total execution time: 0.1798
DEBUG - 2022-11-14 04:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:10:43 --> Total execution time: 0.1828
DEBUG - 2022-11-14 04:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:10:51 --> Total execution time: 0.3076
DEBUG - 2022-11-14 04:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:10:53 --> Total execution time: 0.2011
DEBUG - 2022-11-14 04:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:11:14 --> Total execution time: 0.2439
DEBUG - 2022-11-14 04:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:11:21 --> Total execution time: 0.2808
DEBUG - 2022-11-14 04:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:11:31 --> Total execution time: 0.2007
DEBUG - 2022-11-14 04:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:11:41 --> Total execution time: 0.1901
DEBUG - 2022-11-14 04:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:11:44 --> Total execution time: 0.2416
DEBUG - 2022-11-14 04:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:41:52 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:11:52 --> Total execution time: 0.1378
DEBUG - 2022-11-14 04:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:11:59 --> Total execution time: 0.1961
DEBUG - 2022-11-14 04:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:12:04 --> Total execution time: 0.1915
DEBUG - 2022-11-14 04:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:12:06 --> Total execution time: 0.1667
DEBUG - 2022-11-14 04:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:12:10 --> Total execution time: 0.2277
DEBUG - 2022-11-14 04:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:12:11 --> Total execution time: 0.1864
DEBUG - 2022-11-14 04:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:12:15 --> Total execution time: 0.1835
DEBUG - 2022-11-14 04:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:12:25 --> Total execution time: 0.2363
DEBUG - 2022-11-14 04:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:13:49 --> Total execution time: 0.2316
DEBUG - 2022-11-14 04:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:43:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 04:43:55 --> 404 Page Not Found: Beaded-black-clutch-purse-8-434587html/index
DEBUG - 2022-11-14 04:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:14:14 --> Total execution time: 0.1868
DEBUG - 2022-11-14 04:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:15:13 --> Total execution time: 0.1461
DEBUG - 2022-11-14 04:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:45:14 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:15:14 --> Total execution time: 0.1242
DEBUG - 2022-11-14 04:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:45:14 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:15:14 --> Total execution time: 0.1106
DEBUG - 2022-11-14 04:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:15:22 --> Total execution time: 0.4639
DEBUG - 2022-11-14 04:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:45:23 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:15:23 --> Total execution time: 0.1227
DEBUG - 2022-11-14 04:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:45:25 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:15:25 --> Total execution time: 0.1133
DEBUG - 2022-11-14 04:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:15:30 --> Total execution time: 0.1765
DEBUG - 2022-11-14 04:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:15:33 --> Total execution time: 0.1721
DEBUG - 2022-11-14 04:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:45:34 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:15:34 --> Total execution time: 0.1729
DEBUG - 2022-11-14 04:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:15:40 --> Total execution time: 0.1797
DEBUG - 2022-11-14 04:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:15:49 --> Total execution time: 0.1961
DEBUG - 2022-11-14 04:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:45:54 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:15:54 --> Total execution time: 0.1697
DEBUG - 2022-11-14 04:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:16:00 --> Total execution time: 0.1727
DEBUG - 2022-11-14 04:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:46:55 --> Total execution time: 0.1812
DEBUG - 2022-11-14 04:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:46:57 --> Total execution time: 0.2486
DEBUG - 2022-11-14 04:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:46:57 --> Total execution time: 0.1814
DEBUG - 2022-11-14 16:16:57 --> Total execution time: 0.7182
DEBUG - 2022-11-14 04:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:47:10 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:17:10 --> Total execution time: 0.1706
DEBUG - 2022-11-14 04:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:47:16 --> Total execution time: 0.1904
DEBUG - 2022-11-14 04:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:47:23 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:17:23 --> Total execution time: 0.1133
DEBUG - 2022-11-14 04:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:17:25 --> Total execution time: 0.1873
DEBUG - 2022-11-14 04:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:17:31 --> Total execution time: 0.2104
DEBUG - 2022-11-14 04:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:17:31 --> Total execution time: 0.1121
DEBUG - 2022-11-14 04:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:17:33 --> Total execution time: 0.2518
DEBUG - 2022-11-14 04:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:17:39 --> Total execution time: 0.1865
DEBUG - 2022-11-14 04:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:18:01 --> Total execution time: 0.2100
DEBUG - 2022-11-14 04:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:18:04 --> Total execution time: 0.6314
DEBUG - 2022-11-14 04:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:18:06 --> Total execution time: 2.5544
DEBUG - 2022-11-14 04:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:18:10 --> Total execution time: 0.3709
DEBUG - 2022-11-14 04:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:18:10 --> Total execution time: 0.3272
DEBUG - 2022-11-14 04:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:11 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:18:11 --> Total execution time: 0.6772
DEBUG - 2022-11-14 04:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:18:18 --> Total execution time: 0.2226
DEBUG - 2022-11-14 04:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:18:22 --> Total execution time: 0.2749
DEBUG - 2022-11-14 04:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:23 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:18:23 --> Total execution time: 0.2105
DEBUG - 2022-11-14 04:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:18:25 --> Total execution time: 2.3056
DEBUG - 2022-11-14 04:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:48:29 --> Total execution time: 0.1907
DEBUG - 2022-11-14 04:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:18:30 --> Total execution time: 0.2141
DEBUG - 2022-11-14 04:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:48:32 --> Total execution time: 0.1907
DEBUG - 2022-11-14 04:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:48:32 --> Total execution time: 0.1740
DEBUG - 2022-11-14 04:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:38 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:18:38 --> Total execution time: 0.5467
DEBUG - 2022-11-14 04:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:18:38 --> Total execution time: 0.2062
DEBUG - 2022-11-14 04:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:18:54 --> Total execution time: 0.3000
DEBUG - 2022-11-14 16:18:55 --> Total execution time: 2.3263
DEBUG - 2022-11-14 04:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:49:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 04:49:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 04:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:19:17 --> Total execution time: 1.9360
DEBUG - 2022-11-14 04:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:19:18 --> Total execution time: 0.2016
DEBUG - 2022-11-14 04:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:19:39 --> Total execution time: 0.2107
DEBUG - 2022-11-14 04:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:19:43 --> Total execution time: 0.2271
DEBUG - 2022-11-14 04:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:19:45 --> Total execution time: 0.5722
DEBUG - 2022-11-14 04:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:19:50 --> Total execution time: 0.1842
DEBUG - 2022-11-14 04:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:19:52 --> Total execution time: 0.3717
DEBUG - 2022-11-14 04:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:19:53 --> Total execution time: 0.1874
DEBUG - 2022-11-14 04:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:19:53 --> Total execution time: 0.2674
DEBUG - 2022-11-14 04:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:19:55 --> Total execution time: 0.1785
DEBUG - 2022-11-14 04:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:19:58 --> Total execution time: 0.2173
DEBUG - 2022-11-14 04:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:20:00 --> Total execution time: 0.2678
DEBUG - 2022-11-14 04:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:20:00 --> Total execution time: 0.1779
DEBUG - 2022-11-14 04:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:20:05 --> Total execution time: 0.2214
DEBUG - 2022-11-14 04:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:20:05 --> Total execution time: 0.2413
DEBUG - 2022-11-14 04:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:20:12 --> Total execution time: 0.1761
DEBUG - 2022-11-14 04:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:20:19 --> Total execution time: 0.1731
DEBUG - 2022-11-14 04:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:20:24 --> Total execution time: 0.2414
DEBUG - 2022-11-14 04:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:20:30 --> Total execution time: 0.4033
DEBUG - 2022-11-14 04:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:20:33 --> Total execution time: 0.2093
DEBUG - 2022-11-14 04:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:20:35 --> Total execution time: 0.2178
DEBUG - 2022-11-14 04:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:20:45 --> Total execution time: 0.2634
DEBUG - 2022-11-14 04:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:21:02 --> Total execution time: 0.1913
DEBUG - 2022-11-14 04:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:21:04 --> Total execution time: 0.1760
DEBUG - 2022-11-14 04:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:21:08 --> Total execution time: 0.1793
DEBUG - 2022-11-14 04:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:21:16 --> Total execution time: 0.2050
DEBUG - 2022-11-14 04:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:21:18 --> Total execution time: 0.5021
DEBUG - 2022-11-14 04:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:21:27 --> Total execution time: 0.1954
DEBUG - 2022-11-14 04:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:51:28 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:21:28 --> Total execution time: 0.4583
DEBUG - 2022-11-14 04:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:21:46 --> Total execution time: 0.1856
DEBUG - 2022-11-14 04:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:11 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:22:12 --> Total execution time: 0.4582
DEBUG - 2022-11-14 04:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:12 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:22:12 --> Total execution time: 0.1702
DEBUG - 2022-11-14 04:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:22:13 --> Total execution time: 0.1662
DEBUG - 2022-11-14 04:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:22:17 --> Total execution time: 0.1677
DEBUG - 2022-11-14 04:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:22:23 --> Total execution time: 0.1679
DEBUG - 2022-11-14 04:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:27 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:22:27 --> Total execution time: 0.1097
DEBUG - 2022-11-14 04:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 04:52:28 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 04:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:22:28 --> Total execution time: 0.1059
DEBUG - 2022-11-14 04:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:22:31 --> Total execution time: 0.1819
DEBUG - 2022-11-14 04:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:40 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:22:40 --> Total execution time: 0.1834
DEBUG - 2022-11-14 04:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:22:42 --> Total execution time: 0.2274
DEBUG - 2022-11-14 04:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:22:46 --> Total execution time: 0.1749
DEBUG - 2022-11-14 04:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:22:50 --> Total execution time: 0.1817
DEBUG - 2022-11-14 04:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:22:53 --> Total execution time: 0.1854
DEBUG - 2022-11-14 04:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:22:54 --> Total execution time: 0.1949
DEBUG - 2022-11-14 04:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:22:55 --> Total execution time: 0.2530
DEBUG - 2022-11-14 04:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:22:56 --> Total execution time: 0.2022
DEBUG - 2022-11-14 04:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:23:01 --> Total execution time: 0.2237
DEBUG - 2022-11-14 04:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:23:01 --> Total execution time: 0.2672
DEBUG - 2022-11-14 04:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:23:11 --> Total execution time: 0.2153
DEBUG - 2022-11-14 04:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:23:12 --> Total execution time: 0.1681
DEBUG - 2022-11-14 04:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:23:29 --> Total execution time: 0.5092
DEBUG - 2022-11-14 04:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:23:31 --> Total execution time: 0.2226
DEBUG - 2022-11-14 04:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:23:31 --> Total execution time: 0.2467
DEBUG - 2022-11-14 04:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:23:35 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 04:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:23:36 --> Total execution time: 0.2313
DEBUG - 2022-11-14 04:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:23:42 --> Total execution time: 0.2070
DEBUG - 2022-11-14 04:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:23:44 --> Total execution time: 0.2591
DEBUG - 2022-11-14 04:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:23:47 --> Total execution time: 0.2152
DEBUG - 2022-11-14 04:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:23:52 --> Total execution time: 0.1768
DEBUG - 2022-11-14 04:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:24:06 --> Total execution time: 0.2129
DEBUG - 2022-11-14 04:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:54:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 04:54:26 --> 404 Page Not Found: Nwt-beige-collar-cardigan-512749html/index
DEBUG - 2022-11-14 04:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:24:37 --> Total execution time: 0.2025
DEBUG - 2022-11-14 04:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:55:05 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:25:05 --> Total execution time: 0.1344
DEBUG - 2022-11-14 04:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:25:06 --> Total execution time: 0.1808
DEBUG - 2022-11-14 04:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:25:12 --> Total execution time: 0.1753
DEBUG - 2022-11-14 04:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:25:18 --> Total execution time: 0.2269
DEBUG - 2022-11-14 04:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:25:29 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 04:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:25:30 --> Total execution time: 0.2073
DEBUG - 2022-11-14 04:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:25:41 --> Total execution time: 0.2152
DEBUG - 2022-11-14 04:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:25:48 --> Total execution time: 0.2169
DEBUG - 2022-11-14 04:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:55:55 --> Total execution time: 0.1677
DEBUG - 2022-11-14 04:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:55:57 --> Total execution time: 0.2124
DEBUG - 2022-11-14 04:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:55:58 --> Total execution time: 0.1820
DEBUG - 2022-11-14 04:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:26:01 --> Total execution time: 0.2127
DEBUG - 2022-11-14 04:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:26:12 --> Total execution time: 0.1674
DEBUG - 2022-11-14 04:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:26:16 --> Total execution time: 0.2033
DEBUG - 2022-11-14 04:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:26:23 --> Total execution time: 0.2179
DEBUG - 2022-11-14 04:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:26:37 --> Total execution time: 0.1749
DEBUG - 2022-11-14 04:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:26:49 --> Total execution time: 0.2259
DEBUG - 2022-11-14 04:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:27:23 --> Total execution time: 0.1166
DEBUG - 2022-11-14 04:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:28:00 --> Total execution time: 0.1752
DEBUG - 2022-11-14 04:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:28:01 --> Total execution time: 0.1208
DEBUG - 2022-11-14 04:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:28:01 --> Total execution time: 0.1294
DEBUG - 2022-11-14 04:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:58:11 --> No URI present. Default controller set.
DEBUG - 2022-11-14 04:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:28:11 --> Total execution time: 0.1357
DEBUG - 2022-11-14 04:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 04:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:28:16 --> Total execution time: 0.1666
DEBUG - 2022-11-14 04:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:28:20 --> Total execution time: 0.2349
DEBUG - 2022-11-14 04:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:28:29 --> Total execution time: 0.1750
DEBUG - 2022-11-14 04:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:28:36 --> Total execution time: 0.2525
DEBUG - 2022-11-14 04:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:28:37 --> Total execution time: 0.2215
DEBUG - 2022-11-14 04:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:28:45 --> Total execution time: 0.2198
DEBUG - 2022-11-14 04:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:28:46 --> Total execution time: 0.1711
DEBUG - 2022-11-14 04:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:28:56 --> Total execution time: 0.2228
DEBUG - 2022-11-14 04:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:29:39 --> Total execution time: 3.1675
DEBUG - 2022-11-14 04:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 04:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 04:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:29:44 --> Total execution time: 0.8230
DEBUG - 2022-11-14 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:30:02 --> Total execution time: 0.2678
DEBUG - 2022-11-14 05:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:30:16 --> Total execution time: 0.5587
DEBUG - 2022-11-14 05:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:30:22 --> Total execution time: 0.1771
DEBUG - 2022-11-14 05:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:30:25 --> Total execution time: 0.1870
DEBUG - 2022-11-14 05:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:30:28 --> Total execution time: 0.1817
DEBUG - 2022-11-14 05:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:30:33 --> Total execution time: 0.1825
DEBUG - 2022-11-14 05:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:30:43 --> Total execution time: 0.3885
DEBUG - 2022-11-14 05:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:49 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:30:49 --> Total execution time: 0.1315
DEBUG - 2022-11-14 05:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:00:56 --> Total execution time: 0.1682
DEBUG - 2022-11-14 05:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:00:58 --> Total execution time: 0.1770
DEBUG - 2022-11-14 05:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:00:59 --> Total execution time: 0.1722
DEBUG - 2022-11-14 05:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:01:12 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:31:12 --> Total execution time: 0.2197
DEBUG - 2022-11-14 05:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:01:16 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:31:16 --> Total execution time: 0.1107
DEBUG - 2022-11-14 05:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:31:17 --> Total execution time: 0.1916
DEBUG - 2022-11-14 05:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:31:36 --> Total execution time: 0.1725
DEBUG - 2022-11-14 05:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:01:40 --> Total execution time: 0.1739
DEBUG - 2022-11-14 05:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:31:41 --> Total execution time: 0.1683
DEBUG - 2022-11-14 05:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:31:41 --> Total execution time: 0.1681
DEBUG - 2022-11-14 05:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:01:42 --> Total execution time: 0.2226
DEBUG - 2022-11-14 05:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:01:42 --> Total execution time: 0.1714
DEBUG - 2022-11-14 05:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:31:56 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 05:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:31:57 --> Total execution time: 0.1940
DEBUG - 2022-11-14 05:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:32:07 --> Total execution time: 0.1752
DEBUG - 2022-11-14 05:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:32:15 --> Total execution time: 0.2197
DEBUG - 2022-11-14 05:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:32:16 --> Total execution time: 0.2005
DEBUG - 2022-11-14 05:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:32:44 --> Total execution time: 0.1878
DEBUG - 2022-11-14 05:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:32:48 --> Total execution time: 0.1470
DEBUG - 2022-11-14 05:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:02:50 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:32:50 --> Total execution time: 0.1120
DEBUG - 2022-11-14 05:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:02:55 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:32:55 --> Total execution time: 0.1144
DEBUG - 2022-11-14 05:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:33:01 --> Total execution time: 0.2291
DEBUG - 2022-11-14 05:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:33:10 --> Total execution time: 0.1890
DEBUG - 2022-11-14 05:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:33:11 --> Total execution time: 0.1703
DEBUG - 2022-11-14 05:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:34:16 --> Total execution time: 0.2150
DEBUG - 2022-11-14 05:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:34:35 --> Total execution time: 2.0294
DEBUG - 2022-11-14 05:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:35:08 --> Total execution time: 2.2152
DEBUG - 2022-11-14 05:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:05:08 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:35:09 --> Total execution time: 0.1231
DEBUG - 2022-11-14 05:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:35:14 --> Total execution time: 0.1031
DEBUG - 2022-11-14 05:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:35:20 --> Total execution time: 0.1926
DEBUG - 2022-11-14 05:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:35:24 --> Total execution time: 0.1770
DEBUG - 2022-11-14 05:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:35:28 --> Total execution time: 0.2388
DEBUG - 2022-11-14 05:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:35:36 --> Total execution time: 0.2392
DEBUG - 2022-11-14 05:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:36:07 --> Total execution time: 0.1127
DEBUG - 2022-11-14 05:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:36:32 --> Total execution time: 0.2035
DEBUG - 2022-11-14 05:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:36:50 --> Total execution time: 0.1901
DEBUG - 2022-11-14 05:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:36:59 --> Total execution time: 0.1690
DEBUG - 2022-11-14 05:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:37:03 --> Total execution time: 0.2016
DEBUG - 2022-11-14 05:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:37:10 --> Total execution time: 0.1777
DEBUG - 2022-11-14 05:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:07:11 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:37:12 --> Total execution time: 0.1664
DEBUG - 2022-11-14 05:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:37:12 --> Total execution time: 0.1859
DEBUG - 2022-11-14 05:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:37:13 --> Total execution time: 0.1817
DEBUG - 2022-11-14 05:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:37:28 --> Total execution time: 0.1819
DEBUG - 2022-11-14 05:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:38:34 --> Total execution time: 0.4994
DEBUG - 2022-11-14 05:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:38:34 --> Total execution time: 0.2160
DEBUG - 2022-11-14 05:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:38:36 --> Total execution time: 0.1748
DEBUG - 2022-11-14 05:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:38:45 --> Total execution time: 0.2078
DEBUG - 2022-11-14 05:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:38:48 --> Total execution time: 0.1889
DEBUG - 2022-11-14 05:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:09:13 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:39:13 --> Total execution time: 0.1928
DEBUG - 2022-11-14 05:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:09:31 --> Total execution time: 0.1732
DEBUG - 2022-11-14 05:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:09:34 --> Total execution time: 0.1838
DEBUG - 2022-11-14 05:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:09:34 --> Total execution time: 0.1756
DEBUG - 2022-11-14 05:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:10:23 --> Total execution time: 0.1878
DEBUG - 2022-11-14 05:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:10:25 --> Total execution time: 0.1853
DEBUG - 2022-11-14 05:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:10:25 --> Total execution time: 0.1686
DEBUG - 2022-11-14 05:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:10:57 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:40:57 --> Total execution time: 0.1200
DEBUG - 2022-11-14 05:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:10:59 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:40:59 --> Total execution time: 0.1141
DEBUG - 2022-11-14 05:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:11:19 --> Total execution time: 0.1816
DEBUG - 2022-11-14 05:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:11:23 --> Total execution time: 0.1813
DEBUG - 2022-11-14 05:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:11:24 --> Total execution time: 0.1719
DEBUG - 2022-11-14 05:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:11:25 --> Total execution time: 0.4158
DEBUG - 2022-11-14 05:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:11:43 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:41:44 --> Total execution time: 0.1495
DEBUG - 2022-11-14 05:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:11:52 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:41:52 --> Total execution time: 0.1725
DEBUG - 2022-11-14 05:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:42:07 --> Total execution time: 0.1769
DEBUG - 2022-11-14 05:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:42:15 --> Total execution time: 0.1932
DEBUG - 2022-11-14 05:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:42:20 --> Total execution time: 0.1839
DEBUG - 2022-11-14 05:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:42:40 --> Total execution time: 0.5130
DEBUG - 2022-11-14 05:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 05:14:57 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 05:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:45:14 --> Total execution time: 3.7510
DEBUG - 2022-11-14 05:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:16:47 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:46:48 --> Total execution time: 0.6260
DEBUG - 2022-11-14 16:46:48 --> Total execution time: 1.0316
DEBUG - 2022-11-14 05:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:47:19 --> Total execution time: 0.2110
DEBUG - 2022-11-14 05:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:47:30 --> Total execution time: 0.4796
DEBUG - 2022-11-14 05:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:47:38 --> Total execution time: 0.2219
DEBUG - 2022-11-14 05:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:47:42 --> Total execution time: 0.1855
DEBUG - 2022-11-14 05:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:47:46 --> Total execution time: 0.2237
DEBUG - 2022-11-14 05:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:47:46 --> Total execution time: 0.1085
DEBUG - 2022-11-14 05:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:47:51 --> Total execution time: 0.1761
DEBUG - 2022-11-14 05:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:48:00 --> Total execution time: 0.1705
DEBUG - 2022-11-14 05:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:18:41 --> Total execution time: 0.1146
DEBUG - 2022-11-14 05:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:48:53 --> Total execution time: 0.2270
DEBUG - 2022-11-14 05:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:48:58 --> Total execution time: 0.1785
DEBUG - 2022-11-14 05:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:19:02 --> Total execution time: 0.1994
DEBUG - 2022-11-14 05:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:49:03 --> Total execution time: 0.1685
DEBUG - 2022-11-14 05:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:49:06 --> Total execution time: 0.1842
DEBUG - 2022-11-14 05:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:49:18 --> Total execution time: 0.2028
DEBUG - 2022-11-14 05:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:19:18 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:49:18 --> Total execution time: 0.4538
DEBUG - 2022-11-14 05:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:19:24 --> Total execution time: 0.1734
DEBUG - 2022-11-14 05:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:19:26 --> Total execution time: 0.1905
DEBUG - 2022-11-14 05:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:19:26 --> Total execution time: 0.1773
DEBUG - 2022-11-14 05:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:49:33 --> Total execution time: 0.1905
DEBUG - 2022-11-14 05:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:49:51 --> Total execution time: 0.1863
DEBUG - 2022-11-14 05:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:19:58 --> Total execution time: 0.1838
DEBUG - 2022-11-14 05:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:20:00 --> Total execution time: 0.1707
DEBUG - 2022-11-14 05:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:20:00 --> Total execution time: 0.4029
DEBUG - 2022-11-14 05:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:50:15 --> Total execution time: 0.1690
DEBUG - 2022-11-14 05:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:50:32 --> Total execution time: 0.1861
DEBUG - 2022-11-14 05:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:50:36 --> Total execution time: 0.1960
DEBUG - 2022-11-14 05:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:20:43 --> Total execution time: 0.1895
DEBUG - 2022-11-14 05:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:20:45 --> Total execution time: 0.1861
DEBUG - 2022-11-14 05:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:20:45 --> Total execution time: 0.4101
DEBUG - 2022-11-14 05:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:51:42 --> Total execution time: 0.1731
DEBUG - 2022-11-14 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:21:51 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:51:51 --> Total execution time: 0.4795
DEBUG - 2022-11-14 05:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:51:56 --> Total execution time: 0.1953
DEBUG - 2022-11-14 05:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:52:04 --> Total execution time: 0.2060
DEBUG - 2022-11-14 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:52:10 --> Total execution time: 0.1782
DEBUG - 2022-11-14 05:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:52:19 --> Total execution time: 0.1816
DEBUG - 2022-11-14 05:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:52:20 --> Total execution time: 0.1954
DEBUG - 2022-11-14 05:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:20 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:52:20 --> Total execution time: 0.1719
DEBUG - 2022-11-14 05:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:22:38 --> Total execution time: 0.1966
DEBUG - 2022-11-14 05:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:22:39 --> Total execution time: 0.1844
DEBUG - 2022-11-14 05:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:22:40 --> Total execution time: 0.1681
DEBUG - 2022-11-14 05:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:22:48 --> Total execution time: 0.1826
DEBUG - 2022-11-14 05:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:22:50 --> Total execution time: 0.1783
DEBUG - 2022-11-14 05:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:22:50 --> Total execution time: 0.3427
DEBUG - 2022-11-14 05:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:22:51 --> Total execution time: 0.1758
DEBUG - 2022-11-14 05:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:22:53 --> Total execution time: 0.2511
DEBUG - 2022-11-14 05:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:22:53 --> Total execution time: 0.4849
DEBUG - 2022-11-14 05:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:22:54 --> Total execution time: 0.1845
DEBUG - 2022-11-14 05:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:22:56 --> Total execution time: 0.1867
DEBUG - 2022-11-14 05:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:22:56 --> Total execution time: 0.4104
DEBUG - 2022-11-14 05:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:57 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:52:57 --> Total execution time: 0.1766
DEBUG - 2022-11-14 05:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:52:59 --> Total execution time: 0.4819
DEBUG - 2022-11-14 05:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:23:03 --> Total execution time: 0.2088
DEBUG - 2022-11-14 05:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:23:05 --> Total execution time: 0.1756
DEBUG - 2022-11-14 05:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:23:06 --> Total execution time: 0.1893
DEBUG - 2022-11-14 05:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:23:55 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:53:55 --> Total execution time: 0.1737
DEBUG - 2022-11-14 05:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:53:57 --> Total execution time: 0.1791
DEBUG - 2022-11-14 05:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:54:08 --> Total execution time: 0.1742
DEBUG - 2022-11-14 05:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:54:18 --> Total execution time: 0.1992
DEBUG - 2022-11-14 05:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:54:23 --> Total execution time: 0.1730
DEBUG - 2022-11-14 05:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:54:30 --> Total execution time: 0.1839
DEBUG - 2022-11-14 05:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:54:30 --> Total execution time: 0.2221
DEBUG - 2022-11-14 05:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:54:31 --> Total execution time: 0.2707
DEBUG - 2022-11-14 05:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:54:45 --> Total execution time: 0.1901
DEBUG - 2022-11-14 05:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:25:00 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:55:01 --> Total execution time: 0.4581
DEBUG - 2022-11-14 05:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:25:08 --> Total execution time: 0.1673
DEBUG - 2022-11-14 05:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:25:12 --> Total execution time: 0.1755
DEBUG - 2022-11-14 05:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:25:13 --> Total execution time: 0.1710
DEBUG - 2022-11-14 05:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:55:35 --> Total execution time: 0.1131
DEBUG - 2022-11-14 05:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:25:46 --> Total execution time: 0.1733
DEBUG - 2022-11-14 05:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:25:48 --> Total execution time: 0.1892
DEBUG - 2022-11-14 05:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:25:48 --> Total execution time: 0.4154
DEBUG - 2022-11-14 05:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:25:54 --> Total execution time: 0.2067
DEBUG - 2022-11-14 05:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:25:54 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:55:54 --> Total execution time: 0.1717
DEBUG - 2022-11-14 05:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:56:18 --> Total execution time: 0.1685
DEBUG - 2022-11-14 05:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:56:18 --> Total execution time: 0.1753
DEBUG - 2022-11-14 05:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:56:19 --> Total execution time: 0.1773
DEBUG - 2022-11-14 05:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:26:42 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:56:42 --> Total execution time: 0.1726
DEBUG - 2022-11-14 05:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:56:42 --> Total execution time: 0.1616
DEBUG - 2022-11-14 05:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:56:49 --> Total execution time: 0.1773
DEBUG - 2022-11-14 05:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:27:16 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:57:16 --> Total execution time: 0.1094
DEBUG - 2022-11-14 05:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:27:17 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:57:17 --> Total execution time: 0.1090
DEBUG - 2022-11-14 05:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:27:18 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:57:18 --> Total execution time: 0.1158
DEBUG - 2022-11-14 05:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:57:24 --> Total execution time: 0.1742
DEBUG - 2022-11-14 05:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:57:25 --> Total execution time: 0.1674
DEBUG - 2022-11-14 05:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:57:35 --> Total execution time: 0.1796
DEBUG - 2022-11-14 05:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:57:42 --> Total execution time: 0.1716
DEBUG - 2022-11-14 05:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:57:45 --> Total execution time: 0.2505
DEBUG - 2022-11-14 05:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:57:46 --> Total execution time: 0.1821
DEBUG - 2022-11-14 05:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:57:47 --> Total execution time: 0.1056
DEBUG - 2022-11-14 05:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:58:01 --> Total execution time: 0.5653
DEBUG - 2022-11-14 05:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:59:01 --> Total execution time: 0.2342
DEBUG - 2022-11-14 05:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:59:12 --> Total execution time: 0.1749
DEBUG - 2022-11-14 05:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:00:30 --> Total execution time: 0.1746
DEBUG - 2022-11-14 05:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:00:40 --> Total execution time: 0.6975
DEBUG - 2022-11-14 05:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:00:46 --> Total execution time: 0.2143
DEBUG - 2022-11-14 05:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:01:09 --> Total execution time: 0.1711
DEBUG - 2022-11-14 05:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:01:10 --> Total execution time: 0.4568
DEBUG - 2022-11-14 05:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:01:39 --> Total execution time: 0.1646
DEBUG - 2022-11-14 05:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:01:53 --> Total execution time: 0.1804
DEBUG - 2022-11-14 05:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:31:58 --> Total execution time: 0.1772
DEBUG - 2022-11-14 05:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:32:01 --> Total execution time: 0.1741
DEBUG - 2022-11-14 05:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:32:01 --> Total execution time: 0.2042
DEBUG - 2022-11-14 05:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:02:10 --> Total execution time: 0.1453
DEBUG - 2022-11-14 05:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:02:29 --> Total execution time: 0.1725
DEBUG - 2022-11-14 05:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:02:36 --> Total execution time: 0.1722
DEBUG - 2022-11-14 05:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:32:38 --> Total execution time: 0.1844
DEBUG - 2022-11-14 05:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:32:40 --> Total execution time: 0.1909
DEBUG - 2022-11-14 05:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:32:40 --> Total execution time: 0.1682
DEBUG - 2022-11-14 05:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:02:42 --> Total execution time: 0.2148
DEBUG - 2022-11-14 05:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:33:02 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:03:02 --> Total execution time: 0.1122
DEBUG - 2022-11-14 05:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:33:03 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:03:03 --> Total execution time: 0.1218
DEBUG - 2022-11-14 05:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:33:19 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:03:19 --> Total execution time: 0.1783
DEBUG - 2022-11-14 05:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:03:30 --> Total execution time: 0.1816
DEBUG - 2022-11-14 05:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:33:30 --> Total execution time: 0.1721
DEBUG - 2022-11-14 05:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:33:33 --> Total execution time: 0.1680
DEBUG - 2022-11-14 05:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:33:33 --> Total execution time: 0.4032
DEBUG - 2022-11-14 05:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:03:35 --> Total execution time: 0.1877
DEBUG - 2022-11-14 05:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:03:58 --> Total execution time: 0.1739
DEBUG - 2022-11-14 05:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:03:58 --> Total execution time: 0.1720
DEBUG - 2022-11-14 05:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:04:22 --> Total execution time: 0.1802
DEBUG - 2022-11-14 05:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:04:24 --> Total execution time: 0.1974
DEBUG - 2022-11-14 05:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:34:25 --> Total execution time: 0.1738
DEBUG - 2022-11-14 05:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:04:29 --> Total execution time: 0.1761
DEBUG - 2022-11-14 05:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:34:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 05:34:32 --> 404 Page Not Found: Grey-white-fur-poncho-988258html/index
DEBUG - 2022-11-14 05:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:34:34 --> Total execution time: 0.1828
DEBUG - 2022-11-14 05:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:34:34 --> Total execution time: 0.1676
DEBUG - 2022-11-14 05:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:04:34 --> Total execution time: 0.1705
DEBUG - 2022-11-14 05:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:34:46 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:04:46 --> Total execution time: 0.1865
DEBUG - 2022-11-14 05:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:04:55 --> Total execution time: 0.2253
DEBUG - 2022-11-14 05:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:04:56 --> Total execution time: 0.2119
DEBUG - 2022-11-14 05:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:05:05 --> Total execution time: 0.1891
DEBUG - 2022-11-14 05:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:05:10 --> Total execution time: 0.1795
DEBUG - 2022-11-14 05:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:05:10 --> Total execution time: 0.1925
DEBUG - 2022-11-14 05:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:12 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:05:12 --> Total execution time: 0.1836
DEBUG - 2022-11-14 05:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:05:16 --> Total execution time: 0.1717
DEBUG - 2022-11-14 05:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:18 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:05:19 --> Total execution time: 0.1795
DEBUG - 2022-11-14 05:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:05:39 --> Total execution time: 0.2832
DEBUG - 2022-11-14 05:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:05:44 --> Total execution time: 0.1815
DEBUG - 2022-11-14 05:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:35:50 --> Total execution time: 0.2199
DEBUG - 2022-11-14 05:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:35:53 --> Total execution time: 0.1992
DEBUG - 2022-11-14 05:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:35:53 --> Total execution time: 0.2033
DEBUG - 2022-11-14 05:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:05:55 --> Total execution time: 0.2940
DEBUG - 2022-11-14 05:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:05:56 --> Total execution time: 0.2864
DEBUG - 2022-11-14 05:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:05:59 --> Total execution time: 0.1891
DEBUG - 2022-11-14 05:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 05:36:03 --> 404 Page Not Found: Well-known/traffic-advice
DEBUG - 2022-11-14 05:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:06:04 --> Total execution time: 0.3084
DEBUG - 2022-11-14 05:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:06:04 --> Total execution time: 0.2425
DEBUG - 2022-11-14 05:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 05:36:05 --> 404 Page Not Found: Well-known/traffic-advice
DEBUG - 2022-11-14 05:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:07 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:06:07 --> Total execution time: 0.1470
DEBUG - 2022-11-14 05:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:12 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:06:12 --> Total execution time: 0.2754
DEBUG - 2022-11-14 05:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:06:14 --> Total execution time: 0.1851
DEBUG - 2022-11-14 05:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:06:17 --> Total execution time: 0.1449
DEBUG - 2022-11-14 05:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:06:19 --> Total execution time: 0.2299
DEBUG - 2022-11-14 05:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:20 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:06:20 --> Total execution time: 0.1535
DEBUG - 2022-11-14 05:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:36:25 --> Total execution time: 0.1798
DEBUG - 2022-11-14 05:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:36:27 --> Total execution time: 0.1735
DEBUG - 2022-11-14 05:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:36:27 --> Total execution time: 0.4107
DEBUG - 2022-11-14 05:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:36:32 --> Total execution time: 0.2386
DEBUG - 2022-11-14 05:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:36:32 --> Total execution time: 0.1748
DEBUG - 2022-11-14 05:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:36:34 --> Total execution time: 0.2174
DEBUG - 2022-11-14 05:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:36:34 --> Total execution time: 0.4774
DEBUG - 2022-11-14 05:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:36:35 --> Total execution time: 0.2565
DEBUG - 2022-11-14 05:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:06:37 --> Total execution time: 0.2188
DEBUG - 2022-11-14 05:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:36:37 --> Total execution time: 0.2277
DEBUG - 2022-11-14 05:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:36:38 --> Total execution time: 0.4975
DEBUG - 2022-11-14 05:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:41 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:06:41 --> Total execution time: 0.1405
DEBUG - 2022-11-14 05:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:36:45 --> Total execution time: 0.2126
DEBUG - 2022-11-14 05:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:06:52 --> Total execution time: 0.1914
DEBUG - 2022-11-14 05:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:06:58 --> Total execution time: 0.1952
DEBUG - 2022-11-14 05:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:07:04 --> Total execution time: 0.2650
DEBUG - 2022-11-14 05:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:07:18 --> Total execution time: 0.5123
DEBUG - 2022-11-14 05:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:37:26 --> Total execution time: 0.1795
DEBUG - 2022-11-14 05:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 05:37:26 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 05:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:37:27 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:07:27 --> Total execution time: 0.1179
DEBUG - 2022-11-14 05:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:37:28 --> Total execution time: 0.2072
DEBUG - 2022-11-14 05:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:37:28 --> Total execution time: 0.1769
DEBUG - 2022-11-14 05:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:07:33 --> Total execution time: 0.2012
DEBUG - 2022-11-14 05:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:07:37 --> Total execution time: 0.2734
DEBUG - 2022-11-14 05:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:08:02 --> Total execution time: 0.2796
DEBUG - 2022-11-14 05:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:08:05 --> Total execution time: 0.1831
DEBUG - 2022-11-14 05:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:38:05 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:08:05 --> Total execution time: 0.1192
DEBUG - 2022-11-14 05:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:38:15 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:08:15 --> Total execution time: 0.2498
DEBUG - 2022-11-14 05:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:08:30 --> Total execution time: 0.2620
DEBUG - 2022-11-14 05:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:38:42 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:08:42 --> Total execution time: 0.1173
DEBUG - 2022-11-14 05:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:38:56 --> Total execution time: 0.5569
DEBUG - 2022-11-14 05:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:38:58 --> Total execution time: 0.2395
DEBUG - 2022-11-14 05:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:38:58 --> Total execution time: 0.2211
DEBUG - 2022-11-14 05:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:09:06 --> Total execution time: 0.5065
DEBUG - 2022-11-14 05:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:12 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:09:13 --> Total execution time: 0.6127
DEBUG - 2022-11-14 05:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:09:27 --> Total execution time: 0.1919
DEBUG - 2022-11-14 05:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:09:30 --> Total execution time: 0.1882
DEBUG - 2022-11-14 05:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:39:30 --> Total execution time: 0.2104
DEBUG - 2022-11-14 05:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:09:35 --> Total execution time: 0.1898
DEBUG - 2022-11-14 05:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:09:36 --> Total execution time: 0.2084
DEBUG - 2022-11-14 05:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:09:38 --> Total execution time: 0.2171
DEBUG - 2022-11-14 05:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:09:39 --> Total execution time: 0.1989
DEBUG - 2022-11-14 05:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:39:45 --> Total execution time: 0.2254
DEBUG - 2022-11-14 05:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:39:47 --> Total execution time: 0.1953
DEBUG - 2022-11-14 05:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:39:48 --> Total execution time: 0.4466
DEBUG - 2022-11-14 05:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:09:51 --> Total execution time: 0.2231
DEBUG - 2022-11-14 05:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:53 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:09:53 --> Total execution time: 0.2610
DEBUG - 2022-11-14 05:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:39:54 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:09:54 --> Total execution time: 0.1147
DEBUG - 2022-11-14 05:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:05 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:10:05 --> Total execution time: 0.5808
DEBUG - 2022-11-14 05:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:07 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:10:07 --> Total execution time: 0.2020
DEBUG - 2022-11-14 05:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:10:11 --> Total execution time: 0.1890
DEBUG - 2022-11-14 05:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:10:15 --> Total execution time: 0.1693
DEBUG - 2022-11-14 05:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:10:27 --> Total execution time: 0.1988
DEBUG - 2022-11-14 05:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:10:31 --> Total execution time: 2.5764
DEBUG - 2022-11-14 05:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:10:34 --> Total execution time: 0.1139
DEBUG - 2022-11-14 05:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:10:40 --> Total execution time: 0.2983
DEBUG - 2022-11-14 05:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 05:40:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 05:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:10:41 --> Total execution time: 0.1787
DEBUG - 2022-11-14 05:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:10:42 --> Total execution time: 0.1835
DEBUG - 2022-11-14 05:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:10:47 --> Total execution time: 0.1893
DEBUG - 2022-11-14 05:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:40:49 --> Total execution time: 0.1866
DEBUG - 2022-11-14 05:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:10:50 --> Total execution time: 0.2422
DEBUG - 2022-11-14 05:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:40:52 --> Total execution time: 0.1890
DEBUG - 2022-11-14 05:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:40:52 --> Total execution time: 0.4305
DEBUG - 2022-11-14 05:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:40:53 --> Total execution time: 0.1918
DEBUG - 2022-11-14 05:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:10:55 --> Total execution time: 0.2266
DEBUG - 2022-11-14 05:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:40:57 --> Total execution time: 0.1879
DEBUG - 2022-11-14 05:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:40:58 --> Total execution time: 0.1972
DEBUG - 2022-11-14 05:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:40:58 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:10:58 --> Total execution time: 0.4782
DEBUG - 2022-11-14 05:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:11:14 --> Total execution time: 0.1715
DEBUG - 2022-11-14 05:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:41:56 --> Total execution time: 0.2256
DEBUG - 2022-11-14 05:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:41:58 --> Total execution time: 0.2021
DEBUG - 2022-11-14 05:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:41:58 --> Total execution time: 0.1703
DEBUG - 2022-11-14 05:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:45:03 --> Total execution time: 0.3734
DEBUG - 2022-11-14 05:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:45:05 --> Total execution time: 0.1884
DEBUG - 2022-11-14 05:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:45:05 --> Total execution time: 0.2159
DEBUG - 2022-11-14 05:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:15:25 --> Total execution time: 0.2028
DEBUG - 2022-11-14 05:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:16:48 --> Total execution time: 0.5185
DEBUG - 2022-11-14 05:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:16:51 --> Total execution time: 0.1970
DEBUG - 2022-11-14 05:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:46:55 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:16:55 --> Total execution time: 0.4998
DEBUG - 2022-11-14 05:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:47:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 05:47:06 --> 404 Page Not Found: Stylephp/index
DEBUG - 2022-11-14 05:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:17:44 --> Total execution time: 0.5338
DEBUG - 2022-11-14 05:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:48:15 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:18:15 --> Total execution time: 0.1716
DEBUG - 2022-11-14 05:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:18:22 --> Total execution time: 0.1730
DEBUG - 2022-11-14 05:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:18:32 --> Total execution time: 0.1872
DEBUG - 2022-11-14 05:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:18:39 --> Total execution time: 0.1679
DEBUG - 2022-11-14 05:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:18:47 --> Total execution time: 0.1659
DEBUG - 2022-11-14 05:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:18:57 --> Total execution time: 0.2160
DEBUG - 2022-11-14 05:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:18:58 --> Total execution time: 0.1885
DEBUG - 2022-11-14 05:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:19:01 --> Total execution time: 0.2275
DEBUG - 2022-11-14 05:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:19:06 --> Total execution time: 0.1697
DEBUG - 2022-11-14 05:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:19:09 --> Total execution time: 0.1908
DEBUG - 2022-11-14 05:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:19:11 --> Total execution time: 0.1808
DEBUG - 2022-11-14 05:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:18 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:19:18 --> Total execution time: 0.1751
DEBUG - 2022-11-14 05:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 05:49:19 --> 404 Page Not Found: Chun-li-icon-heroes-bobblehead-statue-street-fighter-new-collectible-blue-867592html/index
DEBUG - 2022-11-14 05:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 05:49:20 --> 404 Page Not Found: Kodak-easyshare-z740-camera-183850html/index
DEBUG - 2022-11-14 05:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 05:49:20 --> 404 Page Not Found: Curtain-call-dance-costume-size-cla-childrens-large-363165html/index
DEBUG - 2022-11-14 05:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 05:49:20 --> 404 Page Not Found: Onix-graphite-z5-graphite-carbon-fiber-pickleball-paddle-brand-new-1030579html/index
DEBUG - 2022-11-14 05:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:19:22 --> Total execution time: 0.1731
DEBUG - 2022-11-14 05:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:19:24 --> Total execution time: 0.1855
DEBUG - 2022-11-14 05:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:19:27 --> Total execution time: 0.1659
DEBUG - 2022-11-14 05:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 05:49:30 --> 404 Page Not Found: Gameboy-advance-sp-ags-1869html/index
DEBUG - 2022-11-14 05:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:19:31 --> Total execution time: 0.1938
DEBUG - 2022-11-14 05:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:19:35 --> Total execution time: 0.2001
DEBUG - 2022-11-14 05:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 05:49:40 --> 404 Page Not Found: Chun-li-icon-heroes-bobblehead-statue-street-fighter-new-collectible-blue-867592html/index
DEBUG - 2022-11-14 05:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 05:49:40 --> 404 Page Not Found: Kodak-easyshare-z740-camera-183850html/index
DEBUG - 2022-11-14 05:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 05:49:40 --> 404 Page Not Found: Onix-graphite-z5-graphite-carbon-fiber-pickleball-paddle-brand-new-1030579html/index
DEBUG - 2022-11-14 05:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 05:49:40 --> 404 Page Not Found: Curtain-call-dance-costume-size-cla-childrens-large-363165html/index
DEBUG - 2022-11-14 05:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:19:44 --> Total execution time: 0.1649
DEBUG - 2022-11-14 05:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:50:21 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:20:22 --> Total execution time: 0.4464
DEBUG - 2022-11-14 05:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:20:26 --> Total execution time: 0.1638
DEBUG - 2022-11-14 05:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:20:45 --> Total execution time: 0.1839
DEBUG - 2022-11-14 05:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:20:51 --> Total execution time: 0.1655
DEBUG - 2022-11-14 05:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:20:54 --> Total execution time: 0.1710
DEBUG - 2022-11-14 05:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:20:58 --> Total execution time: 0.1840
DEBUG - 2022-11-14 05:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:23:26 --> Total execution time: 0.1775
DEBUG - 2022-11-14 05:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:23:31 --> Total execution time: 0.1673
DEBUG - 2022-11-14 05:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:23:40 --> Total execution time: 0.1668
DEBUG - 2022-11-14 05:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:54:45 --> No URI present. Default controller set.
DEBUG - 2022-11-14 05:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:24:45 --> Total execution time: 0.5277
DEBUG - 2022-11-14 05:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:24:55 --> Total execution time: 0.2319
DEBUG - 2022-11-14 05:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 05:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:26:19 --> Total execution time: 0.1875
DEBUG - 2022-11-14 05:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:28:21 --> Total execution time: 0.1932
DEBUG - 2022-11-14 05:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:28:39 --> Total execution time: 0.1846
DEBUG - 2022-11-14 05:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:28:44 --> Total execution time: 0.1989
DEBUG - 2022-11-14 05:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:28:50 --> Total execution time: 0.1774
DEBUG - 2022-11-14 05:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:28:53 --> Total execution time: 0.1827
DEBUG - 2022-11-14 05:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:29:41 --> Total execution time: 0.1791
DEBUG - 2022-11-14 05:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:29:45 --> Total execution time: 0.2287
DEBUG - 2022-11-14 05:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:29:54 --> Total execution time: 0.2185
DEBUG - 2022-11-14 05:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 05:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 05:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:29:59 --> Total execution time: 0.1742
DEBUG - 2022-11-14 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:30:03 --> Total execution time: 0.1316
DEBUG - 2022-11-14 06:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:30:53 --> Total execution time: 0.2038
DEBUG - 2022-11-14 06:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:01:05 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:31:05 --> Total execution time: 0.1144
DEBUG - 2022-11-14 06:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:31:11 --> Total execution time: 0.1070
DEBUG - 2022-11-14 06:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:31:30 --> Total execution time: 0.4522
DEBUG - 2022-11-14 06:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:31:34 --> Total execution time: 0.1797
DEBUG - 2022-11-14 06:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:31:39 --> Total execution time: 0.1914
DEBUG - 2022-11-14 06:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:31:45 --> Total execution time: 0.2133
DEBUG - 2022-11-14 06:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:31:45 --> Total execution time: 0.4885
DEBUG - 2022-11-14 06:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:31:55 --> Total execution time: 0.1855
DEBUG - 2022-11-14 06:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:31:55 --> Total execution time: 0.1722
DEBUG - 2022-11-14 06:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:01:56 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:31:56 --> Total execution time: 0.4574
DEBUG - 2022-11-14 06:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:31:56 --> Total execution time: 0.2187
DEBUG - 2022-11-14 06:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:32:01 --> Total execution time: 0.1786
DEBUG - 2022-11-14 06:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:32:01 --> Total execution time: 0.2490
DEBUG - 2022-11-14 06:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:32:17 --> Total execution time: 0.2203
DEBUG - 2022-11-14 06:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:32:39 --> Total execution time: 0.1741
DEBUG - 2022-11-14 06:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:32:41 --> Total execution time: 0.1726
DEBUG - 2022-11-14 06:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:34:01 --> Total execution time: 0.1808
DEBUG - 2022-11-14 06:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:34:06 --> Total execution time: 0.1762
DEBUG - 2022-11-14 06:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:34:11 --> Total execution time: 0.1871
DEBUG - 2022-11-14 06:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:05:22 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:35:22 --> Total execution time: 0.1209
DEBUG - 2022-11-14 06:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:07:34 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:37:34 --> Total execution time: 0.4971
DEBUG - 2022-11-14 06:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:38:26 --> Total execution time: 2.1902
DEBUG - 2022-11-14 06:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 06:08:31 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 06:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:08:32 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:38:32 --> Total execution time: 0.1108
DEBUG - 2022-11-14 06:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:08:33 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:38:33 --> Total execution time: 0.1135
DEBUG - 2022-11-14 06:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:38:38 --> Total execution time: 0.1757
DEBUG - 2022-11-14 06:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:08:43 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:38:43 --> Total execution time: 0.1714
DEBUG - 2022-11-14 06:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:08:48 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:38:48 --> Total execution time: 0.1199
DEBUG - 2022-11-14 06:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:38:54 --> Total execution time: 0.1650
DEBUG - 2022-11-14 06:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:39:10 --> Total execution time: 0.1795
DEBUG - 2022-11-14 06:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:39:25 --> Total execution time: 0.1819
DEBUG - 2022-11-14 06:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:09:50 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:39:50 --> Total execution time: 0.1096
DEBUG - 2022-11-14 06:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:41:35 --> Total execution time: 0.2327
DEBUG - 2022-11-14 06:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:11:48 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:41:48 --> Total execution time: 0.1113
DEBUG - 2022-11-14 06:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:12:06 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:42:06 --> Total execution time: 0.1067
DEBUG - 2022-11-14 06:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:12:08 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:42:08 --> Total execution time: 0.1028
DEBUG - 2022-11-14 06:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:42:18 --> Total execution time: 0.1757
DEBUG - 2022-11-14 06:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:42:30 --> Total execution time: 0.1772
DEBUG - 2022-11-14 06:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:42:34 --> Total execution time: 0.1073
DEBUG - 2022-11-14 06:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:42:47 --> Total execution time: 0.4424
DEBUG - 2022-11-14 06:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:42:50 --> Total execution time: 0.1937
DEBUG - 2022-11-14 06:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:43:13 --> Total execution time: 0.1657
DEBUG - 2022-11-14 06:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:43:14 --> Total execution time: 0.1950
DEBUG - 2022-11-14 06:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:13:17 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:43:17 --> Total execution time: 0.1773
DEBUG - 2022-11-14 06:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:13:18 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:43:18 --> Total execution time: 0.1695
DEBUG - 2022-11-14 06:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:43:22 --> Total execution time: 0.1755
DEBUG - 2022-11-14 06:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:43:25 --> Total execution time: 0.1764
DEBUG - 2022-11-14 06:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:43:33 --> Total execution time: 0.1735
DEBUG - 2022-11-14 06:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:43:40 --> Total execution time: 0.1776
DEBUG - 2022-11-14 06:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:43:42 --> Total execution time: 0.4488
DEBUG - 2022-11-14 06:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:43:46 --> Total execution time: 0.2180
DEBUG - 2022-11-14 06:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:43:51 --> Total execution time: 0.1752
DEBUG - 2022-11-14 06:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:14:13 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:44:13 --> Total execution time: 0.1932
DEBUG - 2022-11-14 06:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:44:18 --> Total execution time: 0.1770
DEBUG - 2022-11-14 06:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:44:21 --> Total execution time: 0.1783
DEBUG - 2022-11-14 06:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:14:29 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:44:29 --> Total execution time: 0.1732
DEBUG - 2022-11-14 06:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:14:53 --> Total execution time: 0.1799
DEBUG - 2022-11-14 06:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:14:55 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:44:56 --> Total execution time: 0.4685
DEBUG - 2022-11-14 06:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:14:56 --> Total execution time: 0.1820
DEBUG - 2022-11-14 06:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:14:57 --> Total execution time: 0.1673
DEBUG - 2022-11-14 06:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:20 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:45:20 --> Total execution time: 0.1318
DEBUG - 2022-11-14 06:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:20 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:45:20 --> Total execution time: 0.1230
DEBUG - 2022-11-14 06:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:22 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:45:22 --> Total execution time: 0.1089
DEBUG - 2022-11-14 06:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:24 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:45:24 --> Total execution time: 0.1730
DEBUG - 2022-11-14 06:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:45:25 --> Total execution time: 0.2060
DEBUG - 2022-11-14 06:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:26 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:45:26 --> Total execution time: 0.1901
DEBUG - 2022-11-14 06:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:34 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:45:34 --> Total execution time: 0.1715
DEBUG - 2022-11-14 06:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:45:34 --> Total execution time: 0.2065
DEBUG - 2022-11-14 06:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:45:41 --> Total execution time: 0.1307
DEBUG - 2022-11-14 06:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 06:15:43 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-11-14 06:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 06:15:43 --> 404 Page Not Found: Sitemap_1xml/index
DEBUG - 2022-11-14 06:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:45:51 --> Total execution time: 0.1686
DEBUG - 2022-11-14 06:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:45:51 --> Total execution time: 0.1766
DEBUG - 2022-11-14 06:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:45:55 --> Total execution time: 0.1612
DEBUG - 2022-11-14 06:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:46:04 --> Total execution time: 0.1877
DEBUG - 2022-11-14 06:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:16:08 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:46:08 --> Total execution time: 0.1115
DEBUG - 2022-11-14 06:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:46:10 --> Total execution time: 0.1725
DEBUG - 2022-11-14 06:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:46:15 --> Total execution time: 0.2069
DEBUG - 2022-11-14 06:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:46:17 --> Total execution time: 0.2143
DEBUG - 2022-11-14 06:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:16:29 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:46:30 --> Total execution time: 0.1700
DEBUG - 2022-11-14 06:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:16:49 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:46:49 --> Total execution time: 0.1106
DEBUG - 2022-11-14 17:46:49 --> Total execution time: 1.7682
DEBUG - 2022-11-14 06:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:46:50 --> Total execution time: 0.1755
DEBUG - 2022-11-14 06:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 06:16:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 06:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:46:57 --> Total execution time: 0.1732
DEBUG - 2022-11-14 06:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:47:14 --> Total execution time: 0.1793
DEBUG - 2022-11-14 06:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:17:25 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:47:25 --> Total execution time: 0.1134
DEBUG - 2022-11-14 06:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:47:36 --> Total execution time: 0.1695
DEBUG - 2022-11-14 06:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:48:32 --> Total execution time: 0.4517
DEBUG - 2022-11-14 06:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:49:23 --> Total execution time: 0.1837
DEBUG - 2022-11-14 06:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:49:28 --> Total execution time: 0.1911
DEBUG - 2022-11-14 06:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:49:42 --> Total execution time: 0.1755
DEBUG - 2022-11-14 06:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:49:53 --> Total execution time: 0.2313
DEBUG - 2022-11-14 06:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 06:21:46 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-14 06:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:22:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 06:22:03 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-14 06:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:23:37 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:53:38 --> Total execution time: 1.2994
DEBUG - 2022-11-14 06:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:24:35 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:54:36 --> Total execution time: 0.1272
DEBUG - 2022-11-14 06:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:55:07 --> Total execution time: 0.1741
DEBUG - 2022-11-14 06:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:55:15 --> Total execution time: 0.1784
DEBUG - 2022-11-14 06:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:55:33 --> Total execution time: 0.1763
DEBUG - 2022-11-14 06:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:55:37 --> Total execution time: 0.1694
DEBUG - 2022-11-14 06:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:55:53 --> Total execution time: 0.1717
DEBUG - 2022-11-14 06:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:55:56 --> Total execution time: 0.1780
DEBUG - 2022-11-14 06:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:56:00 --> Total execution time: 0.1707
DEBUG - 2022-11-14 06:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:56:14 --> Total execution time: 0.1802
DEBUG - 2022-11-14 06:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:56:36 --> Total execution time: 0.1748
DEBUG - 2022-11-14 06:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:28:50 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:58:50 --> Total execution time: 0.1675
DEBUG - 2022-11-14 06:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:58:57 --> Total execution time: 0.1745
DEBUG - 2022-11-14 06:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:29:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 06:29:07 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-11-14 06:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:59:13 --> Total execution time: 0.2131
DEBUG - 2022-11-14 06:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:59:14 --> Total execution time: 0.1135
DEBUG - 2022-11-14 06:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:59:19 --> Total execution time: 0.1740
DEBUG - 2022-11-14 06:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:59:24 --> Total execution time: 0.1964
DEBUG - 2022-11-14 06:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:59:25 --> Total execution time: 0.2591
DEBUG - 2022-11-14 06:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:59:33 --> Total execution time: 0.1738
DEBUG - 2022-11-14 06:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:59:40 --> Total execution time: 0.1720
DEBUG - 2022-11-14 06:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:59:45 --> Total execution time: 0.3057
DEBUG - 2022-11-14 06:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:59:49 --> Total execution time: 0.1929
DEBUG - 2022-11-14 06:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:59:50 --> Total execution time: 0.2228
DEBUG - 2022-11-14 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:59:57 --> Total execution time: 0.1847
DEBUG - 2022-11-14 06:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:00:01 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 06:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:00:02 --> Total execution time: 0.2042
DEBUG - 2022-11-14 06:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:00:02 --> Total execution time: 0.1790
DEBUG - 2022-11-14 06:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:01:06 --> Total execution time: 0.1680
DEBUG - 2022-11-14 06:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:31:29 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:01:29 --> Total execution time: 0.4557
DEBUG - 2022-11-14 06:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:31:30 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:01:30 --> Total execution time: 0.1721
DEBUG - 2022-11-14 06:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:31:41 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:01:41 --> Total execution time: 0.1137
DEBUG - 2022-11-14 06:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:01:42 --> Total execution time: 0.1814
DEBUG - 2022-11-14 06:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:01:46 --> Total execution time: 0.2029
DEBUG - 2022-11-14 06:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:01:47 --> Total execution time: 0.2898
DEBUG - 2022-11-14 06:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:01:51 --> Total execution time: 0.1820
DEBUG - 2022-11-14 06:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:01:55 --> Total execution time: 0.1831
DEBUG - 2022-11-14 06:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:02:06 --> Total execution time: 0.1818
DEBUG - 2022-11-14 06:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:02:17 --> Total execution time: 0.1715
DEBUG - 2022-11-14 06:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:02:22 --> Total execution time: 0.2464
DEBUG - 2022-11-14 06:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:03:59 --> Total execution time: 0.8064
DEBUG - 2022-11-14 06:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:04:05 --> Total execution time: 0.2209
DEBUG - 2022-11-14 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:04:08 --> Total execution time: 0.2095
DEBUG - 2022-11-14 06:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:04:32 --> Total execution time: 0.2166
DEBUG - 2022-11-14 06:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:34:42 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:04:43 --> Total execution time: 0.4594
DEBUG - 2022-11-14 06:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:04:52 --> Total execution time: 0.2287
DEBUG - 2022-11-14 06:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:04:57 --> Total execution time: 0.1807
DEBUG - 2022-11-14 06:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:35:04 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:05:04 --> Total execution time: 0.1233
DEBUG - 2022-11-14 06:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:05:31 --> Total execution time: 0.1276
DEBUG - 2022-11-14 06:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:05:32 --> Total execution time: 0.1680
DEBUG - 2022-11-14 06:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:36:34 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:06:34 --> Total execution time: 0.1734
DEBUG - 2022-11-14 06:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:06:46 --> Total execution time: 2.2369
DEBUG - 2022-11-14 06:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:36:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 06:36:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 06:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:36:57 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:06:57 --> Total execution time: 0.1236
DEBUG - 2022-11-14 06:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:07:06 --> Total execution time: 0.1118
DEBUG - 2022-11-14 06:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:07:09 --> Total execution time: 0.1775
DEBUG - 2022-11-14 06:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:37:14 --> Total execution time: 0.1782
DEBUG - 2022-11-14 06:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:07:14 --> Total execution time: 0.4750
DEBUG - 2022-11-14 06:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:07:15 --> Total execution time: 0.2015
DEBUG - 2022-11-14 06:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:07:17 --> Total execution time: 0.1765
DEBUG - 2022-11-14 06:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:07:18 --> Total execution time: 0.1868
DEBUG - 2022-11-14 06:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:07:24 --> Total execution time: 0.2181
DEBUG - 2022-11-14 06:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:07:39 --> Total execution time: 0.1871
DEBUG - 2022-11-14 06:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:07:43 --> Total execution time: 0.1843
DEBUG - 2022-11-14 06:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:07:54 --> Total execution time: 0.1957
DEBUG - 2022-11-14 06:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:07:57 --> Total execution time: 0.1760
DEBUG - 2022-11-14 06:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:07:59 --> Total execution time: 0.1707
DEBUG - 2022-11-14 06:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:08:04 --> Total execution time: 0.1949
DEBUG - 2022-11-14 06:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:08:22 --> Total execution time: 0.2110
DEBUG - 2022-11-14 06:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:11:15 --> Total execution time: 0.1103
DEBUG - 2022-11-14 06:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:11:28 --> Total execution time: 0.1800
DEBUG - 2022-11-14 06:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:11:49 --> Total execution time: 0.1909
DEBUG - 2022-11-14 06:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:12:00 --> Total execution time: 0.1892
DEBUG - 2022-11-14 06:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:12:52 --> Total execution time: 0.1696
DEBUG - 2022-11-14 06:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:13:49 --> Total execution time: 0.1167
DEBUG - 2022-11-14 06:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:44:35 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:14:35 --> Total execution time: 0.1146
DEBUG - 2022-11-14 06:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:44:48 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:14:48 --> Total execution time: 0.1692
DEBUG - 2022-11-14 06:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:14:49 --> Total execution time: 0.1658
DEBUG - 2022-11-14 06:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:14:58 --> Total execution time: 0.1723
DEBUG - 2022-11-14 06:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:14:59 --> Total execution time: 0.4700
DEBUG - 2022-11-14 06:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:15:01 --> Total execution time: 0.2397
DEBUG - 2022-11-14 06:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:15:02 --> Total execution time: 0.1768
DEBUG - 2022-11-14 06:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:15:08 --> Total execution time: 0.1682
DEBUG - 2022-11-14 06:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:15:18 --> Total execution time: 0.1969
DEBUG - 2022-11-14 06:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:45:22 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:15:22 --> Total execution time: 0.2520
DEBUG - 2022-11-14 06:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:15:24 --> Total execution time: 0.1798
DEBUG - 2022-11-14 06:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:15:29 --> Total execution time: 0.2066
DEBUG - 2022-11-14 06:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:15:57 --> Total execution time: 0.2874
DEBUG - 2022-11-14 06:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:16:07 --> Total execution time: 2.1385
DEBUG - 2022-11-14 06:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:46:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 06:46:08 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 06:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:16:32 --> Total execution time: 0.2177
DEBUG - 2022-11-14 06:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:16:37 --> Total execution time: 0.5215
DEBUG - 2022-11-14 06:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:16:46 --> Total execution time: 0.1845
DEBUG - 2022-11-14 06:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:46:51 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:16:51 --> Total execution time: 0.1716
DEBUG - 2022-11-14 06:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:46:52 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:16:52 --> Total execution time: 0.1788
DEBUG - 2022-11-14 06:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:16:52 --> Total execution time: 0.2451
DEBUG - 2022-11-14 06:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:16:55 --> Total execution time: 0.1800
DEBUG - 2022-11-14 06:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:17:07 --> Total execution time: 0.1805
DEBUG - 2022-11-14 06:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:17:20 --> Total execution time: 0.1628
DEBUG - 2022-11-14 06:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:17:23 --> Total execution time: 0.1616
DEBUG - 2022-11-14 06:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:17:34 --> Total execution time: 0.1829
DEBUG - 2022-11-14 06:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:17:39 --> Total execution time: 0.1880
DEBUG - 2022-11-14 06:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:17:41 --> Total execution time: 0.1795
DEBUG - 2022-11-14 06:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:17:41 --> Total execution time: 0.1909
DEBUG - 2022-11-14 06:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:17:42 --> Total execution time: 0.2349
DEBUG - 2022-11-14 06:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:17:46 --> Total execution time: 0.1943
DEBUG - 2022-11-14 06:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:17:48 --> Total execution time: 0.1786
DEBUG - 2022-11-14 06:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:17:51 --> Total execution time: 0.2064
DEBUG - 2022-11-14 06:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:17:52 --> Total execution time: 0.1944
DEBUG - 2022-11-14 06:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:17:55 --> Total execution time: 0.1845
DEBUG - 2022-11-14 06:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:48:33 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:18:33 --> Total execution time: 0.1864
DEBUG - 2022-11-14 06:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:48:46 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:18:46 --> Total execution time: 0.1737
DEBUG - 2022-11-14 06:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:18:50 --> Total execution time: 0.1717
DEBUG - 2022-11-14 06:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:19:13 --> Total execution time: 0.1714
DEBUG - 2022-11-14 06:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:19:47 --> Total execution time: 1.8286
DEBUG - 2022-11-14 06:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:19:49 --> Total execution time: 0.1662
DEBUG - 2022-11-14 06:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:20:04 --> Total execution time: 0.1692
DEBUG - 2022-11-14 06:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:20:22 --> Total execution time: 0.4470
DEBUG - 2022-11-14 06:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:20:31 --> Total execution time: 0.1731
DEBUG - 2022-11-14 06:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:20:39 --> Total execution time: 0.1941
DEBUG - 2022-11-14 06:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:20:41 --> Total execution time: 0.1982
DEBUG - 2022-11-14 06:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:20:43 --> Total execution time: 0.4504
DEBUG - 2022-11-14 06:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:21:43 --> Total execution time: 0.1680
DEBUG - 2022-11-14 06:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:21:46 --> Total execution time: 0.1767
DEBUG - 2022-11-14 06:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:21:49 --> Total execution time: 0.1829
DEBUG - 2022-11-14 06:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:22:02 --> Total execution time: 0.2573
DEBUG - 2022-11-14 06:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:22:10 --> Total execution time: 0.1819
DEBUG - 2022-11-14 06:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:22:24 --> Total execution time: 0.2114
DEBUG - 2022-11-14 06:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:52:31 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:22:31 --> Total execution time: 0.1856
DEBUG - 2022-11-14 06:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:52:32 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:22:32 --> Total execution time: 0.1708
DEBUG - 2022-11-14 06:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:52:51 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:22:52 --> Total execution time: 0.2207
DEBUG - 2022-11-14 06:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:22:56 --> Total execution time: 0.1850
DEBUG - 2022-11-14 06:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:23:15 --> Total execution time: 0.4530
DEBUG - 2022-11-14 06:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:23:16 --> Total execution time: 0.1885
DEBUG - 2022-11-14 06:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:23:20 --> Total execution time: 0.1760
DEBUG - 2022-11-14 06:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:23:32 --> Total execution time: 0.1734
DEBUG - 2022-11-14 06:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:23:43 --> Total execution time: 0.1947
DEBUG - 2022-11-14 06:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:23:56 --> Total execution time: 0.2425
DEBUG - 2022-11-14 06:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:53:58 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:23:58 --> Total execution time: 0.4715
DEBUG - 2022-11-14 06:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:24:00 --> Total execution time: 0.1707
DEBUG - 2022-11-14 06:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:24:02 --> Total execution time: 0.1815
DEBUG - 2022-11-14 06:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:24:04 --> Total execution time: 0.1774
DEBUG - 2022-11-14 06:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:24:09 --> Total execution time: 0.1794
DEBUG - 2022-11-14 06:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:24:15 --> Total execution time: 0.2498
DEBUG - 2022-11-14 06:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:24:20 --> Total execution time: 0.1871
DEBUG - 2022-11-14 06:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:24:27 --> Total execution time: 0.2055
DEBUG - 2022-11-14 06:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:24:28 --> Total execution time: 0.2776
DEBUG - 2022-11-14 06:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:24:28 --> Total execution time: 0.4260
DEBUG - 2022-11-14 06:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:24:28 --> Total execution time: 0.3906
DEBUG - 2022-11-14 06:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:24:33 --> Total execution time: 0.1733
DEBUG - 2022-11-14 06:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:24:39 --> Total execution time: 0.2201
DEBUG - 2022-11-14 06:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:24:46 --> Total execution time: 0.1805
DEBUG - 2022-11-14 06:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:25:13 --> Total execution time: 0.1762
DEBUG - 2022-11-14 06:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:25:16 --> Total execution time: 0.2159
DEBUG - 2022-11-14 06:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:25:17 --> Total execution time: 0.1984
DEBUG - 2022-11-14 06:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:25:21 --> Total execution time: 0.1858
DEBUG - 2022-11-14 06:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:25:27 --> Total execution time: 0.2242
DEBUG - 2022-11-14 06:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:25:27 --> Total execution time: 0.1243
DEBUG - 2022-11-14 06:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:25:30 --> Total execution time: 0.2371
DEBUG - 2022-11-14 06:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:25:34 --> Total execution time: 0.2142
DEBUG - 2022-11-14 06:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:25:37 --> Total execution time: 0.2133
DEBUG - 2022-11-14 06:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:25:45 --> Total execution time: 0.2459
DEBUG - 2022-11-14 06:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:25:55 --> Total execution time: 0.2115
DEBUG - 2022-11-14 06:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:26:14 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 06:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:26:15 --> Total execution time: 0.2543
DEBUG - 2022-11-14 06:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:56:42 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:26:42 --> Total execution time: 0.1111
DEBUG - 2022-11-14 06:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:26:43 --> Total execution time: 0.2109
DEBUG - 2022-11-14 06:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:26:44 --> Total execution time: 0.1935
DEBUG - 2022-11-14 06:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:26:47 --> Total execution time: 0.1971
DEBUG - 2022-11-14 06:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:26:47 --> Total execution time: 0.2649
DEBUG - 2022-11-14 06:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:56:47 --> Total execution time: 0.1490
DEBUG - 2022-11-14 06:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:26:47 --> Total execution time: 0.2952
DEBUG - 2022-11-14 06:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:26:48 --> Total execution time: 0.2349
DEBUG - 2022-11-14 06:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:26:50 --> Total execution time: 0.3324
DEBUG - 2022-11-14 06:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:56:52 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:26:53 --> Total execution time: 0.2222
DEBUG - 2022-11-14 06:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:27:12 --> Total execution time: 0.2023
DEBUG - 2022-11-14 06:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:27:12 --> Total execution time: 0.2456
DEBUG - 2022-11-14 06:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:27:12 --> Total execution time: 0.2144
DEBUG - 2022-11-14 06:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:27:13 --> Total execution time: 0.1924
DEBUG - 2022-11-14 06:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:57:13 --> No URI present. Default controller set.
DEBUG - 2022-11-14 06:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:27:13 --> Total execution time: 0.1802
DEBUG - 2022-11-14 06:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:57:29 --> Total execution time: 0.1830
DEBUG - 2022-11-14 06:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:57:35 --> Total execution time: 0.1830
DEBUG - 2022-11-14 06:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:27:49 --> Total execution time: 0.1738
DEBUG - 2022-11-14 06:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 06:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:28:09 --> Total execution time: 0.1859
DEBUG - 2022-11-14 06:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:28:21 --> Total execution time: 0.1945
DEBUG - 2022-11-14 06:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:28:23 --> Total execution time: 0.1665
DEBUG - 2022-11-14 06:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:28:31 --> Total execution time: 0.2055
DEBUG - 2022-11-14 06:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:28:33 --> Total execution time: 0.1676
DEBUG - 2022-11-14 06:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:28:45 --> Total execution time: 0.2025
DEBUG - 2022-11-14 06:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 06:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 06:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:28:54 --> Total execution time: 0.1737
DEBUG - 2022-11-14 07:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:30:02 --> Total execution time: 0.2001
DEBUG - 2022-11-14 07:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:00:25 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:30:25 --> Total execution time: 0.1810
DEBUG - 2022-11-14 07:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:00:41 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:30:41 --> Total execution time: 0.1691
DEBUG - 2022-11-14 07:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:31:07 --> Total execution time: 0.1679
DEBUG - 2022-11-14 07:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:31:29 --> Total execution time: 0.1802
DEBUG - 2022-11-14 07:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:31:36 --> Total execution time: 0.1954
DEBUG - 2022-11-14 07:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:31:41 --> Total execution time: 0.1958
DEBUG - 2022-11-14 07:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:31:52 --> Total execution time: 0.1744
DEBUG - 2022-11-14 07:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:31:53 --> Total execution time: 0.4680
DEBUG - 2022-11-14 07:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:35:14 --> Total execution time: 0.9668
DEBUG - 2022-11-14 07:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:35:20 --> Total execution time: 0.1972
DEBUG - 2022-11-14 07:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:35:47 --> Total execution time: 0.1794
DEBUG - 2022-11-14 07:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:06:15 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:36:15 --> Total execution time: 0.1143
DEBUG - 2022-11-14 07:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:36:28 --> Total execution time: 0.1763
DEBUG - 2022-11-14 07:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:36:37 --> Total execution time: 0.5029
DEBUG - 2022-11-14 07:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:36:45 --> Total execution time: 0.1868
DEBUG - 2022-11-14 07:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:36:55 --> Total execution time: 0.1886
DEBUG - 2022-11-14 07:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:37:01 --> Total execution time: 0.1758
DEBUG - 2022-11-14 07:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:37:27 --> Total execution time: 0.1699
DEBUG - 2022-11-14 07:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:38:17 --> Total execution time: 0.1065
DEBUG - 2022-11-14 07:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:38:40 --> Total execution time: 0.4859
DEBUG - 2022-11-14 07:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:39:21 --> Total execution time: 0.1700
DEBUG - 2022-11-14 07:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:40:31 --> Total execution time: 0.4683
DEBUG - 2022-11-14 07:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:41:05 --> Total execution time: 0.1795
DEBUG - 2022-11-14 07:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:11:07 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:41:07 --> Total execution time: 0.4492
DEBUG - 2022-11-14 07:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:41:17 --> Total execution time: 0.1780
DEBUG - 2022-11-14 07:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:41:31 --> Total execution time: 0.1796
DEBUG - 2022-11-14 07:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:41:32 --> Total execution time: 0.1915
DEBUG - 2022-11-14 07:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:41:36 --> Total execution time: 0.1835
DEBUG - 2022-11-14 07:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:11:46 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:41:46 --> Total execution time: 0.4607
DEBUG - 2022-11-14 07:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:41:46 --> Total execution time: 0.1822
DEBUG - 2022-11-14 07:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:41:48 --> Total execution time: 0.1697
DEBUG - 2022-11-14 07:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:11:58 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:41:59 --> Total execution time: 0.1837
DEBUG - 2022-11-14 07:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:12:00 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:42:00 --> Total execution time: 0.1822
DEBUG - 2022-11-14 07:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:12:18 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:42:18 --> Total execution time: 0.1908
DEBUG - 2022-11-14 07:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:42:46 --> Total execution time: 0.1701
DEBUG - 2022-11-14 07:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:42:52 --> Total execution time: 0.1794
DEBUG - 2022-11-14 07:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:43:03 --> Total execution time: 0.1742
DEBUG - 2022-11-14 07:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:43:10 --> Total execution time: 0.2385
DEBUG - 2022-11-14 07:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:43:20 --> Total execution time: 0.2172
DEBUG - 2022-11-14 07:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:14:09 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:44:09 --> Total execution time: 0.1661
DEBUG - 2022-11-14 07:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:14:16 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:44:16 --> Total execution time: 0.1735
DEBUG - 2022-11-14 07:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:16:07 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:46:08 --> Total execution time: 0.1199
DEBUG - 2022-11-14 07:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 07:16:08 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 07:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:46:19 --> Total execution time: 0.1746
DEBUG - 2022-11-14 07:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:46:26 --> Total execution time: 0.1752
DEBUG - 2022-11-14 07:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:46:30 --> Total execution time: 0.1788
DEBUG - 2022-11-14 07:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:46:39 --> Total execution time: 0.1718
DEBUG - 2022-11-14 07:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:46:50 --> Total execution time: 0.1677
DEBUG - 2022-11-14 07:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:47:39 --> Total execution time: 0.2099
DEBUG - 2022-11-14 07:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:47:50 --> Total execution time: 0.2191
DEBUG - 2022-11-14 07:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:47:59 --> Total execution time: 0.1733
DEBUG - 2022-11-14 07:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:48:34 --> Total execution time: 0.1687
DEBUG - 2022-11-14 07:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:21:41 --> Total execution time: 0.1872
DEBUG - 2022-11-14 07:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:51:46 --> Total execution time: 0.1859
DEBUG - 2022-11-14 07:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:51:50 --> Total execution time: 0.3043
DEBUG - 2022-11-14 07:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:51:52 --> Total execution time: 0.2287
DEBUG - 2022-11-14 07:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:21:54 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:51:54 --> Total execution time: 0.1145
DEBUG - 2022-11-14 07:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:52:02 --> Total execution time: 0.2818
DEBUG - 2022-11-14 07:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:52:18 --> Total execution time: 0.2290
DEBUG - 2022-11-14 07:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:52:32 --> Total execution time: 0.2115
DEBUG - 2022-11-14 07:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:52:38 --> Total execution time: 0.1663
DEBUG - 2022-11-14 07:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:23:12 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:53:12 --> Total execution time: 0.1084
DEBUG - 2022-11-14 07:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:23:13 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:53:13 --> Total execution time: 0.1133
DEBUG - 2022-11-14 07:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:54:19 --> Total execution time: 0.3031
DEBUG - 2022-11-14 07:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:56:15 --> Total execution time: 0.1667
DEBUG - 2022-11-14 07:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:56:36 --> Total execution time: 0.1859
DEBUG - 2022-11-14 07:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:56:36 --> Total execution time: 0.2399
DEBUG - 2022-11-14 07:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:56:40 --> Total execution time: 0.2988
DEBUG - 2022-11-14 07:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:57:01 --> Total execution time: 0.5758
DEBUG - 2022-11-14 07:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:57:25 --> Total execution time: 0.4559
DEBUG - 2022-11-14 07:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:27:29 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:57:29 --> Total execution time: 0.4486
DEBUG - 2022-11-14 07:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:57:30 --> Total execution time: 0.1100
DEBUG - 2022-11-14 07:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:57:46 --> Total execution time: 0.2137
DEBUG - 2022-11-14 07:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:57:55 --> Total execution time: 0.2347
DEBUG - 2022-11-14 07:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:28:04 --> Total execution time: 0.1710
DEBUG - 2022-11-14 07:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:58:04 --> Total execution time: 0.1765
DEBUG - 2022-11-14 07:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:58:10 --> Total execution time: 0.2512
DEBUG - 2022-11-14 07:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:58:13 --> Total execution time: 0.1838
DEBUG - 2022-11-14 07:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:58:14 --> Total execution time: 0.2333
DEBUG - 2022-11-14 07:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:58:15 --> Total execution time: 0.1948
DEBUG - 2022-11-14 07:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:58:24 --> Total execution time: 0.2160
DEBUG - 2022-11-14 07:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:58:40 --> Total execution time: 0.1685
DEBUG - 2022-11-14 07:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:58:42 --> Total execution time: 0.3726
DEBUG - 2022-11-14 07:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:58:48 --> Total execution time: 0.1839
DEBUG - 2022-11-14 07:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:58:56 --> Total execution time: 0.1717
DEBUG - 2022-11-14 07:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:59:14 --> Total execution time: 0.1683
DEBUG - 2022-11-14 07:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:00:26 --> Total execution time: 0.1677
DEBUG - 2022-11-14 07:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:01:05 --> Total execution time: 0.1812
DEBUG - 2022-11-14 07:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:01:11 --> Total execution time: 0.1821
DEBUG - 2022-11-14 07:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:01:27 --> Total execution time: 0.1694
DEBUG - 2022-11-14 07:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:31:29 --> Total execution time: 0.1661
DEBUG - 2022-11-14 07:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:31:31 --> Total execution time: 0.1789
DEBUG - 2022-11-14 07:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:01:39 --> Total execution time: 0.2863
DEBUG - 2022-11-14 07:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:01:41 --> Total execution time: 0.2373
DEBUG - 2022-11-14 07:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:31:43 --> Total execution time: 0.1627
DEBUG - 2022-11-14 07:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:01:46 --> Total execution time: 0.2149
DEBUG - 2022-11-14 07:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:01:47 --> Total execution time: 0.2149
DEBUG - 2022-11-14 07:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:01:47 --> Total execution time: 0.2018
DEBUG - 2022-11-14 07:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:01:48 --> Total execution time: 0.2096
DEBUG - 2022-11-14 07:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:01:48 --> Total execution time: 0.2148
DEBUG - 2022-11-14 07:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:01:54 --> Total execution time: 0.7230
DEBUG - 2022-11-14 07:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:32:00 --> Total execution time: 0.1655
DEBUG - 2022-11-14 07:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:32:03 --> Total execution time: 0.1883
DEBUG - 2022-11-14 07:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:32:06 --> Total execution time: 0.2331
DEBUG - 2022-11-14 07:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:02:10 --> Total execution time: 0.1992
DEBUG - 2022-11-14 07:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:02:28 --> Total execution time: 1.6331
DEBUG - 2022-11-14 07:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:32:44 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:02:44 --> Total execution time: 0.1287
DEBUG - 2022-11-14 07:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:03:41 --> Total execution time: 2.8250
DEBUG - 2022-11-14 07:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:03:52 --> Total execution time: 0.1743
DEBUG - 2022-11-14 07:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:03:55 --> Total execution time: 0.1249
DEBUG - 2022-11-14 07:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:03:56 --> Total execution time: 0.1726
DEBUG - 2022-11-14 07:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:04:01 --> Total execution time: 0.3050
DEBUG - 2022-11-14 07:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:04:05 --> Total execution time: 0.1763
DEBUG - 2022-11-14 07:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:04:12 --> Total execution time: 0.1764
DEBUG - 2022-11-14 07:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:04:26 --> Total execution time: 0.1819
DEBUG - 2022-11-14 07:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:04:33 --> Total execution time: 0.1719
DEBUG - 2022-11-14 07:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:04:39 --> Total execution time: 0.1865
DEBUG - 2022-11-14 07:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:04:55 --> Total execution time: 0.1069
DEBUG - 2022-11-14 07:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:05:05 --> Total execution time: 0.1712
DEBUG - 2022-11-14 07:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:05:12 --> Total execution time: 0.1852
DEBUG - 2022-11-14 07:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:05:13 --> Total execution time: 0.1857
DEBUG - 2022-11-14 07:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:05:17 --> Total execution time: 0.2637
DEBUG - 2022-11-14 07:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:05:28 --> Total execution time: 2.0098
DEBUG - 2022-11-14 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:05:29 --> Total execution time: 0.2604
DEBUG - 2022-11-14 07:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:05:35 --> Total execution time: 0.2054
DEBUG - 2022-11-14 07:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:05:39 --> Total execution time: 0.1810
DEBUG - 2022-11-14 07:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:05:50 --> Total execution time: 0.2045
DEBUG - 2022-11-14 07:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:05:54 --> Total execution time: 0.1801
DEBUG - 2022-11-14 07:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:05:55 --> Total execution time: 0.1766
DEBUG - 2022-11-14 07:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:03 --> Total execution time: 0.2149
DEBUG - 2022-11-14 07:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:23 --> Total execution time: 0.1759
DEBUG - 2022-11-14 07:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:30 --> Total execution time: 0.1810
DEBUG - 2022-11-14 07:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:31 --> Total execution time: 0.1853
DEBUG - 2022-11-14 07:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:49 --> Total execution time: 0.1766
DEBUG - 2022-11-14 07:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:07:03 --> Total execution time: 0.1833
DEBUG - 2022-11-14 07:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:37:03 --> Total execution time: 0.1052
DEBUG - 2022-11-14 07:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:38:52 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:08:54 --> Total execution time: 1.8217
DEBUG - 2022-11-14 07:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:08:56 --> Total execution time: 0.2354
DEBUG - 2022-11-14 07:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:09:05 --> Total execution time: 0.1949
DEBUG - 2022-11-14 07:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:09:07 --> Total execution time: 0.2164
DEBUG - 2022-11-14 07:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:12 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:09:12 --> Total execution time: 0.6253
DEBUG - 2022-11-14 07:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:09:14 --> Total execution time: 0.4047
DEBUG - 2022-11-14 07:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:09:18 --> Total execution time: 0.1856
DEBUG - 2022-11-14 07:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:09:23 --> Total execution time: 0.1793
DEBUG - 2022-11-14 07:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:09:28 --> Total execution time: 0.1908
DEBUG - 2022-11-14 07:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:09:30 --> Total execution time: 0.3807
DEBUG - 2022-11-14 07:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:09:32 --> Total execution time: 0.1806
DEBUG - 2022-11-14 07:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:33 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:09:34 --> Total execution time: 0.1726
DEBUG - 2022-11-14 07:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:35 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:09:35 --> Total execution time: 0.1921
DEBUG - 2022-11-14 07:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:49 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:09:49 --> Total execution time: 0.1125
DEBUG - 2022-11-14 07:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:09:56 --> Total execution time: 0.1668
DEBUG - 2022-11-14 07:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:10:04 --> Total execution time: 0.1688
DEBUG - 2022-11-14 07:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:10:10 --> Total execution time: 0.1877
DEBUG - 2022-11-14 07:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:10:13 --> Total execution time: 0.1737
DEBUG - 2022-11-14 07:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:10:28 --> Total execution time: 0.1731
DEBUG - 2022-11-14 07:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:10:28 --> Total execution time: 0.1839
DEBUG - 2022-11-14 07:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:10:28 --> Total execution time: 0.2652
DEBUG - 2022-11-14 07:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:10:29 --> Total execution time: 0.2136
DEBUG - 2022-11-14 07:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:10:38 --> Total execution time: 0.2123
DEBUG - 2022-11-14 07:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:10:40 --> Total execution time: 0.6166
DEBUG - 2022-11-14 07:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:10:52 --> Total execution time: 0.1679
DEBUG - 2022-11-14 07:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:11:02 --> Total execution time: 0.1827
DEBUG - 2022-11-14 07:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:11:05 --> Total execution time: 0.1724
DEBUG - 2022-11-14 07:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:41:07 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:11:07 --> Total execution time: 0.1082
DEBUG - 2022-11-14 07:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:41:09 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:11:09 --> Total execution time: 0.1702
DEBUG - 2022-11-14 07:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:41:20 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:11:20 --> Total execution time: 0.1775
DEBUG - 2022-11-14 07:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:41:30 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:11:30 --> Total execution time: 0.1164
DEBUG - 2022-11-14 07:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:43:47 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:13:48 --> Total execution time: 0.1756
DEBUG - 2022-11-14 07:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:13:54 --> Total execution time: 0.5278
DEBUG - 2022-11-14 07:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:13:55 --> Total execution time: 0.1798
DEBUG - 2022-11-14 07:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:14:02 --> Total execution time: 0.2828
DEBUG - 2022-11-14 07:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:14:33 --> Total execution time: 2.6895
DEBUG - 2022-11-14 07:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:46:27 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:16:28 --> Total execution time: 0.1503
DEBUG - 2022-11-14 07:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:46:28 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:16:28 --> Total execution time: 0.1187
DEBUG - 2022-11-14 07:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:17:41 --> Total execution time: 0.6285
DEBUG - 2022-11-14 07:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:17:54 --> Total execution time: 0.1753
DEBUG - 2022-11-14 07:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:18:38 --> Total execution time: 0.2274
DEBUG - 2022-11-14 07:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:18:54 --> Total execution time: 0.1684
DEBUG - 2022-11-14 07:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:49:09 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:19:09 --> Total execution time: 0.1259
DEBUG - 2022-11-14 07:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:49:14 --> Total execution time: 0.1712
DEBUG - 2022-11-14 07:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:49:16 --> Total execution time: 0.1665
DEBUG - 2022-11-14 07:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:49:16 --> Total execution time: 0.2108
DEBUG - 2022-11-14 07:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:20:10 --> Total execution time: 1.7893
DEBUG - 2022-11-14 07:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:50:12 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:20:12 --> Total execution time: 0.1171
DEBUG - 2022-11-14 07:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:20:20 --> Total execution time: 0.1681
DEBUG - 2022-11-14 07:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:50:50 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:20:50 --> Total execution time: 0.1238
DEBUG - 2022-11-14 07:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:21:25 --> Total execution time: 0.2016
DEBUG - 2022-11-14 07:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:51:28 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:21:28 --> Total execution time: 0.1152
DEBUG - 2022-11-14 07:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:51:28 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:21:29 --> Total execution time: 0.4471
DEBUG - 2022-11-14 07:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:21:38 --> Total execution time: 1.8863
DEBUG - 2022-11-14 07:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:21:41 --> Total execution time: 0.2036
DEBUG - 2022-11-14 07:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:22:24 --> Total execution time: 0.1912
DEBUG - 2022-11-14 07:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:22:33 --> Total execution time: 0.2013
DEBUG - 2022-11-14 07:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:22:44 --> Total execution time: 0.3942
DEBUG - 2022-11-14 07:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:53:07 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:23:07 --> Total execution time: 0.1114
DEBUG - 2022-11-14 07:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:23:08 --> Total execution time: 0.1595
DEBUG - 2022-11-14 07:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:23:19 --> Total execution time: 0.1757
DEBUG - 2022-11-14 07:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:23:23 --> Total execution time: 0.4556
DEBUG - 2022-11-14 07:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:23:28 --> Total execution time: 0.2107
DEBUG - 2022-11-14 07:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:23:34 --> Total execution time: 0.1943
DEBUG - 2022-11-14 07:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:23:34 --> Total execution time: 0.3520
DEBUG - 2022-11-14 07:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:23:40 --> Total execution time: 0.1739
DEBUG - 2022-11-14 07:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:23:41 --> Total execution time: 0.1799
DEBUG - 2022-11-14 07:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:23:45 --> Total execution time: 0.1758
DEBUG - 2022-11-14 07:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:23:52 --> Total execution time: 0.1798
DEBUG - 2022-11-14 07:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:24:00 --> Total execution time: 0.1827
DEBUG - 2022-11-14 07:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:54:36 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:24:36 --> Total execution time: 0.1098
DEBUG - 2022-11-14 07:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:25:09 --> Total execution time: 0.1850
DEBUG - 2022-11-14 07:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:25:14 --> Total execution time: 0.2176
DEBUG - 2022-11-14 07:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:25:20 --> Total execution time: 0.2056
DEBUG - 2022-11-14 07:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:25:21 --> Total execution time: 0.2073
DEBUG - 2022-11-14 07:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:55:56 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:25:56 --> Total execution time: 0.1140
DEBUG - 2022-11-14 07:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:26:14 --> Total execution time: 0.1757
DEBUG - 2022-11-14 07:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:26:32 --> Total execution time: 0.1770
DEBUG - 2022-11-14 07:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:26:39 --> Total execution time: 0.2068
DEBUG - 2022-11-14 07:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:26:40 --> Total execution time: 0.2031
DEBUG - 2022-11-14 07:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:26:46 --> Total execution time: 0.1719
DEBUG - 2022-11-14 07:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:26:49 --> Total execution time: 0.2029
DEBUG - 2022-11-14 07:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:27:04 --> Total execution time: 0.1723
DEBUG - 2022-11-14 07:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:27:12 --> Total execution time: 0.2049
DEBUG - 2022-11-14 07:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:57:12 --> Total execution time: 0.1689
DEBUG - 2022-11-14 07:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:27:17 --> Total execution time: 0.2184
DEBUG - 2022-11-14 07:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:27:51 --> Total execution time: 0.4731
DEBUG - 2022-11-14 07:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:27:54 --> Total execution time: 0.1723
DEBUG - 2022-11-14 07:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:58:10 --> No URI present. Default controller set.
DEBUG - 2022-11-14 07:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:28:11 --> Total execution time: 0.4435
DEBUG - 2022-11-14 07:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:28:17 --> Total execution time: 0.1820
DEBUG - 2022-11-14 07:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:28:27 --> Total execution time: 0.1761
DEBUG - 2022-11-14 07:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:28:27 --> Total execution time: 0.2895
DEBUG - 2022-11-14 07:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:28:27 --> Total execution time: 0.2780
DEBUG - 2022-11-14 07:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:28:46 --> Total execution time: 0.1722
DEBUG - 2022-11-14 07:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:29:39 --> Total execution time: 0.2118
DEBUG - 2022-11-14 07:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 07:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 07:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 07:59:52 --> Total execution time: 0.1659
DEBUG - 2022-11-14 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:30:02 --> Total execution time: 0.2224
DEBUG - 2022-11-14 08:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:00:05 --> Total execution time: 0.1823
DEBUG - 2022-11-14 08:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:00:14 --> Total execution time: 0.1686
DEBUG - 2022-11-14 08:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:00:18 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:30:18 --> Total execution time: 0.1184
DEBUG - 2022-11-14 08:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:00:20 --> Total execution time: 0.2033
DEBUG - 2022-11-14 08:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:00:22 --> Total execution time: 0.1717
DEBUG - 2022-11-14 08:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:30:25 --> Total execution time: 0.2090
DEBUG - 2022-11-14 08:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:30:31 --> Total execution time: 0.1726
DEBUG - 2022-11-14 08:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:30:51 --> Total execution time: 0.1984
DEBUG - 2022-11-14 08:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:30:52 --> Total execution time: 0.2118
DEBUG - 2022-11-14 08:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:01:08 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:31:08 --> Total execution time: 0.1113
DEBUG - 2022-11-14 08:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:31:16 --> Total execution time: 0.1896
DEBUG - 2022-11-14 08:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:31:17 --> Total execution time: 0.4553
DEBUG - 2022-11-14 08:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:31:29 --> Total execution time: 0.1899
DEBUG - 2022-11-14 08:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:31:34 --> Total execution time: 0.1662
DEBUG - 2022-11-14 08:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:01:41 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:31:41 --> Total execution time: 0.1064
DEBUG - 2022-11-14 08:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:03:43 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:33:43 --> Total execution time: 0.1102
DEBUG - 2022-11-14 08:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:36:24 --> Total execution time: 0.1087
DEBUG - 2022-11-14 08:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:36:45 --> Total execution time: 0.1817
DEBUG - 2022-11-14 08:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:36:50 --> Total execution time: 0.2622
DEBUG - 2022-11-14 08:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:37:48 --> Total execution time: 0.2432
DEBUG - 2022-11-14 08:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:39:15 --> Total execution time: 0.5101
DEBUG - 2022-11-14 08:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:09:24 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:39:24 --> Total execution time: 0.1127
DEBUG - 2022-11-14 08:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:39:29 --> Total execution time: 0.2405
DEBUG - 2022-11-14 08:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:39:33 --> Total execution time: 0.1822
DEBUG - 2022-11-14 08:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:39:40 --> Total execution time: 0.2182
DEBUG - 2022-11-14 08:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:39:43 --> Total execution time: 0.1729
DEBUG - 2022-11-14 08:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:10:57 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:40:57 --> Total execution time: 0.1078
DEBUG - 2022-11-14 08:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:42:04 --> Total execution time: 0.1709
DEBUG - 2022-11-14 08:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:45:58 --> Total execution time: 0.1836
DEBUG - 2022-11-14 08:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:46:10 --> Total execution time: 0.1918
DEBUG - 2022-11-14 08:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:46:12 --> Total execution time: 0.1735
DEBUG - 2022-11-14 08:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:46:19 --> Total execution time: 0.4570
DEBUG - 2022-11-14 08:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:46:21 --> Total execution time: 0.1742
DEBUG - 2022-11-14 08:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:46:26 --> Total execution time: 0.2321
DEBUG - 2022-11-14 08:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:16:49 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:46:50 --> Total execution time: 0.4048
DEBUG - 2022-11-14 08:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:46:50 --> Total execution time: 0.4673
DEBUG - 2022-11-14 08:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:48:54 --> Total execution time: 0.4517
DEBUG - 2022-11-14 08:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:19:07 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:49:07 --> Total execution time: 0.1111
DEBUG - 2022-11-14 08:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:49:24 --> Total execution time: 0.1143
DEBUG - 2022-11-14 08:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:50:28 --> Total execution time: 0.2176
DEBUG - 2022-11-14 08:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:50:37 --> Total execution time: 0.2618
DEBUG - 2022-11-14 08:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:20:53 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:50:53 --> Total execution time: 0.1421
DEBUG - 2022-11-14 08:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:50:59 --> Total execution time: 0.1804
DEBUG - 2022-11-14 08:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:51:02 --> Total execution time: 0.2172
DEBUG - 2022-11-14 08:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:51:08 --> Total execution time: 0.1917
DEBUG - 2022-11-14 08:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:51:09 --> Total execution time: 0.1816
DEBUG - 2022-11-14 08:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:51:15 --> Total execution time: 0.1818
DEBUG - 2022-11-14 08:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:51:20 --> Total execution time: 0.1900
DEBUG - 2022-11-14 08:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:51:20 --> Total execution time: 0.1760
DEBUG - 2022-11-14 08:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:51:33 --> Total execution time: 0.1721
DEBUG - 2022-11-14 08:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:21:39 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:51:39 --> Total execution time: 0.1075
DEBUG - 2022-11-14 08:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:52:18 --> Total execution time: 0.1735
DEBUG - 2022-11-14 08:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:54:12 --> Total execution time: 2.4218
DEBUG - 2022-11-14 08:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:24:19 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:54:19 --> Total execution time: 0.5118
DEBUG - 2022-11-14 08:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:24:34 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:54:34 --> Total execution time: 0.1088
DEBUG - 2022-11-14 08:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:24:51 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:54:51 --> Total execution time: 0.1749
DEBUG - 2022-11-14 08:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:54:56 --> Total execution time: 0.4595
DEBUG - 2022-11-14 08:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:25:00 --> Total execution time: 0.1772
DEBUG - 2022-11-14 08:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:25:02 --> Total execution time: 0.2260
DEBUG - 2022-11-14 08:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:25:03 --> Total execution time: 0.1856
DEBUG - 2022-11-14 08:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:55:16 --> Total execution time: 0.1847
DEBUG - 2022-11-14 08:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:55:21 --> Total execution time: 0.4597
DEBUG - 2022-11-14 08:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:55:30 --> Total execution time: 0.1683
DEBUG - 2022-11-14 08:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:56:22 --> Total execution time: 0.1890
DEBUG - 2022-11-14 08:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:56:37 --> Total execution time: 0.1906
DEBUG - 2022-11-14 08:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:27:26 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:57:27 --> Total execution time: 0.1109
DEBUG - 2022-11-14 08:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:58:56 --> Total execution time: 0.1688
DEBUG - 2022-11-14 08:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:59:07 --> Total execution time: 2.0126
DEBUG - 2022-11-14 08:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 08:29:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 08:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:29:30 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:59:30 --> Total execution time: 0.1778
DEBUG - 2022-11-14 08:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:59:48 --> Total execution time: 0.1737
DEBUG - 2022-11-14 08:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:00:03 --> Total execution time: 0.2125
DEBUG - 2022-11-14 08:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:00:09 --> Total execution time: 0.1741
DEBUG - 2022-11-14 08:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:00:11 --> Total execution time: 0.1860
DEBUG - 2022-11-14 08:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:00:52 --> Total execution time: 0.1713
DEBUG - 2022-11-14 08:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:00:54 --> Total execution time: 0.1792
DEBUG - 2022-11-14 08:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:01:01 --> Total execution time: 0.2115
DEBUG - 2022-11-14 08:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:01:08 --> Total execution time: 0.1805
DEBUG - 2022-11-14 08:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:31:17 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:01:17 --> Total execution time: 0.1150
DEBUG - 2022-11-14 08:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:01:42 --> Total execution time: 0.2231
DEBUG - 2022-11-14 08:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:01:56 --> Total execution time: 0.1774
DEBUG - 2022-11-14 08:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:02:10 --> Total execution time: 0.1765
DEBUG - 2022-11-14 08:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:02:11 --> Total execution time: 0.4618
DEBUG - 2022-11-14 08:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:02:16 --> Total execution time: 0.2024
DEBUG - 2022-11-14 08:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:02:25 --> Total execution time: 0.2685
DEBUG - 2022-11-14 08:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:02:30 --> Total execution time: 0.1126
DEBUG - 2022-11-14 08:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:02:45 --> Total execution time: 0.1747
DEBUG - 2022-11-14 08:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:02:54 --> Total execution time: 0.2042
DEBUG - 2022-11-14 08:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:02:58 --> Total execution time: 0.2129
DEBUG - 2022-11-14 08:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:03:08 --> Total execution time: 0.1823
DEBUG - 2022-11-14 08:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:03:12 --> Total execution time: 0.2518
DEBUG - 2022-11-14 08:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:17 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:03:17 --> Total execution time: 0.1822
DEBUG - 2022-11-14 08:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:03:18 --> Total execution time: 0.1691
DEBUG - 2022-11-14 08:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:03:22 --> Total execution time: 0.1101
DEBUG - 2022-11-14 20:03:24 --> Total execution time: 2.2109
DEBUG - 2022-11-14 08:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 08:33:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 08:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:03:29 --> Total execution time: 0.1896
DEBUG - 2022-11-14 08:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:03:33 --> Total execution time: 0.2115
DEBUG - 2022-11-14 08:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:03:35 --> Total execution time: 0.2119
DEBUG - 2022-11-14 08:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:41 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:03:41 --> Total execution time: 0.1205
DEBUG - 2022-11-14 08:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:03:52 --> Total execution time: 0.1664
DEBUG - 2022-11-14 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:03:58 --> Total execution time: 0.1758
DEBUG - 2022-11-14 08:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:01 --> Total execution time: 0.2075
DEBUG - 2022-11-14 08:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:04 --> Total execution time: 0.2599
DEBUG - 2022-11-14 08:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:09 --> Total execution time: 0.2704
DEBUG - 2022-11-14 08:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:13 --> Total execution time: 0.1761
DEBUG - 2022-11-14 08:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:15 --> Total execution time: 0.3402
DEBUG - 2022-11-14 08:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:18 --> Total execution time: 0.1704
DEBUG - 2022-11-14 08:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:22 --> Total execution time: 0.2096
DEBUG - 2022-11-14 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:29 --> Total execution time: 0.2179
DEBUG - 2022-11-14 08:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:36 --> Total execution time: 0.1747
DEBUG - 2022-11-14 08:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:48 --> Total execution time: 0.1794
DEBUG - 2022-11-14 08:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:06 --> Total execution time: 0.4858
DEBUG - 2022-11-14 08:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:10 --> Total execution time: 0.1731
DEBUG - 2022-11-14 08:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:13 --> Total execution time: 0.1666
DEBUG - 2022-11-14 08:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:20 --> Total execution time: 0.1788
DEBUG - 2022-11-14 08:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:23 --> Total execution time: 0.2211
DEBUG - 2022-11-14 08:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:38 --> Total execution time: 0.2138
DEBUG - 2022-11-14 08:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:35:41 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:41 --> Total execution time: 0.1426
DEBUG - 2022-11-14 08:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:35:47 --> Total execution time: 0.1677
DEBUG - 2022-11-14 08:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:48 --> Total execution time: 0.1728
DEBUG - 2022-11-14 08:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:35:49 --> Total execution time: 0.1665
DEBUG - 2022-11-14 08:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:35:50 --> Total execution time: 0.1784
DEBUG - 2022-11-14 08:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:35:51 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:52 --> Total execution time: 0.1708
DEBUG - 2022-11-14 08:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:52 --> Total execution time: 0.1761
DEBUG - 2022-11-14 08:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:35:56 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:56 --> Total execution time: 0.1492
DEBUG - 2022-11-14 08:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:05 --> Total execution time: 0.1942
DEBUG - 2022-11-14 08:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:14 --> Total execution time: 0.1823
DEBUG - 2022-11-14 08:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:23 --> Total execution time: 0.5181
DEBUG - 2022-11-14 08:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:26 --> Total execution time: 0.1844
DEBUG - 2022-11-14 08:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:36:26 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:27 --> Total execution time: 0.4906
DEBUG - 2022-11-14 08:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:33 --> Total execution time: 0.2007
DEBUG - 2022-11-14 08:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:36:37 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:37 --> Total execution time: 0.2125
DEBUG - 2022-11-14 08:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:37:02 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:02 --> Total execution time: 0.1769
DEBUG - 2022-11-14 08:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:37:04 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:04 --> Total execution time: 0.5049
DEBUG - 2022-11-14 08:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:08 --> Total execution time: 0.1617
DEBUG - 2022-11-14 08:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:14 --> Total execution time: 0.5195
DEBUG - 2022-11-14 08:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:16 --> Total execution time: 0.2118
DEBUG - 2022-11-14 08:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:30 --> Total execution time: 0.2274
DEBUG - 2022-11-14 08:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:38 --> Total execution time: 0.1778
DEBUG - 2022-11-14 08:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:49 --> Total execution time: 0.1860
DEBUG - 2022-11-14 20:07:49 --> Total execution time: 0.1852
DEBUG - 2022-11-14 08:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:51 --> Total execution time: 0.1985
DEBUG - 2022-11-14 08:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:55 --> Total execution time: 0.1808
DEBUG - 2022-11-14 08:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:57 --> Total execution time: 0.1730
DEBUG - 2022-11-14 08:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:59 --> Total execution time: 0.3526
DEBUG - 2022-11-14 08:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:40:59 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:11:00 --> Total execution time: 0.6766
DEBUG - 2022-11-14 08:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:41:40 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:11:41 --> Total execution time: 1.1598
DEBUG - 2022-11-14 08:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:11:41 --> Total execution time: 0.1818
DEBUG - 2022-11-14 08:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:11:45 --> Total execution time: 0.1714
DEBUG - 2022-11-14 08:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:11:54 --> Total execution time: 0.2445
DEBUG - 2022-11-14 08:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:12:03 --> Total execution time: 0.3638
DEBUG - 2022-11-14 08:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:12:48 --> Total execution time: 0.2205
DEBUG - 2022-11-14 08:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:12:49 --> Total execution time: 0.1782
DEBUG - 2022-11-14 08:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:13:54 --> Total execution time: 0.9121
DEBUG - 2022-11-14 08:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:13:57 --> Total execution time: 0.3272
DEBUG - 2022-11-14 08:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:13:57 --> Total execution time: 0.4677
DEBUG - 2022-11-14 08:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:04 --> Total execution time: 0.1760
DEBUG - 2022-11-14 08:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:12 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:12 --> Total execution time: 0.1482
DEBUG - 2022-11-14 08:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:19 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:19 --> Total execution time: 0.1088
DEBUG - 2022-11-14 08:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:24 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:24 --> Total execution time: 0.1192
DEBUG - 2022-11-14 08:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:28 --> Total execution time: 0.1878
DEBUG - 2022-11-14 08:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:28 --> Total execution time: 0.1683
DEBUG - 2022-11-14 08:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:29 --> Total execution time: 0.1834
DEBUG - 2022-11-14 08:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:30 --> Total execution time: 0.2170
DEBUG - 2022-11-14 08:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:31 --> Total execution time: 0.1744
DEBUG - 2022-11-14 08:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:31 --> Total execution time: 0.1840
DEBUG - 2022-11-14 08:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:32 --> Total execution time: 0.1719
DEBUG - 2022-11-14 08:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:32 --> Total execution time: 0.1802
DEBUG - 2022-11-14 08:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:33 --> Total execution time: 0.1737
DEBUG - 2022-11-14 08:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:33 --> Total execution time: 0.3032
DEBUG - 2022-11-14 08:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:34 --> Total execution time: 0.1732
DEBUG - 2022-11-14 08:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:34 --> Total execution time: 0.1722
DEBUG - 2022-11-14 08:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:35 --> Total execution time: 0.1816
DEBUG - 2022-11-14 08:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:42 --> Total execution time: 0.2180
DEBUG - 2022-11-14 08:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:15:26 --> Total execution time: 0.2185
DEBUG - 2022-11-14 08:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:15:27 --> Total execution time: 0.1921
DEBUG - 2022-11-14 08:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:15:47 --> Total execution time: 0.1811
DEBUG - 2022-11-14 08:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:45:52 --> Total execution time: 0.1779
DEBUG - 2022-11-14 08:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:46:03 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:16:03 --> Total execution time: 0.2343
DEBUG - 2022-11-14 08:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:46:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 08:46:06 --> 404 Page Not Found: Events/page
DEBUG - 2022-11-14 08:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:46:08 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:16:08 --> Total execution time: 0.1144
DEBUG - 2022-11-14 08:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:16:10 --> Total execution time: 0.4888
DEBUG - 2022-11-14 08:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:16:22 --> Total execution time: 0.1758
DEBUG - 2022-11-14 08:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:16:27 --> Total execution time: 0.1821
DEBUG - 2022-11-14 08:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:16:54 --> Total execution time: 0.1857
DEBUG - 2022-11-14 08:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:16:57 --> Total execution time: 0.1785
DEBUG - 2022-11-14 08:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:17:14 --> Total execution time: 0.1867
DEBUG - 2022-11-14 08:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:17:22 --> Total execution time: 0.2081
DEBUG - 2022-11-14 08:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:17:29 --> Total execution time: 0.1956
DEBUG - 2022-11-14 08:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:17:36 --> Total execution time: 0.1913
DEBUG - 2022-11-14 08:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:17:47 --> Total execution time: 0.2435
DEBUG - 2022-11-14 08:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:17:56 --> Total execution time: 0.1767
DEBUG - 2022-11-14 08:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:18:07 --> Total execution time: 0.4967
DEBUG - 2022-11-14 08:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:19:03 --> Total execution time: 0.2398
DEBUG - 2022-11-14 08:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:19:58 --> Total execution time: 0.1749
DEBUG - 2022-11-14 08:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:20:03 --> Total execution time: 0.5027
DEBUG - 2022-11-14 08:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:20:29 --> Total execution time: 0.2430
DEBUG - 2022-11-14 08:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:21:27 --> Total execution time: 0.4594
DEBUG - 2022-11-14 08:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:52:28 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:22:28 --> Total execution time: 0.1105
DEBUG - 2022-11-14 08:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:52:30 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:22:30 --> Total execution time: 0.1118
DEBUG - 2022-11-14 08:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:54:21 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:24:21 --> Total execution time: 0.1699
DEBUG - 2022-11-14 08:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:54:40 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:24:41 --> Total execution time: 0.4669
DEBUG - 2022-11-14 08:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:24:46 --> Total execution time: 0.1725
DEBUG - 2022-11-14 08:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:24:53 --> Total execution time: 0.2543
DEBUG - 2022-11-14 08:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:24:54 --> Total execution time: 0.1772
DEBUG - 2022-11-14 08:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:24:59 --> Total execution time: 0.3439
DEBUG - 2022-11-14 08:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:25:06 --> Total execution time: 0.3006
DEBUG - 2022-11-14 08:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:25:20 --> Total execution time: 0.1745
DEBUG - 2022-11-14 08:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:25:26 --> Total execution time: 0.1782
DEBUG - 2022-11-14 08:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:25:27 --> Total execution time: 0.1730
DEBUG - 2022-11-14 08:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:25:32 --> Total execution time: 0.2344
DEBUG - 2022-11-14 08:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:55:35 --> Total execution time: 0.1853
DEBUG - 2022-11-14 08:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:25:46 --> Total execution time: 0.1719
DEBUG - 2022-11-14 08:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:55:49 --> Total execution time: 0.2142
DEBUG - 2022-11-14 08:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:26:00 --> Total execution time: 0.5088
DEBUG - 2022-11-14 08:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:56:16 --> Total execution time: 0.1728
DEBUG - 2022-11-14 08:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:56:19 --> Total execution time: 0.1752
DEBUG - 2022-11-14 08:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:56:19 --> Total execution time: 0.2104
DEBUG - 2022-11-14 08:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:26:28 --> Total execution time: 0.4632
DEBUG - 2022-11-14 08:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 08:56:32 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-11-14 08:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:57:06 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:27:07 --> Total execution time: 0.4840
DEBUG - 2022-11-14 08:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:27:14 --> Total execution time: 0.1753
DEBUG - 2022-11-14 08:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:27:36 --> Total execution time: 0.2313
DEBUG - 2022-11-14 08:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:27:55 --> Total execution time: 0.1171
DEBUG - 2022-11-14 08:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:28:03 --> Total execution time: 0.1908
DEBUG - 2022-11-14 08:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:28:53 --> Total execution time: 0.2313
DEBUG - 2022-11-14 08:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:29:25 --> Total execution time: 0.4602
DEBUG - 2022-11-14 08:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:29:27 --> Total execution time: 0.2364
DEBUG - 2022-11-14 08:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:59:31 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:29:31 --> Total execution time: 0.1080
DEBUG - 2022-11-14 08:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:29:31 --> Total execution time: 0.1728
DEBUG - 2022-11-14 08:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:59:33 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:29:33 --> Total execution time: 0.2077
DEBUG - 2022-11-14 08:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:29:35 --> Total execution time: 0.2345
DEBUG - 2022-11-14 08:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:59:39 --> No URI present. Default controller set.
DEBUG - 2022-11-14 08:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:29:39 --> Total execution time: 0.1770
DEBUG - 2022-11-14 08:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:59:44 --> Total execution time: 0.1768
DEBUG - 2022-11-14 08:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 08:59:49 --> Total execution time: 0.1884
DEBUG - 2022-11-14 08:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 08:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 08:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:29:56 --> Total execution time: 0.4923
DEBUG - 2022-11-14 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:30:02 --> Total execution time: 0.1156
DEBUG - 2022-11-14 09:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:30:07 --> Total execution time: 0.1741
DEBUG - 2022-11-14 09:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:30:22 --> Total execution time: 0.2215
DEBUG - 2022-11-14 09:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:30:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 09:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:30:50 --> Total execution time: 0.2051
DEBUG - 2022-11-14 09:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:30:52 --> Total execution time: 0.4669
DEBUG - 2022-11-14 09:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:31:14 --> Total execution time: 0.2317
DEBUG - 2022-11-14 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:31:27 --> Total execution time: 0.1864
DEBUG - 2022-11-14 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:31:27 --> Total execution time: 0.2026
DEBUG - 2022-11-14 09:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:31:28 --> Total execution time: 0.1901
DEBUG - 2022-11-14 09:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:31:30 --> Total execution time: 0.1769
DEBUG - 2022-11-14 09:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:31:32 --> Total execution time: 0.1771
DEBUG - 2022-11-14 09:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:31:39 --> Total execution time: 0.1911
DEBUG - 2022-11-14 09:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:31:40 --> Total execution time: 0.1757
DEBUG - 2022-11-14 09:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:42 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:31:42 --> Total execution time: 0.1773
DEBUG - 2022-11-14 09:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 09:01:44 --> 404 Page Not Found: Yardley-discontinued-strawberry-coconut-frosted-cranberry-bath-bar-soap-3-pcs-930680html/index
DEBUG - 2022-11-14 09:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:31:54 --> Total execution time: 0.2148
DEBUG - 2022-11-14 09:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:31:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 09:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:31:59 --> Total execution time: 0.2077
DEBUG - 2022-11-14 09:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:32:37 --> Total execution time: 0.2020
DEBUG - 2022-11-14 09:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:32:48 --> Total execution time: 0.1227
DEBUG - 2022-11-14 09:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:32:54 --> Total execution time: 0.1798
DEBUG - 2022-11-14 09:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:32:57 --> Total execution time: 0.1661
DEBUG - 2022-11-14 09:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:03:10 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:03:10 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:33:10 --> Total execution time: 0.1279
DEBUG - 2022-11-14 09:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:33:10 --> Total execution time: 0.1078
DEBUG - 2022-11-14 09:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:33:30 --> Total execution time: 0.4815
DEBUG - 2022-11-14 09:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:34:01 --> Total execution time: 0.1807
DEBUG - 2022-11-14 09:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:34:06 --> Total execution time: 0.1078
DEBUG - 2022-11-14 09:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:35:38 --> Total execution time: 1.0726
DEBUG - 2022-11-14 09:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:35:39 --> Total execution time: 0.2327
DEBUG - 2022-11-14 09:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:06:36 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:36:36 --> Total execution time: 0.1265
DEBUG - 2022-11-14 09:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:06:58 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:36:58 --> Total execution time: 0.1131
DEBUG - 2022-11-14 09:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:07:26 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:37:26 --> Total execution time: 0.4728
DEBUG - 2022-11-14 09:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:07:58 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:37:58 --> Total execution time: 0.1800
DEBUG - 2022-11-14 09:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:08:19 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:38:19 --> Total execution time: 0.1165
DEBUG - 2022-11-14 09:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:09:34 --> Total execution time: 0.1772
DEBUG - 2022-11-14 09:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:39:46 --> Total execution time: 0.1687
DEBUG - 2022-11-14 09:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:40:22 --> Total execution time: 0.1698
DEBUG - 2022-11-14 09:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:40:23 --> Total execution time: 0.3129
DEBUG - 2022-11-14 09:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:40:26 --> Total execution time: 0.2316
DEBUG - 2022-11-14 09:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:40:29 --> Total execution time: 0.2029
DEBUG - 2022-11-14 09:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:10:32 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:40:32 --> Total execution time: 0.1093
DEBUG - 2022-11-14 09:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:40:46 --> Total execution time: 0.1872
DEBUG - 2022-11-14 09:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:41:02 --> Total execution time: 0.1960
DEBUG - 2022-11-14 09:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:41:38 --> Total execution time: 9.7052
DEBUG - 2022-11-14 09:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:41:54 --> Total execution time: 7.3149
DEBUG - 2022-11-14 09:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:13:06 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:43:06 --> Total execution time: 0.1157
DEBUG - 2022-11-14 09:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:43:28 --> Total execution time: 0.5895
DEBUG - 2022-11-14 09:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:44:33 --> Total execution time: 0.5310
DEBUG - 2022-11-14 09:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:15:37 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:45:37 --> Total execution time: 0.1818
DEBUG - 2022-11-14 09:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:45:45 --> Total execution time: 0.1878
DEBUG - 2022-11-14 09:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:15:48 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:45:48 --> Total execution time: 0.4579
DEBUG - 2022-11-14 09:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:45:51 --> Total execution time: 0.1816
DEBUG - 2022-11-14 09:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:45:53 --> Total execution time: 0.1793
DEBUG - 2022-11-14 09:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:46:00 --> Total execution time: 0.2577
DEBUG - 2022-11-14 09:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:46:09 --> Total execution time: 0.1990
DEBUG - 2022-11-14 09:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:46:16 --> Total execution time: 0.2084
DEBUG - 2022-11-14 09:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:16:17 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:46:17 --> Total execution time: 0.4731
DEBUG - 2022-11-14 09:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:16:26 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:46:26 --> Total execution time: 0.1145
DEBUG - 2022-11-14 09:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:46:27 --> Total execution time: 0.1685
DEBUG - 2022-11-14 09:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:46:37 --> Total execution time: 0.1898
DEBUG - 2022-11-14 09:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:46:37 --> Total execution time: 0.2653
DEBUG - 2022-11-14 09:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:46:40 --> Total execution time: 0.1729
DEBUG - 2022-11-14 09:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:46:44 --> Total execution time: 0.1750
DEBUG - 2022-11-14 09:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:46:50 --> Total execution time: 0.1952
DEBUG - 2022-11-14 09:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:46:54 --> Total execution time: 0.2149
DEBUG - 2022-11-14 09:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:46:56 --> Total execution time: 0.2405
DEBUG - 2022-11-14 09:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:47:07 --> Total execution time: 0.1758
DEBUG - 2022-11-14 09:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:47:07 --> Total execution time: 0.2659
DEBUG - 2022-11-14 09:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:47:14 --> Total execution time: 0.1826
DEBUG - 2022-11-14 09:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:17:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 09:17:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 09:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:17:33 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:47:33 --> Total execution time: 0.1076
DEBUG - 2022-11-14 09:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:47:44 --> Total execution time: 0.4559
DEBUG - 2022-11-14 09:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:48:09 --> Total execution time: 0.1714
DEBUG - 2022-11-14 09:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:48:10 --> Total execution time: 0.2059
DEBUG - 2022-11-14 09:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:48:42 --> Total execution time: 0.5133
DEBUG - 2022-11-14 09:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:10 --> Total execution time: 0.8087
DEBUG - 2022-11-14 09:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:19:14 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:14 --> Total execution time: 0.1264
DEBUG - 2022-11-14 09:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:19 --> Total execution time: 0.2129
DEBUG - 2022-11-14 09:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:26 --> Total execution time: 0.5998
DEBUG - 2022-11-14 09:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:19:41 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:41 --> Total execution time: 0.1155
DEBUG - 2022-11-14 09:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:46 --> Total execution time: 0.5236
DEBUG - 2022-11-14 09:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:52 --> Total execution time: 0.1919
DEBUG - 2022-11-14 09:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:50:00 --> Total execution time: 0.2255
DEBUG - 2022-11-14 09:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:50:00 --> Total execution time: 0.1930
DEBUG - 2022-11-14 09:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:50:21 --> Total execution time: 0.1782
DEBUG - 2022-11-14 09:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:50:23 --> Total execution time: 0.1932
DEBUG - 2022-11-14 09:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:50:25 --> Total execution time: 0.6314
DEBUG - 2022-11-14 09:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:50:27 --> Total execution time: 0.2217
DEBUG - 2022-11-14 09:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:50:28 --> Total execution time: 0.1821
DEBUG - 2022-11-14 09:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:50:35 --> Total execution time: 0.1945
DEBUG - 2022-11-14 09:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:50:41 --> Total execution time: 0.2350
DEBUG - 2022-11-14 09:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:50:55 --> Total execution time: 0.2299
DEBUG - 2022-11-14 09:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:51:16 --> Total execution time: 0.4997
DEBUG - 2022-11-14 09:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:51:31 --> Total execution time: 0.1816
DEBUG - 2022-11-14 09:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:51:33 --> Total execution time: 0.1967
DEBUG - 2022-11-14 09:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:51:49 --> Total execution time: 0.2473
DEBUG - 2022-11-14 09:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:19 --> Total execution time: 0.1862
DEBUG - 2022-11-14 09:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:19 --> Total execution time: 0.3943
DEBUG - 2022-11-14 09:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:28 --> Total execution time: 0.2241
DEBUG - 2022-11-14 09:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:28 --> Total execution time: 0.1892
DEBUG - 2022-11-14 09:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:01 --> Total execution time: 0.5017
DEBUG - 2022-11-14 09:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:11 --> Total execution time: 0.1980
DEBUG - 2022-11-14 09:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:28 --> Total execution time: 0.1773
DEBUG - 2022-11-14 09:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:45 --> Total execution time: 0.2215
DEBUG - 2022-11-14 09:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:46 --> Total execution time: 0.2063
DEBUG - 2022-11-14 09:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:46 --> Total execution time: 0.2711
DEBUG - 2022-11-14 09:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:47 --> Total execution time: 0.2290
DEBUG - 2022-11-14 09:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:47 --> Total execution time: 0.2144
DEBUG - 2022-11-14 09:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:48 --> Total execution time: 0.3922
DEBUG - 2022-11-14 09:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:49 --> Total execution time: 0.2542
DEBUG - 2022-11-14 09:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:50 --> Total execution time: 0.2215
DEBUG - 2022-11-14 09:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:50 --> Total execution time: 0.2038
DEBUG - 2022-11-14 09:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:27:07 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:07 --> Total execution time: 0.4575
DEBUG - 2022-11-14 09:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:14 --> Total execution time: 0.1767
DEBUG - 2022-11-14 09:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:26 --> Total execution time: 0.1675
DEBUG - 2022-11-14 09:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:30 --> Total execution time: 0.2039
DEBUG - 2022-11-14 09:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:27:30 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:30 --> Total execution time: 0.1112
DEBUG - 2022-11-14 09:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:36 --> Total execution time: 0.1674
DEBUG - 2022-11-14 09:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:45 --> Total execution time: 0.1722
DEBUG - 2022-11-14 09:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:48 --> Total execution time: 0.1650
DEBUG - 2022-11-14 09:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:52 --> Total execution time: 0.1937
DEBUG - 2022-11-14 09:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:55 --> Total execution time: 0.1910
DEBUG - 2022-11-14 09:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:58:05 --> Total execution time: 0.1792
DEBUG - 2022-11-14 09:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:58:53 --> Total execution time: 2.6304
DEBUG - 2022-11-14 09:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 09:28:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 09:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:29:03 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:59:03 --> Total execution time: 0.1796
DEBUG - 2022-11-14 09:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:29:03 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:59:04 --> Total execution time: 0.2175
DEBUG - 2022-11-14 09:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:59:08 --> Total execution time: 0.1637
DEBUG - 2022-11-14 09:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:59:11 --> Total execution time: 0.1773
DEBUG - 2022-11-14 09:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:59:16 --> Total execution time: 0.1804
DEBUG - 2022-11-14 09:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:59:21 --> Total execution time: 0.2098
DEBUG - 2022-11-14 09:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:00:28 --> Total execution time: 0.1792
DEBUG - 2022-11-14 09:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:00:31 --> Total execution time: 0.2201
DEBUG - 2022-11-14 09:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:00:33 --> Total execution time: 0.2200
DEBUG - 2022-11-14 09:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:00:43 --> Total execution time: 0.2414
DEBUG - 2022-11-14 09:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:31:03 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:01:03 --> Total execution time: 0.4583
DEBUG - 2022-11-14 09:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:03:33 --> Total execution time: 0.5453
DEBUG - 2022-11-14 09:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:05:17 --> Total execution time: 0.1127
DEBUG - 2022-11-14 09:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:08:12 --> Total execution time: 0.5877
DEBUG - 2022-11-14 09:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:08:13 --> Total execution time: 0.1117
DEBUG - 2022-11-14 09:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:08:13 --> Total execution time: 0.1160
DEBUG - 2022-11-14 09:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:08:15 --> Total execution time: 0.1673
DEBUG - 2022-11-14 09:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:08:24 --> Total execution time: 0.2275
DEBUG - 2022-11-14 09:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:08:31 --> Total execution time: 0.1733
DEBUG - 2022-11-14 09:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:08:59 --> Total execution time: 0.1838
DEBUG - 2022-11-14 09:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:41:03 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:11:03 --> Total execution time: 0.1244
DEBUG - 2022-11-14 09:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:41:08 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:11:08 --> Total execution time: 0.1284
DEBUG - 2022-11-14 09:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:11:33 --> Total execution time: 0.1729
DEBUG - 2022-11-14 09:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:13:27 --> Total execution time: 0.1057
DEBUG - 2022-11-14 09:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:44:12 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:14:12 --> Total execution time: 0.1299
DEBUG - 2022-11-14 09:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:17:24 --> Total execution time: 0.5949
DEBUG - 2022-11-14 09:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:47:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 09:47:50 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-11-14 09:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:48:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 09:48:21 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-11-14 09:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:49:42 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:19:42 --> Total execution time: 0.1797
DEBUG - 2022-11-14 09:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:49:43 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:19:43 --> Total execution time: 0.1905
DEBUG - 2022-11-14 09:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:20:04 --> Total execution time: 0.1794
DEBUG - 2022-11-14 09:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:20:10 --> Total execution time: 0.1654
DEBUG - 2022-11-14 09:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:20:15 --> Total execution time: 0.2098
DEBUG - 2022-11-14 09:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:20:16 --> Total execution time: 0.2216
DEBUG - 2022-11-14 09:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:20:18 --> Total execution time: 0.1826
DEBUG - 2022-11-14 09:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:20:24 --> Total execution time: 0.1936
DEBUG - 2022-11-14 09:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:20:28 --> Total execution time: 0.2118
DEBUG - 2022-11-14 09:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:20:36 --> Total execution time: 0.2151
DEBUG - 2022-11-14 09:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:20:41 --> Total execution time: 0.1860
DEBUG - 2022-11-14 09:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:20:43 --> Total execution time: 0.1763
DEBUG - 2022-11-14 09:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:20:50 --> Total execution time: 0.1831
DEBUG - 2022-11-14 09:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:20:51 --> Total execution time: 0.1686
DEBUG - 2022-11-14 09:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:21:02 --> Total execution time: 0.2122
DEBUG - 2022-11-14 09:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:21:12 --> Total execution time: 0.1935
DEBUG - 2022-11-14 09:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:22:12 --> Total execution time: 0.1837
DEBUG - 2022-11-14 09:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:22:48 --> Total execution time: 0.2110
DEBUG - 2022-11-14 09:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:53:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 09:53:16 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-14 09:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:23:58 --> Total execution time: 0.2498
DEBUG - 2022-11-14 09:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:24:09 --> Total execution time: 0.1933
DEBUG - 2022-11-14 09:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:24:38 --> Total execution time: 0.1899
DEBUG - 2022-11-14 09:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:24:58 --> Total execution time: 0.4646
DEBUG - 2022-11-14 09:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:54:59 --> Total execution time: 0.1676
DEBUG - 2022-11-14 09:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:25:10 --> Total execution time: 0.5779
DEBUG - 2022-11-14 09:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:55:30 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:25:30 --> Total execution time: 0.1304
DEBUG - 2022-11-14 09:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:25:43 --> Total execution time: 0.2369
DEBUG - 2022-11-14 09:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:25:52 --> Total execution time: 0.5118
DEBUG - 2022-11-14 09:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:55:53 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:25:53 --> Total execution time: 0.4433
DEBUG - 2022-11-14 09:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:26:05 --> Total execution time: 0.1804
DEBUG - 2022-11-14 21:26:07 --> Total execution time: 2.3687
DEBUG - 2022-11-14 09:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:26:07 --> Total execution time: 0.2216
DEBUG - 2022-11-14 09:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:56:30 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:26:30 --> Total execution time: 0.1702
DEBUG - 2022-11-14 09:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:26:34 --> Total execution time: 0.1689
DEBUG - 2022-11-14 09:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 09:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:26:41 --> Total execution time: 0.1816
DEBUG - 2022-11-14 09:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:26:52 --> Total execution time: 0.2142
DEBUG - 2022-11-14 09:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:26:57 --> Total execution time: 0.1794
DEBUG - 2022-11-14 09:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:58:11 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:28:11 --> Total execution time: 0.1187
DEBUG - 2022-11-14 09:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:58:12 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:28:12 --> Total execution time: 0.1322
DEBUG - 2022-11-14 09:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:58:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 09:58:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 09:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 09:59:58 --> No URI present. Default controller set.
DEBUG - 2022-11-14 09:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 09:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:29:58 --> Total execution time: 0.1163
DEBUG - 2022-11-14 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:30:02 --> Total execution time: 0.1281
DEBUG - 2022-11-14 10:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:30:09 --> Total execution time: 0.1356
DEBUG - 2022-11-14 10:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:30:16 --> Total execution time: 0.1959
DEBUG - 2022-11-14 10:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:30:21 --> Total execution time: 0.2086
DEBUG - 2022-11-14 10:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:30:26 --> Total execution time: 0.2715
DEBUG - 2022-11-14 10:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:30:32 --> Total execution time: 0.1805
DEBUG - 2022-11-14 10:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:30:32 --> Total execution time: 0.1762
DEBUG - 2022-11-14 10:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:30:34 --> Total execution time: 0.1785
DEBUG - 2022-11-14 10:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:00:34 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:30:35 --> Total execution time: 0.1797
DEBUG - 2022-11-14 10:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:32:15 --> Total execution time: 0.1684
DEBUG - 2022-11-14 10:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:32:22 --> Total execution time: 0.1864
DEBUG - 2022-11-14 10:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:32:24 --> Total execution time: 0.1817
DEBUG - 2022-11-14 10:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:32:31 --> Total execution time: 0.2367
DEBUG - 2022-11-14 10:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:32:51 --> Total execution time: 0.1944
DEBUG - 2022-11-14 10:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:02:53 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:32:53 --> Total execution time: 0.1124
DEBUG - 2022-11-14 10:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:33:02 --> Total execution time: 0.1069
DEBUG - 2022-11-14 10:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:33:07 --> Total execution time: 0.2131
DEBUG - 2022-11-14 10:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:03:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 10:03:24 --> 404 Page Not Found: Sitemap_1xml/index
DEBUG - 2022-11-14 10:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 10:03:25 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-11-14 10:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:33:44 --> Total execution time: 0.4678
DEBUG - 2022-11-14 10:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:33:46 --> Total execution time: 0.1797
DEBUG - 2022-11-14 10:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:33:53 --> Total execution time: 0.1790
DEBUG - 2022-11-14 10:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:33:55 --> Total execution time: 0.1781
DEBUG - 2022-11-14 10:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:33:58 --> Total execution time: 0.1790
DEBUG - 2022-11-14 10:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:34:00 --> Total execution time: 0.1847
DEBUG - 2022-11-14 10:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:34:04 --> Total execution time: 0.1102
DEBUG - 2022-11-14 10:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:34:11 --> Total execution time: 0.1758
DEBUG - 2022-11-14 10:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:34:15 --> Total execution time: 0.1816
DEBUG - 2022-11-14 10:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:34:31 --> Total execution time: 0.1113
DEBUG - 2022-11-14 10:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:35:41 --> Total execution time: 0.2109
DEBUG - 2022-11-14 10:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:36:05 --> Total execution time: 0.1794
DEBUG - 2022-11-14 10:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:38:49 --> Total execution time: 0.1822
DEBUG - 2022-11-14 10:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:09:38 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:39:38 --> Total execution time: 0.1270
DEBUG - 2022-11-14 10:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:39:43 --> Total execution time: 0.1941
DEBUG - 2022-11-14 10:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:40:06 --> Total execution time: 0.2272
DEBUG - 2022-11-14 10:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:10:19 --> Total execution time: 0.1127
DEBUG - 2022-11-14 10:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:10:21 --> Total execution time: 0.1952
DEBUG - 2022-11-14 10:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:10:22 --> Total execution time: 0.1819
DEBUG - 2022-11-14 10:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:10:28 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:40:28 --> Total execution time: 0.1297
DEBUG - 2022-11-14 10:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:40:29 --> Total execution time: 0.5136
DEBUG - 2022-11-14 10:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:40:31 --> Total execution time: 0.1183
DEBUG - 2022-11-14 10:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:40:32 --> Total execution time: 0.1862
DEBUG - 2022-11-14 10:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:40:37 --> Total execution time: 0.2313
DEBUG - 2022-11-14 10:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:40:41 --> Total execution time: 0.1696
DEBUG - 2022-11-14 10:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:40:48 --> Total execution time: 0.2090
DEBUG - 2022-11-14 10:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:40:55 --> Total execution time: 0.2131
DEBUG - 2022-11-14 10:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:11:39 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:41:39 --> Total execution time: 0.1101
DEBUG - 2022-11-14 10:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:11:45 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:41:45 --> Total execution time: 0.1124
DEBUG - 2022-11-14 10:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:41:52 --> Total execution time: 0.1130
DEBUG - 2022-11-14 10:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:42:05 --> Total execution time: 0.1761
DEBUG - 2022-11-14 10:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:42:07 --> Total execution time: 0.1856
DEBUG - 2022-11-14 10:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:42:11 --> Total execution time: 0.1837
DEBUG - 2022-11-14 10:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:42:17 --> Total execution time: 0.2005
DEBUG - 2022-11-14 10:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:42:23 --> Total execution time: 0.1797
DEBUG - 2022-11-14 10:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:42:25 --> Total execution time: 0.1888
DEBUG - 2022-11-14 10:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:42:29 --> Total execution time: 0.1853
DEBUG - 2022-11-14 10:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:42:36 --> Total execution time: 0.2154
DEBUG - 2022-11-14 10:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:42:41 --> Total execution time: 0.2105
DEBUG - 2022-11-14 10:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:43:00 --> Total execution time: 0.1863
DEBUG - 2022-11-14 10:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:43:08 --> Total execution time: 0.2284
DEBUG - 2022-11-14 10:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:43:10 --> Total execution time: 0.1906
DEBUG - 2022-11-14 10:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:43:26 --> Total execution time: 0.1885
DEBUG - 2022-11-14 10:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:43:47 --> Total execution time: 0.1790
DEBUG - 2022-11-14 10:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:43:49 --> Total execution time: 0.1928
DEBUG - 2022-11-14 10:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:43:59 --> Total execution time: 0.2296
DEBUG - 2022-11-14 10:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:14:18 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:44:18 --> Total execution time: 0.1108
DEBUG - 2022-11-14 10:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:14:23 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:44:23 --> Total execution time: 0.1696
DEBUG - 2022-11-14 10:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:44:33 --> Total execution time: 0.2484
DEBUG - 2022-11-14 10:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:44:44 --> Total execution time: 0.2174
DEBUG - 2022-11-14 10:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:44:48 --> Total execution time: 0.2331
DEBUG - 2022-11-14 10:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:44:53 --> Total execution time: 0.2197
DEBUG - 2022-11-14 10:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:06 --> Total execution time: 0.1881
DEBUG - 2022-11-14 10:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:16 --> Total execution time: 0.1760
DEBUG - 2022-11-14 10:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:47 --> Total execution time: 0.1117
DEBUG - 2022-11-14 10:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:53 --> Total execution time: 0.1887
DEBUG - 2022-11-14 10:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:46:09 --> Total execution time: 0.1740
DEBUG - 2022-11-14 10:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:19:27 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:49:27 --> Total execution time: 0.1171
DEBUG - 2022-11-14 10:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:49:32 --> Total execution time: 0.1670
DEBUG - 2022-11-14 10:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:49:37 --> Total execution time: 0.1989
DEBUG - 2022-11-14 10:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:51:00 --> Total execution time: 0.4543
DEBUG - 2022-11-14 10:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:51:20 --> Total execution time: 0.1693
DEBUG - 2022-11-14 10:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:51:43 --> Total execution time: 0.1764
DEBUG - 2022-11-14 10:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:53:05 --> Total execution time: 0.6416
DEBUG - 2022-11-14 10:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:53:23 --> Total execution time: 0.2019
DEBUG - 2022-11-14 10:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:53:41 --> Total execution time: 0.1798
DEBUG - 2022-11-14 10:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:54:03 --> Total execution time: 0.1127
DEBUG - 2022-11-14 10:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:54:09 --> Total execution time: 0.1735
DEBUG - 2022-11-14 10:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:24:10 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:54:10 --> Total execution time: 0.1165
DEBUG - 2022-11-14 10:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:54:19 --> Total execution time: 0.2054
DEBUG - 2022-11-14 10:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:54:23 --> Total execution time: 0.1732
DEBUG - 2022-11-14 10:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:54:42 --> Total execution time: 0.1835
DEBUG - 2022-11-14 10:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:54:43 --> Total execution time: 0.1713
DEBUG - 2022-11-14 10:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:54:44 --> Total execution time: 0.1709
DEBUG - 2022-11-14 10:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:54:55 --> Total execution time: 0.1768
DEBUG - 2022-11-14 10:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:54:57 --> Total execution time: 0.1076
DEBUG - 2022-11-14 10:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:06 --> Total execution time: 0.1842
DEBUG - 2022-11-14 10:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:08 --> Total execution time: 0.1268
DEBUG - 2022-11-14 10:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:09 --> Total execution time: 0.1815
DEBUG - 2022-11-14 10:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:14 --> Total execution time: 0.1784
DEBUG - 2022-11-14 10:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:26 --> Total execution time: 0.1665
DEBUG - 2022-11-14 10:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:32 --> Total execution time: 0.1680
DEBUG - 2022-11-14 10:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:47 --> Total execution time: 0.1772
DEBUG - 2022-11-14 10:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:25:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 10:25:49 --> 404 Page Not Found: Admin/public
DEBUG - 2022-11-14 10:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:58 --> Total execution time: 0.1650
DEBUG - 2022-11-14 10:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:56:19 --> Total execution time: 0.1784
DEBUG - 2022-11-14 10:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:26:51 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:56:51 --> Total execution time: 0.1123
DEBUG - 2022-11-14 10:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 10:26:57 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-14 10:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:27:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 10:27:01 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-14 10:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:27:36 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:57:36 --> Total execution time: 0.4491
DEBUG - 2022-11-14 10:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:57:49 --> Total execution time: 0.1806
DEBUG - 2022-11-14 10:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:57:52 --> Total execution time: 0.1717
DEBUG - 2022-11-14 10:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:28:48 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:58:48 --> Total execution time: 0.1196
DEBUG - 2022-11-14 10:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:59:46 --> Total execution time: 0.1705
DEBUG - 2022-11-14 10:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:59:47 --> Total execution time: 0.5495
DEBUG - 2022-11-14 10:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:59:59 --> Total execution time: 0.2018
DEBUG - 2022-11-14 10:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:00:23 --> Total execution time: 0.1690
DEBUG - 2022-11-14 10:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:00:25 --> Total execution time: 0.2073
DEBUG - 2022-11-14 10:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:00:40 --> Total execution time: 0.1846
DEBUG - 2022-11-14 10:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:02:03 --> Total execution time: 0.1833
DEBUG - 2022-11-14 10:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:02:10 --> Total execution time: 0.1925
DEBUG - 2022-11-14 10:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:02:22 --> Total execution time: 0.1779
DEBUG - 2022-11-14 10:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:02:34 --> Total execution time: 0.2317
DEBUG - 2022-11-14 10:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:33:10 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:10 --> Total execution time: 0.1106
DEBUG - 2022-11-14 10:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:33:11 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:11 --> Total execution time: 0.1117
DEBUG - 2022-11-14 10:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:15 --> Total execution time: 0.2067
DEBUG - 2022-11-14 10:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:25 --> Total execution time: 0.1720
DEBUG - 2022-11-14 10:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:29 --> Total execution time: 0.1691
DEBUG - 2022-11-14 10:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:38 --> Total execution time: 0.4522
DEBUG - 2022-11-14 10:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:39 --> Total execution time: 0.2130
DEBUG - 2022-11-14 10:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:40 --> Total execution time: 0.2677
DEBUG - 2022-11-14 10:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:41 --> Total execution time: 0.1676
DEBUG - 2022-11-14 10:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:44 --> Total execution time: 0.1067
DEBUG - 2022-11-14 10:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:46 --> Total execution time: 0.2179
DEBUG - 2022-11-14 10:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:04:53 --> Total execution time: 0.1837
DEBUG - 2022-11-14 10:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:06:27 --> Total execution time: 0.1820
DEBUG - 2022-11-14 10:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:08:03 --> Total execution time: 0.5336
DEBUG - 2022-11-14 10:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:42:23 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:12:26 --> Total execution time: 2.3767
DEBUG - 2022-11-14 10:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:12:26 --> Total execution time: 0.1742
DEBUG - 2022-11-14 10:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:12:27 --> Total execution time: 0.1928
DEBUG - 2022-11-14 10:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:13:21 --> Total execution time: 0.5099
DEBUG - 2022-11-14 10:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:13:22 --> Total execution time: 0.1787
DEBUG - 2022-11-14 10:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:13:23 --> Total execution time: 0.1777
DEBUG - 2022-11-14 10:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:14:28 --> Total execution time: 0.2001
DEBUG - 2022-11-14 10:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:45:00 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:15:01 --> Total execution time: 0.1112
DEBUG - 2022-11-14 10:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:45:22 --> Total execution time: 0.1853
DEBUG - 2022-11-14 10:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:45:24 --> Total execution time: 0.1621
DEBUG - 2022-11-14 10:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:45:25 --> Total execution time: 0.2035
DEBUG - 2022-11-14 10:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:17:16 --> Total execution time: 2.1761
DEBUG - 2022-11-14 10:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:47:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 10:47:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 10:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:17:59 --> Total execution time: 0.1093
DEBUG - 2022-11-14 10:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:18:21 --> Total execution time: 0.1732
DEBUG - 2022-11-14 10:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:18:30 --> Total execution time: 0.1842
DEBUG - 2022-11-14 10:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:18:35 --> Total execution time: 0.3473
DEBUG - 2022-11-14 10:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:18:46 --> Total execution time: 1.8317
DEBUG - 2022-11-14 10:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:18:57 --> Total execution time: 0.1844
DEBUG - 2022-11-14 10:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:19:07 --> Total execution time: 0.1717
DEBUG - 2022-11-14 10:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:19:23 --> Total execution time: 0.1744
DEBUG - 2022-11-14 10:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:19:31 --> Total execution time: 0.2403
DEBUG - 2022-11-14 10:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:19:43 --> Total execution time: 0.4591
DEBUG - 2022-11-14 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:19:54 --> Total execution time: 0.1715
DEBUG - 2022-11-14 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:20:10 --> Total execution time: 0.4464
DEBUG - 2022-11-14 10:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:50:41 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:20:42 --> Total execution time: 0.1168
DEBUG - 2022-11-14 10:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:21:14 --> Total execution time: 0.1793
DEBUG - 2022-11-14 10:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:51:21 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:21:21 --> Total execution time: 0.1193
DEBUG - 2022-11-14 10:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:21:22 --> Total execution time: 0.1815
DEBUG - 2022-11-14 10:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:21:37 --> Total execution time: 0.1678
DEBUG - 2022-11-14 10:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:21:40 --> Total execution time: 0.1670
DEBUG - 2022-11-14 10:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:21:42 --> Total execution time: 0.1716
DEBUG - 2022-11-14 10:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:21:57 --> Total execution time: 0.1832
DEBUG - 2022-11-14 10:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:21:58 --> Total execution time: 0.2387
DEBUG - 2022-11-14 10:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:22:03 --> Total execution time: 0.2098
DEBUG - 2022-11-14 10:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:22:12 --> Total execution time: 0.1764
DEBUG - 2022-11-14 10:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:22:22 --> Total execution time: 0.1915
DEBUG - 2022-11-14 10:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:22:30 --> Total execution time: 0.2249
DEBUG - 2022-11-14 10:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:22:34 --> Total execution time: 0.1772
DEBUG - 2022-11-14 10:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:22:39 --> Total execution time: 0.2064
DEBUG - 2022-11-14 10:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:22:57 --> Total execution time: 0.2202
DEBUG - 2022-11-14 10:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 10:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:23:00 --> Total execution time: 0.1657
DEBUG - 2022-11-14 10:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:23:38 --> Total execution time: 0.1735
DEBUG - 2022-11-14 10:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:24:12 --> Total execution time: 0.4678
DEBUG - 2022-11-14 10:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:54:23 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:24:23 --> Total execution time: 0.1118
DEBUG - 2022-11-14 10:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:24:49 --> Total execution time: 0.4556
DEBUG - 2022-11-14 10:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:25:23 --> Total execution time: 0.1907
DEBUG - 2022-11-14 10:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:25:30 --> Total execution time: 0.2245
DEBUG - 2022-11-14 10:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:25:36 --> Total execution time: 0.1775
DEBUG - 2022-11-14 10:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:25:44 --> Total execution time: 0.1769
DEBUG - 2022-11-14 10:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:25:56 --> Total execution time: 0.1792
DEBUG - 2022-11-14 10:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:26:06 --> Total execution time: 0.1757
DEBUG - 2022-11-14 10:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:26:12 --> Total execution time: 0.1873
DEBUG - 2022-11-14 10:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:26:19 --> Total execution time: 0.2430
DEBUG - 2022-11-14 10:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:26:47 --> Total execution time: 0.2416
DEBUG - 2022-11-14 10:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:26:54 --> Total execution time: 0.1774
DEBUG - 2022-11-14 10:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:26:57 --> Total execution time: 0.1814
DEBUG - 2022-11-14 10:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:26:58 --> Total execution time: 0.1787
DEBUG - 2022-11-14 10:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:27:00 --> Total execution time: 0.1855
DEBUG - 2022-11-14 10:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:57:04 --> No URI present. Default controller set.
DEBUG - 2022-11-14 10:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:27:04 --> Total execution time: 0.1105
DEBUG - 2022-11-14 10:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 10:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 10:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:27:12 --> Total execution time: 0.4557
DEBUG - 2022-11-14 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:03 --> Total execution time: 0.1729
DEBUG - 2022-11-14 11:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:00:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 11:00:12 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-11-14 11:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:00:26 --> No URI present. Default controller set.
DEBUG - 2022-11-14 11:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:26 --> Total execution time: 0.1376
DEBUG - 2022-11-14 11:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:28 --> Total execution time: 0.4675
DEBUG - 2022-11-14 11:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:39 --> Total execution time: 0.1833
DEBUG - 2022-11-14 11:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:02:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 11:02:29 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 11:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:02:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 11:02:30 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 11:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:03:28 --> No URI present. Default controller set.
DEBUG - 2022-11-14 11:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:33:28 --> Total execution time: 0.1160
DEBUG - 2022-11-14 11:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:34:04 --> Total execution time: 0.4571
DEBUG - 2022-11-14 11:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:04:25 --> No URI present. Default controller set.
DEBUG - 2022-11-14 11:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:34:25 --> Total execution time: 0.1693
DEBUG - 2022-11-14 11:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:34:56 --> Total execution time: 0.4475
DEBUG - 2022-11-14 11:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:35:01 --> Total execution time: 0.1199
DEBUG - 2022-11-14 11:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:35:21 --> Total execution time: 0.1877
DEBUG - 2022-11-14 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:35:33 --> Total execution time: 0.2051
DEBUG - 2022-11-14 11:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:35:46 --> Total execution time: 0.1832
DEBUG - 2022-11-14 11:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:01 --> Total execution time: 0.1732
DEBUG - 2022-11-14 11:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:03 --> Total execution time: 0.1821
DEBUG - 2022-11-14 11:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:25 --> Total execution time: 0.5613
DEBUG - 2022-11-14 11:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:27 --> Total execution time: 0.2169
DEBUG - 2022-11-14 11:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:29 --> Total execution time: 0.1676
DEBUG - 2022-11-14 11:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:35 --> Total execution time: 0.1724
DEBUG - 2022-11-14 11:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:50 --> Total execution time: 0.4336
DEBUG - 2022-11-14 11:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:50 --> Total execution time: 0.1794
DEBUG - 2022-11-14 11:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:08:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 11:08:28 --> 404 Page Not Found: Milk-makeup-disco-daze-makeup-bag-232937html/index
DEBUG - 2022-11-14 11:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:38:58 --> Total execution time: 0.3123
DEBUG - 2022-11-14 11:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:39:15 --> Total execution time: 0.2029
DEBUG - 2022-11-14 11:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:39:31 --> Total execution time: 0.2359
DEBUG - 2022-11-14 11:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:40:15 --> Total execution time: 0.4879
DEBUG - 2022-11-14 11:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:10:35 --> No URI present. Default controller set.
DEBUG - 2022-11-14 11:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:40:35 --> Total execution time: 0.4662
DEBUG - 2022-11-14 11:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:10:37 --> No URI present. Default controller set.
DEBUG - 2022-11-14 11:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:40:37 --> Total execution time: 0.1704
DEBUG - 2022-11-14 11:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:40:41 --> Total execution time: 0.1857
DEBUG - 2022-11-14 11:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:40:43 --> Total execution time: 0.1795
DEBUG - 2022-11-14 11:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:40:47 --> Total execution time: 0.1864
DEBUG - 2022-11-14 11:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:40:48 --> Total execution time: 0.1762
DEBUG - 2022-11-14 11:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:40:52 --> Total execution time: 0.2200
DEBUG - 2022-11-14 11:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:41:09 --> Total execution time: 0.4178
DEBUG - 2022-11-14 11:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:41:27 --> Total execution time: 0.1689
DEBUG - 2022-11-14 11:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:41:31 --> Total execution time: 0.2445
DEBUG - 2022-11-14 11:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:41:35 --> Total execution time: 0.1894
DEBUG - 2022-11-14 11:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:42:00 --> Total execution time: 0.1678
DEBUG - 2022-11-14 11:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:12:42 --> No URI present. Default controller set.
DEBUG - 2022-11-14 11:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:42:42 --> Total execution time: 0.1708
DEBUG - 2022-11-14 11:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:42:48 --> Total execution time: 0.1199
DEBUG - 2022-11-14 11:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:43:25 --> Total execution time: 0.1790
DEBUG - 2022-11-14 11:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:44:14 --> Total execution time: 0.2671
DEBUG - 2022-11-14 11:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:44:53 --> Total execution time: 0.2108
DEBUG - 2022-11-14 11:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:04 --> Total execution time: 0.2321
DEBUG - 2022-11-14 11:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 11:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:52 --> Total execution time: 0.2155
DEBUG - 2022-11-14 11:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:59 --> Total execution time: 0.1680
DEBUG - 2022-11-14 11:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:46:06 --> Total execution time: 0.2162
DEBUG - 2022-11-14 11:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:46:16 --> Total execution time: 0.1781
DEBUG - 2022-11-14 11:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:46:18 --> Total execution time: 0.1791
DEBUG - 2022-11-14 11:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:51:47 --> Total execution time: 0.1686
DEBUG - 2022-11-14 11:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:23:34 --> No URI present. Default controller set.
DEBUG - 2022-11-14 11:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:53:34 --> Total execution time: 0.1149
DEBUG - 2022-11-14 11:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:53:52 --> Total execution time: 0.1805
DEBUG - 2022-11-14 11:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:54:21 --> Total execution time: 0.1915
DEBUG - 2022-11-14 11:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:54:33 --> Total execution time: 0.2508
DEBUG - 2022-11-14 11:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:54:59 --> Total execution time: 0.1669
DEBUG - 2022-11-14 11:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:24:59 --> No URI present. Default controller set.
DEBUG - 2022-11-14 11:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:54:59 --> Total execution time: 0.1058
DEBUG - 2022-11-14 11:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:25:00 --> No URI present. Default controller set.
DEBUG - 2022-11-14 11:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:55:00 --> Total execution time: 0.1080
DEBUG - 2022-11-14 11:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:55:01 --> Total execution time: 0.2290
DEBUG - 2022-11-14 11:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:55:51 --> Total execution time: 0.1782
DEBUG - 2022-11-14 11:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:55:57 --> Total execution time: 0.1889
DEBUG - 2022-11-14 11:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:56:07 --> Total execution time: 0.1772
DEBUG - 2022-11-14 11:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:26:21 --> No URI present. Default controller set.
DEBUG - 2022-11-14 11:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:56:21 --> Total execution time: 0.4667
DEBUG - 2022-11-14 11:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:56:25 --> Total execution time: 0.1698
DEBUG - 2022-11-14 11:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:26:33 --> No URI present. Default controller set.
DEBUG - 2022-11-14 11:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:56:33 --> Total execution time: 0.1897
DEBUG - 2022-11-14 11:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:26:40 --> Total execution time: 0.1738
DEBUG - 2022-11-14 11:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:26:43 --> Total execution time: 0.1889
DEBUG - 2022-11-14 11:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:26:43 --> Total execution time: 0.2105
DEBUG - 2022-11-14 11:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:26:51 --> No URI present. Default controller set.
DEBUG - 2022-11-14 11:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:56:51 --> Total execution time: 0.1110
DEBUG - 2022-11-14 11:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:56:59 --> Total execution time: 0.1726
DEBUG - 2022-11-14 11:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:57:15 --> Total execution time: 0.1834
DEBUG - 2022-11-14 11:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:57:25 --> Total execution time: 0.1862
DEBUG - 2022-11-14 11:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:57:31 --> Total execution time: 0.1808
DEBUG - 2022-11-14 11:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:57:36 --> Total execution time: 2.2886
DEBUG - 2022-11-14 11:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:57:39 --> Total execution time: 0.2096
DEBUG - 2022-11-14 11:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:57:46 --> Total execution time: 0.1781
DEBUG - 2022-11-14 11:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:58:00 --> Total execution time: 0.2095
DEBUG - 2022-11-14 11:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:58:08 --> Total execution time: 0.1786
DEBUG - 2022-11-14 11:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:58:11 --> Total execution time: 0.1839
DEBUG - 2022-11-14 11:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:58:13 --> Total execution time: 0.3382
DEBUG - 2022-11-14 11:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:58:15 --> Total execution time: 0.1974
DEBUG - 2022-11-14 11:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:58:25 --> Total execution time: 0.1762
DEBUG - 2022-11-14 11:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:58:31 --> Total execution time: 0.2274
DEBUG - 2022-11-14 11:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:58:43 --> Total execution time: 0.1664
DEBUG - 2022-11-14 11:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:58:51 --> Total execution time: 0.1786
DEBUG - 2022-11-14 11:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:58:54 --> Total execution time: 0.2148
DEBUG - 2022-11-14 11:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:58:54 --> Total execution time: 0.1860
DEBUG - 2022-11-14 11:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:58:58 --> Total execution time: 0.1956
DEBUG - 2022-11-14 11:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:29:38 --> No URI present. Default controller set.
DEBUG - 2022-11-14 11:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:59:38 --> Total execution time: 0.1140
DEBUG - 2022-11-14 11:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:59:47 --> Total execution time: 0.1763
DEBUG - 2022-11-14 11:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:00:19 --> Total execution time: 0.5850
DEBUG - 2022-11-14 11:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:01:10 --> Total execution time: 0.1750
DEBUG - 2022-11-14 11:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:01:14 --> Total execution time: 0.2197
DEBUG - 2022-11-14 11:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 11:31:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 11:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:02:18 --> Total execution time: 0.1727
DEBUG - 2022-11-14 11:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 11:33:12 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-14 11:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:05:52 --> Total execution time: 0.1919
DEBUG - 2022-11-14 11:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:06:15 --> Total execution time: 0.1722
DEBUG - 2022-11-14 11:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:41:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 11:41:21 --> 404 Page Not Found: Danessa-myricks-yummy-skin-blurring-balm-powder-656781html/index
DEBUG - 2022-11-14 11:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:14:08 --> Total execution time: 4.7398
DEBUG - 2022-11-14 11:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:14:19 --> Total execution time: 0.1108
DEBUG - 2022-11-14 11:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:15:59 --> Total execution time: 0.1138
DEBUG - 2022-11-14 11:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:16:06 --> Total execution time: 0.2046
DEBUG - 2022-11-14 11:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:16:14 --> Total execution time: 0.4425
DEBUG - 2022-11-14 11:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:16:15 --> Total execution time: 0.1950
DEBUG - 2022-11-14 11:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:16:47 --> Total execution time: 0.4665
DEBUG - 2022-11-14 11:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:16:54 --> Total execution time: 0.1583
DEBUG - 2022-11-14 11:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:16:58 --> Total execution time: 0.2017
DEBUG - 2022-11-14 11:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:17:03 --> Total execution time: 0.1670
DEBUG - 2022-11-14 11:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:17:09 --> Total execution time: 0.1759
DEBUG - 2022-11-14 11:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:17:14 --> Total execution time: 0.1950
DEBUG - 2022-11-14 11:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:17:18 --> Total execution time: 0.1839
DEBUG - 2022-11-14 11:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:17:19 --> Total execution time: 0.1990
DEBUG - 2022-11-14 11:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:17:22 --> Total execution time: 0.1802
DEBUG - 2022-11-14 11:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:47:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 11:47:29 --> 404 Page Not Found: Nwot-new-era-39thirty-2014-us-open-championship-stitched-graphic-golf-hat-sm-476594html/index
DEBUG - 2022-11-14 11:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:47:30 --> No URI present. Default controller set.
DEBUG - 2022-11-14 11:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:17:30 --> Total execution time: 0.1127
DEBUG - 2022-11-14 11:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:17:32 --> Total execution time: 0.1752
DEBUG - 2022-11-14 11:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:17:35 --> Total execution time: 0.1801
DEBUG - 2022-11-14 11:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:17:36 --> Total execution time: 0.1837
DEBUG - 2022-11-14 11:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:17:37 --> Total execution time: 0.2074
DEBUG - 2022-11-14 11:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:47:59 --> Total execution time: 0.1703
DEBUG - 2022-11-14 11:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:18:07 --> Total execution time: 0.1769
DEBUG - 2022-11-14 11:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:48:20 --> Total execution time: 0.1675
DEBUG - 2022-11-14 11:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:48:28 --> Total execution time: 0.1659
DEBUG - 2022-11-14 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:18:37 --> Total execution time: 0.1658
DEBUG - 2022-11-14 11:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:19:22 --> Total execution time: 0.4548
DEBUG - 2022-11-14 11:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:19:28 --> Total execution time: 0.1811
DEBUG - 2022-11-14 11:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:19:43 --> Total execution time: 0.1751
DEBUG - 2022-11-14 11:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:20:01 --> Total execution time: 0.1770
DEBUG - 2022-11-14 11:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:20:38 --> Total execution time: 0.1762
DEBUG - 2022-11-14 11:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:20:54 --> Total execution time: 0.1846
DEBUG - 2022-11-14 11:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:20:54 --> Total execution time: 0.2485
DEBUG - 2022-11-14 11:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:20:59 --> Total execution time: 0.1776
DEBUG - 2022-11-14 11:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:21:03 --> Total execution time: 0.4555
DEBUG - 2022-11-14 11:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:21:05 --> Total execution time: 0.1784
DEBUG - 2022-11-14 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:21:09 --> Total execution time: 0.1673
DEBUG - 2022-11-14 11:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:21:59 --> Total execution time: 0.1764
DEBUG - 2022-11-14 11:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:22:03 --> Total execution time: 0.1694
DEBUG - 2022-11-14 11:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 11:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:22:08 --> Total execution time: 0.1625
DEBUG - 2022-11-14 11:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:27:17 --> Total execution time: 0.9980
DEBUG - 2022-11-14 11:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:27:29 --> Total execution time: 0.4563
DEBUG - 2022-11-14 11:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:27:34 --> Total execution time: 0.2843
DEBUG - 2022-11-14 11:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:28:17 --> Total execution time: 0.2613
DEBUG - 2022-11-14 11:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 11:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 11:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:29:41 --> Total execution time: 0.4558
DEBUG - 2022-11-14 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:30:03 --> Total execution time: 0.1332
DEBUG - 2022-11-14 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:30:14 --> Total execution time: 0.4589
DEBUG - 2022-11-14 12:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:30:21 --> Total execution time: 0.1753
DEBUG - 2022-11-14 12:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:30:37 --> Total execution time: 0.1729
DEBUG - 2022-11-14 12:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:31:56 --> Total execution time: 0.4013
DEBUG - 2022-11-14 12:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:02:02 --> Total execution time: 0.2743
DEBUG - 2022-11-14 12:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:32:10 --> Total execution time: 0.4136
DEBUG - 2022-11-14 12:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:32:16 --> Total execution time: 0.2720
DEBUG - 2022-11-14 12:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:32:36 --> Total execution time: 0.2014
DEBUG - 2022-11-14 12:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:03:07 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:07 --> Total execution time: 0.1170
DEBUG - 2022-11-14 12:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:03:09 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:09 --> Total execution time: 0.1207
DEBUG - 2022-11-14 12:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:03:10 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:10 --> Total execution time: 0.1079
DEBUG - 2022-11-14 12:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:03:11 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:11 --> Total execution time: 0.1205
DEBUG - 2022-11-14 12:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:24 --> Total execution time: 0.1715
DEBUG - 2022-11-14 12:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:34:24 --> Total execution time: 0.1939
DEBUG - 2022-11-14 12:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:34:38 --> Total execution time: 0.1702
DEBUG - 2022-11-14 12:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:04:50 --> Total execution time: 0.1810
DEBUG - 2022-11-14 12:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:34:53 --> Total execution time: 0.2884
DEBUG - 2022-11-14 12:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:05:09 --> Total execution time: 0.1722
DEBUG - 2022-11-14 12:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:05:30 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:35:30 --> Total execution time: 0.1204
DEBUG - 2022-11-14 12:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:05:32 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:35:32 --> Total execution time: 0.1718
DEBUG - 2022-11-14 12:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:05:32 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:35:33 --> Total execution time: 0.1685
DEBUG - 2022-11-14 12:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:05:35 --> Total execution time: 0.1614
DEBUG - 2022-11-14 12:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:05:40 --> Total execution time: 0.1830
DEBUG - 2022-11-14 12:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:35:56 --> Total execution time: 0.2950
DEBUG - 2022-11-14 12:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:05:57 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:35:57 --> Total execution time: 0.1033
DEBUG - 2022-11-14 12:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:06:26 --> Total execution time: 0.1731
DEBUG - 2022-11-14 12:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:06:27 --> Total execution time: 0.1990
DEBUG - 2022-11-14 12:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:36:31 --> Total execution time: 0.2694
DEBUG - 2022-11-14 12:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:06:31 --> Total execution time: 0.1761
DEBUG - 2022-11-14 12:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:06:35 --> Total execution time: 0.1689
DEBUG - 2022-11-14 12:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:36:39 --> Total execution time: 0.1779
DEBUG - 2022-11-14 12:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:36:49 --> Total execution time: 0.2168
DEBUG - 2022-11-14 12:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:36:53 --> Total execution time: 0.1769
DEBUG - 2022-11-14 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:37:03 --> Total execution time: 0.1811
DEBUG - 2022-11-14 12:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:37:20 --> Total execution time: 0.1758
DEBUG - 2022-11-14 12:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:37:29 --> Total execution time: 0.2075
DEBUG - 2022-11-14 12:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:37:37 --> Total execution time: 0.2001
DEBUG - 2022-11-14 12:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:08:22 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:38:23 --> Total execution time: 0.1126
DEBUG - 2022-11-14 12:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:08:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 12:08:28 --> 404 Page Not Found: 2005-allstate-400-at-the-brickyard-polo-shirt-xl-826706html/index
DEBUG - 2022-11-14 12:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:08:33 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:38:33 --> Total execution time: 0.1830
DEBUG - 2022-11-14 12:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:09:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 12:09:59 --> 404 Page Not Found: Integrity-bride-doll-1996-898916html/index
DEBUG - 2022-11-14 12:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:09:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 12:09:59 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 12:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:11:08 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:41:08 --> Total execution time: 0.1161
DEBUG - 2022-11-14 12:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:42:01 --> Total execution time: 0.1809
DEBUG - 2022-11-14 12:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:12:02 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:42:02 --> Total execution time: 0.2558
DEBUG - 2022-11-14 12:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:42:41 --> Total execution time: 5.5202
DEBUG - 2022-11-14 12:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:43:18 --> Total execution time: 1.2924
DEBUG - 2022-11-14 12:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:43:20 --> Total execution time: 0.2154
DEBUG - 2022-11-14 12:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:43:27 --> Total execution time: 0.8410
DEBUG - 2022-11-14 12:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:43:45 --> Total execution time: 0.1876
DEBUG - 2022-11-14 12:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:14:09 --> Total execution time: 0.1869
DEBUG - 2022-11-14 12:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:44:20 --> Total execution time: 0.2954
DEBUG - 2022-11-14 12:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:16:31 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:46:33 --> Total execution time: 1.4210
DEBUG - 2022-11-14 12:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:46:43 --> Total execution time: 0.2655
DEBUG - 2022-11-14 12:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:47:17 --> Total execution time: 0.1774
DEBUG - 2022-11-14 12:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:47:57 --> Total execution time: 0.2721
DEBUG - 2022-11-14 12:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:48:58 --> Total execution time: 0.5242
DEBUG - 2022-11-14 12:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:49:07 --> Total execution time: 0.2091
DEBUG - 2022-11-14 12:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:22:05 --> Total execution time: 0.1713
DEBUG - 2022-11-14 12:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:53:50 --> Total execution time: 0.2183
DEBUG - 2022-11-14 12:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:54:14 --> Total execution time: 0.4763
DEBUG - 2022-11-14 12:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:54:14 --> Total execution time: 0.1162
DEBUG - 2022-11-14 12:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:54:21 --> Total execution time: 0.2297
DEBUG - 2022-11-14 12:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:54:34 --> Total execution time: 0.1815
DEBUG - 2022-11-14 12:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:54:38 --> Total execution time: 0.3991
DEBUG - 2022-11-14 12:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:54:44 --> Total execution time: 0.3046
DEBUG - 2022-11-14 12:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:24:45 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:54:45 --> Total execution time: 0.1164
DEBUG - 2022-11-14 12:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:25:06 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:55:07 --> Total execution time: 0.1087
DEBUG - 2022-11-14 12:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:55:15 --> Total execution time: 0.3909
DEBUG - 2022-11-14 12:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:26:35 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:56:36 --> Total execution time: 0.1718
DEBUG - 2022-11-14 12:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:56:42 --> Total execution time: 0.1846
DEBUG - 2022-11-14 12:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:26:42 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:56:42 --> Total execution time: 0.1080
DEBUG - 2022-11-14 12:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:26:43 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:56:43 --> Total execution time: 0.1253
DEBUG - 2022-11-14 12:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:56:55 --> Total execution time: 0.1732
DEBUG - 2022-11-14 12:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:57:10 --> Total execution time: 0.2130
DEBUG - 2022-11-14 12:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:57:26 --> Total execution time: 0.1869
DEBUG - 2022-11-14 12:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:57:31 --> Total execution time: 0.1768
DEBUG - 2022-11-14 12:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:57:39 --> Total execution time: 0.1657
DEBUG - 2022-11-14 12:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:59:39 --> Total execution time: 0.1758
DEBUG - 2022-11-14 12:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:59:57 --> Total execution time: 0.5509
DEBUG - 2022-11-14 12:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:29:59 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:59:59 --> Total execution time: 0.1341
DEBUG - 2022-11-14 12:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:30:00 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:30:14 --> Total execution time: 0.1684
DEBUG - 2022-11-14 12:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:30:24 --> Total execution time: 0.1744
DEBUG - 2022-11-14 12:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:30:31 --> Total execution time: 0.1780
DEBUG - 2022-11-14 12:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:30:39 --> Total execution time: 0.1803
DEBUG - 2022-11-14 12:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:31:37 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:31:43 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:32:29 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:38:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 12:38:43 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-14 12:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:50:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 12:50:31 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 12:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:50:31 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:50:31 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:53:16 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:53:25 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:53:27 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:53:34 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:56:20 --> No URI present. Default controller set.
DEBUG - 2022-11-14 12:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 12:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 12:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 12:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:01:07 --> No URI present. Default controller set.
DEBUG - 2022-11-14 13:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:05:31 --> No URI present. Default controller set.
DEBUG - 2022-11-14 13:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:12:17 --> No URI present. Default controller set.
DEBUG - 2022-11-14 13:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:13:47 --> No URI present. Default controller set.
DEBUG - 2022-11-14 13:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:17:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 13:17:29 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 13:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:18:03 --> No URI present. Default controller set.
DEBUG - 2022-11-14 13:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:18:05 --> No URI present. Default controller set.
DEBUG - 2022-11-14 13:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:20:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 13:20:31 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 13:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:24:27 --> No URI present. Default controller set.
DEBUG - 2022-11-14 13:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 13:33:10 --> 404 Page Not Found: New-balance-basketball-athletic-shoes-for-men-40649html/index
DEBUG - 2022-11-14 13:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 13:33:10 --> 404 Page Not Found: Rocky-mens-camouflage-insulated-hunting-jacket-coat-xxl-mossy-oak-new-break-up-255244html/index
DEBUG - 2022-11-14 13:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:35:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 13:35:31 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 13:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:40:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 13:40:02 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 13:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:45:52 --> No URI present. Default controller set.
DEBUG - 2022-11-14 13:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:50:31 --> No URI present. Default controller set.
DEBUG - 2022-11-14 13:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 13:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:05:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 14:05:31 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 14:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:17:51 --> No URI present. Default controller set.
DEBUG - 2022-11-14 14:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:17:51 --> No URI present. Default controller set.
DEBUG - 2022-11-14 14:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:17:52 --> No URI present. Default controller set.
DEBUG - 2022-11-14 14:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:18:45 --> No URI present. Default controller set.
DEBUG - 2022-11-14 14:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:20:31 --> No URI present. Default controller set.
DEBUG - 2022-11-14 14:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 14:34:11 --> 404 Page Not Found: Sitemap_1xml/index
DEBUG - 2022-11-14 14:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 14:34:11 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-11-14 14:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:42:22 --> No URI present. Default controller set.
DEBUG - 2022-11-14 14:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:42:39 --> No URI present. Default controller set.
DEBUG - 2022-11-14 14:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:44:29 --> No URI present. Default controller set.
DEBUG - 2022-11-14 14:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 14:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:47:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 14:47:29 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 14:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:50:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 14:50:31 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 14:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:53:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 14:53:02 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-14 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 15:00:24 --> No URI present. Default controller set.
DEBUG - 2022-11-14 15:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 15:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 15:12:19 --> No URI present. Default controller set.
DEBUG - 2022-11-14 15:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 15:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 15:23:30 --> No URI present. Default controller set.
DEBUG - 2022-11-14 15:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 15:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 15:27:39 --> No URI present. Default controller set.
DEBUG - 2022-11-14 15:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 15:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 15:31:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 15:31:26 --> 404 Page Not Found: Sitemap_1xml/index
DEBUG - 2022-11-14 15:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 15:31:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 15:31:30 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-14 15:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 15:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 15:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 15:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 15:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 15:50:20 --> No URI present. Default controller set.
DEBUG - 2022-11-14 15:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 15:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 15:50:22 --> No URI present. Default controller set.
DEBUG - 2022-11-14 15:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 15:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 15:50:43 --> No URI present. Default controller set.
DEBUG - 2022-11-14 15:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 15:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 15:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 15:51:29 --> No URI present. Default controller set.
DEBUG - 2022-11-14 15:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 15:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:09:59 --> Total execution time: 0.1872
DEBUG - 2022-11-14 16:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:10:22 --> No URI present. Default controller set.
DEBUG - 2022-11-14 16:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:12:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 16:12:33 --> 404 Page Not Found: Nintendo-ds-lite-in-pink-818813html/index
DEBUG - 2022-11-14 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:29:11 --> No URI present. Default controller set.
DEBUG - 2022-11-14 16:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 16:32:57 --> 404 Page Not Found: List_teacher/index
DEBUG - 2022-11-14 16:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:48:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 16:48:25 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-14 16:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:54:31 --> No URI present. Default controller set.
DEBUG - 2022-11-14 16:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:54:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 16:54:32 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 16:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:57:43 --> No URI present. Default controller set.
DEBUG - 2022-11-14 16:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:57:45 --> No URI present. Default controller set.
DEBUG - 2022-11-14 16:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:57:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 16:57:47 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-11-14 16:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:57:47 --> No URI present. Default controller set.
DEBUG - 2022-11-14 16:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:57:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 16:57:49 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-11-14 16:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:57:49 --> No URI present. Default controller set.
DEBUG - 2022-11-14 16:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 16:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:58:15 --> No URI present. Default controller set.
DEBUG - 2022-11-14 16:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:01:53 --> No URI present. Default controller set.
DEBUG - 2022-11-14 17:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:15:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 17:15:22 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-14 17:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 17:18:14 --> 404 Page Not Found: Event/inspiration-memento-live-commission-art-2
DEBUG - 2022-11-14 17:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:25:58 --> No URI present. Default controller set.
DEBUG - 2022-11-14 17:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:28:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 17:28:50 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-14 17:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 17:33:28 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-11-14 17:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:37:24 --> No URI present. Default controller set.
DEBUG - 2022-11-14 17:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:42:19 --> No URI present. Default controller set.
DEBUG - 2022-11-14 17:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:47:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 17:47:29 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 17:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:50:29 --> No URI present. Default controller set.
DEBUG - 2022-11-14 17:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:52:33 --> No URI present. Default controller set.
DEBUG - 2022-11-14 17:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:55:47 --> No URI present. Default controller set.
DEBUG - 2022-11-14 17:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 17:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:09:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 18:09:16 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-14 18:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:22:44 --> No URI present. Default controller set.
DEBUG - 2022-11-14 18:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:42:04 --> No URI present. Default controller set.
DEBUG - 2022-11-14 18:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:42:37 --> No URI present. Default controller set.
DEBUG - 2022-11-14 18:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:44:17 --> No URI present. Default controller set.
DEBUG - 2022-11-14 18:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:49:30 --> No URI present. Default controller set.
DEBUG - 2022-11-14 18:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:51:40 --> No URI present. Default controller set.
DEBUG - 2022-11-14 18:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 18:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:01:39 --> No URI present. Default controller set.
DEBUG - 2022-11-14 19:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:01:55 --> No URI present. Default controller set.
DEBUG - 2022-11-14 19:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:06:28 --> No URI present. Default controller set.
DEBUG - 2022-11-14 19:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:07:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 19:07:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 19:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:14:08 --> No URI present. Default controller set.
DEBUG - 2022-11-14 19:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:15:59 --> No URI present. Default controller set.
DEBUG - 2022-11-14 19:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:17:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 19:17:29 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 19:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:17:39 --> Total execution time: 0.1795
DEBUG - 2022-11-14 19:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:17:41 --> Total execution time: 0.2174
DEBUG - 2022-11-14 19:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:17:42 --> Total execution time: 0.1844
DEBUG - 2022-11-14 19:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:17:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 19:17:47 --> 404 Page Not Found: Sitemap_1xml/index
DEBUG - 2022-11-14 19:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:17:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 19:17:47 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-11-14 19:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:21:46 --> No URI present. Default controller set.
DEBUG - 2022-11-14 19:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:22:55 --> No URI present. Default controller set.
DEBUG - 2022-11-14 19:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:26:24 --> No URI present. Default controller set.
DEBUG - 2022-11-14 19:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:28:26 --> No URI present. Default controller set.
DEBUG - 2022-11-14 19:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:29:07 --> Total execution time: 0.1710
DEBUG - 2022-11-14 19:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:29:09 --> Total execution time: 0.2106
DEBUG - 2022-11-14 19:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:29:09 --> Total execution time: 0.1863
DEBUG - 2022-11-14 19:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:30:11 --> No URI present. Default controller set.
DEBUG - 2022-11-14 19:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:30:19 --> Total execution time: 0.1647
DEBUG - 2022-11-14 19:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:30:21 --> Total execution time: 0.1647
DEBUG - 2022-11-14 19:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:30:21 --> Total execution time: 0.1786
DEBUG - 2022-11-14 19:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:33:21 --> No URI present. Default controller set.
DEBUG - 2022-11-14 19:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:35:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 19:35:05 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-14 19:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:35:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 19:35:09 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-14 19:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:38:35 --> No URI present. Default controller set.
DEBUG - 2022-11-14 19:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:50:43 --> Total execution time: 0.1740
DEBUG - 2022-11-14 19:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 19:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:53:20 --> No URI present. Default controller set.
DEBUG - 2022-11-14 19:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:01:21 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:02:35 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:03:03 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:03:27 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:03:28 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:04:54 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:05:19 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:23 --> Total execution time: 0.1680
DEBUG - 2022-11-14 20:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:29 --> Total execution time: 0.1709
DEBUG - 2022-11-14 20:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:05:29 --> Total execution time: 0.3671
DEBUG - 2022-11-14 20:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:09 --> Total execution time: 0.1660
DEBUG - 2022-11-14 20:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:11 --> Total execution time: 0.1720
DEBUG - 2022-11-14 20:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:11 --> Total execution time: 0.1736
DEBUG - 2022-11-14 20:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:06:28 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:08:22 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:08:40 --> Total execution time: 0.1754
DEBUG - 2022-11-14 20:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:08:41 --> Total execution time: 0.1595
DEBUG - 2022-11-14 20:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:08:49 --> Total execution time: 0.1738
DEBUG - 2022-11-14 20:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:09:24 --> Total execution time: 0.1076
DEBUG - 2022-11-14 20:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:09:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 20:09:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 20:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:09:43 --> Total execution time: 0.1641
DEBUG - 2022-11-14 20:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:09:44 --> Total execution time: 0.3969
DEBUG - 2022-11-14 20:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:09:58 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:13:22 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:13:52 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:17:47 --> Total execution time: 0.1833
DEBUG - 2022-11-14 20:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:17:58 --> Total execution time: 0.2486
DEBUG - 2022-11-14 20:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:20:39 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 20:27:31 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-14 20:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:29:31 --> Total execution time: 0.1624
DEBUG - 2022-11-14 20:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:29:36 --> Total execution time: 0.1682
DEBUG - 2022-11-14 20:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:29:42 --> Total execution time: 0.1708
DEBUG - 2022-11-14 20:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:34:11 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:34:44 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:35:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 20:35:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 20:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:37:03 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:37:03 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:38:06 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:38:07 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:42:51 --> Total execution time: 0.1690
DEBUG - 2022-11-14 20:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:44:58 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:47:28 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:47:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 20:47:29 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 20:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:50:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 20:50:39 --> 404 Page Not Found: Wp-includes/versions.php
DEBUG - 2022-11-14 20:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:50:47 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:51:57 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:52:23 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:52:51 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:52:52 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:52:53 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:52:53 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:52:53 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:52:54 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:52:56 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:52:57 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:53:02 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:54:18 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:54:33 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:54:40 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 20:54:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 20:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:56:09 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:56:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 20:56:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 20:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:56:28 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:57:04 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:13 --> Total execution time: 0.1739
DEBUG - 2022-11-14 20:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:14 --> Total execution time: 0.2444
DEBUG - 2022-11-14 20:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:15 --> Total execution time: 0.1756
DEBUG - 2022-11-14 20:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:57:22 --> No URI present. Default controller set.
DEBUG - 2022-11-14 20:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:57:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 20:57:58 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 20:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:59:34 --> Total execution time: 0.1657
DEBUG - 2022-11-14 20:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:59:39 --> Total execution time: 0.1856
DEBUG - 2022-11-14 20:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 20:59:39 --> Total execution time: 0.1649
DEBUG - 2022-11-14 21:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:00:58 --> Total execution time: 0.1617
DEBUG - 2022-11-14 21:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:01:21 --> Total execution time: 0.1772
DEBUG - 2022-11-14 21:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:01:48 --> Total execution time: 0.1667
DEBUG - 2022-11-14 21:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:02:02 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:02:27 --> Total execution time: 0.1886
DEBUG - 2022-11-14 21:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:02:36 --> Total execution time: 0.1761
DEBUG - 2022-11-14 21:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:02:39 --> Total execution time: 0.1713
DEBUG - 2022-11-14 21:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:02:45 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:07:28 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:20:28 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:21:44 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:22:43 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:25:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 21:25:33 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-14 21:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:36:46 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:40:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 21:40:09 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-14 21:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:40:15 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:42:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 21:42:58 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-14 21:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:43:52 --> Total execution time: 0.1761
DEBUG - 2022-11-14 21:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:44:17 --> Total execution time: 0.1708
DEBUG - 2022-11-14 21:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:44:22 --> Total execution time: 0.1708
DEBUG - 2022-11-14 21:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:44:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 21:44:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 21:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:45:05 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:11 --> Total execution time: 0.1644
DEBUG - 2022-11-14 21:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:13 --> Total execution time: 0.1724
DEBUG - 2022-11-14 21:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:32 --> Total execution time: 0.1693
DEBUG - 2022-11-14 21:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:51 --> Total execution time: 0.1899
DEBUG - 2022-11-14 21:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:45:59 --> Total execution time: 0.1705
DEBUG - 2022-11-14 21:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:46:37 --> Total execution time: 0.1686
DEBUG - 2022-11-14 21:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:53:40 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 21:53:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-14 21:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:55:16 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:55:30 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:55:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 21:55:43 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-11-14 21:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:55:54 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:56:17 --> Total execution time: 0.1776
DEBUG - 2022-11-14 21:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:56:30 --> Total execution time: 0.2396
DEBUG - 2022-11-14 21:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:57:34 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:57:49 --> Total execution time: 0.1664
DEBUG - 2022-11-14 21:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:57:54 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:58:05 --> Total execution time: 0.1851
DEBUG - 2022-11-14 21:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:58:39 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:59:07 --> No URI present. Default controller set.
DEBUG - 2022-11-14 21:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 21:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 21:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 21:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:00:27 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:00:33 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 22:02:44 --> 404 Page Not Found: Well-known/traffic-advice
DEBUG - 2022-11-14 22:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:05:28 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:09:43 --> Total execution time: 0.1723
DEBUG - 2022-11-14 22:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:10:06 --> Total execution time: 0.2056
DEBUG - 2022-11-14 22:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:12:39 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:13:44 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:13:57 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:17:56 --> Total execution time: 0.4947
DEBUG - 2022-11-14 22:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:18:13 --> Total execution time: 0.2443
DEBUG - 2022-11-14 22:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:19:52 --> Total execution time: 0.1783
DEBUG - 2022-11-14 22:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:20:00 --> Total execution time: 0.1905
DEBUG - 2022-11-14 22:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:27:04 --> Total execution time: 0.2167
DEBUG - 2022-11-14 22:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:27:09 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:27:12 --> Total execution time: 0.2624
DEBUG - 2022-11-14 22:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:27:18 --> Total execution time: 0.1898
DEBUG - 2022-11-14 22:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:28:22 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:28:44 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:30:03 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:30:09 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:45 --> Total execution time: 0.1661
DEBUG - 2022-11-14 22:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:31:40 --> Total execution time: 0.1773
DEBUG - 2022-11-14 22:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:31:42 --> Total execution time: 0.2075
DEBUG - 2022-11-14 22:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:31:42 --> Total execution time: 0.1669
DEBUG - 2022-11-14 22:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:32:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 22:32:42 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-11-14 22:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:34:15 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:34:16 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:36:29 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:41 --> Total execution time: 0.1602
DEBUG - 2022-11-14 22:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:41:05 --> Total execution time: 0.6101
DEBUG - 2022-11-14 22:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:41:16 --> Total execution time: 0.2877
DEBUG - 2022-11-14 22:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:44:38 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:45:10 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:45:23 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:45:54 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:46:49 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:51:30 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:53:26 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:53:55 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:56:50 --> No URI present. Default controller set.
DEBUG - 2022-11-14 22:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 22:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 22:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 22:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:06:07 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:06:17 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:09:49 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:19:36 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:23:26 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:27:55 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:33:34 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:33:37 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:33:48 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:52 --> Total execution time: 0.1792
DEBUG - 2022-11-14 23:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:53 --> Total execution time: 0.1750
DEBUG - 2022-11-14 23:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:33:54 --> Total execution time: 0.1658
DEBUG - 2022-11-14 23:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:35:08 --> Total execution time: 0.1813
DEBUG - 2022-11-14 23:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:35:12 --> Total execution time: 0.1872
DEBUG - 2022-11-14 23:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:35:18 --> Total execution time: 0.1765
DEBUG - 2022-11-14 23:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:35:26 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:35:38 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:39:52 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:40:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 23:40:42 --> 404 Page Not Found: Well-known/traffic-advice
DEBUG - 2022-11-14 23:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:40:54 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:41:11 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:43:17 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 23:44:46 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-11-14 23:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 23:44:46 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-11-14 23:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:45:28 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 23:49:46 --> 404 Page Not Found: Coca-cola-polar-bear-musical-house-of-lloyd-christmas-around-the-world-nib-471318html/index
DEBUG - 2022-11-14 23:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:52:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 23:52:15 --> 404 Page Not Found: Sitemap_1xml/index
DEBUG - 2022-11-14 23:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:52:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-14 23:52:15 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-11-14 23:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:54:07 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:54:15 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-14 23:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 23:59:06 --> No URI present. Default controller set.
DEBUG - 2022-11-14 23:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 23:59:07 --> Encryption: Auto-configured driver 'openssl'.
