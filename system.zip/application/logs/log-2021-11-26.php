<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-26 13:07:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 13:07:31 --> Total execution time: 0.1531
DEBUG - 2021-11-26 13:07:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 13:07:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 17:37:33 --> Total execution time: 0.0781
DEBUG - 2021-11-26 13:07:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 17:37:39 --> Total execution time: 0.0587
DEBUG - 2021-11-26 13:07:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 17:37:46 --> Total execution time: 0.0611
DEBUG - 2021-11-26 13:07:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 17:37:52 --> Total execution time: 0.0511
DEBUG - 2021-11-26 13:07:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 17:37:53 --> Total execution time: 0.0566
DEBUG - 2021-11-26 13:08:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 17:38:00 --> Total execution time: 0.0630
DEBUG - 2021-11-26 13:08:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 17:38:02 --> Total execution time: 0.0496
DEBUG - 2021-11-26 13:22:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 17:52:19 --> Total execution time: 1.9121
DEBUG - 2021-11-26 13:22:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 17:52:21 --> Total execution time: 0.0872
DEBUG - 2021-11-26 13:22:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:22:24 --> UTF-8 Support Enabled
ERROR - 2021-11-26 13:22:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:22:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:22:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 13:22:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:22:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 13:22:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:22:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:22:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:22:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 13:22:24 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 13:22:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:22:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:22:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:22:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 13:22:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:22:24 --> UTF-8 Support Enabled
ERROR - 2021-11-26 13:22:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:22:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 13:22:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 17:53:16 --> Total execution time: 0.0490
DEBUG - 2021-11-26 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 13:23:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 13:23:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 13:23:16 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 13:23:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 13:23:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 13:23:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 13:23:16 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 13:23:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:23:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 17:53:22 --> Total execution time: 0.1006
DEBUG - 2021-11-26 13:23:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:23:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 13:23:22 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 13:23:22 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 13:23:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:23:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:23:22 --> UTF-8 Support Enabled
ERROR - 2021-11-26 13:23:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:23:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 13:23:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:23:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 13:23:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:23:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:23:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 13:23:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:23:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 13:23:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 13:45:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:15:14 --> Total execution time: 0.0698
DEBUG - 2021-11-26 13:45:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:15:39 --> Total execution time: 0.0490
DEBUG - 2021-11-26 13:45:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:15:48 --> Total execution time: 0.0693
DEBUG - 2021-11-26 13:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:15:53 --> Total execution time: 0.0987
DEBUG - 2021-11-26 13:45:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:15:57 --> Total execution time: 0.0754
DEBUG - 2021-11-26 13:45:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:15:58 --> Total execution time: 0.0487
DEBUG - 2021-11-26 13:46:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:16:38 --> Total execution time: 0.0490
DEBUG - 2021-11-26 13:46:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:16:41 --> Total execution time: 0.0474
DEBUG - 2021-11-26 13:46:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:16:59 --> Total execution time: 0.0672
DEBUG - 2021-11-26 13:47:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:17:01 --> Total execution time: 0.0708
DEBUG - 2021-11-26 13:47:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:17:12 --> Total execution time: 0.0684
DEBUG - 2021-11-26 13:47:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:17:25 --> Total execution time: 0.0494
DEBUG - 2021-11-26 13:47:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:17:26 --> Total execution time: 0.0733
DEBUG - 2021-11-26 13:47:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:17:39 --> Total execution time: 0.0489
DEBUG - 2021-11-26 13:48:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:18:09 --> Total execution time: 0.0491
DEBUG - 2021-11-26 13:48:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:18:11 --> Total execution time: 0.0657
DEBUG - 2021-11-26 13:48:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:18:12 --> Total execution time: 0.0476
DEBUG - 2021-11-26 13:48:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:18:13 --> Total execution time: 0.0879
DEBUG - 2021-11-26 13:48:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:18:14 --> Total execution time: 0.0514
DEBUG - 2021-11-26 13:48:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:18:22 --> Total execution time: 0.0468
DEBUG - 2021-11-26 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:18:32 --> Total execution time: 0.0475
DEBUG - 2021-11-26 13:57:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:27:32 --> Total execution time: 0.0502
DEBUG - 2021-11-26 13:57:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:27:44 --> Total execution time: 0.0467
DEBUG - 2021-11-26 13:57:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:27:53 --> Total execution time: 0.0497
DEBUG - 2021-11-26 13:58:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:28:12 --> Total execution time: 0.0487
DEBUG - 2021-11-26 13:58:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:28:14 --> Total execution time: 0.0452
DEBUG - 2021-11-26 13:58:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:28:33 --> Total execution time: 0.0488
DEBUG - 2021-11-26 13:58:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:28:52 --> Total execution time: 0.0496
DEBUG - 2021-11-26 13:59:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 13:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 13:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:29:38 --> Total execution time: 0.0505
DEBUG - 2021-11-26 14:03:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:33:40 --> Total execution time: 0.0631
DEBUG - 2021-11-26 14:04:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:34:09 --> Total execution time: 0.0513
DEBUG - 2021-11-26 14:06:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:36:50 --> Total execution time: 0.0498
DEBUG - 2021-11-26 14:07:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:37:46 --> Total execution time: 0.0516
DEBUG - 2021-11-26 14:08:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:38:02 --> Total execution time: 0.0696
DEBUG - 2021-11-26 14:08:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:38:09 --> Total execution time: 0.0579
DEBUG - 2021-11-26 14:08:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:38:23 --> Total execution time: 0.0766
DEBUG - 2021-11-26 14:08:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:38:28 --> Total execution time: 0.0474
DEBUG - 2021-11-26 14:11:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:41:03 --> Total execution time: 0.0544
DEBUG - 2021-11-26 14:11:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:41:06 --> Total execution time: 0.0625
DEBUG - 2021-11-26 14:11:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:41:09 --> Total execution time: 0.0480
DEBUG - 2021-11-26 14:11:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:41:13 --> Total execution time: 0.0690
DEBUG - 2021-11-26 14:11:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:41:18 --> Total execution time: 0.0483
DEBUG - 2021-11-26 14:11:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:41:22 --> Total execution time: 0.0637
DEBUG - 2021-11-26 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:41:25 --> Total execution time: 0.0482
DEBUG - 2021-11-26 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:41:27 --> Total execution time: 0.0472
DEBUG - 2021-11-26 14:11:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:41:33 --> Total execution time: 0.0477
DEBUG - 2021-11-26 14:11:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:41:56 --> Total execution time: 0.0675
DEBUG - 2021-11-26 14:12:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:42:04 --> Total execution time: 0.0479
DEBUG - 2021-11-26 14:19:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:49:09 --> Total execution time: 0.0529
DEBUG - 2021-11-26 14:19:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:49:11 --> Total execution time: 0.0507
DEBUG - 2021-11-26 14:19:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:49:32 --> Total execution time: 0.0564
DEBUG - 2021-11-26 14:19:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:49:57 --> Total execution time: 0.0967
DEBUG - 2021-11-26 14:20:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:50:00 --> Total execution time: 0.0460
DEBUG - 2021-11-26 14:20:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:50:01 --> Total execution time: 0.0824
DEBUG - 2021-11-26 14:20:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:50:02 --> Total execution time: 0.0452
DEBUG - 2021-11-26 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:50:05 --> Total execution time: 0.0612
DEBUG - 2021-11-26 14:20:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:50:07 --> Total execution time: 0.0482
DEBUG - 2021-11-26 14:20:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:50:34 --> Total execution time: 0.0873
DEBUG - 2021-11-26 14:20:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:50:36 --> Total execution time: 0.0457
DEBUG - 2021-11-26 14:20:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:50:37 --> Total execution time: 0.0605
DEBUG - 2021-11-26 14:20:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:50:40 --> Total execution time: 0.0466
DEBUG - 2021-11-26 14:20:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:50:42 --> Total execution time: 0.0496
DEBUG - 2021-11-26 14:21:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:51:01 --> Total execution time: 0.1149
DEBUG - 2021-11-26 14:21:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:51:02 --> Total execution time: 0.0444
DEBUG - 2021-11-26 14:21:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:51:05 --> Total execution time: 0.0595
DEBUG - 2021-11-26 14:21:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:51:10 --> Total execution time: 0.0492
DEBUG - 2021-11-26 14:21:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:51:17 --> Total execution time: 0.0818
DEBUG - 2021-11-26 14:21:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:51:20 --> Total execution time: 0.0460
DEBUG - 2021-11-26 14:21:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:51:21 --> Total execution time: 0.0455
DEBUG - 2021-11-26 14:21:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:51:25 --> Total execution time: 0.0475
DEBUG - 2021-11-26 14:23:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:53:43 --> Total execution time: 0.0483
DEBUG - 2021-11-26 14:24:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:24:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 14:24:15 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 14:24:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 14:24:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:24:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 14:24:15 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 14:24:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 14:24:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 14:24:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 14:24:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:24:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 14:24:15 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 14:24:15 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 14:24:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 14:24:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:54:17 --> Total execution time: 0.0562
DEBUG - 2021-11-26 14:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 14:24:18 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 14:24:18 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 14:24:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 14:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 14:24:18 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 14:24:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 14:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 14:24:18 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 14:24:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 14:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 14:24:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 14:25:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:55:06 --> Total execution time: 0.0534
DEBUG - 2021-11-26 14:25:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:25:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:25:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 14:25:06 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 14:25:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 14:25:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:25:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:25:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 14:25:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 14:25:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 14:25:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 14:25:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:25:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:25:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:25:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:25:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 14:25:06 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 14:25:06 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 14:25:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 14:25:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 14:25:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 14:25:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:55:40 --> Total execution time: 0.0738
DEBUG - 2021-11-26 14:26:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:56:39 --> Total execution time: 0.0758
DEBUG - 2021-11-26 14:27:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:57:29 --> Total execution time: 0.0505
DEBUG - 2021-11-26 14:28:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:58:12 --> Total execution time: 0.0500
DEBUG - 2021-11-26 14:28:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:58:36 --> Total execution time: 0.0624
DEBUG - 2021-11-26 14:29:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 18:59:01 --> Total execution time: 0.0567
DEBUG - 2021-11-26 14:32:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:02:54 --> Total execution time: 0.0758
DEBUG - 2021-11-26 14:36:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:06:05 --> Total execution time: 0.0717
DEBUG - 2021-11-26 14:36:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 14:36:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:06:09 --> Total execution time: 0.0443
DEBUG - 2021-11-26 14:36:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 14:36:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:06:34 --> Total execution time: 0.0467
DEBUG - 2021-11-26 14:37:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:07:28 --> Total execution time: 0.0500
DEBUG - 2021-11-26 14:37:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 14:37:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:07:32 --> Total execution time: 0.0474
DEBUG - 2021-11-26 14:39:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:09:39 --> Total execution time: 0.0565
DEBUG - 2021-11-26 14:39:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:09:58 --> Total execution time: 0.0481
DEBUG - 2021-11-26 14:40:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:10:06 --> Total execution time: 0.0488
DEBUG - 2021-11-26 14:40:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:10:27 --> Total execution time: 0.0479
DEBUG - 2021-11-26 14:40:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:10:57 --> Total execution time: 0.0593
DEBUG - 2021-11-26 14:41:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:11:02 --> Total execution time: 0.0716
DEBUG - 2021-11-26 14:44:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:44:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-26 19:14:07 --> Severity: Notice --> Constant SITE_NAME already defined C:\xampp\htdocs\soumya\loan\application\core\DB_Controller.php 35
ERROR - 2021-11-26 19:14:07 --> Severity: Notice --> Constant SITE_NAME already defined C:\xampp\htdocs\soumya\loan\application\core\DB_Controller.php 36
ERROR - 2021-11-26 19:14:07 --> Severity: Notice --> Constant SITE_NAME already defined C:\xampp\htdocs\soumya\loan\application\core\DB_Controller.php 37
ERROR - 2021-11-26 19:14:07 --> Severity: Notice --> Constant SITE_NAME already defined C:\xampp\htdocs\soumya\loan\application\core\DB_Controller.php 38
DEBUG - 2021-11-26 19:14:07 --> Total execution time: 0.0692
DEBUG - 2021-11-26 14:44:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:14:16 --> Total execution time: 0.0955
DEBUG - 2021-11-26 14:45:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 14:47:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:17:49 --> Total execution time: 0.0478
DEBUG - 2021-11-26 14:47:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:17:57 --> Total execution time: 0.0460
DEBUG - 2021-11-26 14:48:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:18:42 --> Total execution time: 0.0695
DEBUG - 2021-11-26 14:49:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:19:24 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 19:19:24 --> You did not select a file to upload.
DEBUG - 2021-11-26 14:49:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:19:24 --> Total execution time: 0.0449
DEBUG - 2021-11-26 14:50:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:20:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 14:50:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:20:40 --> Total execution time: 0.0447
DEBUG - 2021-11-26 14:51:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:21:51 --> Total execution time: 0.0499
DEBUG - 2021-11-26 14:52:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:22:52 --> Total execution time: 0.0491
DEBUG - 2021-11-26 14:53:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:23:29 --> Total execution time: 0.0556
DEBUG - 2021-11-26 14:53:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:23:37 --> Total execution time: 0.0496
DEBUG - 2021-11-26 14:54:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:24:22 --> Total execution time: 0.0713
DEBUG - 2021-11-26 14:54:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:24:40 --> Total execution time: 0.0497
DEBUG - 2021-11-26 14:55:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:25:02 --> Total execution time: 0.0586
DEBUG - 2021-11-26 14:55:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:25:23 --> Total execution time: 0.0466
DEBUG - 2021-11-26 14:56:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:26:31 --> Total execution time: 0.0520
DEBUG - 2021-11-26 14:57:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:27:20 --> Total execution time: 0.0527
DEBUG - 2021-11-26 14:57:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:27:31 --> Total execution time: 0.0569
DEBUG - 2021-11-26 14:57:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:27:59 --> Total execution time: 0.0542
DEBUG - 2021-11-26 14:58:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 14:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 14:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:28:38 --> Total execution time: 0.0467
DEBUG - 2021-11-26 15:02:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:32:38 --> Total execution time: 0.0563
DEBUG - 2021-11-26 15:02:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:32:41 --> Total execution time: 0.0449
DEBUG - 2021-11-26 15:25:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:55:52 --> Total execution time: 0.0750
DEBUG - 2021-11-26 15:26:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:56:02 --> Total execution time: 0.0706
DEBUG - 2021-11-26 15:26:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:56:20 --> Total execution time: 0.0907
DEBUG - 2021-11-26 15:29:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:29:27 --> Severity: error --> Exception: syntax error, unexpected '}', expecting elseif (T_ELSEIF) or else (T_ELSE) or endif (T_ENDIF) C:\xampp\htdocs\soumya\loan\application\controllers\Admin\Profile_Controller.php 16
DEBUG - 2021-11-26 15:29:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 19:59:57 --> Total execution time: 0.0688
DEBUG - 2021-11-26 15:31:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:01:13 --> Total execution time: 0.0508
DEBUG - 2021-11-26 15:32:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:02:03 --> Total execution time: 0.0501
DEBUG - 2021-11-26 15:32:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 15:32:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:02:19 --> Total execution time: 0.0472
DEBUG - 2021-11-26 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:02:33 --> Total execution time: 0.0603
DEBUG - 2021-11-26 15:34:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:04:25 --> Total execution time: 0.0606
DEBUG - 2021-11-26 15:35:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:05:05 --> Total execution time: 0.0576
DEBUG - 2021-11-26 15:35:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:05:19 --> Total execution time: 0.0682
DEBUG - 2021-11-26 15:35:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:05:33 --> Total execution time: 0.0807
DEBUG - 2021-11-26 15:35:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:05:50 --> Total execution time: 0.0731
DEBUG - 2021-11-26 15:36:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:06:07 --> Total execution time: 0.0465
DEBUG - 2021-11-26 15:36:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:06:49 --> Total execution time: 0.0582
DEBUG - 2021-11-26 15:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:39:37 --> UTF-8 Support Enabled
ERROR - 2021-11-26 15:39:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:39:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:39:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:39:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:39:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:39:37 --> UTF-8 Support Enabled
ERROR - 2021-11-26 15:39:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:39:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:39:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:39:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:39:37 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 15:39:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:39:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:39:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:40:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:10:17 --> Total execution time: 0.0642
DEBUG - 2021-11-26 15:40:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:40:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:40:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:40:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:40:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:40:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:40:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:40:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:40:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:40:17 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 15:40:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:40:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:40:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:40:17 --> UTF-8 Support Enabled
ERROR - 2021-11-26 15:40:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:40:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:40:17 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 15:40:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:40:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:40:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:40:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:41:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:11:37 --> Total execution time: 0.0515
DEBUG - 2021-11-26 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:41:38 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 15:41:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:41:38 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 15:41:38 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 15:41:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:41:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:41:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:41:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:42:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:12:06 --> Total execution time: 0.0734
DEBUG - 2021-11-26 15:45:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:15:05 --> Total execution time: 0.0489
DEBUG - 2021-11-26 15:45:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 15:45:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:15:18 --> Total execution time: 0.0478
DEBUG - 2021-11-26 15:45:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:45:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:45:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:45:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:45:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:45:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:45:21 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 15:45:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:45:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:45:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:45:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:45:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:45:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:45:21 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 15:45:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:45:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:45:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 15:45:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:15:27 --> Total execution time: 0.0531
DEBUG - 2021-11-26 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:16:05 --> Total execution time: 0.0663
DEBUG - 2021-11-26 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:46:05 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 15:46:05 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 15:46:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:46:05 --> UTF-8 Support Enabled
ERROR - 2021-11-26 15:46:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:46:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:46:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 15:46:05 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 15:46:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 15:46:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:16:15 --> Total execution time: 0.0448
DEBUG - 2021-11-26 15:46:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:16:20 --> Total execution time: 0.0450
DEBUG - 2021-11-26 15:46:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 15:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 15:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:16:45 --> Total execution time: 0.0747
DEBUG - 2021-11-26 16:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:15:58 --> UTF-8 Support Enabled
ERROR - 2021-11-26 16:15:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:15:58 --> UTF-8 Support Enabled
ERROR - 2021-11-26 16:15:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:15:58 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:15:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:15:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:15:58 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:15:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:15:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:20:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:50:12 --> Total execution time: 0.0715
DEBUG - 2021-11-26 16:20:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:50:34 --> Total execution time: 0.0507
DEBUG - 2021-11-26 16:21:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:51:15 --> Total execution time: 0.0618
DEBUG - 2021-11-26 16:24:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:54:38 --> Total execution time: 0.0496
DEBUG - 2021-11-26 16:25:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:55:13 --> Total execution time: 0.0783
DEBUG - 2021-11-26 16:25:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:25:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:25:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:25:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:25:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:25:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:25:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:25:15 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:25:15 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:25:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:25:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:25:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:25:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:25:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:25:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:25:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:25:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:25:15 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:25:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:25:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:25:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:56:39 --> Total execution time: 0.0554
DEBUG - 2021-11-26 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:26:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:26:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:26:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:26:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:26:40 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:26:40 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:26:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:26:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:27:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 20:57:02 --> Total execution time: 0.0573
DEBUG - 2021-11-26 16:30:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:00:19 --> Total execution time: 0.0535
DEBUG - 2021-11-26 16:32:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:02:08 --> Total execution time: 0.0833
DEBUG - 2021-11-26 16:32:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:02:28 --> Total execution time: 0.0486
DEBUG - 2021-11-26 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:03:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 21:03:27 --> You did not select a file to upload.
DEBUG - 2021-11-26 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:03:27 --> Total execution time: 0.0448
DEBUG - 2021-11-26 16:33:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:03:30 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 21:03:30 --> You did not select a file to upload.
DEBUG - 2021-11-26 16:33:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:03:30 --> Total execution time: 0.0460
DEBUG - 2021-11-26 16:34:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:04:00 --> Total execution time: 0.0881
DEBUG - 2021-11-26 16:34:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:04:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 16:34:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:04:31 --> Total execution time: 0.0662
DEBUG - 2021-11-26 16:35:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:35:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-26 21:05:46 --> Severity: Notice --> Undefined property: stdClass::$Admin_Profile_Image_Path C:\xampp\htdocs\soumya\loan\application\core\DB_Controller.php 41
ERROR - 2021-11-26 21:05:46 --> Severity: Notice --> Undefined property: stdClass::$Admin_Profile_Image C:\xampp\htdocs\soumya\loan\application\core\DB_Controller.php 41
DEBUG - 2021-11-26 21:05:46 --> Total execution time: 0.0529
DEBUG - 2021-11-26 16:35:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:35:46 --> No URI present. Default controller set.
DEBUG - 2021-11-26 16:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:35:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-26 21:05:46 --> Severity: error --> Exception: Unable to locate the model you have specified: User_logins C:\xampp\htdocs\soumya\loan\system\core\Loader.php 348
DEBUG - 2021-11-26 16:37:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:07:04 --> Total execution time: 0.0489
DEBUG - 2021-11-26 16:38:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 16:38:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 16:38:37 --> Total execution time: 0.0755
DEBUG - 2021-11-26 16:39:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 16:39:20 --> Total execution time: 0.0443
DEBUG - 2021-11-26 16:41:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 16:41:10 --> Total execution time: 0.0496
DEBUG - 2021-11-26 16:43:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 16:43:24 --> Total execution time: 0.0631
DEBUG - 2021-11-26 16:43:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 16:43:42 --> Total execution time: 0.0509
DEBUG - 2021-11-26 16:43:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 16:43:54 --> Total execution time: 0.0521
DEBUG - 2021-11-26 16:44:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 16:44:20 --> Total execution time: 0.0495
DEBUG - 2021-11-26 16:44:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:44:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:44:26 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:44:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:44:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:44:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:44:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:44:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:44:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:44:26 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:44:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:44:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:44:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 16:44:50 --> Total execution time: 0.0657
DEBUG - 2021-11-26 16:44:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:44:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:44:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:44:50 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:44:50 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:44:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:44:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:44:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:44:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:44:50 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:44:50 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:44:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:45:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 16:45:48 --> Total execution time: 0.0511
DEBUG - 2021-11-26 16:46:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 16:46:19 --> Total execution time: 0.0511
DEBUG - 2021-11-26 16:46:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 16:46:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:16:27 --> Total execution time: 0.0504
DEBUG - 2021-11-26 16:46:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:16:31 --> Total execution time: 0.0475
DEBUG - 2021-11-26 16:48:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:18:50 --> Total execution time: 0.0626
DEBUG - 2021-11-26 16:49:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:19:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 21:19:21 --> You did not select a file to upload.
DEBUG - 2021-11-26 16:49:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:19:21 --> Total execution time: 0.0679
DEBUG - 2021-11-26 16:50:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:20:16 --> Total execution time: 0.0762
DEBUG - 2021-11-26 16:51:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:21:20 --> Total execution time: 0.0597
DEBUG - 2021-11-26 16:51:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:21:35 --> Total execution time: 0.0655
DEBUG - 2021-11-26 16:51:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:21:44 --> Total execution time: 0.0833
DEBUG - 2021-11-26 16:51:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:21:50 --> Total execution time: 0.0732
DEBUG - 2021-11-26 16:52:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:52:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:52:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:52:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:00 --> UTF-8 Support Enabled
ERROR - 2021-11-26 16:52:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:52:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:52:00 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:52:00 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:52:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:52:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:52:00 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:52:00 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:52:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:52:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:22:34 --> Total execution time: 0.0490
DEBUG - 2021-11-26 16:52:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:52:34 --> UTF-8 Support Enabled
ERROR - 2021-11-26 16:52:34 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:52:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:52:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:52:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:52:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:52:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:52:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:52:34 --> UTF-8 Support Enabled
ERROR - 2021-11-26 16:52:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:52:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:52:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:52:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:52:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:22:40 --> Total execution time: 0.0601
DEBUG - 2021-11-26 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:52:55 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:52:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:52:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:52:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:52:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:52:55 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 16:52:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 16:52:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 16:53:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:23:05 --> Total execution time: 0.0493
DEBUG - 2021-11-26 16:53:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:23:13 --> Total execution time: 0.0496
DEBUG - 2021-11-26 16:53:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:23:30 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 21:23:30 --> You did not select a file to upload.
DEBUG - 2021-11-26 21:23:30 --> You did not select a file to upload.
DEBUG - 2021-11-26 16:53:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:23:30 --> Total execution time: 0.0482
DEBUG - 2021-11-26 16:53:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:23:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 21:23:55 --> You did not select a file to upload.
DEBUG - 2021-11-26 21:23:55 --> You did not select a file to upload.
DEBUG - 2021-11-26 16:53:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:23:55 --> Total execution time: 0.0600
DEBUG - 2021-11-26 16:54:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:24:06 --> Total execution time: 0.0679
DEBUG - 2021-11-26 16:54:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:24:15 --> Total execution time: 0.0519
DEBUG - 2021-11-26 16:54:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:24:21 --> Total execution time: 0.0474
DEBUG - 2021-11-26 16:54:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:24:22 --> Total execution time: 0.0745
DEBUG - 2021-11-26 16:54:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:24:24 --> Total execution time: 0.0730
DEBUG - 2021-11-26 16:54:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:24:26 --> Total execution time: 0.0490
DEBUG - 2021-11-26 16:56:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:26:00 --> Total execution time: 0.0555
DEBUG - 2021-11-26 16:56:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:26:05 --> Total execution time: 0.0471
DEBUG - 2021-11-26 16:56:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:26:07 --> Total execution time: 0.0601
DEBUG - 2021-11-26 16:56:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:26:09 --> Total execution time: 0.0493
DEBUG - 2021-11-26 16:56:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:26:26 --> Total execution time: 0.0797
DEBUG - 2021-11-26 16:57:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:27:00 --> Total execution time: 0.0459
DEBUG - 2021-11-26 16:57:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:27:01 --> Total execution time: 0.0488
DEBUG - 2021-11-26 16:57:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:27:03 --> Total execution time: 0.0485
DEBUG - 2021-11-26 16:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 16:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:27:05 --> Total execution time: 0.0453
DEBUG - 2021-11-26 16:57:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 16:57:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:27:07 --> Total execution time: 0.0468
DEBUG - 2021-11-26 16:57:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:27:15 --> Total execution time: 0.0707
DEBUG - 2021-11-26 16:57:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:27:16 --> Total execution time: 0.0550
DEBUG - 2021-11-26 16:57:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:27:19 --> Total execution time: 0.0473
DEBUG - 2021-11-26 16:57:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:27:20 --> Total execution time: 0.0484
DEBUG - 2021-11-26 16:57:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:27:30 --> Total execution time: 0.0689
DEBUG - 2021-11-26 16:57:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:27:31 --> Total execution time: 0.0524
DEBUG - 2021-11-26 16:57:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:27:40 --> Total execution time: 0.0483
DEBUG - 2021-11-26 16:57:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:27:50 --> Total execution time: 0.0482
DEBUG - 2021-11-26 16:57:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:27:57 --> Total execution time: 0.0685
DEBUG - 2021-11-26 16:58:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:28:46 --> Total execution time: 0.0650
DEBUG - 2021-11-26 16:58:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:28:49 --> Total execution time: 0.0641
DEBUG - 2021-11-26 16:59:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 16:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 16:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:29:29 --> Total execution time: 0.0843
DEBUG - 2021-11-26 17:01:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:31:32 --> Total execution time: 0.0521
DEBUG - 2021-11-26 17:01:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:31:34 --> Total execution time: 0.0486
DEBUG - 2021-11-26 17:02:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:32:29 --> Total execution time: 0.0585
DEBUG - 2021-11-26 17:02:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 17:02:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:32:31 --> Total execution time: 0.0451
DEBUG - 2021-11-26 17:02:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 17:02:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:32:36 --> Total execution time: 0.0447
DEBUG - 2021-11-26 17:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 17:02:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 17:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 17:02:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 17:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:02:53 --> UTF-8 Support Enabled
ERROR - 2021-11-26 17:02:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 17:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 17:02:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 17:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 17:02:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 17:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-26 17:02:53 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 17:02:53 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-26 17:02:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-26 17:03:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:33:36 --> Total execution time: 0.0710
DEBUG - 2021-11-26 17:04:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 17:04:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 17:04:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 17:04:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:34:58 --> Total execution time: 0.0469
DEBUG - 2021-11-26 17:05:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:35:03 --> Total execution time: 0.0603
DEBUG - 2021-11-26 17:05:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:35:10 --> Total execution time: 0.0528
DEBUG - 2021-11-26 17:16:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:46:44 --> Total execution time: 0.0522
DEBUG - 2021-11-26 17:21:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:51:12 --> Total execution time: 0.0711
DEBUG - 2021-11-26 17:24:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:54:12 --> Total execution time: 0.0726
DEBUG - 2021-11-26 17:24:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:54:21 --> Total execution time: 0.0718
DEBUG - 2021-11-26 17:25:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:55:42 --> Total execution time: 0.0464
DEBUG - 2021-11-26 17:25:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-26 17:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-26 17:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-26 21:55:56 --> Total execution time: 0.0588
