<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-01-06 13:56:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 13:56:55 --> No URI present. Default controller set.
DEBUG - 2023-01-06 13:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 13:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 13:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:26:55 --> Total execution time: 0.0609
DEBUG - 2023-01-06 13:56:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 13:56:56 --> No URI present. Default controller set.
DEBUG - 2023-01-06 13:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 13:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 13:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:26:56 --> Total execution time: 0.0724
DEBUG - 2023-01-06 14:10:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:40:08 --> Total execution time: 0.0562
DEBUG - 2023-01-06 14:10:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:40:13 --> Total execution time: 0.0629
DEBUG - 2023-01-06 14:10:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 14:10:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:40:55 --> Total execution time: 0.0469
DEBUG - 2023-01-06 14:17:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:47:36 --> Total execution time: 0.0648
DEBUG - 2023-01-06 14:17:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:17:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:17:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:17:43 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-06 14:17:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:17:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:17:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:17:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:17:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:17:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:17:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:47:46 --> Total execution time: 0.0563
DEBUG - 2023-01-06 14:17:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:17:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:17:47 --> UTF-8 Support Enabled
ERROR - 2023-01-06 14:17:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:17:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:17:47 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-06 14:17:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:17:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:17:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:17:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:17:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:17:50 --> No URI present. Default controller set.
DEBUG - 2023-01-06 14:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:47:50 --> Total execution time: 0.0648
DEBUG - 2023-01-06 14:17:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:47:53 --> Total execution time: 0.0556
DEBUG - 2023-01-06 14:18:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:48:11 --> Total execution time: 0.0566
DEBUG - 2023-01-06 14:18:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:48:16 --> Total execution time: 0.0836
DEBUG - 2023-01-06 14:18:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:48:42 --> Total execution time: 0.0559
DEBUG - 2023-01-06 14:18:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 14:18:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:48:43 --> Total execution time: 0.0589
DEBUG - 2023-01-06 14:18:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:48:46 --> Total execution time: 0.0483
DEBUG - 2023-01-06 14:18:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:48:50 --> Total execution time: 0.0481
DEBUG - 2023-01-06 14:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 14:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:48:52 --> Total execution time: 0.0487
DEBUG - 2023-01-06 14:19:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:49:46 --> Total execution time: 0.0621
DEBUG - 2023-01-06 14:20:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:50:02 --> Total execution time: 0.0632
DEBUG - 2023-01-06 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:20:05 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-06 14:20:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:20:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:20:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:20:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:21:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:51:06 --> Total execution time: 0.0548
DEBUG - 2023-01-06 14:21:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:21:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:21:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:21:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:21:06 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-06 14:21:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:21:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:21:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:21:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:51:14 --> Total execution time: 0.0568
DEBUG - 2023-01-06 14:21:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:21:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:21:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:21:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:21:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:21:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:21:15 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-06 14:21:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:21:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:21:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:21:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:21:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:51:17 --> Total execution time: 0.0498
DEBUG - 2023-01-06 14:28:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:58:20 --> Total execution time: 0.0663
DEBUG - 2023-01-06 14:28:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:28:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:28:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:28:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:28:23 --> UTF-8 Support Enabled
ERROR - 2023-01-06 14:28:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:28:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:28:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:28:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:28:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:28:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:28:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:58:29 --> Total execution time: 0.0504
DEBUG - 2023-01-06 14:28:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:58:46 --> Total execution time: 0.0468
DEBUG - 2023-01-06 14:28:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:58:51 --> Total execution time: 0.0474
DEBUG - 2023-01-06 14:28:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 18:58:56 --> Total execution time: 0.0489
DEBUG - 2023-01-06 14:29:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:29:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-06 18:59:03 --> Query error: Unknown column 'Donaters' in 'field list' - Invalid query: UPDATE `donaters` SET `Donaters` = 'e10adc3949ba59abbe56e057f20f883e'
WHERE `dntrs_id` = '1'
DEBUG - 2023-01-06 14:29:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:29:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-06 18:59:16 --> Query error: Unknown column 'Donaters' in 'field list' - Invalid query: UPDATE `donaters` SET `Donaters` = 'e10adc3949ba59abbe56e057f20f883e'
WHERE `dntrs_id` = '1'
DEBUG - 2023-01-06 14:29:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:29:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-06 18:59:38 --> Query error: Unknown column 'Donaters' in 'field list' - Invalid query: UPDATE `donaters` SET `Donaters` = 'e10adc3949ba59abbe56e057f20f883e'
WHERE `dntrs_id` = '1'
DEBUG - 2023-01-06 14:29:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:29:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-06 18:59:53 --> Severity: Notice --> Undefined variable: check C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\User_Dashboard.php 54
ERROR - 2023-01-06 18:59:53 --> Query error: Unknown column 'Donaters' in 'field list' - Invalid query: UPDATE `donaters` SET `Donaters` = 'e10adc3949ba59abbe56e057f20f883e'
WHERE `dntrs_id` = '1'
DEBUG - 2023-01-06 14:30:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:30:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-06 19:00:02 --> Query error: Unknown column 'Donaters' in 'field list' - Invalid query: UPDATE `donaters` SET `Donaters` = 'e10adc3949ba59abbe56e057f20f883e'
WHERE `dntrs_id` = '1'
DEBUG - 2023-01-06 14:30:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:00:24 --> Total execution time: 0.0473
DEBUG - 2023-01-06 14:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:01:05 --> Total execution time: 0.0490
DEBUG - 2023-01-06 14:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:31:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:31:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:31:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:31:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:31:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:01:15 --> Total execution time: 0.0530
DEBUG - 2023-01-06 14:32:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:02:40 --> Total execution time: 0.0601
DEBUG - 2023-01-06 14:33:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:03:53 --> Total execution time: 0.0747
DEBUG - 2023-01-06 14:44:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:14:25 --> Total execution time: 0.0753
DEBUG - 2023-01-06 14:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:15:13 --> Total execution time: 0.0555
DEBUG - 2023-01-06 14:45:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:15:31 --> Total execution time: 0.0525
DEBUG - 2023-01-06 14:45:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:15:55 --> Total execution time: 0.0600
DEBUG - 2023-01-06 14:51:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:21:09 --> Total execution time: 0.0619
DEBUG - 2023-01-06 14:51:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:21:28 --> Total execution time: 0.0512
DEBUG - 2023-01-06 14:51:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:21:48 --> Total execution time: 0.0727
DEBUG - 2023-01-06 14:52:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:22:02 --> Total execution time: 0.0659
DEBUG - 2023-01-06 14:52:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:52:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:52:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:52:04 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-06 14:52:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:52:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:52:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:52:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:52:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:52:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:52:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:52:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:22:16 --> Total execution time: 0.0586
DEBUG - 2023-01-06 14:52:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:52:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:52:16 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:52:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:52:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:52:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:52:17 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-06 14:52:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:52:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:52:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:52:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:52:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:22:51 --> Total execution time: 0.0586
DEBUG - 2023-01-06 14:52:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:52:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:52:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:52:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:52:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:52:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:52:51 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-06 14:52:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:52:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:52:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:52:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:53:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:23:02 --> Total execution time: 0.0619
DEBUG - 2023-01-06 14:53:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:53:03 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:53:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:53:03 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:53:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:53:03 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:53:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:53:03 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:57:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:27:33 --> Total execution time: 0.0713
DEBUG - 2023-01-06 14:57:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:57:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:57:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:57:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:57:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:57:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:57:34 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-06 14:57:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:57:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:57:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:57:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:57:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:27:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-06 19:27:38 --> You did not select a file to upload.
DEBUG - 2023-01-06 14:57:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 14:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 14:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:27:38 --> Total execution time: 0.0515
DEBUG - 2023-01-06 14:57:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:57:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:57:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:57:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:57:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:57:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:57:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:57:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:57:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 14:57:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 14:57:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-06 14:57:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-06 15:00:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 15:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 15:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 15:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:30:04 --> Total execution time: 0.0766
DEBUG - 2023-01-06 15:00:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 15:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 15:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 15:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:30:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-06 19:30:06 --> You did not select a file to upload.
DEBUG - 2023-01-06 15:00:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 15:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 15:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 15:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:30:06 --> Total execution time: 0.0533
DEBUG - 2023-01-06 15:00:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 15:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 15:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 15:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:30:14 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-06 15:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 15:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 15:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 15:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:30:15 --> Total execution time: 0.0504
DEBUG - 2023-01-06 15:00:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 15:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 15:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 15:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:30:55 --> Total execution time: 0.0662
DEBUG - 2023-01-06 15:01:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 15:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 15:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 15:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:31:05 --> Total execution time: 0.0596
DEBUG - 2023-01-06 15:01:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-06 15:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-06 15:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-06 15:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-06 19:31:11 --> Total execution time: 0.0585
