<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-01-11 15:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:19:26 --> No URI present. Default controller set.
DEBUG - 2023-01-11 15:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:49:26 --> Total execution time: 0.0791
DEBUG - 2023-01-11 15:19:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 15:19:33 --> Total execution time: 0.0558
DEBUG - 2023-01-11 15:20:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 15:20:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:50:05 --> Total execution time: 0.0708
DEBUG - 2023-01-11 15:20:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:50:12 --> Total execution time: 0.0533
DEBUG - 2023-01-11 15:20:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:50:16 --> Total execution time: 0.0417
DEBUG - 2023-01-11 15:20:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:20:18 --> No URI present. Default controller set.
DEBUG - 2023-01-11 15:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:50:18 --> Total execution time: 0.0438
DEBUG - 2023-01-11 15:20:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:20:20 --> No URI present. Default controller set.
DEBUG - 2023-01-11 15:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:50:20 --> Total execution time: 0.0509
DEBUG - 2023-01-11 15:20:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:50:22 --> Total execution time: 0.0644
DEBUG - 2023-01-11 15:20:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:50:26 --> Total execution time: 0.0675
DEBUG - 2023-01-11 15:20:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 15:20:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:50:32 --> Total execution time: 0.0428
DEBUG - 2023-01-11 15:20:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:50:36 --> Total execution time: 0.0638
DEBUG - 2023-01-11 15:20:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 15:20:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:50:49 --> Total execution time: 0.0440
DEBUG - 2023-01-11 15:21:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:51:02 --> Total execution time: 0.0432
DEBUG - 2023-01-11 15:21:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:51:04 --> Total execution time: 0.0697
DEBUG - 2023-01-11 15:21:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:51:12 --> Total execution time: 0.0657
DEBUG - 2023-01-11 15:21:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:51:14 --> Total execution time: 0.0518
DEBUG - 2023-01-11 15:21:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:21:18 --> No URI present. Default controller set.
DEBUG - 2023-01-11 15:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:51:18 --> Total execution time: 0.0473
DEBUG - 2023-01-11 15:21:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 15:21:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:51:22 --> Total execution time: 0.0539
DEBUG - 2023-01-11 15:21:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:51:27 --> Total execution time: 0.0423
DEBUG - 2023-01-11 15:21:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:51:42 --> Total execution time: 0.0643
DEBUG - 2023-01-11 15:21:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-11 15:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-11 15:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-11 15:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-11 19:51:45 --> Total execution time: 0.0439
