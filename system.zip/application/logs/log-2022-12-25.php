<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-12-25 00:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 00:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 00:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 00:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 00:43:38 --> Total execution time: 0.4444
DEBUG - 2022-12-25 00:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 00:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 00:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 00:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 00:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 00:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 00:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 00:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 06:13:47 --> Total execution time: 0.1158
DEBUG - 2022-12-25 00:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 00:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 00:43:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 00:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 00:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 00:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 00:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 06:14:00 --> Total execution time: 0.0911
DEBUG - 2022-12-25 00:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 00:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 00:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 00:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 06:14:02 --> Total execution time: 0.0588
DEBUG - 2022-12-25 00:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 00:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 00:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 00:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 06:14:55 --> Total execution time: 0.0444
DEBUG - 2022-12-25 00:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 00:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 00:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 00:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 06:15:06 --> Total execution time: 0.0309
DEBUG - 2022-12-25 00:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 00:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 00:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 00:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 06:15:17 --> Total execution time: 0.0369
DEBUG - 2022-12-25 00:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 00:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 00:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 00:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 06:15:32 --> Total execution time: 0.0686
DEBUG - 2022-12-25 00:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 00:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 00:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 00:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 06:15:39 --> Total execution time: 0.0479
DEBUG - 2022-12-25 00:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 00:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 00:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 00:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 06:15:41 --> Total execution time: 0.0605
DEBUG - 2022-12-25 00:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 00:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 00:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 00:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 06:16:17 --> Total execution time: 0.0633
DEBUG - 2022-12-25 00:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 00:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 00:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 00:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 06:16:25 --> Total execution time: 0.0400
DEBUG - 2022-12-25 00:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 00:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 00:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 00:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 06:16:30 --> Total execution time: 0.0726
DEBUG - 2022-12-25 02:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:18:32 --> No URI present. Default controller set.
DEBUG - 2022-12-25 02:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 07:48:32 --> Total execution time: 0.1015
DEBUG - 2022-12-25 02:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 07:49:48 --> Total execution time: 0.0349
DEBUG - 2022-12-25 02:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:21:56 --> No URI present. Default controller set.
DEBUG - 2022-12-25 02:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 07:51:56 --> Total execution time: 0.0407
DEBUG - 2022-12-25 02:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:21:59 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:21:59 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:21:59 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:21:59 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:30:45 --> No URI present. Default controller set.
DEBUG - 2022-12-25 02:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:00:45 --> Total execution time: 0.0792
DEBUG - 2022-12-25 02:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:30:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:30:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:30:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:30:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:30:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:30:48 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:33:31 --> No URI present. Default controller set.
DEBUG - 2022-12-25 02:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:03:31 --> Total execution time: 0.0467
DEBUG - 2022-12-25 02:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:35:17 --> No URI present. Default controller set.
DEBUG - 2022-12-25 02:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:05:17 --> Total execution time: 0.0385
DEBUG - 2022-12-25 02:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:35:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:35:18 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:35:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:35:18 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:35:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:35:18 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:35:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:35:18 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:36:03 --> No URI present. Default controller set.
DEBUG - 2022-12-25 02:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:06:03 --> Total execution time: 0.0386
DEBUG - 2022-12-25 02:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:36:03 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:36:03 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:36:03 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:36:04 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:38:04 --> No URI present. Default controller set.
DEBUG - 2022-12-25 02:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:08:04 --> Total execution time: 0.0393
DEBUG - 2022-12-25 02:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:38:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:38:04 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:38:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:38:05 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:38:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:38:05 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:38:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:38:05 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:38:28 --> No URI present. Default controller set.
DEBUG - 2022-12-25 02:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:08:28 --> Total execution time: 0.0315
DEBUG - 2022-12-25 02:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:38:28 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:38:28 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:38:28 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:38:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:38:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:38:48 --> No URI present. Default controller set.
DEBUG - 2022-12-25 02:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:08:48 --> Total execution time: 0.0384
DEBUG - 2022-12-25 02:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:38:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:38:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:38:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:38:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:38:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:38:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:38:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:38:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:39:34 --> No URI present. Default controller set.
DEBUG - 2022-12-25 02:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:09:34 --> Total execution time: 0.0372
DEBUG - 2022-12-25 02:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:39:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:39:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:39:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:39:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:39:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:39:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:39:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:39:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:40:33 --> No URI present. Default controller set.
DEBUG - 2022-12-25 02:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:10:33 --> Total execution time: 0.0391
DEBUG - 2022-12-25 02:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:40:33 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:40:33 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:40:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:40:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:40:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:40:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:10:38 --> Total execution time: 0.0299
DEBUG - 2022-12-25 02:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:40:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:40:39 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:40:40 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:40:40 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:40:40 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:11:48 --> Total execution time: 0.0774
DEBUG - 2022-12-25 02:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:41:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:41:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:41:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:41:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:09 --> No URI present. Default controller set.
DEBUG - 2022-12-25 02:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:13:09 --> Total execution time: 0.0293
DEBUG - 2022-12-25 02:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:43:09 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:43:10 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:43:10 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:43:10 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:13:28 --> Total execution time: 0.0330
DEBUG - 2022-12-25 02:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:43:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:43:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:43:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:43:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:13:34 --> Total execution time: 0.0387
DEBUG - 2022-12-25 02:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:43:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:43:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:43:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:43:39 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:13:46 --> Total execution time: 0.0299
DEBUG - 2022-12-25 02:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:43:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:43:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:43:48 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:43:48 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:15:20 --> Total execution time: 0.0343
DEBUG - 2022-12-25 02:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:15:24 --> Total execution time: 0.0334
DEBUG - 2022-12-25 02:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:20:13 --> Total execution time: 0.0403
DEBUG - 2022-12-25 02:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:50:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:50:58 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:50:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:50:58 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:50:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:50:58 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:50:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:50:58 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:24:26 --> Total execution time: 0.0547
DEBUG - 2022-12-25 02:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:54:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:54:27 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:54:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:54:27 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:54:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:54:28 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:54:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:54:28 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:26:21 --> Total execution time: 0.0359
DEBUG - 2022-12-25 02:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:56:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:56:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:56:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:56:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:56:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:56:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:56:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:27:18 --> Total execution time: 0.0411
DEBUG - 2022-12-25 02:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:57:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:57:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:57:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:57:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:57:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:57:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:57:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:57:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:28:08 --> Total execution time: 0.0384
DEBUG - 2022-12-25 02:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:58:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:58:08 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:58:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:58:09 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:58:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:58:09 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:58:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:58:09 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:28:43 --> Total execution time: 0.0395
DEBUG - 2022-12-25 02:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:58:44 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:58:44 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:58:44 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 02:58:44 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 02:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 02:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 02:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 02:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:29:26 --> Total execution time: 0.0468
DEBUG - 2022-12-25 03:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:30:41 --> Total execution time: 0.0368
DEBUG - 2022-12-25 03:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:31:15 --> Total execution time: 0.0584
DEBUG - 2022-12-25 03:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:32:53 --> Total execution time: 0.0537
DEBUG - 2022-12-25 03:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:33:22 --> Total execution time: 0.0300
DEBUG - 2022-12-25 03:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:33:40 --> Total execution time: 0.0375
DEBUG - 2022-12-25 03:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:34:12 --> Total execution time: 0.0307
DEBUG - 2022-12-25 03:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:34:15 --> Total execution time: 0.0265
DEBUG - 2022-12-25 03:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:34:25 --> Total execution time: 0.0346
DEBUG - 2022-12-25 03:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:04:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:04:29 --> UTF-8 Support Enabled
ERROR - 2022-12-25 03:04:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:04:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:04:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:34:47 --> Total execution time: 0.0345
DEBUG - 2022-12-25 03:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:04:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:04:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:04:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:04:48 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:04:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:04:48 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:04:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:04:48 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:34:54 --> Total execution time: 0.0318
DEBUG - 2022-12-25 03:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:04:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:04:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:04:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:04:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:04:55 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:36:09 --> Total execution time: 0.0317
DEBUG - 2022-12-25 03:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:06:10 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:06:10 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:06:10 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:06:10 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:36:29 --> Total execution time: 0.0332
DEBUG - 2022-12-25 03:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:06:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:06:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:06:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:06:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:06:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:06:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:06:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:06:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:38:56 --> Total execution time: 0.0568
DEBUG - 2022-12-25 03:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:08:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:08:57 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:08:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:08:57 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:08:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:08:57 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:08:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:08:57 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:39:48 --> Total execution time: 0.0391
DEBUG - 2022-12-25 03:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:09:48 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:09:48 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:09:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:09:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:09:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:09:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:41:02 --> Total execution time: 0.0548
DEBUG - 2022-12-25 03:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:11:03 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:11:03 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:11:03 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:11:03 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:41:38 --> Total execution time: 0.0398
DEBUG - 2022-12-25 03:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:11:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:11:39 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:11:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:11:39 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:11:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:11:39 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:11:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:11:39 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:44:22 --> Total execution time: 0.0455
DEBUG - 2022-12-25 03:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:14:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:14:23 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:14:24 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:14:24 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:14:24 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:44:41 --> Total execution time: 0.0839
DEBUG - 2022-12-25 03:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:14:42 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:14:42 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:14:42 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:14:42 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:47:44 --> Total execution time: 0.0351
DEBUG - 2022-12-25 03:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:17:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:17:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:17:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:17:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:17:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:17:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:17:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:17:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:48:15 --> Total execution time: 0.0334
DEBUG - 2022-12-25 03:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:18:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:18:15 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:18:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:18:16 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:18:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:18:16 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:18:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:18:16 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:50:09 --> Total execution time: 0.0433
DEBUG - 2022-12-25 03:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:20:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:20:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:20:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:20:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:50:46 --> Total execution time: 0.0769
DEBUG - 2022-12-25 03:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:20:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:20:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:20:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:20:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:51:15 --> Total execution time: 0.0540
DEBUG - 2022-12-25 03:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:21:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:21:15 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:21:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:21:16 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:21:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:21:16 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:21:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:21:16 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:52:51 --> Total execution time: 0.0453
DEBUG - 2022-12-25 03:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:23:00 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:23:00 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:23:00 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:23:00 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:54:14 --> Total execution time: 0.0335
DEBUG - 2022-12-25 03:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:57:25 --> Total execution time: 0.0531
DEBUG - 2022-12-25 03:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:27:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:27:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:27:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:27:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:27:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:27:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:27:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:27:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 08:58:31 --> Total execution time: 0.0303
DEBUG - 2022-12-25 03:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:28:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:28:32 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:28:32 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:28:32 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:29:55 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:29:55 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:29:55 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:29:55 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:00:58 --> Total execution time: 0.0360
DEBUG - 2022-12-25 03:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:03:19 --> Total execution time: 0.0381
DEBUG - 2022-12-25 03:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:03:56 --> Total execution time: 0.0378
DEBUG - 2022-12-25 03:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:07:41 --> Total execution time: 0.0377
DEBUG - 2022-12-25 03:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:38:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:38:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:38:36 --> UTF-8 Support Enabled
ERROR - 2022-12-25 03:38:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:38:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:38:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:38:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:38:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:10:42 --> Total execution time: 0.0474
DEBUG - 2022-12-25 03:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:40:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:40:42 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:40:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:40:42 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:40:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:40:42 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:40:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:40:42 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:11:12 --> Total execution time: 0.0396
DEBUG - 2022-12-25 03:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:41:13 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:41:13 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:41:13 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:41:13 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:42:25 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:42:25 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:42:25 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:42:25 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:13:30 --> Total execution time: 0.0488
DEBUG - 2022-12-25 03:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:43:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:43:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:43:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:43:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:43:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:43:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:43:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:43:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:14:20 --> Total execution time: 0.0359
DEBUG - 2022-12-25 03:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:14:52 --> Total execution time: 0.0344
DEBUG - 2022-12-25 03:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:16:39 --> Total execution time: 0.0896
DEBUG - 2022-12-25 03:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:46:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:46:48 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:46:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:46:48 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:46:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:46:48 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:46:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:46:48 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:18:30 --> Total execution time: 0.0440
DEBUG - 2022-12-25 03:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:48:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:48:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:48:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:48:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:48:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:48:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:48:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:48:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:19:03 --> Total execution time: 0.0319
DEBUG - 2022-12-25 03:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:49:04 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:49:04 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:49:04 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 03:49:04 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 03:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 03:51:16 --> No URI present. Default controller set.
DEBUG - 2022-12-25 03:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 03:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 03:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:21:16 --> Total execution time: 0.0456
DEBUG - 2022-12-25 04:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:15:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:15:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:15:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:15:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:46:36 --> Total execution time: 0.0859
DEBUG - 2022-12-25 04:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:16:37 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:16:37 --> UTF-8 Support Enabled
ERROR - 2022-12-25 04:16:37 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:16:37 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:16:37 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:47:25 --> Total execution time: 0.0481
DEBUG - 2022-12-25 04:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:47:36 --> Total execution time: 0.0286
DEBUG - 2022-12-25 04:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:17:39 --> No URI present. Default controller set.
DEBUG - 2022-12-25 04:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:47:39 --> Total execution time: 0.0347
DEBUG - 2022-12-25 04:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 04:19:31 --> Total execution time: 0.0593
DEBUG - 2022-12-25 04:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:19:34 --> No URI present. Default controller set.
DEBUG - 2022-12-25 04:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:49:34 --> Total execution time: 0.0816
DEBUG - 2022-12-25 04:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:49:39 --> Total execution time: 0.0301
DEBUG - 2022-12-25 04:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:19:39 --> No URI present. Default controller set.
DEBUG - 2022-12-25 04:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:49:39 --> Total execution time: 0.0186
DEBUG - 2022-12-25 04:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:19:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:19:39 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-25 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:50:10 --> Total execution time: 0.0394
DEBUG - 2022-12-25 04:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:51:26 --> Total execution time: 0.0451
DEBUG - 2022-12-25 04:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:21:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:21:26 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-25 04:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:52:12 --> Total execution time: 0.0320
DEBUG - 2022-12-25 04:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:52:44 --> Total execution time: 0.0579
DEBUG - 2022-12-25 04:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:52:49 --> Total execution time: 0.0249
DEBUG - 2022-12-25 04:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:22:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:22:57 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:22:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:22:57 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:22:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:22:57 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:22:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:22:57 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:55:13 --> Total execution time: 0.0415
DEBUG - 2022-12-25 04:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:25:14 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:25:14 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:25:14 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:25:14 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:56:25 --> Total execution time: 0.0360
DEBUG - 2022-12-25 04:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:26:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:26:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:26:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:26:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:26:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:26:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:26:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:26:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:56:35 --> Total execution time: 0.0319
DEBUG - 2022-12-25 04:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:26:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:26:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:26:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:26:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:26:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:26:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:26:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:26:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:56:40 --> Total execution time: 0.0408
DEBUG - 2022-12-25 04:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 09:57:35 --> Total execution time: 0.0286
DEBUG - 2022-12-25 04:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:27:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:27:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:27:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 04:27:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 04:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 04:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 04:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 04:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 10:12:47 --> Total execution time: 0.0666
DEBUG - 2022-12-25 05:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 05:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 05:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 10:35:34 --> Total execution time: 0.0520
DEBUG - 2022-12-25 05:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:05:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 05:05:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 05:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:05:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 05:05:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 05:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:05:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 05:05:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 05:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:05:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 05:05:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 05:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 05:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 05:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 10:37:52 --> Total execution time: 0.0709
DEBUG - 2022-12-25 05:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 05:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 05:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 10:40:51 --> Total execution time: 0.0648
DEBUG - 2022-12-25 05:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 05:10:57 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 05:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 05:10:57 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 05:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 05:10:57 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 05:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 05:10:57 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 05:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 05:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 05:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 10:43:49 --> Total execution time: 0.0440
DEBUG - 2022-12-25 05:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:13:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 05:13:50 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 05:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:13:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 05:13:50 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 05:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:13:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 05:13:50 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 05:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:13:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 05:13:50 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-25 05:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 05:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 05:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 10:45:05 --> Total execution time: 0.0413
DEBUG - 2022-12-25 05:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:15:07 --> No URI present. Default controller set.
DEBUG - 2022-12-25 05:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 05:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 05:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 10:45:07 --> Total execution time: 0.0351
DEBUG - 2022-12-25 05:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 05:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 05:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 10:47:15 --> Total execution time: 0.0473
DEBUG - 2022-12-25 05:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 05:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 05:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 10:47:18 --> Total execution time: 0.0347
DEBUG - 2022-12-25 05:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 05:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 05:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 10:48:24 --> Total execution time: 0.0330
DEBUG - 2022-12-25 05:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 05:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 05:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 05:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 10:49:00 --> Total execution time: 0.0285
DEBUG - 2022-12-25 06:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 06:22:48 --> No URI present. Default controller set.
DEBUG - 2022-12-25 06:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 06:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 06:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 10:52:49 --> Total execution time: 0.6966
DEBUG - 2022-12-25 06:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 06:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 06:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 06:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 06:22:54 --> Total execution time: 0.0620
DEBUG - 2022-12-25 06:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 06:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 06:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 06:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 06:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 06:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 06:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 06:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 10:52:57 --> Total execution time: 0.0899
DEBUG - 2022-12-25 06:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 06:22:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 06:22:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 06:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 06:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 06:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 06:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 10:53:04 --> Total execution time: 0.0630
DEBUG - 2022-12-25 06:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 06:23:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 06:23:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 12:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 12:27:56 --> No URI present. Default controller set.
DEBUG - 2022-12-25 12:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 12:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 12:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 16:57:56 --> Total execution time: 0.0655
DEBUG - 2022-12-25 12:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 12:27:58 --> No URI present. Default controller set.
DEBUG - 2022-12-25 12:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 12:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 12:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 16:57:58 --> Total execution time: 0.0451
DEBUG - 2022-12-25 12:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 12:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 12:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 12:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 12:28:05 --> Total execution time: 0.0664
DEBUG - 2022-12-25 12:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 12:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 12:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 12:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 12:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 12:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 12:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 12:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 17:00:53 --> Total execution time: 0.0537
DEBUG - 2022-12-25 12:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 12:30:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 12:30:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 12:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 12:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 12:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 12:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 17:03:41 --> Total execution time: 0.0550
DEBUG - 2022-12-25 12:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 12:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 12:33:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 12:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 12:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 12:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 12:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 17:03:43 --> Total execution time: 0.0442
DEBUG - 2022-12-25 12:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 12:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 12:33:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 12:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 12:34:05 --> No URI present. Default controller set.
DEBUG - 2022-12-25 12:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 12:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 12:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 17:04:05 --> Total execution time: 0.0417
DEBUG - 2022-12-25 12:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 12:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 12:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 12:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 17:04:08 --> Total execution time: 0.0418
DEBUG - 2022-12-25 12:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 12:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 12:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 12:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 17:04:11 --> Total execution time: 0.0420
DEBUG - 2022-12-25 13:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 17:46:34 --> Total execution time: 0.0441
DEBUG - 2022-12-25 13:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:16:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 17:49:05 --> Total execution time: 0.0651
DEBUG - 2022-12-25 13:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:19:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:19:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 17:49:07 --> Total execution time: 0.0421
DEBUG - 2022-12-25 13:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 17:49:29 --> Total execution time: 0.0482
DEBUG - 2022-12-25 13:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:19:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 17:49:32 --> Total execution time: 0.0557
DEBUG - 2022-12-25 13:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:19:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:19:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:19:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:19:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 17:56:22 --> Total execution time: 0.0455
DEBUG - 2022-12-25 13:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:26:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:26:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 17:58:37 --> Total execution time: 0.0456
DEBUG - 2022-12-25 13:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:28:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:28:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:32:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:32:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:32:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:32:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:32:50 --> UTF-8 Support Enabled
ERROR - 2022-12-25 13:32:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:32:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:32:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:32:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:32:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:32:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:32:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:32:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:32:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:02:55 --> Total execution time: 0.0643
DEBUG - 2022-12-25 13:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:32:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:32:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:32:55 --> UTF-8 Support Enabled
ERROR - 2022-12-25 13:32:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:32:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:32:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:32:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:32:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:32:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:32:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:04:23 --> Total execution time: 0.0768
DEBUG - 2022-12-25 13:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:34:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:34:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:34:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:34:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:34:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:34:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:34:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:34:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:34:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:34:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:34:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:34:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:34:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:34:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:34:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:34:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:37:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:37:31 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 25
DEBUG - 2022-12-25 13:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:07:36 --> Total execution time: 0.0662
DEBUG - 2022-12-25 13:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:37:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:37:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:47:17 --> UTF-8 Support Enabled
ERROR - 2022-12-25 13:47:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:47:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:47:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:47:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:47:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:47:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:47:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:47:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:47:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:47:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:47:23 --> Severity: error --> Exception: syntax error, unexpected ',' C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 37
DEBUG - 2022-12-25 13:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:17:29 --> Total execution time: 0.0727
DEBUG - 2022-12-25 13:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:47:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:47:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:47:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:47:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:47:29 --> UTF-8 Support Enabled
ERROR - 2022-12-25 13:47:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:47:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:47:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:47:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:47:30 --> UTF-8 Support Enabled
ERROR - 2022-12-25 13:47:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:47:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:47:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:47:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:47:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:47:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:19:36 --> Total execution time: 0.0568
DEBUG - 2022-12-25 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:49:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:49:36 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:49:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:49:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:49:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:49:36 --> UTF-8 Support Enabled
ERROR - 2022-12-25 13:49:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:49:36 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:49:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:49:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:49:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:20:44 --> Total execution time: 0.0457
DEBUG - 2022-12-25 13:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:50:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:50:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:50:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:50:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:50:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:50:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:50:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:50:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:50:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:50:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:50:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:50:45 --> UTF-8 Support Enabled
ERROR - 2022-12-25 13:50:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:50:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:50:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:50:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:50:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:50:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:21:18 --> Total execution time: 0.0454
DEBUG - 2022-12-25 13:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:51:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:51:19 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:51:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:51:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:51:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:51:19 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:51:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:51:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:51:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:51:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:22:34 --> Total execution time: 0.0486
DEBUG - 2022-12-25 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:52:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:52:34 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:52:34 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:52:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:52:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:52:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:52:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:52:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:52:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:52:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:22:52 --> Total execution time: 0.0682
DEBUG - 2022-12-25 13:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:52:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:52:53 --> UTF-8 Support Enabled
ERROR - 2022-12-25 13:52:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:52:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:52:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:52:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:52:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:52:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:52:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:52:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:52:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:25:18 --> Total execution time: 0.0673
DEBUG - 2022-12-25 13:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:55:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:55:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:55:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:55:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:55:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:55:18 --> UTF-8 Support Enabled
ERROR - 2022-12-25 13:55:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:55:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:55:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:55:18 --> UTF-8 Support Enabled
ERROR - 2022-12-25 13:55:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:55:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 13:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:27:46 --> Total execution time: 0.0669
DEBUG - 2022-12-25 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:57:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:57:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:57:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:57:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:57:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:57:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:57:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:57:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:57:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 13:57:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:57:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 13:57:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:57:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:57:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:57:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:57:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 13:57:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 13:57:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:34:09 --> Total execution time: 0.0473
DEBUG - 2022-12-25 14:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:04:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:04:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:35:00 --> Total execution time: 0.0640
DEBUG - 2022-12-25 14:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:05:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 14:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:35:20 --> Total execution time: 0.0526
DEBUG - 2022-12-25 14:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:05:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:05:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:35:35 --> Total execution time: 0.0450
DEBUG - 2022-12-25 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:05:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:05:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:36:55 --> Total execution time: 0.0429
DEBUG - 2022-12-25 14:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:06:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:06:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 14:07:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 14:07:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:37:10 --> Total execution time: 0.0484
DEBUG - 2022-12-25 14:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 14:07:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 14:07:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:37:23 --> Total execution time: 0.0628
DEBUG - 2022-12-25 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:07:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:38:06 --> Total execution time: 0.0628
DEBUG - 2022-12-25 14:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:08:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:08:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:08:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:08:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:08:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:08:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:08:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:08:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:08:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:08:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:08:07 --> UTF-8 Support Enabled
ERROR - 2022-12-25 14:08:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:08:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:08:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:08:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:08:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:08:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:08:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:38:09 --> Total execution time: 0.0448
DEBUG - 2022-12-25 14:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:08:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:08:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:43:05 --> Total execution time: 0.0668
DEBUG - 2022-12-25 14:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:13:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:13:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:47:44 --> Total execution time: 0.0453
DEBUG - 2022-12-25 14:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:17:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:48:09 --> Total execution time: 0.0433
DEBUG - 2022-12-25 14:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:18:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:18:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 14:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:48:51 --> Total execution time: 0.0740
DEBUG - 2022-12-25 14:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:18:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:18:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:58:03 --> Total execution time: 0.0754
DEBUG - 2022-12-25 14:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:28:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:28:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:58:10 --> Total execution time: 0.0487
DEBUG - 2022-12-25 14:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:28:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:28:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:58:48 --> Total execution time: 0.0929
DEBUG - 2022-12-25 14:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:28:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:58:56 --> Total execution time: 0.0586
DEBUG - 2022-12-25 14:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:28:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:58:57 --> Total execution time: 0.0646
DEBUG - 2022-12-25 14:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:59:03 --> Total execution time: 0.0598
DEBUG - 2022-12-25 14:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:29:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 18:59:34 --> Total execution time: 0.0473
DEBUG - 2022-12-25 14:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:29:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 14:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 14:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 14:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 14:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 14:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 14:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 14:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 14:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 14:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 14:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 14:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:03:55 --> Total execution time: 0.0615
DEBUG - 2022-12-25 14:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:33:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:33:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:04:15 --> Total execution time: 0.0650
DEBUG - 2022-12-25 14:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:34:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:34:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:04:25 --> Total execution time: 0.0495
DEBUG - 2022-12-25 14:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:34:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:34:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:35:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-25 19:05:38 --> 404 Page Not Found: 
DEBUG - 2022-12-25 14:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:05:45 --> Total execution time: 0.0640
DEBUG - 2022-12-25 14:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:35:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:05:49 --> Total execution time: 0.0610
DEBUG - 2022-12-25 14:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:35:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:06:39 --> Total execution time: 0.0706
DEBUG - 2022-12-25 14:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:36:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:36:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:09:00 --> Total execution time: 0.0505
DEBUG - 2022-12-25 14:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:39:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:39:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:39:14 --> UTF-8 Support Enabled
ERROR - 2022-12-25 14:39:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:39:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:39:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:39:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 14:39:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:39:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:39:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:39:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:10:47 --> Total execution time: 0.0755
DEBUG - 2022-12-25 14:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:40:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:40:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:13:05 --> Total execution time: 0.0718
DEBUG - 2022-12-25 14:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:43:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:43:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:43:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:43:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:43:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:43:08 --> UTF-8 Support Enabled
ERROR - 2022-12-25 14:43:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:43:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:43:08 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 14:43:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:43:08 --> UTF-8 Support Enabled
ERROR - 2022-12-25 14:43:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:43:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:43:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:17:25 --> Total execution time: 0.0751
DEBUG - 2022-12-25 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:47:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:47:25 --> UTF-8 Support Enabled
ERROR - 2022-12-25 14:47:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:47:25 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 14:47:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:47:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:47:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:47:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:47:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:47:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:19:46 --> Total execution time: 0.0704
DEBUG - 2022-12-25 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:49:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:49:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:49:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:49:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:49:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 14:49:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:49:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:49:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:49:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:20:41 --> Total execution time: 0.0563
DEBUG - 2022-12-25 14:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:50:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:50:41 --> UTF-8 Support Enabled
ERROR - 2022-12-25 14:50:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 14:50:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:50:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:50:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 14:50:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:50:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:50:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:50:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 14:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:28:28 --> Total execution time: 0.0530
DEBUG - 2022-12-25 14:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:58:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:28:55 --> Total execution time: 0.0776
DEBUG - 2022-12-25 14:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:58:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:58:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 14:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 14:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 14:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 14:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:29:14 --> Total execution time: 0.0545
DEBUG - 2022-12-25 14:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 14:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 14:59:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 15:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 15:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:30:32 --> Total execution time: 0.0522
DEBUG - 2022-12-25 15:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:00:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:00:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 15:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 15:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 15:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 15:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:30:37 --> Total execution time: 0.0566
DEBUG - 2022-12-25 15:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:00:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:00:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 15:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 15:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:31:07 --> Total execution time: 0.0489
DEBUG - 2022-12-25 15:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:01:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 15:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 15:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:54:13 --> Total execution time: 0.8026
DEBUG - 2022-12-25 15:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:24:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:24:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 15:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 15:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 19:59:06 --> Total execution time: 0.0672
DEBUG - 2022-12-25 15:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:29:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 15:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 15:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 20:01:03 --> Total execution time: 0.0812
DEBUG - 2022-12-25 15:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:31:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:31:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 15:31:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:31:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:31:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 15:31:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:31:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:31:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 15:31:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 15:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 20:01:50 --> Total execution time: 0.0572
DEBUG - 2022-12-25 15:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:31:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 15:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:31:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 15:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 15:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 20:02:22 --> Total execution time: 0.0828
DEBUG - 2022-12-25 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:32:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:32:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 15:32:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:32:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 15:32:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:22 --> UTF-8 Support Enabled
ERROR - 2022-12-25 15:32:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:32:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:32:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:32:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:32:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:32:25 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 15:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 15:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 20:07:33 --> Total execution time: 0.0687
DEBUG - 2022-12-25 15:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:37:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:37:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 15:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:37:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:37:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:37:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:37:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 15:37:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:37:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:37:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 15:37:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:37:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:37:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 15:37:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:37:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:37:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 15:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 20:08:27 --> Total execution time: 0.0531
DEBUG - 2022-12-25 15:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:38:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:38:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 15:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:38:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:38:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:38:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:38:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 15:38:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:38:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:38:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:38:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:38:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 15:38:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:38:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:38:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:38:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:38:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 15:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 20:24:06 --> Total execution time: 0.0718
DEBUG - 2022-12-25 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:06 --> No URI present. Default controller set.
DEBUG - 2022-12-25 15:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:54:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 15:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 15:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:54:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:54:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:54:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 20:24:06 --> Total execution time: 0.1575
DEBUG - 2022-12-25 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:54:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:54:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:54:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:54:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:54:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 15:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 20:24:19 --> Total execution time: 0.0930
DEBUG - 2022-12-25 15:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:54:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 15:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:54:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 15:54:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:54:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:54:20 --> UTF-8 Support Enabled
ERROR - 2022-12-25 15:54:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 15:54:20 --> UTF-8 Support Enabled
ERROR - 2022-12-25 15:54:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:54:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:54:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 15:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 15:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 15:54:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 16:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 20:48:23 --> Total execution time: 0.0693
DEBUG - 2022-12-25 16:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:18:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:18:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 20:50:24 --> Total execution time: 0.0786
DEBUG - 2022-12-25 16:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:20:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 20:50:30 --> Total execution time: 0.0761
DEBUG - 2022-12-25 16:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:20:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:20:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 20:52:02 --> Total execution time: 0.0713
DEBUG - 2022-12-25 16:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:22:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:22:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 20:52:08 --> Total execution time: 0.0774
DEBUG - 2022-12-25 16:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:22:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 20:55:59 --> Total execution time: 0.0591
DEBUG - 2022-12-25 16:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:25:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:25:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:31:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:31:44 --> Severity: error --> Exception: syntax error, unexpected ',' C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 150
DEBUG - 2022-12-25 16:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:44:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:44:58 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 192
DEBUG - 2022-12-25 16:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:45:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:45:18 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 192
DEBUG - 2022-12-25 16:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:15:54 --> Total execution time: 0.0777
DEBUG - 2022-12-25 16:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:45:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:16:37 --> Total execution time: 0.0584
DEBUG - 2022-12-25 16:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:18:03 --> Total execution time: 0.0620
DEBUG - 2022-12-25 16:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:18:08 --> Total execution time: 0.0759
DEBUG - 2022-12-25 16:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:48:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:48:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:18:42 --> Total execution time: 0.0758
DEBUG - 2022-12-25 16:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:48:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:48:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:18:52 --> Total execution time: 0.0743
DEBUG - 2022-12-25 16:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:48:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:48:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:21:52 --> Total execution time: 0.0689
DEBUG - 2022-12-25 16:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:51:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:51:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:22:15 --> Total execution time: 0.0537
DEBUG - 2022-12-25 16:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:22:43 --> Total execution time: 0.0532
DEBUG - 2022-12-25 16:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 16:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:22:48 --> Total execution time: 0.0540
DEBUG - 2022-12-25 16:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:52:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:52:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:53:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:53:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 16:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:53:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:53:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 16:53:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 16:53:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 16:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:53:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:53:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 16:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:53:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:53:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 16:53:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:53:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 16:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:53:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:53:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 16:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:24:56 --> Total execution time: 0.0715
DEBUG - 2022-12-25 16:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:54:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:54:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:54:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:54:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 16:54:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:54:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 16:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:54:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:54:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 16:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:54:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:54:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 16:54:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 16:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:54:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:54:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 16:54:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:54:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 16:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:54:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:54:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 16:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:25:06 --> Total execution time: 0.0664
DEBUG - 2022-12-25 16:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:55:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:55:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:25:35 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-25 21:25:35 --> You did not select a file to upload.
ERROR - 2022-12-25 21:25:35 --> Severity: Notice --> Trying to get property 'kyc_document_file' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 166
DEBUG - 2022-12-25 21:25:35 --> You did not select a file to upload.
ERROR - 2022-12-25 21:25:35 --> Severity: Notice --> Trying to get property 'kyc_logo' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 175
DEBUG - 2022-12-25 16:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:25:35 --> Total execution time: 0.0753
DEBUG - 2022-12-25 16:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:55:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:26:47 --> Total execution time: 0.0538
DEBUG - 2022-12-25 16:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:56:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:56:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:26:50 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-25 21:26:50 --> You did not select a file to upload.
DEBUG - 2022-12-25 21:26:50 --> You did not select a file to upload.
DEBUG - 2022-12-25 16:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:26:50 --> Total execution time: 0.0548
DEBUG - 2022-12-25 16:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:56:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:56:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:26:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-25 21:26:58 --> You did not select a file to upload.
DEBUG - 2022-12-25 21:26:58 --> You did not select a file to upload.
DEBUG - 2022-12-25 16:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:26:58 --> Total execution time: 0.0546
DEBUG - 2022-12-25 16:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:56:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:56:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:28:04 --> Total execution time: 0.0672
DEBUG - 2022-12-25 16:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:58:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:58:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:28:14 --> Upload class already loaded. Second attempt ignored.
ERROR - 2022-12-25 21:28:14 --> Severity: Warning --> unlink(assets/uploads/kyc/): Is a directory C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 163
ERROR - 2022-12-25 21:28:14 --> Severity: Warning --> unlink(assets/uploads/kyc/): Is a directory C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 172
DEBUG - 2022-12-25 16:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:28:14 --> Total execution time: 0.0534
DEBUG - 2022-12-25 16:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:58:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:58:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:28:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-25 21:28:23 --> You did not select a file to upload.
DEBUG - 2022-12-25 21:28:23 --> You did not select a file to upload.
DEBUG - 2022-12-25 16:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:28:23 --> Total execution time: 0.0543
DEBUG - 2022-12-25 16:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:58:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:58:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:58:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:58:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 16:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 16:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 16:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:28:48 --> Total execution time: 0.0696
DEBUG - 2022-12-25 16:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 16:58:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 16:58:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:33:12 --> Total execution time: 0.0724
DEBUG - 2022-12-25 17:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:03:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:03:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:03:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:03:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:33:22 --> Total execution time: 0.0665
DEBUG - 2022-12-25 17:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:03:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:03:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:35:53 --> Total execution time: 0.0516
DEBUG - 2022-12-25 17:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:05:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:05:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:35:56 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-25 21:35:56 --> You did not select a file to upload.
DEBUG - 2022-12-25 21:35:56 --> You did not select a file to upload.
ERROR - 2022-12-25 21:35:56 --> Severity: error --> Exception: Too few arguments to function DB_Model::updateWhere(), 1 passed in C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php on line 222 and exactly 2 expected C:\xampp\htdocs\gopal\crowd_funding\application\core\DB_Model.php 232
DEBUG - 2022-12-25 17:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:36:19 --> Total execution time: 0.0463
DEBUG - 2022-12-25 17:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:36:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-25 21:36:21 --> You did not select a file to upload.
DEBUG - 2022-12-25 21:36:21 --> You did not select a file to upload.
DEBUG - 2022-12-25 17:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:36:21 --> Total execution time: 0.0489
DEBUG - 2022-12-25 17:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:06:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:06:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:38:55 --> Total execution time: 0.1050
DEBUG - 2022-12-25 17:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:08:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:08:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:38:57 --> Total execution time: 0.0665
DEBUG - 2022-12-25 17:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:08:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:08:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 17:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:39:19 --> Total execution time: 0.0550
DEBUG - 2022-12-25 17:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:09:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:09:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:39:35 --> Total execution time: 0.0638
DEBUG - 2022-12-25 17:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:09:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:09:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:39:38 --> Total execution time: 0.0452
DEBUG - 2022-12-25 17:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:09:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:09:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:41:10 --> Total execution time: 0.0472
DEBUG - 2022-12-25 17:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:11:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:11:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:41:21 --> Total execution time: 0.0570
DEBUG - 2022-12-25 17:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:11:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:42:20 --> Total execution time: 0.0621
DEBUG - 2022-12-25 17:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:12:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:42:28 --> Total execution time: 0.0666
DEBUG - 2022-12-25 17:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:12:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:12:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:42:36 --> Total execution time: 0.0553
DEBUG - 2022-12-25 17:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:12:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:12:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:44:54 --> Total execution time: 0.0560
DEBUG - 2022-12-25 17:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:14:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:14:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 17:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:45:03 --> Total execution time: 0.0465
DEBUG - 2022-12-25 17:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:15:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:15:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:45:58 --> Total execution time: 0.0747
DEBUG - 2022-12-25 17:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:15:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 17:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:46:00 --> Total execution time: 0.0552
DEBUG - 2022-12-25 17:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:16:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:16:04 --> UTF-8 Support Enabled
ERROR - 2022-12-25 17:16:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:16:04 --> UTF-8 Support Enabled
ERROR - 2022-12-25 17:16:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:16:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:16:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:16:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:16:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:16:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:16:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:16:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:16:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:16:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:47:04 --> Total execution time: 0.0713
DEBUG - 2022-12-25 17:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:17:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:17:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:17:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:17:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:17:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:17:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:17:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:17:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:17:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:17:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:47:19 --> Upload class already loaded. Second attempt ignored.
ERROR - 2022-12-25 21:47:19 --> Severity: Notice --> Trying to get property 'kyc_document_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 258
ERROR - 2022-12-25 21:47:19 --> Severity: Notice --> Trying to get property 'kyc_document_file' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 258
DEBUG - 2022-12-25 17:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:47:19 --> Total execution time: 0.0462
DEBUG - 2022-12-25 17:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:17:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:17:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:49:01 --> Total execution time: 0.0448
DEBUG - 2022-12-25 17:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:19:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:19:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:49:17 --> Total execution time: 0.0813
DEBUG - 2022-12-25 17:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:19:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:19:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:49:24 --> Total execution time: 0.0632
DEBUG - 2022-12-25 17:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:19:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:19:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:49:27 --> Total execution time: 0.0643
DEBUG - 2022-12-25 17:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:19:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:19:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:49:33 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-25 21:49:33 --> You did not select a file to upload.
DEBUG - 2022-12-25 21:49:33 --> You did not select a file to upload.
DEBUG - 2022-12-25 17:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:49:33 --> Total execution time: 0.0474
DEBUG - 2022-12-25 17:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:19:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:19:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:49:34 --> Total execution time: 0.0610
DEBUG - 2022-12-25 17:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:19:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:19:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:52:44 --> Total execution time: 0.0721
DEBUG - 2022-12-25 17:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:22:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:53:28 --> Total execution time: 0.0447
DEBUG - 2022-12-25 17:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:23:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:23:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:55:44 --> Total execution time: 0.0480
DEBUG - 2022-12-25 17:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:25:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:56:07 --> Total execution time: 0.0670
DEBUG - 2022-12-25 17:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:26:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:56:56 --> Total execution time: 0.0463
DEBUG - 2022-12-25 17:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:26:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:57:11 --> Total execution time: 0.0460
DEBUG - 2022-12-25 17:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:27:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:27:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:57:44 --> Total execution time: 0.0501
DEBUG - 2022-12-25 17:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:27:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:27:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:27:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:27:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:27:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:27:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:27:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:27:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:27:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:27:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:58:07 --> Total execution time: 0.0494
DEBUG - 2022-12-25 17:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:28:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:28:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:28:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:28:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:28:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:28:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:28:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:28:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:28:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:58:47 --> Total execution time: 0.0467
DEBUG - 2022-12-25 17:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:28:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:28:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:28:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:28:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:28:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:28:47 --> UTF-8 Support Enabled
ERROR - 2022-12-25 17:28:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:28:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:28:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:28:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:28:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 21:59:26 --> Total execution time: 0.0453
DEBUG - 2022-12-25 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:29:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:29:26 --> UTF-8 Support Enabled
ERROR - 2022-12-25 17:29:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:29:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:29:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:29:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:29:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:29:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:29:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:29:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:29:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:31:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:31:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:31:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:31:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:31:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:31:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:31:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:31:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:02:46 --> Total execution time: 0.0662
DEBUG - 2022-12-25 17:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:32:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:32:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:32:46 --> UTF-8 Support Enabled
ERROR - 2022-12-25 17:32:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:32:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:32:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:32:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:32:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:32:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:32:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:32:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:38:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:38:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:38:30 --> UTF-8 Support Enabled
ERROR - 2022-12-25 17:38:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:38:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:38:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:38:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:38:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:38:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:08:33 --> Total execution time: 0.0726
DEBUG - 2022-12-25 17:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:38:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:38:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:38:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:38:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:38:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:38:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:38:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:38:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:38:34 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:38:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:38:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:08:38 --> Total execution time: 0.0413
DEBUG - 2022-12-25 17:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:10:02 --> Total execution time: 0.0580
DEBUG - 2022-12-25 17:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:40:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:40:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:10:07 --> Total execution time: 0.0405
DEBUG - 2022-12-25 17:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:10:23 --> Total execution time: 0.0595
DEBUG - 2022-12-25 17:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:40:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:40:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:10:28 --> Total execution time: 0.0424
DEBUG - 2022-12-25 17:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:10:34 --> Total execution time: 0.0551
DEBUG - 2022-12-25 17:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:40:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:10:39 --> Total execution time: 0.0423
DEBUG - 2022-12-25 17:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:11:33 --> Total execution time: 0.0597
DEBUG - 2022-12-25 17:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:41:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:41:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:41:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:41:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:41:34 --> UTF-8 Support Enabled
ERROR - 2022-12-25 17:41:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:41:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:41:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:41:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:41:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:11:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-25 22:11:37 --> Total execution time: 0.0501
DEBUG - 2022-12-25 17:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:13:46 --> Total execution time: 0.0479
DEBUG - 2022-12-25 17:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:43:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:43:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:43:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:43:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:43:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:43:46 --> UTF-8 Support Enabled
ERROR - 2022-12-25 17:43:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:43:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:43:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:43:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:13:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-25 22:13:51 --> Total execution time: 0.0493
DEBUG - 2022-12-25 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:20:55 --> Total execution time: 0.0517
DEBUG - 2022-12-25 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:50:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:50:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:50:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:50:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:50:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:50:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:50:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:50:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:50:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:21:54 --> Total execution time: 0.0482
DEBUG - 2022-12-25 17:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:51:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:51:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:51:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:51:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:51:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:51:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:51:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:51:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:51:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:51:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:51:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:51:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:51:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:51:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:51:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:51:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:22:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-25 22:22:04 --> Total execution time: 0.0543
DEBUG - 2022-12-25 17:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:04 --> 404 Page Not Found: Vugfgax3mzu1548jfxaujpg/index
DEBUG - 2022-12-25 17:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:22:45 --> Total execution time: 0.0472
DEBUG - 2022-12-25 17:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:52:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:22:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-25 22:22:49 --> Total execution time: 0.0554
DEBUG - 2022-12-25 17:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:22:51 --> Total execution time: 0.0448
DEBUG - 2022-12-25 17:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:52:51 --> UTF-8 Support Enabled
ERROR - 2022-12-25 17:52:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:22:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-25 22:22:54 --> Total execution time: 0.0648
DEBUG - 2022-12-25 17:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:22:55 --> Total execution time: 0.0623
DEBUG - 2022-12-25 17:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:52:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:52:55 --> UTF-8 Support Enabled
ERROR - 2022-12-25 17:52:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:52:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:23:55 --> Total execution time: 0.0651
DEBUG - 2022-12-25 17:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:53:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:53:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:24:05 --> Total execution time: 0.0531
DEBUG - 2022-12-25 17:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:54:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:54:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:24:42 --> Total execution time: 0.0654
DEBUG - 2022-12-25 17:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:54:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:54:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:54:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:54:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:54:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:54:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:54:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:54:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:54:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:54:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:54:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:54:45 --> UTF-8 Support Enabled
ERROR - 2022-12-25 17:54:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:54:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:54:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:54:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:25:12 --> Total execution time: 0.0864
DEBUG - 2022-12-25 17:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:55:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:55:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:55:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:55:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:55:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:55:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:55:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:55:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:55:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:55:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:55:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:25:44 --> Total execution time: 0.0582
DEBUG - 2022-12-25 17:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:55:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:55:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:55:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:55:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:55:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-25 17:55:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:55:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:55:45 --> UTF-8 Support Enabled
ERROR - 2022-12-25 17:55:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:55:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-25 17:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:25:45 --> Total execution time: 0.0485
DEBUG - 2022-12-25 17:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:55:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:55:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:26:55 --> Total execution time: 0.0600
DEBUG - 2022-12-25 17:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:56:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:56:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:26:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-25 22:26:59 --> Total execution time: 0.0579
DEBUG - 2022-12-25 17:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:27:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-25 22:27:03 --> Total execution time: 0.0564
DEBUG - 2022-12-25 17:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:27:13 --> Total execution time: 0.0654
DEBUG - 2022-12-25 17:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:57:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:57:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:27:22 --> Total execution time: 0.0746
DEBUG - 2022-12-25 17:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:57:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:57:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:57:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:57:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-25 17:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-25 17:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-25 17:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-25 22:27:42 --> Total execution time: 0.0698
DEBUG - 2022-12-25 17:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-25 17:57:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-25 17:57:42 --> 404 Page Not Found: Assets/website_esa
