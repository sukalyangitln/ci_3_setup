<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-09 00:02:55 --> Total execution time: 0.1112
DEBUG - 2022-07-09 00:30:03 --> Total execution time: 0.2114
DEBUG - 2022-07-09 00:33:15 --> Total execution time: 0.0522
DEBUG - 2022-07-09 00:33:23 --> Total execution time: 0.0654
DEBUG - 2022-07-09 00:33:32 --> Total execution time: 0.0889
DEBUG - 2022-07-09 00:39:33 --> Total execution time: 0.0939
DEBUG - 2022-07-09 00:41:43 --> Total execution time: 0.0883
DEBUG - 2022-07-09 00:44:07 --> Total execution time: 0.1713
DEBUG - 2022-07-09 01:02:48 --> Total execution time: 0.2355
DEBUG - 2022-07-09 01:25:28 --> Total execution time: 0.0942
DEBUG - 2022-07-09 01:30:03 --> Total execution time: 0.0982
DEBUG - 2022-07-09 01:33:46 --> Total execution time: 0.0559
DEBUG - 2022-07-09 01:33:49 --> Total execution time: 0.0491
DEBUG - 2022-07-09 01:33:55 --> Total execution time: 0.0615
DEBUG - 2022-07-09 01:40:10 --> Total execution time: 0.1014
DEBUG - 2022-07-09 01:40:18 --> Total execution time: 0.0346
DEBUG - 2022-07-09 01:40:22 --> Total execution time: 0.0536
DEBUG - 2022-07-09 01:40:28 --> Total execution time: 0.0689
DEBUG - 2022-07-09 01:40:38 --> Total execution time: 0.0837
DEBUG - 2022-07-09 01:41:06 --> Total execution time: 0.0733
DEBUG - 2022-07-09 01:41:11 --> Total execution time: 0.0593
DEBUG - 2022-07-09 01:41:15 --> Total execution time: 0.0615
DEBUG - 2022-07-09 01:41:22 --> Total execution time: 0.0554
DEBUG - 2022-07-09 01:53:49 --> Total execution time: 0.2027
DEBUG - 2022-07-09 02:09:56 --> Total execution time: 0.0599
DEBUG - 2022-07-09 02:11:07 --> Total execution time: 0.0475
DEBUG - 2022-07-09 02:11:31 --> Total execution time: 0.0403
DEBUG - 2022-07-09 02:11:34 --> Total execution time: 0.0315
DEBUG - 2022-07-09 02:17:45 --> Total execution time: 0.0594
DEBUG - 2022-07-09 02:18:16 --> Total execution time: 0.0969
DEBUG - 2022-07-09 02:18:26 --> Total execution time: 0.0698
DEBUG - 2022-07-09 02:18:28 --> Total execution time: 0.1221
DEBUG - 2022-07-09 02:18:34 --> Total execution time: 0.0911
DEBUG - 2022-07-09 02:18:49 --> Total execution time: 0.0815
DEBUG - 2022-07-09 02:19:08 --> Total execution time: 0.0552
DEBUG - 2022-07-09 02:25:03 --> Total execution time: 0.1191
DEBUG - 2022-07-09 02:26:09 --> Total execution time: 0.1677
DEBUG - 2022-07-09 02:26:30 --> Total execution time: 0.0577
DEBUG - 2022-07-09 02:26:40 --> Total execution time: 0.0693
DEBUG - 2022-07-09 02:30:03 --> Total execution time: 0.0529
DEBUG - 2022-07-09 02:30:41 --> Total execution time: 0.0681
DEBUG - 2022-07-09 02:47:21 --> Total execution time: 0.0855
DEBUG - 2022-07-09 02:47:44 --> Total execution time: 0.0459
DEBUG - 2022-07-09 03:09:28 --> Total execution time: 0.2437
DEBUG - 2022-07-09 03:11:50 --> Total execution time: 0.0933
DEBUG - 2022-07-09 03:20:50 --> Total execution time: 0.0840
DEBUG - 2022-07-09 03:23:54 --> Total execution time: 0.0861
DEBUG - 2022-07-09 03:26:42 --> Total execution time: 0.0364
DEBUG - 2022-07-09 03:28:38 --> Total execution time: 0.0372
DEBUG - 2022-07-09 03:30:04 --> Total execution time: 0.0624
DEBUG - 2022-07-09 03:30:18 --> Total execution time: 0.0524
DEBUG - 2022-07-09 03:31:57 --> Total execution time: 0.0412
DEBUG - 2022-07-09 03:33:39 --> Total execution time: 0.0380
DEBUG - 2022-07-09 03:36:03 --> Total execution time: 0.1174
DEBUG - 2022-07-09 03:37:59 --> Total execution time: 0.0372
DEBUG - 2022-07-09 03:41:41 --> Total execution time: 0.1056
DEBUG - 2022-07-09 03:44:15 --> Total execution time: 0.0861
DEBUG - 2022-07-09 03:44:16 --> Total execution time: 0.0556
DEBUG - 2022-07-09 03:44:24 --> Total execution time: 0.0533
DEBUG - 2022-07-09 03:44:47 --> Total execution time: 0.0763
DEBUG - 2022-07-09 03:45:06 --> Total execution time: 0.0712
DEBUG - 2022-07-09 03:45:19 --> Total execution time: 0.1490
DEBUG - 2022-07-09 03:46:34 --> Total execution time: 0.0684
DEBUG - 2022-07-09 03:46:35 --> Total execution time: 0.0628
DEBUG - 2022-07-09 03:46:52 --> Total execution time: 0.0589
DEBUG - 2022-07-09 03:46:58 --> Total execution time: 0.0592
DEBUG - 2022-07-09 03:47:09 --> Total execution time: 0.0583
DEBUG - 2022-07-09 03:47:13 --> Total execution time: 0.0735
DEBUG - 2022-07-09 03:47:18 --> Total execution time: 0.0919
DEBUG - 2022-07-09 03:47:34 --> Total execution time: 0.0751
DEBUG - 2022-07-09 03:47:35 --> Total execution time: 0.0526
DEBUG - 2022-07-09 03:47:40 --> Total execution time: 0.0577
DEBUG - 2022-07-09 03:47:58 --> Total execution time: 0.0618
DEBUG - 2022-07-09 03:51:48 --> Total execution time: 0.1980
DEBUG - 2022-07-09 03:52:00 --> Total execution time: 0.0707
DEBUG - 2022-07-09 03:52:10 --> Total execution time: 0.1004
DEBUG - 2022-07-09 03:55:12 --> Total execution time: 0.1286
DEBUG - 2022-07-09 03:58:40 --> Total execution time: 0.2603
DEBUG - 2022-07-09 03:59:56 --> Total execution time: 0.1080
DEBUG - 2022-07-09 04:01:33 --> Total execution time: 0.0833
DEBUG - 2022-07-09 04:01:41 --> Total execution time: 0.0574
DEBUG - 2022-07-09 04:01:46 --> Total execution time: 0.0573
DEBUG - 2022-07-09 04:02:02 --> Total execution time: 0.0566
DEBUG - 2022-07-09 04:02:08 --> Total execution time: 0.0587
DEBUG - 2022-07-09 04:22:32 --> Total execution time: 0.2225
DEBUG - 2022-07-09 04:22:52 --> Total execution time: 0.0511
DEBUG - 2022-07-09 04:30:02 --> Total execution time: 0.1530
DEBUG - 2022-07-09 04:37:48 --> Total execution time: 0.1222
DEBUG - 2022-07-09 04:37:50 --> Total execution time: 0.0517
DEBUG - 2022-07-09 04:37:52 --> Total execution time: 0.0488
DEBUG - 2022-07-09 05:01:38 --> Total execution time: 0.1706
DEBUG - 2022-07-09 05:24:43 --> Total execution time: 0.1975
DEBUG - 2022-07-09 05:30:02 --> Total execution time: 0.1441
DEBUG - 2022-07-09 05:33:42 --> Total execution time: 0.0908
DEBUG - 2022-07-09 05:33:50 --> Total execution time: 0.0476
DEBUG - 2022-07-09 05:35:16 --> Total execution time: 0.0501
DEBUG - 2022-07-09 05:35:41 --> Total execution time: 0.0490
DEBUG - 2022-07-09 05:35:58 --> Total execution time: 0.0491
DEBUG - 2022-07-09 05:36:31 --> Total execution time: 0.0775
DEBUG - 2022-07-09 05:36:38 --> Total execution time: 0.0705
DEBUG - 2022-07-09 05:36:49 --> Total execution time: 0.0585
DEBUG - 2022-07-09 05:37:04 --> Total execution time: 0.0646
DEBUG - 2022-07-09 05:39:31 --> Total execution time: 0.1084
DEBUG - 2022-07-09 05:40:02 --> Total execution time: 0.0539
DEBUG - 2022-07-09 05:40:19 --> Total execution time: 0.0528
DEBUG - 2022-07-09 05:44:09 --> Total execution time: 0.0904
DEBUG - 2022-07-09 05:44:12 --> Total execution time: 0.0356
DEBUG - 2022-07-09 05:44:14 --> Total execution time: 0.0637
DEBUG - 2022-07-09 05:44:18 --> Total execution time: 0.0579
DEBUG - 2022-07-09 05:44:20 --> Total execution time: 0.0774
DEBUG - 2022-07-09 05:44:36 --> Total execution time: 0.0491
DEBUG - 2022-07-09 05:45:13 --> Total execution time: 0.0360
DEBUG - 2022-07-09 06:00:55 --> Total execution time: 0.1255
DEBUG - 2022-07-09 06:11:41 --> Total execution time: 0.2026
DEBUG - 2022-07-09 06:11:45 --> Total execution time: 0.1468
DEBUG - 2022-07-09 06:11:50 --> Total execution time: 0.0757
DEBUG - 2022-07-09 06:11:53 --> Total execution time: 0.0928
DEBUG - 2022-07-09 06:20:36 --> Total execution time: 0.0539
DEBUG - 2022-07-09 06:20:44 --> Total execution time: 0.0499
DEBUG - 2022-07-09 06:21:03 --> Total execution time: 0.0599
DEBUG - 2022-07-09 06:21:08 --> Total execution time: 0.0777
DEBUG - 2022-07-09 06:21:18 --> Total execution time: 0.0582
DEBUG - 2022-07-09 06:21:28 --> Total execution time: 0.0711
DEBUG - 2022-07-09 06:25:22 --> Total execution time: 0.1140
DEBUG - 2022-07-09 06:25:33 --> Total execution time: 0.0516
DEBUG - 2022-07-09 06:28:12 --> Total execution time: 0.1554
DEBUG - 2022-07-09 06:28:17 --> Total execution time: 0.0603
DEBUG - 2022-07-09 06:28:19 --> Total execution time: 0.0827
DEBUG - 2022-07-09 06:28:49 --> Total execution time: 0.0493
DEBUG - 2022-07-09 06:29:40 --> Total execution time: 0.0525
DEBUG - 2022-07-09 06:30:02 --> Total execution time: 0.1257
DEBUG - 2022-07-09 06:31:28 --> Total execution time: 0.0638
DEBUG - 2022-07-09 06:32:00 --> Total execution time: 0.0726
DEBUG - 2022-07-09 06:32:41 --> Total execution time: 0.0581
DEBUG - 2022-07-09 06:34:05 --> Total execution time: 0.0670
DEBUG - 2022-07-09 06:34:18 --> Total execution time: 0.0521
DEBUG - 2022-07-09 06:34:21 --> Total execution time: 0.0556
DEBUG - 2022-07-09 06:34:38 --> Total execution time: 0.0654
DEBUG - 2022-07-09 06:34:54 --> Total execution time: 0.0747
DEBUG - 2022-07-09 06:35:10 --> Total execution time: 0.0358
DEBUG - 2022-07-09 06:35:11 --> Total execution time: 0.0517
DEBUG - 2022-07-09 06:35:25 --> Total execution time: 0.0359
DEBUG - 2022-07-09 06:36:12 --> Total execution time: 0.0548
DEBUG - 2022-07-09 06:36:16 --> Total execution time: 0.0627
DEBUG - 2022-07-09 06:36:26 --> Total execution time: 0.0529
DEBUG - 2022-07-09 06:36:28 --> Total execution time: 0.0562
DEBUG - 2022-07-09 06:36:34 --> Total execution time: 0.1342
DEBUG - 2022-07-09 06:36:42 --> Total execution time: 0.1434
DEBUG - 2022-07-09 06:36:47 --> Total execution time: 0.0577
DEBUG - 2022-07-09 06:36:53 --> Total execution time: 0.0986
DEBUG - 2022-07-09 06:36:58 --> Total execution time: 0.0814
DEBUG - 2022-07-09 06:37:16 --> Total execution time: 0.0540
DEBUG - 2022-07-09 06:37:21 --> Total execution time: 0.0815
DEBUG - 2022-07-09 06:37:21 --> Total execution time: 0.1328
DEBUG - 2022-07-09 06:37:23 --> Total execution time: 0.0790
DEBUG - 2022-07-09 06:37:26 --> Total execution time: 0.1527
DEBUG - 2022-07-09 06:37:30 --> Total execution time: 0.0778
DEBUG - 2022-07-09 06:37:32 --> Total execution time: 0.0592
DEBUG - 2022-07-09 06:37:35 --> Total execution time: 0.0990
DEBUG - 2022-07-09 06:37:36 --> Total execution time: 0.0701
DEBUG - 2022-07-09 06:38:23 --> Total execution time: 0.0577
DEBUG - 2022-07-09 06:38:29 --> Total execution time: 0.0546
DEBUG - 2022-07-09 06:38:37 --> Total execution time: 0.0891
DEBUG - 2022-07-09 06:38:38 --> Total execution time: 0.0589
DEBUG - 2022-07-09 06:38:49 --> Total execution time: 0.0771
DEBUG - 2022-07-09 06:38:50 --> Total execution time: 0.0529
DEBUG - 2022-07-09 06:38:57 --> Total execution time: 0.0703
DEBUG - 2022-07-09 06:39:01 --> Total execution time: 0.0534
DEBUG - 2022-07-09 06:39:36 --> Total execution time: 0.1058
DEBUG - 2022-07-09 06:39:44 --> Total execution time: 0.0554
DEBUG - 2022-07-09 06:40:03 --> Total execution time: 0.0834
DEBUG - 2022-07-09 06:40:11 --> Total execution time: 0.0771
DEBUG - 2022-07-09 06:40:17 --> Total execution time: 0.0562
DEBUG - 2022-07-09 06:40:27 --> Total execution time: 0.1309
DEBUG - 2022-07-09 06:40:57 --> Total execution time: 0.0717
DEBUG - 2022-07-09 06:46:02 --> Total execution time: 0.0410
DEBUG - 2022-07-09 06:46:14 --> Total execution time: 0.0624
DEBUG - 2022-07-09 06:46:21 --> Total execution time: 0.0893
DEBUG - 2022-07-09 06:46:49 --> Total execution time: 0.0586
DEBUG - 2022-07-09 06:47:17 --> Total execution time: 1.9264
DEBUG - 2022-07-09 06:47:50 --> Total execution time: 0.0516
DEBUG - 2022-07-09 06:51:07 --> Total execution time: 0.1396
DEBUG - 2022-07-09 06:56:08 --> Total execution time: 0.1365
DEBUG - 2022-07-09 06:56:20 --> Total execution time: 0.0506
DEBUG - 2022-07-09 06:56:22 --> Total execution time: 0.0406
DEBUG - 2022-07-09 06:56:59 --> Total execution time: 0.0542
DEBUG - 2022-07-09 06:57:29 --> Total execution time: 0.0617
DEBUG - 2022-07-09 07:03:03 --> Total execution time: 0.2120
DEBUG - 2022-07-09 07:03:15 --> Total execution time: 0.0411
DEBUG - 2022-07-09 07:03:21 --> Total execution time: 0.0514
DEBUG - 2022-07-09 07:03:31 --> Total execution time: 0.0609
DEBUG - 2022-07-09 07:03:48 --> Total execution time: 0.0570
DEBUG - 2022-07-09 07:03:52 --> Total execution time: 0.0520
DEBUG - 2022-07-09 07:03:58 --> Total execution time: 0.0591
DEBUG - 2022-07-09 07:03:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 07:03:59 --> Total execution time: 0.0434
DEBUG - 2022-07-09 07:07:49 --> Total execution time: 0.0366
DEBUG - 2022-07-09 07:07:55 --> Total execution time: 0.0328
DEBUG - 2022-07-09 07:08:24 --> Total execution time: 0.0674
DEBUG - 2022-07-09 07:08:34 --> Total execution time: 0.0811
DEBUG - 2022-07-09 07:08:36 --> Total execution time: 0.0494
DEBUG - 2022-07-09 07:08:42 --> Total execution time: 0.0569
DEBUG - 2022-07-09 07:08:51 --> Total execution time: 0.1277
DEBUG - 2022-07-09 07:08:51 --> Total execution time: 0.0527
DEBUG - 2022-07-09 07:08:54 --> Total execution time: 0.0519
DEBUG - 2022-07-09 07:09:00 --> Total execution time: 0.0548
DEBUG - 2022-07-09 07:09:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 07:09:01 --> Total execution time: 0.1284
DEBUG - 2022-07-09 07:09:01 --> Total execution time: 0.0672
DEBUG - 2022-07-09 07:09:42 --> Total execution time: 0.0569
DEBUG - 2022-07-09 07:09:47 --> Total execution time: 0.0535
DEBUG - 2022-07-09 07:10:04 --> Total execution time: 0.0582
DEBUG - 2022-07-09 07:10:25 --> Total execution time: 0.0533
DEBUG - 2022-07-09 07:10:33 --> Total execution time: 0.0932
DEBUG - 2022-07-09 07:11:06 --> Total execution time: 0.0556
DEBUG - 2022-07-09 07:11:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 07:11:07 --> Total execution time: 0.0530
DEBUG - 2022-07-09 07:11:08 --> Total execution time: 0.0506
DEBUG - 2022-07-09 07:13:29 --> Total execution time: 0.0366
DEBUG - 2022-07-09 07:13:31 --> Total execution time: 0.0544
DEBUG - 2022-07-09 07:13:42 --> Total execution time: 0.0512
DEBUG - 2022-07-09 07:13:42 --> Total execution time: 0.0592
DEBUG - 2022-07-09 07:13:45 --> Total execution time: 0.0539
DEBUG - 2022-07-09 07:13:53 --> Total execution time: 0.0557
DEBUG - 2022-07-09 07:13:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 07:13:54 --> Total execution time: 0.0501
DEBUG - 2022-07-09 07:13:57 --> Total execution time: 0.0363
DEBUG - 2022-07-09 07:14:27 --> Total execution time: 0.1388
DEBUG - 2022-07-09 07:14:31 --> Total execution time: 0.0660
DEBUG - 2022-07-09 07:14:38 --> Total execution time: 0.0491
DEBUG - 2022-07-09 07:14:56 --> Total execution time: 0.0560
DEBUG - 2022-07-09 07:15:24 --> Total execution time: 0.0519
DEBUG - 2022-07-09 07:20:43 --> Total execution time: 0.1098
DEBUG - 2022-07-09 07:22:15 --> Total execution time: 0.0633
DEBUG - 2022-07-09 07:27:56 --> Total execution time: 0.1215
DEBUG - 2022-07-09 07:30:04 --> Total execution time: 0.0433
DEBUG - 2022-07-09 07:34:40 --> Total execution time: 0.1272
DEBUG - 2022-07-09 07:36:04 --> Total execution time: 0.0375
DEBUG - 2022-07-09 07:36:09 --> Total execution time: 0.0548
DEBUG - 2022-07-09 07:36:16 --> Total execution time: 0.0536
DEBUG - 2022-07-09 07:36:20 --> Total execution time: 0.0528
DEBUG - 2022-07-09 07:36:24 --> Total execution time: 0.0571
DEBUG - 2022-07-09 07:36:32 --> Total execution time: 0.0729
DEBUG - 2022-07-09 07:36:59 --> Total execution time: 0.0531
DEBUG - 2022-07-09 07:37:03 --> Total execution time: 0.0514
DEBUG - 2022-07-09 07:37:08 --> Total execution time: 0.0588
DEBUG - 2022-07-09 07:37:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 07:37:09 --> Total execution time: 0.0446
DEBUG - 2022-07-09 07:37:32 --> Total execution time: 0.0527
DEBUG - 2022-07-09 07:38:39 --> Total execution time: 0.1534
DEBUG - 2022-07-09 07:38:39 --> Total execution time: 0.0508
DEBUG - 2022-07-09 07:38:39 --> Total execution time: 0.0563
DEBUG - 2022-07-09 07:38:42 --> Total execution time: 0.0783
DEBUG - 2022-07-09 07:38:46 --> Total execution time: 0.0505
DEBUG - 2022-07-09 07:38:51 --> Total execution time: 0.0526
DEBUG - 2022-07-09 07:38:55 --> Total execution time: 0.0391
DEBUG - 2022-07-09 07:38:57 --> Total execution time: 0.0736
DEBUG - 2022-07-09 07:38:59 --> Total execution time: 0.0566
DEBUG - 2022-07-09 07:39:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 07:39:00 --> Total execution time: 0.0615
DEBUG - 2022-07-09 07:40:05 --> Total execution time: 0.0502
DEBUG - 2022-07-09 07:40:20 --> Total execution time: 0.0486
DEBUG - 2022-07-09 07:40:29 --> Total execution time: 0.0555
DEBUG - 2022-07-09 07:40:34 --> Total execution time: 0.0524
DEBUG - 2022-07-09 07:40:40 --> Total execution time: 0.0577
DEBUG - 2022-07-09 07:40:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 07:40:41 --> Total execution time: 0.0598
DEBUG - 2022-07-09 07:41:28 --> Total execution time: 0.1251
DEBUG - 2022-07-09 07:41:32 --> Total execution time: 0.0499
DEBUG - 2022-07-09 07:41:47 --> Total execution time: 0.0641
DEBUG - 2022-07-09 07:41:59 --> Total execution time: 0.0493
DEBUG - 2022-07-09 07:42:18 --> Total execution time: 0.0531
DEBUG - 2022-07-09 07:42:25 --> Total execution time: 0.0533
DEBUG - 2022-07-09 07:42:32 --> Total execution time: 0.0749
DEBUG - 2022-07-09 07:42:42 --> Total execution time: 0.0543
DEBUG - 2022-07-09 07:43:06 --> Total execution time: 0.0591
DEBUG - 2022-07-09 07:43:10 --> Total execution time: 0.0526
DEBUG - 2022-07-09 07:43:14 --> Total execution time: 0.0448
DEBUG - 2022-07-09 07:43:15 --> Total execution time: 0.0473
DEBUG - 2022-07-09 07:43:16 --> Total execution time: 0.0449
DEBUG - 2022-07-09 07:43:16 --> Total execution time: 0.0593
DEBUG - 2022-07-09 07:47:16 --> Total execution time: 0.2018
DEBUG - 2022-07-09 07:47:24 --> Total execution time: 0.0595
DEBUG - 2022-07-09 07:49:50 --> Total execution time: 0.0978
DEBUG - 2022-07-09 08:02:29 --> Total execution time: 0.1180
DEBUG - 2022-07-09 08:05:30 --> Total execution time: 0.1100
DEBUG - 2022-07-09 08:06:37 --> Total execution time: 1.9415
DEBUG - 2022-07-09 08:07:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 08:07:07 --> Total execution time: 0.0559
DEBUG - 2022-07-09 08:07:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 08:07:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 08:07:08 --> Total execution time: 0.1952
DEBUG - 2022-07-09 08:07:11 --> Total execution time: 0.0660
DEBUG - 2022-07-09 08:07:22 --> Total execution time: 0.0855
DEBUG - 2022-07-09 08:08:39 --> Total execution time: 0.0413
DEBUG - 2022-07-09 08:09:10 --> Total execution time: 0.0513
DEBUG - 2022-07-09 08:11:49 --> Total execution time: 0.1082
DEBUG - 2022-07-09 08:12:35 --> Total execution time: 0.0390
DEBUG - 2022-07-09 08:23:10 --> Total execution time: 0.1544
DEBUG - 2022-07-09 08:23:20 --> Total execution time: 0.0666
DEBUG - 2022-07-09 08:23:49 --> Total execution time: 0.0536
DEBUG - 2022-07-09 08:24:06 --> Total execution time: 0.0823
DEBUG - 2022-07-09 08:24:15 --> Total execution time: 0.0591
DEBUG - 2022-07-09 08:24:43 --> Total execution time: 0.0753
DEBUG - 2022-07-09 08:25:31 --> Total execution time: 0.0802
DEBUG - 2022-07-09 08:27:16 --> Total execution time: 0.0489
DEBUG - 2022-07-09 08:29:11 --> Total execution time: 0.0417
DEBUG - 2022-07-09 08:30:02 --> Total execution time: 0.0493
DEBUG - 2022-07-09 08:36:26 --> Total execution time: 0.0563
DEBUG - 2022-07-09 08:36:45 --> Total execution time: 0.0981
DEBUG - 2022-07-09 08:36:54 --> Total execution time: 0.0646
DEBUG - 2022-07-09 08:37:15 --> Total execution time: 0.0412
DEBUG - 2022-07-09 08:37:58 --> Total execution time: 0.0597
DEBUG - 2022-07-09 08:42:30 --> Total execution time: 0.0706
DEBUG - 2022-07-09 08:43:01 --> Total execution time: 0.0765
DEBUG - 2022-07-09 08:46:41 --> Total execution time: 0.1271
DEBUG - 2022-07-09 08:46:59 --> Total execution time: 0.0899
DEBUG - 2022-07-09 08:47:02 --> Total execution time: 0.1093
DEBUG - 2022-07-09 08:47:14 --> Total execution time: 0.0836
DEBUG - 2022-07-09 08:47:17 --> Total execution time: 0.0843
DEBUG - 2022-07-09 08:47:37 --> Total execution time: 0.0775
DEBUG - 2022-07-09 08:47:39 --> Total execution time: 0.1042
DEBUG - 2022-07-09 08:47:43 --> Total execution time: 0.0940
DEBUG - 2022-07-09 08:47:49 --> Total execution time: 0.0816
DEBUG - 2022-07-09 08:47:53 --> Total execution time: 0.0847
DEBUG - 2022-07-09 08:48:01 --> Total execution time: 0.1549
DEBUG - 2022-07-09 08:48:10 --> Total execution time: 0.0849
DEBUG - 2022-07-09 08:48:26 --> Total execution time: 0.0674
DEBUG - 2022-07-09 08:54:18 --> Total execution time: 0.1159
DEBUG - 2022-07-09 09:00:54 --> Total execution time: 0.0989
DEBUG - 2022-07-09 09:06:51 --> Total execution time: 0.0915
DEBUG - 2022-07-09 09:06:55 --> Total execution time: 0.0529
DEBUG - 2022-07-09 09:07:11 --> Total execution time: 0.0530
DEBUG - 2022-07-09 09:07:27 --> Total execution time: 0.0584
DEBUG - 2022-07-09 09:08:52 --> Total execution time: 0.0520
DEBUG - 2022-07-09 09:11:35 --> Total execution time: 0.0576
DEBUG - 2022-07-09 09:12:15 --> Total execution time: 0.0626
DEBUG - 2022-07-09 09:13:55 --> Total execution time: 0.0909
DEBUG - 2022-07-09 09:17:16 --> Total execution time: 0.0911
DEBUG - 2022-07-09 09:17:37 --> Total execution time: 0.0504
DEBUG - 2022-07-09 09:18:46 --> Total execution time: 0.0347
DEBUG - 2022-07-09 09:19:12 --> Total execution time: 0.0833
DEBUG - 2022-07-09 09:19:24 --> Total execution time: 0.0922
DEBUG - 2022-07-09 09:19:36 --> Total execution time: 0.0675
DEBUG - 2022-07-09 09:19:39 --> Total execution time: 0.0364
DEBUG - 2022-07-09 09:19:44 --> Total execution time: 0.0575
DEBUG - 2022-07-09 09:19:46 --> Total execution time: 0.0576
DEBUG - 2022-07-09 09:20:00 --> Total execution time: 0.0539
DEBUG - 2022-07-09 09:20:08 --> Total execution time: 0.0554
DEBUG - 2022-07-09 09:20:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 09:20:09 --> Total execution time: 0.0643
DEBUG - 2022-07-09 09:22:48 --> Total execution time: 0.0656
DEBUG - 2022-07-09 09:23:01 --> Total execution time: 0.0684
DEBUG - 2022-07-09 09:23:48 --> Total execution time: 0.0606
DEBUG - 2022-07-09 09:25:04 --> Total execution time: 0.0943
DEBUG - 2022-07-09 09:25:14 --> Total execution time: 0.0551
DEBUG - 2022-07-09 09:25:21 --> Total execution time: 0.0613
DEBUG - 2022-07-09 09:25:26 --> Total execution time: 0.0661
DEBUG - 2022-07-09 09:25:57 --> Total execution time: 0.0762
DEBUG - 2022-07-09 09:26:31 --> Total execution time: 0.1094
DEBUG - 2022-07-09 09:26:49 --> Total execution time: 0.0748
DEBUG - 2022-07-09 09:26:55 --> Total execution time: 0.0703
DEBUG - 2022-07-09 09:27:12 --> Total execution time: 0.0541
DEBUG - 2022-07-09 09:27:47 --> Total execution time: 0.0595
DEBUG - 2022-07-09 09:28:46 --> Total execution time: 0.0633
DEBUG - 2022-07-09 09:29:51 --> Total execution time: 0.1482
DEBUG - 2022-07-09 09:29:53 --> Total execution time: 0.0764
DEBUG - 2022-07-09 09:30:02 --> Total execution time: 0.0624
DEBUG - 2022-07-09 09:30:19 --> Total execution time: 0.0512
DEBUG - 2022-07-09 09:30:48 --> Total execution time: 0.0612
DEBUG - 2022-07-09 09:31:06 --> Total execution time: 0.1104
DEBUG - 2022-07-09 09:32:27 --> Total execution time: 0.8213
DEBUG - 2022-07-09 09:33:49 --> Total execution time: 0.0408
DEBUG - 2022-07-09 09:35:08 --> Total execution time: 0.0655
DEBUG - 2022-07-09 09:35:22 --> Total execution time: 0.0564
DEBUG - 2022-07-09 09:35:32 --> Total execution time: 0.0514
DEBUG - 2022-07-09 09:35:37 --> Total execution time: 0.0529
DEBUG - 2022-07-09 09:35:45 --> Total execution time: 0.0547
DEBUG - 2022-07-09 09:35:53 --> Total execution time: 0.0547
DEBUG - 2022-07-09 09:35:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 09:35:54 --> Total execution time: 0.0533
DEBUG - 2022-07-09 09:39:33 --> Total execution time: 0.1210
DEBUG - 2022-07-09 09:39:41 --> Total execution time: 0.0364
DEBUG - 2022-07-09 09:40:08 --> Total execution time: 0.0347
DEBUG - 2022-07-09 09:40:35 --> Total execution time: 0.0589
DEBUG - 2022-07-09 09:40:52 --> Total execution time: 0.0527
DEBUG - 2022-07-09 09:40:58 --> Total execution time: 0.0505
DEBUG - 2022-07-09 09:41:26 --> Total execution time: 0.0677
DEBUG - 2022-07-09 09:41:48 --> Total execution time: 0.0645
DEBUG - 2022-07-09 09:42:33 --> Total execution time: 0.1306
DEBUG - 2022-07-09 09:42:41 --> Total execution time: 0.1049
DEBUG - 2022-07-09 09:42:58 --> Total execution time: 0.0389
DEBUG - 2022-07-09 09:43:05 --> Total execution time: 0.0333
DEBUG - 2022-07-09 09:43:27 --> Total execution time: 0.0694
DEBUG - 2022-07-09 09:43:31 --> Total execution time: 0.0516
DEBUG - 2022-07-09 09:43:37 --> Total execution time: 0.0558
DEBUG - 2022-07-09 09:43:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 09:43:39 --> Total execution time: 0.0508
DEBUG - 2022-07-09 09:43:40 --> Total execution time: 0.0588
DEBUG - 2022-07-09 09:45:13 --> Total execution time: 0.0337
DEBUG - 2022-07-09 09:45:35 --> Total execution time: 0.0331
DEBUG - 2022-07-09 09:46:04 --> Total execution time: 0.0527
DEBUG - 2022-07-09 09:46:08 --> Total execution time: 0.0616
DEBUG - 2022-07-09 09:46:11 --> Total execution time: 0.0465
DEBUG - 2022-07-09 09:46:14 --> Total execution time: 0.0362
DEBUG - 2022-07-09 09:46:16 --> Total execution time: 0.0501
DEBUG - 2022-07-09 09:46:40 --> Total execution time: 0.1244
DEBUG - 2022-07-09 09:46:47 --> Total execution time: 0.0441
DEBUG - 2022-07-09 09:46:51 --> Total execution time: 0.0443
DEBUG - 2022-07-09 09:46:57 --> Total execution time: 0.0653
DEBUG - 2022-07-09 09:47:23 --> Total execution time: 0.0491
DEBUG - 2022-07-09 09:47:33 --> Total execution time: 0.0977
DEBUG - 2022-07-09 09:47:37 --> Total execution time: 0.0945
DEBUG - 2022-07-09 09:48:14 --> Total execution time: 0.0356
DEBUG - 2022-07-09 09:48:44 --> Total execution time: 0.0650
DEBUG - 2022-07-09 09:48:53 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 09:48:53 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-07-09 09:48:54 --> Total execution time: 0.0886
DEBUG - 2022-07-09 09:49:00 --> Total execution time: 0.0918
DEBUG - 2022-07-09 09:49:31 --> Total execution time: 0.0802
DEBUG - 2022-07-09 09:53:02 --> Total execution time: 0.0671
DEBUG - 2022-07-09 09:53:13 --> Total execution time: 0.0584
DEBUG - 2022-07-09 09:58:10 --> Total execution time: 0.0532
DEBUG - 2022-07-09 09:58:49 --> Total execution time: 0.1395
DEBUG - 2022-07-09 10:00:22 --> Total execution time: 0.0505
DEBUG - 2022-07-09 10:02:56 --> Total execution time: 0.0477
DEBUG - 2022-07-09 10:02:59 --> Total execution time: 0.0501
DEBUG - 2022-07-09 10:03:06 --> Total execution time: 0.0584
DEBUG - 2022-07-09 10:03:10 --> Total execution time: 0.0865
DEBUG - 2022-07-09 10:03:13 --> Total execution time: 0.0639
DEBUG - 2022-07-09 10:03:31 --> Total execution time: 0.0505
DEBUG - 2022-07-09 10:03:33 --> Total execution time: 0.0434
DEBUG - 2022-07-09 10:04:02 --> Total execution time: 0.0615
DEBUG - 2022-07-09 10:07:14 --> Total execution time: 0.1129
DEBUG - 2022-07-09 10:09:17 --> Total execution time: 0.1259
DEBUG - 2022-07-09 10:10:52 --> Total execution time: 0.0514
DEBUG - 2022-07-09 10:10:57 --> Total execution time: 0.0706
DEBUG - 2022-07-09 10:11:02 --> Total execution time: 0.0775
DEBUG - 2022-07-09 10:11:05 --> Total execution time: 0.0592
DEBUG - 2022-07-09 10:11:12 --> Total execution time: 0.0510
DEBUG - 2022-07-09 10:11:14 --> Total execution time: 0.0549
DEBUG - 2022-07-09 10:11:15 --> Total execution time: 0.0496
DEBUG - 2022-07-09 10:11:37 --> Total execution time: 0.0565
DEBUG - 2022-07-09 10:11:52 --> Total execution time: 0.0786
DEBUG - 2022-07-09 10:11:57 --> Total execution time: 0.1101
DEBUG - 2022-07-09 10:12:01 --> Total execution time: 0.0740
DEBUG - 2022-07-09 10:12:11 --> Total execution time: 0.0594
DEBUG - 2022-07-09 10:12:22 --> Total execution time: 0.0579
DEBUG - 2022-07-09 10:12:35 --> Total execution time: 0.1012
DEBUG - 2022-07-09 10:12:49 --> Total execution time: 0.0797
DEBUG - 2022-07-09 10:12:59 --> Total execution time: 0.0613
DEBUG - 2022-07-09 10:13:08 --> Total execution time: 0.0523
DEBUG - 2022-07-09 10:13:08 --> Total execution time: 0.0397
DEBUG - 2022-07-09 10:13:10 --> Total execution time: 0.0818
DEBUG - 2022-07-09 10:13:17 --> Total execution time: 0.0624
DEBUG - 2022-07-09 10:13:31 --> Total execution time: 0.0537
DEBUG - 2022-07-09 10:13:32 --> Total execution time: 0.0346
DEBUG - 2022-07-09 10:13:55 --> Total execution time: 0.0508
DEBUG - 2022-07-09 10:14:05 --> Total execution time: 0.0739
DEBUG - 2022-07-09 10:14:12 --> Total execution time: 0.0646
DEBUG - 2022-07-09 10:14:13 --> Total execution time: 0.0582
DEBUG - 2022-07-09 10:14:15 --> Total execution time: 0.0544
DEBUG - 2022-07-09 10:14:15 --> Total execution time: 0.0860
DEBUG - 2022-07-09 10:14:16 --> Total execution time: 0.0661
DEBUG - 2022-07-09 10:14:17 --> Total execution time: 0.0571
DEBUG - 2022-07-09 10:14:18 --> Total execution time: 0.0815
DEBUG - 2022-07-09 10:14:18 --> Total execution time: 0.0584
DEBUG - 2022-07-09 10:14:19 --> Total execution time: 0.0775
DEBUG - 2022-07-09 10:14:19 --> Total execution time: 0.0536
DEBUG - 2022-07-09 10:14:20 --> Total execution time: 0.0540
DEBUG - 2022-07-09 10:14:20 --> Total execution time: 0.0552
DEBUG - 2022-07-09 10:14:21 --> Total execution time: 0.0543
DEBUG - 2022-07-09 10:14:21 --> Total execution time: 0.0554
DEBUG - 2022-07-09 10:14:22 --> Total execution time: 0.0620
DEBUG - 2022-07-09 10:14:23 --> Total execution time: 0.0578
DEBUG - 2022-07-09 10:14:23 --> Total execution time: 0.0526
DEBUG - 2022-07-09 10:14:24 --> Total execution time: 0.0534
DEBUG - 2022-07-09 10:14:25 --> Total execution time: 0.0352
DEBUG - 2022-07-09 10:14:35 --> Total execution time: 0.0885
DEBUG - 2022-07-09 10:14:36 --> Total execution time: 0.0846
DEBUG - 2022-07-09 10:14:44 --> Total execution time: 0.0514
DEBUG - 2022-07-09 10:14:47 --> Total execution time: 0.0663
DEBUG - 2022-07-09 10:14:58 --> Total execution time: 0.0567
DEBUG - 2022-07-09 10:15:06 --> Total execution time: 0.0668
DEBUG - 2022-07-09 10:15:23 --> Total execution time: 0.0673
DEBUG - 2022-07-09 10:15:26 --> Total execution time: 0.0548
DEBUG - 2022-07-09 10:15:28 --> Total execution time: 0.0535
DEBUG - 2022-07-09 10:15:37 --> Total execution time: 0.0696
DEBUG - 2022-07-09 10:15:55 --> Total execution time: 0.0740
DEBUG - 2022-07-09 10:16:00 --> Total execution time: 0.0741
DEBUG - 2022-07-09 10:16:07 --> Total execution time: 0.0561
DEBUG - 2022-07-09 10:16:10 --> Total execution time: 0.0965
DEBUG - 2022-07-09 10:16:11 --> Total execution time: 0.0590
DEBUG - 2022-07-09 10:16:22 --> Total execution time: 0.0802
DEBUG - 2022-07-09 10:16:36 --> Total execution time: 0.0615
DEBUG - 2022-07-09 10:16:36 --> Total execution time: 0.0395
DEBUG - 2022-07-09 10:16:41 --> Total execution time: 0.0532
DEBUG - 2022-07-09 10:16:43 --> Total execution time: 0.0600
DEBUG - 2022-07-09 10:16:43 --> Total execution time: 0.0352
DEBUG - 2022-07-09 10:16:52 --> Total execution time: 0.1095
DEBUG - 2022-07-09 10:17:01 --> Total execution time: 0.0968
DEBUG - 2022-07-09 10:17:14 --> Total execution time: 0.0603
DEBUG - 2022-07-09 10:17:14 --> Total execution time: 0.0873
DEBUG - 2022-07-09 10:17:18 --> Total execution time: 0.0464
DEBUG - 2022-07-09 10:17:21 --> Total execution time: 0.0751
DEBUG - 2022-07-09 10:17:41 --> Total execution time: 0.1057
DEBUG - 2022-07-09 10:18:05 --> Total execution time: 0.0729
DEBUG - 2022-07-09 10:18:10 --> Total execution time: 0.0722
DEBUG - 2022-07-09 10:18:17 --> Total execution time: 0.0713
DEBUG - 2022-07-09 10:18:24 --> Total execution time: 0.0793
DEBUG - 2022-07-09 10:18:28 --> Total execution time: 0.0591
DEBUG - 2022-07-09 10:18:43 --> Total execution time: 0.0535
DEBUG - 2022-07-09 10:18:57 --> Total execution time: 0.0570
DEBUG - 2022-07-09 10:19:05 --> Total execution time: 0.0790
DEBUG - 2022-07-09 10:19:08 --> Total execution time: 0.0491
DEBUG - 2022-07-09 10:20:22 --> Total execution time: 0.0518
DEBUG - 2022-07-09 10:20:29 --> Total execution time: 0.0771
DEBUG - 2022-07-09 10:20:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 10:20:29 --> Total execution time: 0.0613
DEBUG - 2022-07-09 10:20:30 --> Total execution time: 0.0505
DEBUG - 2022-07-09 10:20:54 --> Total execution time: 0.0501
DEBUG - 2022-07-09 10:20:55 --> Total execution time: 0.0336
DEBUG - 2022-07-09 10:21:03 --> Total execution time: 0.0347
DEBUG - 2022-07-09 10:21:22 --> Total execution time: 0.0649
DEBUG - 2022-07-09 10:21:41 --> Total execution time: 0.0673
DEBUG - 2022-07-09 10:22:05 --> Total execution time: 0.0539
DEBUG - 2022-07-09 10:24:58 --> Total execution time: 0.1299
DEBUG - 2022-07-09 10:25:59 --> Total execution time: 0.0653
DEBUG - 2022-07-09 10:26:02 --> Total execution time: 0.0680
DEBUG - 2022-07-09 10:26:03 --> Total execution time: 0.0664
DEBUG - 2022-07-09 10:26:03 --> Total execution time: 0.0574
DEBUG - 2022-07-09 10:26:04 --> Total execution time: 0.0542
DEBUG - 2022-07-09 10:26:10 --> Total execution time: 0.0510
DEBUG - 2022-07-09 10:26:12 --> Total execution time: 0.0588
DEBUG - 2022-07-09 10:26:14 --> Total execution time: 0.0623
DEBUG - 2022-07-09 10:26:27 --> Total execution time: 0.1449
DEBUG - 2022-07-09 10:26:30 --> Total execution time: 0.0596
DEBUG - 2022-07-09 10:26:35 --> Total execution time: 0.0702
DEBUG - 2022-07-09 10:26:40 --> Total execution time: 0.0631
DEBUG - 2022-07-09 10:26:57 --> Total execution time: 0.0624
DEBUG - 2022-07-09 10:27:17 --> Total execution time: 0.0831
DEBUG - 2022-07-09 10:27:38 --> Total execution time: 0.0643
DEBUG - 2022-07-09 10:28:17 --> Total execution time: 0.0496
DEBUG - 2022-07-09 10:28:39 --> Total execution time: 0.0585
DEBUG - 2022-07-09 10:28:40 --> Total execution time: 0.0514
DEBUG - 2022-07-09 10:28:51 --> Total execution time: 0.0583
DEBUG - 2022-07-09 10:28:58 --> Total execution time: 0.0673
DEBUG - 2022-07-09 10:28:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 10:28:59 --> Total execution time: 0.0513
DEBUG - 2022-07-09 10:29:05 --> Total execution time: 0.0680
DEBUG - 2022-07-09 10:29:14 --> Total execution time: 0.0551
DEBUG - 2022-07-09 10:29:17 --> Total execution time: 0.0672
DEBUG - 2022-07-09 10:29:25 --> Total execution time: 0.0771
DEBUG - 2022-07-09 10:29:26 --> Total execution time: 0.0887
DEBUG - 2022-07-09 10:29:38 --> Total execution time: 0.0870
DEBUG - 2022-07-09 10:29:38 --> Total execution time: 0.0871
DEBUG - 2022-07-09 10:29:40 --> Total execution time: 0.1105
DEBUG - 2022-07-09 10:29:40 --> Total execution time: 0.1657
DEBUG - 2022-07-09 10:29:40 --> Total execution time: 0.2700
DEBUG - 2022-07-09 10:29:41 --> Total execution time: 0.0805
DEBUG - 2022-07-09 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:30:02 --> Total execution time: 0.0945
DEBUG - 2022-07-09 00:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:30:49 --> Total execution time: 0.0949
DEBUG - 2022-07-09 00:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:01:05 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:31:05 --> Total execution time: 0.0531
DEBUG - 2022-07-09 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:01:13 --> Total execution time: 0.0658
DEBUG - 2022-07-09 00:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:01:15 --> Total execution time: 0.0542
DEBUG - 2022-07-09 00:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:01:15 --> Total execution time: 0.1003
DEBUG - 2022-07-09 00:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:01:41 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:31:41 --> Total execution time: 0.1320
DEBUG - 2022-07-09 00:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:31:43 --> Total execution time: 0.0767
DEBUG - 2022-07-09 00:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:31:43 --> Total execution time: 0.1044
DEBUG - 2022-07-09 00:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:31:45 --> Total execution time: 0.1161
DEBUG - 2022-07-09 00:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:31:49 --> Total execution time: 0.1076
DEBUG - 2022-07-09 00:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:31:50 --> Total execution time: 0.0855
DEBUG - 2022-07-09 00:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:31:50 --> Total execution time: 0.1075
DEBUG - 2022-07-09 00:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:31:50 --> Total execution time: 0.0679
DEBUG - 2022-07-09 00:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:31:51 --> Total execution time: 0.0671
DEBUG - 2022-07-09 00:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:31:52 --> Total execution time: 0.0723
DEBUG - 2022-07-09 00:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:31:58 --> Total execution time: 0.0607
DEBUG - 2022-07-09 00:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:32:00 --> Total execution time: 0.7132
DEBUG - 2022-07-09 00:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:32:50 --> Total execution time: 0.0645
DEBUG - 2022-07-09 00:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:03:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 00:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:33:15 --> Total execution time: 2.0438
DEBUG - 2022-07-09 00:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:03:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 00:03:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 00:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:34:14 --> Total execution time: 0.1346
DEBUG - 2022-07-09 00:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:05:16 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:35:16 --> Total execution time: 0.0450
DEBUG - 2022-07-09 00:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:06:42 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:36:42 --> Total execution time: 0.0413
DEBUG - 2022-07-09 00:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:36:43 --> Total execution time: 0.0512
DEBUG - 2022-07-09 00:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:36:47 --> Total execution time: 0.0825
DEBUG - 2022-07-09 00:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:36:49 --> Total execution time: 0.1048
DEBUG - 2022-07-09 00:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:07:17 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:37:17 --> Total execution time: 0.0366
DEBUG - 2022-07-09 00:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:37:25 --> Total execution time: 0.0849
DEBUG - 2022-07-09 00:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:37:26 --> Total execution time: 0.1353
DEBUG - 2022-07-09 00:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:37:27 --> Total execution time: 0.1082
DEBUG - 2022-07-09 00:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:37:28 --> Total execution time: 0.0899
DEBUG - 2022-07-09 00:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:37:28 --> Total execution time: 0.0804
DEBUG - 2022-07-09 00:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:37:30 --> Total execution time: 0.0987
DEBUG - 2022-07-09 00:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:37:34 --> Total execution time: 1.6311
DEBUG - 2022-07-09 00:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:37:39 --> Total execution time: 0.0491
DEBUG - 2022-07-09 00:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:37:49 --> Total execution time: 0.0637
DEBUG - 2022-07-09 00:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:37:49 --> Total execution time: 0.0492
DEBUG - 2022-07-09 00:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:37:51 --> Total execution time: 0.0581
DEBUG - 2022-07-09 00:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:37:56 --> Total execution time: 0.0964
DEBUG - 2022-07-09 00:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:38:02 --> Total execution time: 0.2189
DEBUG - 2022-07-09 00:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:38:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 00:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:38:04 --> Total execution time: 0.0596
DEBUG - 2022-07-09 00:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:38:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 10:38:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 10:38:05 --> Total execution time: 0.1889
DEBUG - 2022-07-09 00:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:08:27 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:38:28 --> Total execution time: 0.0381
DEBUG - 2022-07-09 00:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:38:31 --> Total execution time: 0.0337
DEBUG - 2022-07-09 00:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:38:57 --> Total execution time: 0.0507
DEBUG - 2022-07-09 00:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:09:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 00:09:15 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-09 00:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:39:36 --> Total execution time: 0.0555
DEBUG - 2022-07-09 00:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:39:40 --> Total execution time: 0.0956
DEBUG - 2022-07-09 00:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:39:49 --> Total execution time: 0.1529
DEBUG - 2022-07-09 00:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:40:23 --> Total execution time: 0.1370
DEBUG - 2022-07-09 00:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:40:43 --> Total execution time: 0.1675
DEBUG - 2022-07-09 00:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:41:01 --> Total execution time: 0.0595
DEBUG - 2022-07-09 00:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:41:13 --> Total execution time: 0.0563
DEBUG - 2022-07-09 00:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:41:29 --> Total execution time: 0.0642
DEBUG - 2022-07-09 00:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:11:54 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:41:54 --> Total execution time: 0.1336
DEBUG - 2022-07-09 00:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:12:21 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:42:21 --> Total execution time: 0.1369
DEBUG - 2022-07-09 00:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:42:37 --> Total execution time: 0.0542
DEBUG - 2022-07-09 00:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:42:40 --> Total execution time: 0.0540
DEBUG - 2022-07-09 00:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:42:45 --> Total execution time: 0.0978
DEBUG - 2022-07-09 00:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:42:59 --> Total execution time: 0.0604
DEBUG - 2022-07-09 00:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:13:02 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:43:02 --> Total execution time: 0.0386
DEBUG - 2022-07-09 00:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:13:47 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:43:47 --> Total execution time: 0.0511
DEBUG - 2022-07-09 00:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:21:53 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:51:53 --> Total execution time: 0.1170
DEBUG - 2022-07-09 00:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:51:57 --> Total execution time: 0.0695
DEBUG - 2022-07-09 00:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:52:07 --> Total execution time: 0.0762
DEBUG - 2022-07-09 00:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:52:18 --> Total execution time: 0.0918
DEBUG - 2022-07-09 00:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:52:20 --> Total execution time: 0.1613
DEBUG - 2022-07-09 00:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:52:23 --> Total execution time: 0.0873
DEBUG - 2022-07-09 00:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:52:24 --> Total execution time: 0.0639
DEBUG - 2022-07-09 00:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:52:26 --> Total execution time: 0.0967
DEBUG - 2022-07-09 00:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:52:30 --> Total execution time: 0.0497
DEBUG - 2022-07-09 00:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:52:36 --> Total execution time: 0.0813
DEBUG - 2022-07-09 00:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:52:36 --> Total execution time: 0.0539
DEBUG - 2022-07-09 00:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:53:34 --> Total execution time: 0.1562
DEBUG - 2022-07-09 00:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:57:18 --> Total execution time: 0.1939
DEBUG - 2022-07-09 00:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:27:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 00:27:33 --> 404 Page Not Found: Teacher/subhash-chhabra
DEBUG - 2022-07-09 00:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:01:37 --> Total execution time: 0.2617
DEBUG - 2022-07-09 00:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:31:39 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:01:39 --> Total execution time: 0.0445
DEBUG - 2022-07-09 00:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:01:49 --> Total execution time: 0.0713
DEBUG - 2022-07-09 00:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:03:01 --> Total execution time: 0.0815
DEBUG - 2022-07-09 00:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:03:30 --> Total execution time: 0.0880
DEBUG - 2022-07-09 00:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:03:31 --> Total execution time: 0.0571
DEBUG - 2022-07-09 00:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:03:32 --> Total execution time: 0.0647
DEBUG - 2022-07-09 00:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:03:32 --> Total execution time: 0.0605
DEBUG - 2022-07-09 00:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:35:43 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:05:43 --> Total execution time: 0.0405
DEBUG - 2022-07-09 00:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:05:49 --> Total execution time: 0.0504
DEBUG - 2022-07-09 00:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:35:53 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:05:53 --> Total execution time: 0.0381
DEBUG - 2022-07-09 00:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:06:31 --> Total execution time: 0.0751
DEBUG - 2022-07-09 00:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:07:28 --> Total execution time: 0.0649
DEBUG - 2022-07-09 00:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:07:46 --> Total execution time: 0.0621
DEBUG - 2022-07-09 00:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:07:48 --> Total execution time: 0.0736
DEBUG - 2022-07-09 00:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:08:01 --> Total execution time: 0.0690
DEBUG - 2022-07-09 00:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:38:42 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:08:42 --> Total execution time: 0.1347
DEBUG - 2022-07-09 00:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:38:43 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:08:43 --> Total execution time: 0.0549
DEBUG - 2022-07-09 00:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:08:56 --> Total execution time: 0.0409
DEBUG - 2022-07-09 00:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:09:03 --> Total execution time: 0.0534
DEBUG - 2022-07-09 00:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:39:12 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:09:12 --> Total execution time: 0.0521
DEBUG - 2022-07-09 00:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:10:14 --> Total execution time: 0.0978
DEBUG - 2022-07-09 00:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:11:58 --> Total execution time: 0.1295
DEBUG - 2022-07-09 00:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:12:07 --> Total execution time: 0.0660
DEBUG - 2022-07-09 00:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:12:25 --> Total execution time: 0.0550
DEBUG - 2022-07-09 00:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:12:32 --> Total execution time: 0.0520
DEBUG - 2022-07-09 00:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:12:37 --> Total execution time: 0.0869
DEBUG - 2022-07-09 00:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:42:47 --> Total execution time: 0.0472
DEBUG - 2022-07-09 00:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:12:57 --> Total execution time: 0.0619
DEBUG - 2022-07-09 00:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:13:06 --> Total execution time: 0.0666
DEBUG - 2022-07-09 00:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:44:06 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:14:07 --> Total execution time: 0.1338
DEBUG - 2022-07-09 00:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:45:08 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:15:08 --> Total execution time: 0.0746
DEBUG - 2022-07-09 00:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:15:12 --> Total execution time: 0.0519
DEBUG - 2022-07-09 00:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:15:26 --> Total execution time: 0.0502
DEBUG - 2022-07-09 00:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:15:53 --> Total execution time: 0.0572
DEBUG - 2022-07-09 00:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:16:13 --> Total execution time: 0.0809
DEBUG - 2022-07-09 00:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:16:18 --> Total execution time: 0.0751
DEBUG - 2022-07-09 00:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:16:23 --> Total execution time: 0.0754
DEBUG - 2022-07-09 00:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:16:26 --> Total execution time: 0.0680
DEBUG - 2022-07-09 00:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:16:33 --> Total execution time: 0.0603
DEBUG - 2022-07-09 00:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:16:42 --> Total execution time: 0.0650
DEBUG - 2022-07-09 00:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:47:39 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:17:39 --> Total execution time: 0.0442
DEBUG - 2022-07-09 00:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:17:40 --> Total execution time: 0.0724
DEBUG - 2022-07-09 00:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:17:51 --> Total execution time: 0.0851
DEBUG - 2022-07-09 00:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:17:52 --> Total execution time: 0.0606
DEBUG - 2022-07-09 00:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:17:55 --> Total execution time: 0.0605
DEBUG - 2022-07-09 00:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:17:59 --> Total execution time: 0.1156
DEBUG - 2022-07-09 00:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:18:01 --> Total execution time: 0.0617
DEBUG - 2022-07-09 00:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:18:04 --> Total execution time: 0.0722
DEBUG - 2022-07-09 00:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:18:35 --> Total execution time: 0.0960
DEBUG - 2022-07-09 00:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:18:39 --> Total execution time: 0.0667
DEBUG - 2022-07-09 00:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:18:43 --> Total execution time: 0.0975
DEBUG - 2022-07-09 00:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:18:47 --> Total execution time: 0.0563
DEBUG - 2022-07-09 00:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:18:51 --> Total execution time: 0.0708
DEBUG - 2022-07-09 00:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:18:52 --> Total execution time: 0.0629
DEBUG - 2022-07-09 00:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:18:54 --> Total execution time: 0.0635
DEBUG - 2022-07-09 00:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:18:57 --> Total execution time: 0.1269
DEBUG - 2022-07-09 00:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:19:04 --> Total execution time: 0.0640
DEBUG - 2022-07-09 00:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:19:08 --> Total execution time: 0.1449
DEBUG - 2022-07-09 00:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:19:09 --> Total execution time: 0.0714
DEBUG - 2022-07-09 00:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:19:16 --> Total execution time: 0.0749
DEBUG - 2022-07-09 00:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:19:18 --> Total execution time: 0.0742
DEBUG - 2022-07-09 00:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:19:18 --> Total execution time: 0.0683
DEBUG - 2022-07-09 00:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:21 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:19:21 --> Total execution time: 0.0664
DEBUG - 2022-07-09 00:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:19:28 --> Total execution time: 0.0653
DEBUG - 2022-07-09 00:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:41 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:19:41 --> Total execution time: 0.1372
DEBUG - 2022-07-09 00:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:41 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:19:41 --> Total execution time: 0.0555
DEBUG - 2022-07-09 00:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:19:42 --> Total execution time: 0.0494
DEBUG - 2022-07-09 00:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:19:46 --> Total execution time: 0.0605
DEBUG - 2022-07-09 00:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:19:47 --> Total execution time: 0.0474
DEBUG - 2022-07-09 00:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:49:51 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:19:51 --> Total execution time: 0.0567
DEBUG - 2022-07-09 00:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:50:07 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:20:07 --> Total execution time: 0.0614
DEBUG - 2022-07-09 00:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:50:15 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:20:15 --> Total execution time: 0.0630
DEBUG - 2022-07-09 00:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:20:37 --> Total execution time: 0.0633
DEBUG - 2022-07-09 00:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:50:48 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:20:48 --> Total execution time: 0.0613
DEBUG - 2022-07-09 00:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:50:54 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:20:54 --> Total execution time: 0.0568
DEBUG - 2022-07-09 00:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:21:03 --> Total execution time: 0.0580
DEBUG - 2022-07-09 00:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:21:07 --> Total execution time: 0.0419
DEBUG - 2022-07-09 00:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:21:08 --> Total execution time: 0.0511
DEBUG - 2022-07-09 00:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:51:18 --> Total execution time: 0.0584
DEBUG - 2022-07-09 00:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:51:19 --> Total execution time: 0.0660
DEBUG - 2022-07-09 00:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:51:19 --> Total execution time: 0.1412
DEBUG - 2022-07-09 00:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:51:21 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:21:21 --> Total execution time: 0.0510
DEBUG - 2022-07-09 00:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:21:25 --> Total execution time: 0.0575
DEBUG - 2022-07-09 00:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:21:30 --> Total execution time: 0.0600
DEBUG - 2022-07-09 00:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:21:33 --> Total execution time: 0.0491
DEBUG - 2022-07-09 00:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:21:41 --> Total execution time: 0.0554
DEBUG - 2022-07-09 00:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:21:49 --> Total execution time: 0.0992
DEBUG - 2022-07-09 00:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:22:11 --> Total execution time: 0.1426
DEBUG - 2022-07-09 00:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:22:48 --> Total execution time: 0.0369
DEBUG - 2022-07-09 00:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:22:49 --> Total execution time: 0.0683
DEBUG - 2022-07-09 00:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:52:56 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:22:56 --> Total execution time: 0.0768
DEBUG - 2022-07-09 00:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:53:08 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:23:08 --> Total execution time: 0.0525
DEBUG - 2022-07-09 00:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:23:40 --> Total execution time: 2.9780
DEBUG - 2022-07-09 00:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:53:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 00:53:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 00:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:54:32 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:24:32 --> Total execution time: 0.1303
DEBUG - 2022-07-09 00:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:54:42 --> Total execution time: 0.0652
DEBUG - 2022-07-09 00:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:54:44 --> Total execution time: 0.0481
DEBUG - 2022-07-09 00:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:54:44 --> Total execution time: 0.1051
DEBUG - 2022-07-09 00:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:55:09 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:25:09 --> Total execution time: 0.0397
DEBUG - 2022-07-09 00:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:25:23 --> Total execution time: 0.0505
DEBUG - 2022-07-09 00:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:25:24 --> Total execution time: 0.0582
DEBUG - 2022-07-09 00:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:55:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 00:55:54 --> 404 Page Not Found: Comments/feed
DEBUG - 2022-07-09 00:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:56:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 00:56:23 --> 404 Page Not Found: Comments/feed
DEBUG - 2022-07-09 00:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:26:26 --> Total execution time: 0.0512
DEBUG - 2022-07-09 00:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:26:30 --> Total execution time: 0.0498
DEBUG - 2022-07-09 00:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:26:44 --> Total execution time: 0.0537
DEBUG - 2022-07-09 00:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:26:50 --> Total execution time: 0.0560
DEBUG - 2022-07-09 00:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:26:53 --> Total execution time: 0.0603
DEBUG - 2022-07-09 00:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:57:02 --> Total execution time: 0.0551
DEBUG - 2022-07-09 00:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:27:10 --> Total execution time: 0.0604
DEBUG - 2022-07-09 00:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:57:21 --> Total execution time: 0.0824
DEBUG - 2022-07-09 00:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:27:22 --> Total execution time: 0.0649
DEBUG - 2022-07-09 00:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:57:31 --> Total execution time: 0.0521
DEBUG - 2022-07-09 00:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:57:50 --> Total execution time: 0.0599
DEBUG - 2022-07-09 00:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:57:51 --> Total execution time: 0.0634
DEBUG - 2022-07-09 00:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:57:53 --> Total execution time: 0.0540
DEBUG - 2022-07-09 00:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:57:56 --> Total execution time: 0.0528
DEBUG - 2022-07-09 00:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:58:25 --> Total execution time: 0.0690
DEBUG - 2022-07-09 00:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:58:27 --> Total execution time: 0.0572
DEBUG - 2022-07-09 00:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:28:27 --> Total execution time: 0.0519
DEBUG - 2022-07-09 00:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:58:27 --> Total execution time: 0.1382
DEBUG - 2022-07-09 00:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:28:28 --> Total execution time: 0.0498
DEBUG - 2022-07-09 00:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:28:29 --> Total execution time: 0.0505
DEBUG - 2022-07-09 00:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:28:35 --> Total execution time: 0.0552
DEBUG - 2022-07-09 00:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 00:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:28:37 --> Total execution time: 0.0627
DEBUG - 2022-07-09 00:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:28:44 --> Total execution time: 0.0552
DEBUG - 2022-07-09 00:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:28:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 00:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:28:45 --> Total execution time: 0.0618
DEBUG - 2022-07-09 00:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:29:05 --> Total execution time: 0.0501
DEBUG - 2022-07-09 00:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:29:12 --> Total execution time: 0.0853
DEBUG - 2022-07-09 00:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:59:30 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:29:30 --> Total execution time: 0.0490
DEBUG - 2022-07-09 00:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:59:31 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:29:31 --> Total execution time: 0.0557
DEBUG - 2022-07-09 00:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 00:59:40 --> No URI present. Default controller set.
DEBUG - 2022-07-09 00:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 00:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:29:40 --> Total execution time: 0.0558
DEBUG - 2022-07-09 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:30:02 --> Total execution time: 0.0725
DEBUG - 2022-07-09 01:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:00:13 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:30:13 --> Total execution time: 0.0520
DEBUG - 2022-07-09 01:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:32:16 --> Total execution time: 0.2280
DEBUG - 2022-07-09 01:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:02:19 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:32:19 --> Total execution time: 0.1393
DEBUG - 2022-07-09 01:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:32:23 --> Total execution time: 0.0529
DEBUG - 2022-07-09 01:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:32:32 --> Total execution time: 0.0786
DEBUG - 2022-07-09 01:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:32:40 --> Total execution time: 0.0727
DEBUG - 2022-07-09 01:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:32:41 --> Total execution time: 0.2679
DEBUG - 2022-07-09 01:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:02:44 --> Total execution time: 0.0621
DEBUG - 2022-07-09 01:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:32:45 --> Total execution time: 0.0881
DEBUG - 2022-07-09 01:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:02:47 --> Total execution time: 0.0638
DEBUG - 2022-07-09 01:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:02:47 --> Total execution time: 0.0673
DEBUG - 2022-07-09 01:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:02:50 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:32:50 --> Total execution time: 0.0532
DEBUG - 2022-07-09 01:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:32:52 --> Total execution time: 0.0932
DEBUG - 2022-07-09 01:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:32:53 --> Total execution time: 0.0877
DEBUG - 2022-07-09 01:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:03:04 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:04 --> Total execution time: 0.0492
DEBUG - 2022-07-09 01:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:10 --> Total execution time: 0.1062
DEBUG - 2022-07-09 01:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:03:14 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:14 --> Total execution time: 0.0591
DEBUG - 2022-07-09 01:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:03:18 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:18 --> Total execution time: 0.0848
DEBUG - 2022-07-09 01:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:21 --> Total execution time: 0.0803
DEBUG - 2022-07-09 01:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:22 --> Total execution time: 0.0994
DEBUG - 2022-07-09 01:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:24 --> Total execution time: 0.0623
DEBUG - 2022-07-09 01:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:03:29 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:29 --> Total execution time: 0.0550
DEBUG - 2022-07-09 01:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:34 --> Total execution time: 0.0769
DEBUG - 2022-07-09 01:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:37 --> Total execution time: 0.0854
DEBUG - 2022-07-09 01:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:04:36 --> Total execution time: 0.0442
DEBUG - 2022-07-09 01:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:04:38 --> Total execution time: 0.0642
DEBUG - 2022-07-09 01:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:04:38 --> Total execution time: 0.1055
DEBUG - 2022-07-09 01:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:34:40 --> Total execution time: 0.0804
DEBUG - 2022-07-09 01:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:34:41 --> Total execution time: 0.1119
DEBUG - 2022-07-09 01:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:05:05 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:35:05 --> Total execution time: 0.0691
DEBUG - 2022-07-09 01:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:05:26 --> Total execution time: 0.0992
DEBUG - 2022-07-09 01:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:05:27 --> Total execution time: 0.0854
DEBUG - 2022-07-09 01:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:05:27 --> Total execution time: 0.1286
DEBUG - 2022-07-09 01:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:05:28 --> Total execution time: 0.0389
DEBUG - 2022-07-09 01:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:05:30 --> Total execution time: 0.0547
DEBUG - 2022-07-09 01:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:05:30 --> Total execution time: 0.1194
DEBUG - 2022-07-09 01:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:35:50 --> Total execution time: 0.0589
DEBUG - 2022-07-09 01:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:36:16 --> Total execution time: 0.1818
DEBUG - 2022-07-09 01:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:36:19 --> Total execution time: 0.1314
DEBUG - 2022-07-09 01:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:36:23 --> Total execution time: 0.0780
DEBUG - 2022-07-09 01:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:36:24 --> Total execution time: 0.0792
DEBUG - 2022-07-09 01:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:36:31 --> Total execution time: 0.0567
DEBUG - 2022-07-09 01:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:36:33 --> Total execution time: 0.0551
DEBUG - 2022-07-09 01:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:48 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:36:48 --> Total execution time: 0.0513
DEBUG - 2022-07-09 01:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:36:49 --> Total execution time: 0.0773
DEBUG - 2022-07-09 01:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:36:50 --> Total execution time: 0.0639
DEBUG - 2022-07-09 01:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:36:50 --> Total execution time: 0.0829
DEBUG - 2022-07-09 01:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:36:51 --> Total execution time: 0.1547
DEBUG - 2022-07-09 01:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:36:51 --> Total execution time: 0.2421
DEBUG - 2022-07-09 01:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:36:51 --> Total execution time: 0.0929
DEBUG - 2022-07-09 01:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:36:51 --> Total execution time: 0.0801
DEBUG - 2022-07-09 01:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:36:52 --> Total execution time: 0.0843
DEBUG - 2022-07-09 01:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:37:01 --> Total execution time: 0.0603
DEBUG - 2022-07-09 01:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:37:11 --> Total execution time: 0.6653
DEBUG - 2022-07-09 01:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:37:17 --> Total execution time: 0.0708
DEBUG - 2022-07-09 01:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:37:34 --> Total execution time: 0.0648
DEBUG - 2022-07-09 01:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:07:46 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:37:46 --> Total execution time: 0.0358
DEBUG - 2022-07-09 01:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:07:52 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:37:52 --> Total execution time: 0.0515
DEBUG - 2022-07-09 01:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:08:04 --> Total execution time: 0.0526
DEBUG - 2022-07-09 01:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:08:06 --> Total execution time: 0.0557
DEBUG - 2022-07-09 01:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:08:06 --> Total execution time: 0.1115
DEBUG - 2022-07-09 01:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:38:12 --> Total execution time: 0.1306
DEBUG - 2022-07-09 01:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:38:13 --> Total execution time: 0.0574
DEBUG - 2022-07-09 01:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:38:14 --> Total execution time: 0.0719
DEBUG - 2022-07-09 01:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:38:22 --> Total execution time: 0.0586
DEBUG - 2022-07-09 01:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:38:26 --> Total execution time: 0.0760
DEBUG - 2022-07-09 01:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:38:48 --> Total execution time: 0.4992
DEBUG - 2022-07-09 01:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:38:49 --> Total execution time: 0.0495
DEBUG - 2022-07-09 01:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:38:56 --> Total execution time: 0.0656
DEBUG - 2022-07-09 01:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:39:15 --> Total execution time: 0.0559
DEBUG - 2022-07-09 01:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:39:17 --> Total execution time: 0.0578
DEBUG - 2022-07-09 01:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:39:26 --> Total execution time: 0.0945
DEBUG - 2022-07-09 01:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:39:33 --> Total execution time: 0.0569
DEBUG - 2022-07-09 01:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:39:39 --> Total execution time: 0.0554
DEBUG - 2022-07-09 01:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:39:39 --> Total execution time: 0.0787
DEBUG - 2022-07-09 01:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:09:45 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:39:45 --> Total execution time: 0.0540
DEBUG - 2022-07-09 01:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:39:50 --> Total execution time: 0.0489
DEBUG - 2022-07-09 01:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:39:56 --> Total execution time: 0.0565
DEBUG - 2022-07-09 01:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:40:03 --> Total execution time: 0.0604
DEBUG - 2022-07-09 01:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:40:03 --> Total execution time: 0.0540
DEBUG - 2022-07-09 01:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:40:08 --> Total execution time: 0.0542
DEBUG - 2022-07-09 01:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:40:09 --> Total execution time: 0.0818
DEBUG - 2022-07-09 01:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:10:16 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:40:16 --> Total execution time: 0.0552
DEBUG - 2022-07-09 01:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:40:17 --> Total execution time: 0.0558
DEBUG - 2022-07-09 01:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:40:21 --> Total execution time: 0.0697
DEBUG - 2022-07-09 01:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:40:22 --> Total execution time: 0.0600
DEBUG - 2022-07-09 01:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:40:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 01:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:40:35 --> Total execution time: 0.0695
DEBUG - 2022-07-09 01:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:40:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 11:40:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 11:40:37 --> Total execution time: 0.2139
DEBUG - 2022-07-09 01:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:10:41 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:40:41 --> Total execution time: 0.0690
DEBUG - 2022-07-09 01:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:11:07 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:41:07 --> Total execution time: 0.0396
DEBUG - 2022-07-09 01:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:41:12 --> Total execution time: 0.0623
DEBUG - 2022-07-09 01:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:41:13 --> Total execution time: 0.0501
DEBUG - 2022-07-09 01:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:41:21 --> Total execution time: 0.0944
DEBUG - 2022-07-09 01:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:41:22 --> Total execution time: 0.0834
DEBUG - 2022-07-09 01:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:41:48 --> Total execution time: 0.0533
DEBUG - 2022-07-09 01:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:42:28 --> Total execution time: 0.0551
DEBUG - 2022-07-09 01:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:42:35 --> Total execution time: 0.0507
DEBUG - 2022-07-09 01:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:42:45 --> Total execution time: 0.0536
DEBUG - 2022-07-09 01:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:42:53 --> Total execution time: 0.0553
DEBUG - 2022-07-09 01:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:42:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 01:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:42:54 --> Total execution time: 0.0585
DEBUG - 2022-07-09 01:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:44:31 --> Total execution time: 0.0514
DEBUG - 2022-07-09 01:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:44:53 --> Total execution time: 0.1252
DEBUG - 2022-07-09 01:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:44:56 --> Total execution time: 0.0554
DEBUG - 2022-07-09 01:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:45:17 --> Total execution time: 0.0737
DEBUG - 2022-07-09 01:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:15:21 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:45:21 --> Total execution time: 0.1342
DEBUG - 2022-07-09 01:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:45:31 --> Total execution time: 0.1434
DEBUG - 2022-07-09 01:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:15:34 --> Total execution time: 0.1287
DEBUG - 2022-07-09 01:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:15:36 --> Total execution time: 0.0538
DEBUG - 2022-07-09 01:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:15:36 --> Total execution time: 0.1064
DEBUG - 2022-07-09 01:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:15:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 01:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:45:47 --> Total execution time: 2.0380
DEBUG - 2022-07-09 01:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:45:51 --> Total execution time: 0.0518
DEBUG - 2022-07-09 01:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:15:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 01:15:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 01:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:16:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 01:16:55 --> 404 Page Not Found: Shop/feed
DEBUG - 2022-07-09 01:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:47:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 01:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:47:24 --> Total execution time: 0.0539
DEBUG - 2022-07-09 01:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:47:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 11:47:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 11:47:26 --> Total execution time: 0.1856
DEBUG - 2022-07-09 01:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:47:39 --> Total execution time: 0.0551
DEBUG - 2022-07-09 01:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:49:48 --> Total execution time: 0.1323
DEBUG - 2022-07-09 01:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:49:55 --> Total execution time: 1.7126
DEBUG - 2022-07-09 01:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:50:20 --> Total execution time: 0.0687
DEBUG - 2022-07-09 01:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:50:27 --> Total execution time: 0.1501
DEBUG - 2022-07-09 01:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:21:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 01:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:51:11 --> Total execution time: 1.4710
DEBUG - 2022-07-09 01:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:21:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 01:21:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 01:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:51:44 --> Total execution time: 0.1259
DEBUG - 2022-07-09 01:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:51:50 --> Total execution time: 0.0576
DEBUG - 2022-07-09 01:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:21:55 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:51:55 --> Total execution time: 0.1633
DEBUG - 2022-07-09 01:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:22:20 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:52:20 --> Total execution time: 0.1322
DEBUG - 2022-07-09 01:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:52:22 --> Total execution time: 0.0596
DEBUG - 2022-07-09 01:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:22:30 --> Total execution time: 0.1493
DEBUG - 2022-07-09 01:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:52:31 --> Total execution time: 0.0808
DEBUG - 2022-07-09 01:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:22:31 --> Total execution time: 0.0565
DEBUG - 2022-07-09 01:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:22:31 --> Total execution time: 0.1146
DEBUG - 2022-07-09 01:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:22:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 01:22:32 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-09 01:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:52:48 --> Total execution time: 0.0565
DEBUG - 2022-07-09 01:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:52:52 --> Total execution time: 0.0599
DEBUG - 2022-07-09 01:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:52:56 --> Total execution time: 0.0502
DEBUG - 2022-07-09 01:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:53:09 --> Total execution time: 0.0574
DEBUG - 2022-07-09 01:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:23:52 --> Total execution time: 0.0539
DEBUG - 2022-07-09 01:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:23:53 --> Total execution time: 0.0713
DEBUG - 2022-07-09 01:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:23:53 --> Total execution time: 0.1318
DEBUG - 2022-07-09 01:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:54:36 --> Total execution time: 0.0650
DEBUG - 2022-07-09 01:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:54:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 01:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:54:37 --> Total execution time: 0.0513
DEBUG - 2022-07-09 01:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:54:50 --> Total execution time: 0.0561
DEBUG - 2022-07-09 01:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:54:54 --> Total execution time: 0.0510
DEBUG - 2022-07-09 01:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:25:12 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:55:12 --> Total execution time: 0.0523
DEBUG - 2022-07-09 01:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:25:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 01:25:15 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-09 01:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:55:18 --> Total execution time: 0.0519
DEBUG - 2022-07-09 01:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:55:22 --> Total execution time: 0.0643
DEBUG - 2022-07-09 01:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:55:26 --> Total execution time: 0.0575
DEBUG - 2022-07-09 01:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:55:48 --> Total execution time: 0.0655
DEBUG - 2022-07-09 01:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:55:58 --> Total execution time: 0.0530
DEBUG - 2022-07-09 01:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 01:26:11 --> 404 Page Not Found: Category/health
DEBUG - 2022-07-09 01:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:56:12 --> Total execution time: 0.0559
DEBUG - 2022-07-09 01:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:26:13 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:56:13 --> Total execution time: 0.0565
DEBUG - 2022-07-09 01:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:26:15 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:56:15 --> Total execution time: 0.0515
DEBUG - 2022-07-09 01:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:56:28 --> Total execution time: 0.0605
DEBUG - 2022-07-09 01:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:56:37 --> Total execution time: 0.0614
DEBUG - 2022-07-09 01:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:56:42 --> Total execution time: 0.0872
DEBUG - 2022-07-09 01:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:56:55 --> Total execution time: 0.0564
DEBUG - 2022-07-09 01:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:56:59 --> Total execution time: 0.0868
DEBUG - 2022-07-09 01:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:00 --> Total execution time: 0.0631
DEBUG - 2022-07-09 01:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:01 --> Total execution time: 0.0595
DEBUG - 2022-07-09 01:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:01 --> Total execution time: 0.0587
DEBUG - 2022-07-09 01:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:01 --> Total execution time: 0.0705
DEBUG - 2022-07-09 01:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:08 --> Total execution time: 0.0554
DEBUG - 2022-07-09 01:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:09 --> Total execution time: 0.0596
DEBUG - 2022-07-09 01:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:09 --> Total execution time: 0.0537
DEBUG - 2022-07-09 01:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:10 --> Total execution time: 0.0624
DEBUG - 2022-07-09 01:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:12 --> Total execution time: 0.0550
DEBUG - 2022-07-09 01:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:15 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:15 --> Total execution time: 0.0412
DEBUG - 2022-07-09 01:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 01:27:27 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-09 01:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:35 --> Total execution time: 0.0699
DEBUG - 2022-07-09 01:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:37 --> Total execution time: 0.0554
DEBUG - 2022-07-09 01:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:41 --> Total execution time: 0.0538
DEBUG - 2022-07-09 01:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:44 --> Total execution time: 0.0584
DEBUG - 2022-07-09 01:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:47 --> Total execution time: 0.0569
DEBUG - 2022-07-09 01:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:48 --> Total execution time: 0.0584
DEBUG - 2022-07-09 01:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:48 --> Total execution time: 0.0555
DEBUG - 2022-07-09 01:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:53 --> Total execution time: 0.0564
DEBUG - 2022-07-09 01:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:57:56 --> Total execution time: 0.0539
DEBUG - 2022-07-09 01:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:58:07 --> Total execution time: 0.0546
DEBUG - 2022-07-09 01:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:58:20 --> Total execution time: 0.0715
DEBUG - 2022-07-09 01:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:28:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 01:28:24 --> 404 Page Not Found: Category/culture
DEBUG - 2022-07-09 01:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:58:27 --> Total execution time: 0.0879
DEBUG - 2022-07-09 01:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:58:35 --> Total execution time: 0.0414
DEBUG - 2022-07-09 01:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:58:56 --> Total execution time: 0.0873
DEBUG - 2022-07-09 01:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:58:59 --> Total execution time: 0.0675
DEBUG - 2022-07-09 01:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:59:01 --> Total execution time: 0.0670
DEBUG - 2022-07-09 01:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:59:03 --> Total execution time: 0.0685
DEBUG - 2022-07-09 01:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:59:11 --> Total execution time: 0.0593
DEBUG - 2022-07-09 01:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:59:11 --> Total execution time: 0.0603
DEBUG - 2022-07-09 01:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:59:32 --> Total execution time: 0.1205
DEBUG - 2022-07-09 01:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:30:02 --> Total execution time: 0.2093
DEBUG - 2022-07-09 01:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:30:27 --> Total execution time: 0.0572
DEBUG - 2022-07-09 01:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:01:16 --> Total execution time: 0.0693
DEBUG - 2022-07-09 01:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:01:24 --> Total execution time: 0.0731
DEBUG - 2022-07-09 01:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:33:30 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:03:31 --> Total execution time: 0.1352
DEBUG - 2022-07-09 01:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:03:38 --> Total execution time: 0.0537
DEBUG - 2022-07-09 01:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:04:13 --> Total execution time: 0.1627
DEBUG - 2022-07-09 01:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:04:58 --> Total execution time: 0.0897
DEBUG - 2022-07-09 01:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:05:04 --> Total execution time: 0.0769
DEBUG - 2022-07-09 01:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:36:42 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:06:42 --> Total execution time: 0.1272
DEBUG - 2022-07-09 01:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:07:04 --> Total execution time: 0.0556
DEBUG - 2022-07-09 01:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:38:34 --> Total execution time: 0.0577
DEBUG - 2022-07-09 01:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:39:30 --> Total execution time: 0.0492
DEBUG - 2022-07-09 01:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:11:28 --> Total execution time: 0.1242
DEBUG - 2022-07-09 01:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:43:45 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:13:45 --> Total execution time: 0.2021
DEBUG - 2022-07-09 01:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:44:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 01:44:33 --> 404 Page Not Found: Category/reviews
DEBUG - 2022-07-09 01:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:15:50 --> Total execution time: 0.0623
DEBUG - 2022-07-09 01:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:15:57 --> Total execution time: 0.0783
DEBUG - 2022-07-09 01:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:46:14 --> Total execution time: 0.0552
DEBUG - 2022-07-09 01:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:16:19 --> Total execution time: 0.0485
DEBUG - 2022-07-09 01:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:16:23 --> Total execution time: 0.0672
DEBUG - 2022-07-09 01:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:16:35 --> Total execution time: 0.0704
DEBUG - 2022-07-09 01:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:16:51 --> Total execution time: 0.0523
DEBUG - 2022-07-09 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:16:57 --> Total execution time: 0.0454
DEBUG - 2022-07-09 01:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:17:05 --> Total execution time: 0.0278
DEBUG - 2022-07-09 01:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:48:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 01:48:09 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-09 01:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:48:44 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:18:44 --> Total execution time: 0.0354
DEBUG - 2022-07-09 01:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:49:18 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:19:18 --> Total execution time: 0.0374
DEBUG - 2022-07-09 01:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:50:22 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:20:23 --> Total execution time: 0.0373
DEBUG - 2022-07-09 01:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:50:31 --> Total execution time: 0.0584
DEBUG - 2022-07-09 01:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:50:32 --> Total execution time: 0.0551
DEBUG - 2022-07-09 01:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:50:32 --> Total execution time: 0.1066
DEBUG - 2022-07-09 01:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:51:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 01:51:51 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-09 01:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:52:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 01:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:22:09 --> Total execution time: 1.8877
DEBUG - 2022-07-09 01:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:52:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 01:52:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 01:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:22:50 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 01:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:22:51 --> Total execution time: 0.0555
DEBUG - 2022-07-09 01:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:22:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 12:22:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 12:22:52 --> Total execution time: 0.2107
DEBUG - 2022-07-09 01:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:22:55 --> Total execution time: 0.0688
DEBUG - 2022-07-09 01:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:23:01 --> Total execution time: 0.1062
DEBUG - 2022-07-09 01:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:23:07 --> Total execution time: 0.0496
DEBUG - 2022-07-09 01:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:23:46 --> Total execution time: 0.0351
DEBUG - 2022-07-09 01:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:24:07 --> Total execution time: 0.0581
DEBUG - 2022-07-09 01:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:24:24 --> Total execution time: 0.0365
DEBUG - 2022-07-09 01:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:24:34 --> Total execution time: 0.0521
DEBUG - 2022-07-09 01:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:24:41 --> Total execution time: 0.0614
DEBUG - 2022-07-09 01:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:25:05 --> Total execution time: 0.0348
DEBUG - 2022-07-09 01:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:55:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 01:55:08 --> 404 Page Not Found: User/l
DEBUG - 2022-07-09 01:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:25:10 --> Total execution time: 0.0489
DEBUG - 2022-07-09 01:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:55:11 --> No URI present. Default controller set.
DEBUG - 2022-07-09 01:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:25:11 --> Total execution time: 0.0428
DEBUG - 2022-07-09 01:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:26:29 --> Total execution time: 0.0572
DEBUG - 2022-07-09 01:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:26:39 --> Total execution time: 0.0512
DEBUG - 2022-07-09 01:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:26:49 --> Total execution time: 0.0783
DEBUG - 2022-07-09 01:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:27:04 --> Total execution time: 0.0530
DEBUG - 2022-07-09 01:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:27:16 --> Total execution time: 0.1607
DEBUG - 2022-07-09 01:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:27:19 --> Total execution time: 0.0647
DEBUG - 2022-07-09 01:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:27:26 --> Total execution time: 0.0684
DEBUG - 2022-07-09 01:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:27:51 --> Total execution time: 0.1403
DEBUG - 2022-07-09 01:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:28:11 --> Total execution time: 0.0591
DEBUG - 2022-07-09 01:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:28:18 --> Total execution time: 0.0659
DEBUG - 2022-07-09 01:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:28:18 --> Total execution time: 0.0560
DEBUG - 2022-07-09 01:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:28:32 --> Total execution time: 0.0568
DEBUG - 2022-07-09 01:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:28:39 --> Total execution time: 0.0672
DEBUG - 2022-07-09 01:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:28:48 --> Total execution time: 0.0838
DEBUG - 2022-07-09 01:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:29:11 --> Total execution time: 0.1687
DEBUG - 2022-07-09 01:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:29:16 --> Total execution time: 0.0679
DEBUG - 2022-07-09 01:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 01:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 01:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 01:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:29:54 --> Total execution time: 0.0540
DEBUG - 2022-07-09 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:30:03 --> Total execution time: 0.0704
DEBUG - 2022-07-09 02:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:30:18 --> Total execution time: 0.0568
DEBUG - 2022-07-09 02:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:30:49 --> Total execution time: 0.0511
DEBUG - 2022-07-09 02:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:01:10 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:31:10 --> Total execution time: 0.0602
DEBUG - 2022-07-09 02:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:31:13 --> Total execution time: 0.0508
DEBUG - 2022-07-09 02:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:31:34 --> Total execution time: 0.0508
DEBUG - 2022-07-09 02:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:33:22 --> Total execution time: 0.1587
DEBUG - 2022-07-09 02:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:33:22 --> Total execution time: 0.0716
DEBUG - 2022-07-09 02:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:33:26 --> Total execution time: 0.0849
DEBUG - 2022-07-09 02:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:34:02 --> Total execution time: 0.1297
DEBUG - 2022-07-09 02:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:34:18 --> Total execution time: 0.1228
DEBUG - 2022-07-09 02:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:34:37 --> Total execution time: 0.0460
DEBUG - 2022-07-09 02:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:34:50 --> Total execution time: 0.0662
DEBUG - 2022-07-09 02:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:35:01 --> Total execution time: 0.0581
DEBUG - 2022-07-09 02:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:35:14 --> Total execution time: 0.0570
DEBUG - 2022-07-09 02:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:35:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 02:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:35:15 --> Total execution time: 0.0448
DEBUG - 2022-07-09 02:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:36:59 --> Total execution time: 0.1391
DEBUG - 2022-07-09 02:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:37:07 --> Total execution time: 0.0853
DEBUG - 2022-07-09 02:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:37:10 --> Total execution time: 0.1571
DEBUG - 2022-07-09 02:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:37:11 --> Total execution time: 0.0886
DEBUG - 2022-07-09 02:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:37:18 --> Total execution time: 0.0781
DEBUG - 2022-07-09 02:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:37:18 --> Total execution time: 0.1576
DEBUG - 2022-07-09 02:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:37:26 --> Total execution time: 0.0610
DEBUG - 2022-07-09 02:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:37:45 --> Total execution time: 0.0863
DEBUG - 2022-07-09 02:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:39:08 --> Total execution time: 0.0505
DEBUG - 2022-07-09 02:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:39:13 --> Total execution time: 0.1773
DEBUG - 2022-07-09 02:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:39:30 --> Total execution time: 0.0582
DEBUG - 2022-07-09 02:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:39:31 --> Total execution time: 0.0606
DEBUG - 2022-07-09 02:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:39:40 --> Total execution time: 0.1053
DEBUG - 2022-07-09 02:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:09:53 --> Total execution time: 0.0533
DEBUG - 2022-07-09 02:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:39:53 --> Total execution time: 0.0771
DEBUG - 2022-07-09 02:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:10:02 --> Total execution time: 0.1030
DEBUG - 2022-07-09 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:40:12 --> Total execution time: 0.1058
DEBUG - 2022-07-09 02:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:40:22 --> Total execution time: 0.0847
DEBUG - 2022-07-09 02:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:40:31 --> Total execution time: 0.0861
DEBUG - 2022-07-09 02:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:40:33 --> Total execution time: 0.0897
DEBUG - 2022-07-09 02:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:40:35 --> Total execution time: 0.0917
DEBUG - 2022-07-09 02:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:40:38 --> Total execution time: 0.0526
DEBUG - 2022-07-09 02:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:40:44 --> Total execution time: 0.0971
DEBUG - 2022-07-09 02:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:10:45 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:40:45 --> Total execution time: 0.0548
DEBUG - 2022-07-09 02:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:40:46 --> Total execution time: 0.0746
DEBUG - 2022-07-09 02:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:40:50 --> Total execution time: 0.0532
DEBUG - 2022-07-09 02:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:40:55 --> Total execution time: 0.0541
DEBUG - 2022-07-09 02:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:40:59 --> Total execution time: 0.0589
DEBUG - 2022-07-09 02:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:41:00 --> Total execution time: 0.0700
DEBUG - 2022-07-09 02:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:41:08 --> Total execution time: 0.0813
DEBUG - 2022-07-09 02:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:41:11 --> Total execution time: 0.0614
DEBUG - 2022-07-09 02:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:41:14 --> Total execution time: 0.0903
DEBUG - 2022-07-09 02:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:41:19 --> Total execution time: 0.0567
DEBUG - 2022-07-09 02:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:41:21 --> Total execution time: 0.0743
DEBUG - 2022-07-09 02:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:42:06 --> Total execution time: 0.0788
DEBUG - 2022-07-09 02:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:43:42 --> Total execution time: 0.0564
DEBUG - 2022-07-09 02:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:43:48 --> Total execution time: 0.2095
DEBUG - 2022-07-09 02:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:43:49 --> Total execution time: 0.1020
DEBUG - 2022-07-09 02:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:43:50 --> Total execution time: 0.0791
DEBUG - 2022-07-09 02:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:44:00 --> Total execution time: 0.0834
DEBUG - 2022-07-09 02:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:44:28 --> Total execution time: 0.0662
DEBUG - 2022-07-09 02:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:44:35 --> Total execution time: 0.1458
DEBUG - 2022-07-09 02:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:14:36 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:44:36 --> Total execution time: 0.0447
DEBUG - 2022-07-09 02:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:45:10 --> Total execution time: 0.1559
DEBUG - 2022-07-09 02:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:45:21 --> Total execution time: 0.1343
DEBUG - 2022-07-09 02:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:45:23 --> Total execution time: 0.0598
DEBUG - 2022-07-09 02:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:47:25 --> Total execution time: 0.1468
DEBUG - 2022-07-09 02:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:17:27 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:47:28 --> Total execution time: 0.0483
DEBUG - 2022-07-09 02:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:47:28 --> Total execution time: 0.0858
DEBUG - 2022-07-09 02:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:47:29 --> Total execution time: 0.0567
DEBUG - 2022-07-09 02:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:47:32 --> Total execution time: 0.0293
DEBUG - 2022-07-09 02:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:47:34 --> Total execution time: 0.0762
DEBUG - 2022-07-09 02:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:48:07 --> Total execution time: 0.0507
DEBUG - 2022-07-09 02:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:48:14 --> Total execution time: 0.0542
DEBUG - 2022-07-09 02:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:48:33 --> Total execution time: 0.0551
DEBUG - 2022-07-09 02:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:48:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 02:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:48:34 --> Total execution time: 0.0500
DEBUG - 2022-07-09 02:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:48:36 --> Total execution time: 0.0544
DEBUG - 2022-07-09 02:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:48:50 --> Total execution time: 0.0870
DEBUG - 2022-07-09 02:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:49:21 --> Total execution time: 0.0567
DEBUG - 2022-07-09 02:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:49:47 --> Total execution time: 0.0601
DEBUG - 2022-07-09 02:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:50:40 --> Total execution time: 0.0692
DEBUG - 2022-07-09 02:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:51:09 --> Total execution time: 0.0739
DEBUG - 2022-07-09 02:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:51:57 --> Total execution time: 0.0500
DEBUG - 2022-07-09 02:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:52:33 --> Total execution time: 0.1830
DEBUG - 2022-07-09 02:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:52:55 --> Total execution time: 0.0332
DEBUG - 2022-07-09 02:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:23:14 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:53:14 --> Total execution time: 0.0384
DEBUG - 2022-07-09 02:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:53:23 --> Total execution time: 0.0385
DEBUG - 2022-07-09 02:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:53:31 --> Total execution time: 0.0562
DEBUG - 2022-07-09 02:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:53:36 --> Total execution time: 0.1513
DEBUG - 2022-07-09 02:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:53:43 --> Total execution time: 0.1403
DEBUG - 2022-07-09 02:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:53:45 --> Total execution time: 0.1300
DEBUG - 2022-07-09 02:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:53:47 --> Total execution time: 0.0792
DEBUG - 2022-07-09 02:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:53:47 --> Total execution time: 0.0535
DEBUG - 2022-07-09 02:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:53:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 02:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:53:48 --> Total execution time: 0.0514
DEBUG - 2022-07-09 02:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:53:51 --> Total execution time: 0.0731
DEBUG - 2022-07-09 02:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:53:52 --> Total execution time: 0.0562
DEBUG - 2022-07-09 02:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:53:59 --> Total execution time: 0.0499
DEBUG - 2022-07-09 02:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:24:06 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:54:06 --> Total execution time: 0.0424
DEBUG - 2022-07-09 02:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:54:12 --> Total execution time: 0.0776
DEBUG - 2022-07-09 02:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:54:14 --> Total execution time: 0.0547
DEBUG - 2022-07-09 02:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:24:20 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:54:20 --> Total execution time: 0.0434
DEBUG - 2022-07-09 02:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:54:40 --> Total execution time: 0.0584
DEBUG - 2022-07-09 02:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:24:43 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:54:43 --> Total execution time: 0.0624
DEBUG - 2022-07-09 02:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:54:48 --> Total execution time: 0.0686
DEBUG - 2022-07-09 02:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:54:48 --> Total execution time: 0.0469
DEBUG - 2022-07-09 02:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:54:57 --> Total execution time: 0.0558
DEBUG - 2022-07-09 02:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:55:01 --> Total execution time: 0.0580
DEBUG - 2022-07-09 02:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:55:11 --> Total execution time: 0.0693
DEBUG - 2022-07-09 02:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:55:54 --> Total execution time: 0.0578
DEBUG - 2022-07-09 02:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:57:48 --> Total execution time: 0.1223
DEBUG - 2022-07-09 02:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:59:38 --> Total execution time: 0.1451
DEBUG - 2022-07-09 02:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:59:45 --> Total execution time: 0.0559
DEBUG - 2022-07-09 02:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:59:51 --> Total execution time: 0.0570
DEBUG - 2022-07-09 02:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:29:58 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:59:58 --> Total execution time: 0.0467
DEBUG - 2022-07-09 02:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:00:02 --> Total execution time: 0.0879
DEBUG - 2022-07-09 02:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:30:46 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:00:46 --> Total execution time: 0.0530
DEBUG - 2022-07-09 02:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:01:01 --> Total execution time: 0.0607
DEBUG - 2022-07-09 02:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:01:08 --> Total execution time: 0.0570
DEBUG - 2022-07-09 02:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:01:18 --> Total execution time: 0.0632
DEBUG - 2022-07-09 02:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:01:22 --> Total execution time: 0.0598
DEBUG - 2022-07-09 02:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:01:23 --> Total execution time: 0.0560
DEBUG - 2022-07-09 02:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:01:33 --> Total execution time: 0.0583
DEBUG - 2022-07-09 02:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:01:34 --> Total execution time: 0.0509
DEBUG - 2022-07-09 02:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:01:40 --> Total execution time: 0.0505
DEBUG - 2022-07-09 02:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:01:45 --> Total execution time: 0.0557
DEBUG - 2022-07-09 02:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:02:56 --> Total execution time: 0.1340
DEBUG - 2022-07-09 02:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:03:23 --> Total execution time: 0.0569
DEBUG - 2022-07-09 02:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:03:39 --> Total execution time: 0.0612
DEBUG - 2022-07-09 02:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:35:04 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:35:04 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:05:04 --> Total execution time: 0.1416
DEBUG - 2022-07-09 02:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:05:04 --> Total execution time: 0.1585
DEBUG - 2022-07-09 02:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:35:26 --> Total execution time: 0.0540
DEBUG - 2022-07-09 02:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:35:35 --> Total execution time: 0.0732
DEBUG - 2022-07-09 02:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:35:55 --> Total execution time: 0.0552
DEBUG - 2022-07-09 02:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:35:56 --> Total execution time: 0.0695
DEBUG - 2022-07-09 02:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:35:56 --> Total execution time: 0.1262
DEBUG - 2022-07-09 02:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:06:02 --> Total execution time: 0.0524
DEBUG - 2022-07-09 02:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:06:09 --> Total execution time: 0.0884
DEBUG - 2022-07-09 02:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:06:44 --> Total execution time: 0.1271
DEBUG - 2022-07-09 02:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:06:48 --> Total execution time: 0.0511
DEBUG - 2022-07-09 02:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:07:09 --> Total execution time: 0.0917
DEBUG - 2022-07-09 02:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:07:17 --> Total execution time: 0.0581
DEBUG - 2022-07-09 02:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:07:18 --> Total execution time: 0.0562
DEBUG - 2022-07-09 02:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:37:19 --> Total execution time: 0.0505
DEBUG - 2022-07-09 02:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:20 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:07:20 --> Total execution time: 0.0700
DEBUG - 2022-07-09 02:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:37:20 --> Total execution time: 0.0578
DEBUG - 2022-07-09 02:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:37:21 --> Total execution time: 0.0787
DEBUG - 2022-07-09 02:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:37:24 --> Total execution time: 0.0686
DEBUG - 2022-07-09 02:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:37:26 --> Total execution time: 0.0708
DEBUG - 2022-07-09 02:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:37:26 --> Total execution time: 0.1251
DEBUG - 2022-07-09 02:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:07:26 --> Total execution time: 0.0693
DEBUG - 2022-07-09 02:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:07:30 --> Total execution time: 0.0708
DEBUG - 2022-07-09 02:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:07:39 --> Total execution time: 0.0796
DEBUG - 2022-07-09 02:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:48 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:07:48 --> Total execution time: 0.0376
DEBUG - 2022-07-09 02:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:07:54 --> Total execution time: 0.0333
DEBUG - 2022-07-09 02:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:07:57 --> Total execution time: 0.0750
DEBUG - 2022-07-09 02:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:08:21 --> Total execution time: 0.0619
DEBUG - 2022-07-09 02:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:08:27 --> Total execution time: 0.0541
DEBUG - 2022-07-09 02:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:08:32 --> Total execution time: 0.0554
DEBUG - 2022-07-09 02:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:08:32 --> Total execution time: 0.0634
DEBUG - 2022-07-09 02:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:08:33 --> Total execution time: 0.0580
DEBUG - 2022-07-09 02:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:08:38 --> Total execution time: 0.0744
DEBUG - 2022-07-09 02:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:08:42 --> Total execution time: 0.0563
DEBUG - 2022-07-09 02:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:08:43 --> Total execution time: 0.0617
DEBUG - 2022-07-09 02:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:38:43 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:08:43 --> Total execution time: 0.0555
DEBUG - 2022-07-09 02:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:38:47 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:08:47 --> Total execution time: 0.0529
DEBUG - 2022-07-09 02:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:10:16 --> Total execution time: 0.0525
DEBUG - 2022-07-09 02:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:45:01 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:15:01 --> Total execution time: 0.2107
DEBUG - 2022-07-09 02:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:45:12 --> Total execution time: 0.0620
DEBUG - 2022-07-09 02:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:45:19 --> Total execution time: 0.0745
DEBUG - 2022-07-09 02:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:45:19 --> Total execution time: 0.1182
DEBUG - 2022-07-09 02:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:45:21 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:15:21 --> Total execution time: 0.0593
DEBUG - 2022-07-09 02:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:46:45 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:16:45 --> Total execution time: 0.0358
DEBUG - 2022-07-09 02:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:46:48 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:16:48 --> Total execution time: 0.0396
DEBUG - 2022-07-09 02:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:46:53 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:16:53 --> Total execution time: 0.0361
DEBUG - 2022-07-09 02:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:47:06 --> Total execution time: 0.0587
DEBUG - 2022-07-09 02:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:47:08 --> Total execution time: 0.0564
DEBUG - 2022-07-09 02:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:47:08 --> Total execution time: 0.1039
DEBUG - 2022-07-09 02:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:48:12 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:18:12 --> Total execution time: 0.0617
DEBUG - 2022-07-09 02:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:48:59 --> Total execution time: 0.0604
DEBUG - 2022-07-09 02:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:49:00 --> Total execution time: 0.0755
DEBUG - 2022-07-09 02:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:49:00 --> Total execution time: 0.0951
DEBUG - 2022-07-09 02:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:49:09 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:19:09 --> Total execution time: 0.0528
DEBUG - 2022-07-09 02:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:21:31 --> Total execution time: 0.1049
DEBUG - 2022-07-09 02:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:21:50 --> Total execution time: 0.0618
DEBUG - 2022-07-09 02:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:21:56 --> Total execution time: 0.0816
DEBUG - 2022-07-09 02:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:21:57 --> Total execution time: 0.0779
DEBUG - 2022-07-09 02:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:21:58 --> Total execution time: 0.1070
DEBUG - 2022-07-09 02:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:22:14 --> Total execution time: 0.0581
DEBUG - 2022-07-09 02:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:22:20 --> Total execution time: 0.0579
DEBUG - 2022-07-09 02:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:22:39 --> Total execution time: 0.0607
DEBUG - 2022-07-09 02:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:22:47 --> Total execution time: 0.1317
DEBUG - 2022-07-09 02:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:22:56 --> Total execution time: 0.0898
DEBUG - 2022-07-09 02:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:22:58 --> Total execution time: 0.0541
DEBUG - 2022-07-09 02:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:23:00 --> Total execution time: 0.0572
DEBUG - 2022-07-09 02:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:23:06 --> Total execution time: 0.0667
DEBUG - 2022-07-09 02:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:23:07 --> Total execution time: 0.0328
DEBUG - 2022-07-09 02:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:23:08 --> Total execution time: 0.0592
DEBUG - 2022-07-09 02:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:23:08 --> Total execution time: 0.0581
DEBUG - 2022-07-09 02:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:23:09 --> Total execution time: 0.0694
DEBUG - 2022-07-09 02:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:23:10 --> Total execution time: 0.0634
DEBUG - 2022-07-09 02:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:23:17 --> Total execution time: 0.0775
DEBUG - 2022-07-09 02:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:23:23 --> Total execution time: 0.0554
DEBUG - 2022-07-09 02:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:23:30 --> Total execution time: 0.0876
DEBUG - 2022-07-09 02:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:23:36 --> Total execution time: 0.1292
DEBUG - 2022-07-09 02:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:23:43 --> Total execution time: 0.0531
DEBUG - 2022-07-09 02:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:23:52 --> Total execution time: 0.0570
DEBUG - 2022-07-09 02:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:23:53 --> Total execution time: 0.0707
DEBUG - 2022-07-09 02:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:24:08 --> Total execution time: 0.0661
DEBUG - 2022-07-09 02:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:24:16 --> Total execution time: 0.0567
DEBUG - 2022-07-09 02:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:24:25 --> Total execution time: 0.0603
DEBUG - 2022-07-09 02:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:55:22 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:25:22 --> Total execution time: 0.0384
DEBUG - 2022-07-09 02:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:55:25 --> Total execution time: 0.0783
DEBUG - 2022-07-09 02:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:55:26 --> Total execution time: 0.0693
DEBUG - 2022-07-09 02:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:55:27 --> Total execution time: 0.0539
DEBUG - 2022-07-09 02:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:55:35 --> Total execution time: 0.0707
DEBUG - 2022-07-09 02:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:25:36 --> Total execution time: 0.0564
DEBUG - 2022-07-09 02:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:25:51 --> Total execution time: 0.0375
DEBUG - 2022-07-09 02:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:55:59 --> Total execution time: 0.0504
DEBUG - 2022-07-09 02:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:56:01 --> Total execution time: 0.1092
DEBUG - 2022-07-09 02:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:56:01 --> Total execution time: 0.2382
DEBUG - 2022-07-09 02:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:56:07 --> Total execution time: 0.0526
DEBUG - 2022-07-09 02:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 02:56:09 --> Total execution time: 0.0630
DEBUG - 2022-07-09 02:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:26:11 --> Total execution time: 0.0497
DEBUG - 2022-07-09 02:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 02:56:12 --> No URI present. Default controller set.
DEBUG - 2022-07-09 02:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 02:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:26:12 --> Total execution time: 0.0561
DEBUG - 2022-07-09 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:30:02 --> Total execution time: 0.1909
DEBUG - 2022-07-09 03:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:02:16 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:32:16 --> Total execution time: 0.0965
DEBUG - 2022-07-09 03:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:04:50 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:34:50 --> Total execution time: 0.0372
DEBUG - 2022-07-09 03:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:04:58 --> Total execution time: 0.0627
DEBUG - 2022-07-09 03:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:05:08 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:35:08 --> Total execution time: 0.1346
DEBUG - 2022-07-09 03:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:35:19 --> Total execution time: 0.0596
DEBUG - 2022-07-09 03:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:05:20 --> Total execution time: 0.0783
DEBUG - 2022-07-09 03:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:05:20 --> Total execution time: 0.1173
DEBUG - 2022-07-09 03:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:35:34 --> Total execution time: 0.0618
DEBUG - 2022-07-09 03:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:35:40 --> Total execution time: 0.0762
DEBUG - 2022-07-09 03:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:36:05 --> Total execution time: 0.0831
DEBUG - 2022-07-09 03:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:36:08 --> Total execution time: 0.0713
DEBUG - 2022-07-09 03:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:36:13 --> Total execution time: 0.0860
DEBUG - 2022-07-09 03:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:06:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 03:06:29 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-09 03:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:06:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 03:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:36:49 --> Total execution time: 2.1314
DEBUG - 2022-07-09 03:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:06:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 03:06:52 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 03:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:37:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 03:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:37:36 --> Total execution time: 0.0547
DEBUG - 2022-07-09 03:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:37:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 13:37:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 13:37:37 --> Total execution time: 0.1890
DEBUG - 2022-07-09 03:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:37:39 --> Total execution time: 0.0571
DEBUG - 2022-07-09 03:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:37:52 --> Total execution time: 0.0842
DEBUG - 2022-07-09 03:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:37:59 --> Total execution time: 0.0539
DEBUG - 2022-07-09 03:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:38:41 --> Total execution time: 0.0358
DEBUG - 2022-07-09 03:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:09:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 03:09:18 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-09 03:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:09:55 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:39:55 --> Total execution time: 0.0780
DEBUG - 2022-07-09 03:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:09:55 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:39:55 --> Total execution time: 0.0452
DEBUG - 2022-07-09 03:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:39:57 --> Total execution time: 0.0330
DEBUG - 2022-07-09 03:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:40:11 --> Total execution time: 0.0652
DEBUG - 2022-07-09 03:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:40:19 --> Total execution time: 0.0908
DEBUG - 2022-07-09 03:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:40:33 --> Total execution time: 0.0558
DEBUG - 2022-07-09 03:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:11:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 03:11:33 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-09 03:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:43:55 --> Total execution time: 0.0494
DEBUG - 2022-07-09 03:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:45:46 --> Total execution time: 0.0502
DEBUG - 2022-07-09 03:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:45:48 --> Total execution time: 0.1351
DEBUG - 2022-07-09 03:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:45:52 --> Total execution time: 0.0685
DEBUG - 2022-07-09 03:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:45:59 --> Total execution time: 0.0684
DEBUG - 2022-07-09 03:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:46:02 --> Total execution time: 0.0661
DEBUG - 2022-07-09 03:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:16:02 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:46:02 --> Total execution time: 0.0539
DEBUG - 2022-07-09 03:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:16:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 03:16:03 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-09 03:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:46:08 --> Total execution time: 0.0590
DEBUG - 2022-07-09 03:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:46:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 03:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:46:09 --> Total execution time: 0.0652
DEBUG - 2022-07-09 03:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:46:12 --> Total execution time: 0.0592
DEBUG - 2022-07-09 03:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:47:43 --> Total execution time: 0.0531
DEBUG - 2022-07-09 03:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:48:00 --> Total execution time: 0.0588
DEBUG - 2022-07-09 03:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:48:03 --> Total execution time: 0.0571
DEBUG - 2022-07-09 03:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:48:04 --> Total execution time: 0.0514
DEBUG - 2022-07-09 03:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:48:10 --> Total execution time: 0.0493
DEBUG - 2022-07-09 03:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:48:14 --> Total execution time: 0.0537
DEBUG - 2022-07-09 03:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:48:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 03:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:48:15 --> Total execution time: 0.0453
DEBUG - 2022-07-09 03:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:48:33 --> Total execution time: 0.0624
DEBUG - 2022-07-09 03:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:22:01 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:52:01 --> Total execution time: 0.3436
DEBUG - 2022-07-09 03:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:22:05 --> Total execution time: 0.0505
DEBUG - 2022-07-09 03:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:22:06 --> Total execution time: 0.0558
DEBUG - 2022-07-09 03:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:22:07 --> Total execution time: 0.1148
DEBUG - 2022-07-09 03:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:52:37 --> Total execution time: 0.0534
DEBUG - 2022-07-09 03:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:52:59 --> Total execution time: 0.1610
DEBUG - 2022-07-09 03:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:53:03 --> Total execution time: 0.0504
DEBUG - 2022-07-09 03:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:53:35 --> Total execution time: 0.0577
DEBUG - 2022-07-09 03:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:53:55 --> Total execution time: 0.0718
DEBUG - 2022-07-09 03:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:54:02 --> Total execution time: 0.0572
DEBUG - 2022-07-09 03:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:54:05 --> Total execution time: 0.0533
DEBUG - 2022-07-09 03:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:54:08 --> Total execution time: 0.0941
DEBUG - 2022-07-09 03:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:54:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 03:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:54:09 --> Total execution time: 0.0464
DEBUG - 2022-07-09 03:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:25:24 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:55:24 --> Total execution time: 0.0396
DEBUG - 2022-07-09 03:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:55:32 --> Total execution time: 0.0330
DEBUG - 2022-07-09 03:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:55:44 --> Total execution time: 0.0541
DEBUG - 2022-07-09 03:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:55:58 --> Total execution time: 0.0720
DEBUG - 2022-07-09 03:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:56:03 --> Total execution time: 0.0555
DEBUG - 2022-07-09 03:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:56:10 --> Total execution time: 0.0710
DEBUG - 2022-07-09 03:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:56:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 03:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:56:11 --> Total execution time: 0.0526
DEBUG - 2022-07-09 03:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:27:06 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:57:06 --> Total execution time: 0.0549
DEBUG - 2022-07-09 03:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:57:08 --> Total execution time: 0.0598
DEBUG - 2022-07-09 03:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:57:12 --> Total execution time: 0.0506
DEBUG - 2022-07-09 03:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:57:20 --> Total execution time: 0.0610
DEBUG - 2022-07-09 03:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:57:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 03:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:57:21 --> Total execution time: 0.0501
DEBUG - 2022-07-09 03:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:57:24 --> Total execution time: 0.0727
DEBUG - 2022-07-09 03:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:57:29 --> Total execution time: 0.0583
DEBUG - 2022-07-09 03:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:57:33 --> Total execution time: 0.0596
DEBUG - 2022-07-09 03:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:57:37 --> Total execution time: 0.0503
DEBUG - 2022-07-09 03:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:57:56 --> Total execution time: 0.0578
DEBUG - 2022-07-09 03:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:58:08 --> Total execution time: 0.0957
DEBUG - 2022-07-09 03:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:58:17 --> Total execution time: 0.0531
DEBUG - 2022-07-09 03:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:58:20 --> Total execution time: 0.0548
DEBUG - 2022-07-09 03:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:28:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 03:28:22 --> 404 Page Not Found: Category/uncategorized
DEBUG - 2022-07-09 03:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:58:36 --> Total execution time: 0.0576
DEBUG - 2022-07-09 03:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:58:37 --> Total execution time: 0.1351
DEBUG - 2022-07-09 03:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:58:41 --> Total execution time: 0.0612
DEBUG - 2022-07-09 03:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:58:54 --> Total execution time: 0.0548
DEBUG - 2022-07-09 03:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:58:57 --> Total execution time: 0.0554
DEBUG - 2022-07-09 03:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:58:57 --> Total execution time: 0.0921
DEBUG - 2022-07-09 03:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:59:01 --> Total execution time: 0.0511
DEBUG - 2022-07-09 03:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:59:03 --> Total execution time: 0.0561
DEBUG - 2022-07-09 03:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:59:10 --> Total execution time: 0.0724
DEBUG - 2022-07-09 03:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:59:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 03:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:59:11 --> Total execution time: 0.0439
DEBUG - 2022-07-09 03:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:00:16 --> Total execution time: 0.1671
DEBUG - 2022-07-09 03:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:00:17 --> Total execution time: 0.0856
DEBUG - 2022-07-09 03:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:00:23 --> Total execution time: 0.0899
DEBUG - 2022-07-09 03:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:00:24 --> Total execution time: 0.1355
DEBUG - 2022-07-09 03:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:00:24 --> Total execution time: 0.0756
DEBUG - 2022-07-09 03:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:00:25 --> Total execution time: 0.0827
DEBUG - 2022-07-09 03:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:00:25 --> Total execution time: 0.0798
DEBUG - 2022-07-09 03:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:00:32 --> Total execution time: 0.2052
DEBUG - 2022-07-09 03:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:02:58 --> Total execution time: 0.1161
DEBUG - 2022-07-09 03:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:33:03 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:03:03 --> Total execution time: 0.0416
DEBUG - 2022-07-09 03:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:37:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 03:37:03 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-09 03:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:42:30 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:12:30 --> Total execution time: 0.1090
DEBUG - 2022-07-09 03:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:12:33 --> Total execution time: 0.0513
DEBUG - 2022-07-09 03:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:12:41 --> Total execution time: 0.0594
DEBUG - 2022-07-09 03:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:12:51 --> Total execution time: 0.0724
DEBUG - 2022-07-09 03:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:13:07 --> Total execution time: 0.0816
DEBUG - 2022-07-09 03:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:13:29 --> Total execution time: 0.0957
DEBUG - 2022-07-09 03:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:13:38 --> Total execution time: 0.0651
DEBUG - 2022-07-09 03:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:13:39 --> Total execution time: 0.0559
DEBUG - 2022-07-09 03:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:17:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 03:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:17:14 --> Total execution time: 0.0572
DEBUG - 2022-07-09 03:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:17:23 --> Total execution time: 0.0576
DEBUG - 2022-07-09 03:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:17:48 --> Total execution time: 0.0561
DEBUG - 2022-07-09 03:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:18:05 --> Total execution time: 0.0638
DEBUG - 2022-07-09 03:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:18:13 --> Total execution time: 0.0705
DEBUG - 2022-07-09 03:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:18:30 --> Total execution time: 0.0538
DEBUG - 2022-07-09 03:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:48:43 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:18:43 --> Total execution time: 0.0539
DEBUG - 2022-07-09 03:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:49:04 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:19:04 --> Total execution time: 0.0533
DEBUG - 2022-07-09 03:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:49:13 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:19:13 --> Total execution time: 0.0381
DEBUG - 2022-07-09 03:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:49:23 --> Total execution time: 0.0519
DEBUG - 2022-07-09 03:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:49:27 --> Total execution time: 0.0580
DEBUG - 2022-07-09 03:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:49:27 --> Total execution time: 0.1088
DEBUG - 2022-07-09 03:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:50:47 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:20:47 --> Total execution time: 0.0458
DEBUG - 2022-07-09 03:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:51:10 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:21:10 --> Total execution time: 0.0603
DEBUG - 2022-07-09 03:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:21:16 --> Total execution time: 0.0339
DEBUG - 2022-07-09 03:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:21:30 --> Total execution time: 0.0665
DEBUG - 2022-07-09 03:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:21:36 --> Total execution time: 0.0605
DEBUG - 2022-07-09 03:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:21:44 --> Total execution time: 0.0732
DEBUG - 2022-07-09 03:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:21:57 --> Total execution time: 0.0781
DEBUG - 2022-07-09 03:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:52:32 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:22:32 --> Total execution time: 0.0438
DEBUG - 2022-07-09 03:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:52:40 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:22:40 --> Total execution time: 0.0354
DEBUG - 2022-07-09 03:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:52:40 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:22:40 --> Total execution time: 0.0439
DEBUG - 2022-07-09 03:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:23:02 --> Total execution time: 0.1312
DEBUG - 2022-07-09 03:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:23:49 --> Total execution time: 0.0430
DEBUG - 2022-07-09 03:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:24:16 --> Total execution time: 0.0544
DEBUG - 2022-07-09 03:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:54:23 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:24:23 --> Total execution time: 0.0307
DEBUG - 2022-07-09 03:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:24:40 --> Total execution time: 0.0596
DEBUG - 2022-07-09 03:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:54:51 --> Total execution time: 0.0335
DEBUG - 2022-07-09 03:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:54:53 --> Total execution time: 0.0537
DEBUG - 2022-07-09 03:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:54:53 --> Total execution time: 0.1257
DEBUG - 2022-07-09 03:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:54:56 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:24:56 --> Total execution time: 0.0513
DEBUG - 2022-07-09 03:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:24:57 --> Total execution time: 0.1069
DEBUG - 2022-07-09 03:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:24:59 --> Total execution time: 0.0497
DEBUG - 2022-07-09 03:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:55:01 --> Total execution time: 0.0788
DEBUG - 2022-07-09 03:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:55:03 --> Total execution time: 0.0907
DEBUG - 2022-07-09 03:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:55:03 --> Total execution time: 0.1641
DEBUG - 2022-07-09 03:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:25:08 --> Total execution time: 0.0511
DEBUG - 2022-07-09 03:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:25:15 --> Total execution time: 0.1274
DEBUG - 2022-07-09 03:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:55:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 03:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:25:54 --> Total execution time: 1.9386
DEBUG - 2022-07-09 03:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:55:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 03:55:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 03:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 03:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:26:20 --> Total execution time: 0.0730
DEBUG - 2022-07-09 03:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:26:33 --> Total execution time: 0.0701
DEBUG - 2022-07-09 03:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:26:56 --> Total execution time: 0.0920
DEBUG - 2022-07-09 03:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:56:59 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:26:59 --> Total execution time: 0.0558
DEBUG - 2022-07-09 03:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:27:17 --> Total execution time: 1.5410
DEBUG - 2022-07-09 03:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:27:33 --> Total execution time: 1.4601
DEBUG - 2022-07-09 03:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:57:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 03:57:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 03:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:28:05 --> Total execution time: 1.4345
DEBUG - 2022-07-09 03:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 03:58:06 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 03:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:28:39 --> Total execution time: 1.6091
DEBUG - 2022-07-09 03:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:58:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 03:58:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 03:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:28:59 --> Total execution time: 0.0504
DEBUG - 2022-07-09 03:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:29:39 --> Total execution time: 0.0706
DEBUG - 2022-07-09 03:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 03:59:53 --> No URI present. Default controller set.
DEBUG - 2022-07-09 03:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 03:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:29:54 --> Total execution time: 0.1421
DEBUG - 2022-07-09 04:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:30:03 --> Total execution time: 0.0702
DEBUG - 2022-07-09 04:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:30:07 --> Total execution time: 1.5104
DEBUG - 2022-07-09 04:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:00:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 04:00:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 04:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:30:12 --> Total execution time: 1.5266
DEBUG - 2022-07-09 04:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:30:40 --> Total execution time: 1.5085
DEBUG - 2022-07-09 04:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:00:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 04:00:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 04:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:31:39 --> Total execution time: 0.0658
DEBUG - 2022-07-09 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:01:50 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:31:50 --> Total execution time: 0.0400
DEBUG - 2022-07-09 04:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:32:05 --> Total execution time: 0.0512
DEBUG - 2022-07-09 04:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:32:36 --> Total execution time: 0.0576
DEBUG - 2022-07-09 04:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:03:56 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:33:56 --> Total execution time: 0.0557
DEBUG - 2022-07-09 04:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:03:57 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:33:57 --> Total execution time: 0.0521
DEBUG - 2022-07-09 04:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:34:01 --> Total execution time: 0.0343
DEBUG - 2022-07-09 04:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:04:14 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:34:14 --> Total execution time: 0.0432
DEBUG - 2022-07-09 04:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:34:37 --> Total execution time: 0.0610
DEBUG - 2022-07-09 04:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:34:44 --> Total execution time: 0.0538
DEBUG - 2022-07-09 04:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:34:51 --> Total execution time: 0.0491
DEBUG - 2022-07-09 04:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:35:19 --> Total execution time: 0.0619
DEBUG - 2022-07-09 04:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:35:30 --> Total execution time: 0.0587
DEBUG - 2022-07-09 04:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:35:46 --> Total execution time: 0.0503
DEBUG - 2022-07-09 04:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:05:53 --> Total execution time: 0.0496
DEBUG - 2022-07-09 04:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:05:55 --> Total execution time: 0.0714
DEBUG - 2022-07-09 04:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:05:55 --> Total execution time: 0.1109
DEBUG - 2022-07-09 04:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:37:03 --> Total execution time: 0.0788
DEBUG - 2022-07-09 04:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:37:17 --> Total execution time: 0.0515
DEBUG - 2022-07-09 04:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:42:50 --> Total execution time: 0.0821
DEBUG - 2022-07-09 04:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:43:00 --> Total execution time: 0.1090
DEBUG - 2022-07-09 04:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:13:05 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:43:05 --> Total execution time: 0.1556
DEBUG - 2022-07-09 04:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:43:29 --> Total execution time: 0.0534
DEBUG - 2022-07-09 04:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:13:35 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:43:35 --> Total execution time: 0.0539
DEBUG - 2022-07-09 04:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:13:43 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:43:43 --> Total execution time: 0.0526
DEBUG - 2022-07-09 04:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:43:52 --> Total execution time: 0.0602
DEBUG - 2022-07-09 04:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:44:02 --> Total execution time: 0.0511
DEBUG - 2022-07-09 04:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:14:18 --> Total execution time: 0.0601
DEBUG - 2022-07-09 04:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:14:20 --> Total execution time: 0.0624
DEBUG - 2022-07-09 04:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:14:20 --> Total execution time: 0.1160
DEBUG - 2022-07-09 04:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:44:22 --> Total execution time: 0.0563
DEBUG - 2022-07-09 04:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:44:48 --> Total execution time: 0.0578
DEBUG - 2022-07-09 04:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:45:00 --> Total execution time: 0.0740
DEBUG - 2022-07-09 04:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:45:10 --> Total execution time: 0.0786
DEBUG - 2022-07-09 04:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:45:11 --> Total execution time: 0.0896
DEBUG - 2022-07-09 04:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:45:14 --> Total execution time: 0.0740
DEBUG - 2022-07-09 04:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:46:43 --> Total execution time: 0.0510
DEBUG - 2022-07-09 04:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:16:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 04:16:44 --> 404 Page Not Found: Category/world
DEBUG - 2022-07-09 04:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:46:59 --> Total execution time: 0.0993
DEBUG - 2022-07-09 04:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:47:07 --> Total execution time: 0.0546
DEBUG - 2022-07-09 04:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:47:14 --> Total execution time: 0.1082
DEBUG - 2022-07-09 04:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:47:51 --> Total execution time: 0.0461
DEBUG - 2022-07-09 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:47:59 --> Total execution time: 0.0604
DEBUG - 2022-07-09 04:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:48:00 --> Total execution time: 0.0492
DEBUG - 2022-07-09 04:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:48:02 --> Total execution time: 0.0616
DEBUG - 2022-07-09 04:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:48:02 --> Total execution time: 0.0515
DEBUG - 2022-07-09 04:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:18:02 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:48:02 --> Total execution time: 0.0480
DEBUG - 2022-07-09 04:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:19:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 04:19:55 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-09 04:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:19:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 04:19:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 04:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:25:20 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:55:20 --> Total execution time: 0.2245
DEBUG - 2022-07-09 04:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:25:26 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:55:26 --> Total execution time: 0.0545
DEBUG - 2022-07-09 04:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:55:34 --> Total execution time: 0.0567
DEBUG - 2022-07-09 04:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:55:35 --> Total execution time: 0.0702
DEBUG - 2022-07-09 04:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:55:55 --> Total execution time: 0.0539
DEBUG - 2022-07-09 04:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:56:00 --> Total execution time: 0.0493
DEBUG - 2022-07-09 04:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:56:13 --> Total execution time: 0.0557
DEBUG - 2022-07-09 04:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:56:17 --> Total execution time: 0.0490
DEBUG - 2022-07-09 04:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 04:26:20 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-09 04:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:56:39 --> Total execution time: 0.0531
DEBUG - 2022-07-09 04:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:56:42 --> Total execution time: 0.0530
DEBUG - 2022-07-09 04:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:56:49 --> Total execution time: 0.0530
DEBUG - 2022-07-09 04:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:56:56 --> Total execution time: 0.0607
DEBUG - 2022-07-09 04:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:56:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 04:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:56:57 --> Total execution time: 0.0524
DEBUG - 2022-07-09 04:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:57:24 --> Total execution time: 0.0605
DEBUG - 2022-07-09 04:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:57:33 --> Total execution time: 0.0599
DEBUG - 2022-07-09 04:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:57:33 --> Total execution time: 0.0539
DEBUG - 2022-07-09 04:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:57:40 --> Total execution time: 0.0603
DEBUG - 2022-07-09 04:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:57:44 --> Total execution time: 0.0543
DEBUG - 2022-07-09 04:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:57:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 04:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:57:45 --> Total execution time: 0.0545
DEBUG - 2022-07-09 04:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:59:35 --> Total execution time: 0.0599
DEBUG - 2022-07-09 04:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:00:30 --> Total execution time: 0.0539
DEBUG - 2022-07-09 04:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:30:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 04:30:36 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-09 04:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:03:58 --> Total execution time: 0.2168
DEBUG - 2022-07-09 04:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:04:03 --> Total execution time: 0.0634
DEBUG - 2022-07-09 04:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:04:06 --> Total execution time: 0.0574
DEBUG - 2022-07-09 04:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:04:09 --> Total execution time: 0.0722
DEBUG - 2022-07-09 04:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:04:12 --> Total execution time: 0.0647
DEBUG - 2022-07-09 04:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:04:14 --> Total execution time: 0.0659
DEBUG - 2022-07-09 04:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:04:18 --> Total execution time: 0.0810
DEBUG - 2022-07-09 04:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:04:19 --> Total execution time: 0.2631
DEBUG - 2022-07-09 04:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:04:22 --> Total execution time: 0.0632
DEBUG - 2022-07-09 04:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:04:28 --> Total execution time: 0.0681
DEBUG - 2022-07-09 04:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:28 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:04:28 --> Total execution time: 0.0620
DEBUG - 2022-07-09 04:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:04:32 --> Total execution time: 0.0722
DEBUG - 2022-07-09 04:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:04:38 --> Total execution time: 0.0499
DEBUG - 2022-07-09 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:04:47 --> Total execution time: 0.0644
DEBUG - 2022-07-09 04:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:04:52 --> Total execution time: 0.1093
DEBUG - 2022-07-09 04:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:06:04 --> Total execution time: 0.1274
DEBUG - 2022-07-09 04:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:06:12 --> Total execution time: 0.1026
DEBUG - 2022-07-09 04:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:07:13 --> Total execution time: 0.0672
DEBUG - 2022-07-09 04:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:07:36 --> Total execution time: 0.1092
DEBUG - 2022-07-09 04:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:08:01 --> Total execution time: 0.0545
DEBUG - 2022-07-09 04:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:08:26 --> Total execution time: 0.0532
DEBUG - 2022-07-09 04:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 04:38:39 --> 404 Page Not Found: Category/news
DEBUG - 2022-07-09 04:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:09:10 --> Total execution time: 0.0861
DEBUG - 2022-07-09 04:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:10:54 --> Total execution time: 0.0626
DEBUG - 2022-07-09 04:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:11:01 --> Total execution time: 0.0993
DEBUG - 2022-07-09 04:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:41:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 04:41:55 --> 404 Page Not Found: News/feed
DEBUG - 2022-07-09 04:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:12:27 --> Total execution time: 0.0922
DEBUG - 2022-07-09 04:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:12:43 --> Total execution time: 0.1690
DEBUG - 2022-07-09 04:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:12:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 04:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:12:49 --> Total execution time: 0.1098
DEBUG - 2022-07-09 04:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:12:58 --> Total execution time: 0.0734
DEBUG - 2022-07-09 04:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:13:08 --> Total execution time: 0.0579
DEBUG - 2022-07-09 04:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:14:01 --> Total execution time: 0.1621
DEBUG - 2022-07-09 04:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:14:03 --> Total execution time: 0.0573
DEBUG - 2022-07-09 04:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:14:04 --> Total execution time: 0.0514
DEBUG - 2022-07-09 04:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:46:28 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:16:28 --> Total execution time: 0.0520
DEBUG - 2022-07-09 04:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:16:32 --> Total execution time: 0.0433
DEBUG - 2022-07-09 04:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:17:12 --> Total execution time: 0.0409
DEBUG - 2022-07-09 04:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:17:23 --> Total execution time: 0.0672
DEBUG - 2022-07-09 04:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:47:50 --> Total execution time: 0.0545
DEBUG - 2022-07-09 04:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:17:50 --> Total execution time: 0.0594
DEBUG - 2022-07-09 04:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:17:55 --> Total execution time: 0.0687
DEBUG - 2022-07-09 04:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:17:56 --> Total execution time: 0.0577
DEBUG - 2022-07-09 04:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:48:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 04:48:46 --> 404 Page Not Found: Appphp/feed
DEBUG - 2022-07-09 04:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:50:43 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:20:43 --> Total execution time: 0.0538
DEBUG - 2022-07-09 04:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:20:47 --> Total execution time: 0.0704
DEBUG - 2022-07-09 04:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:20:49 --> Total execution time: 0.0711
DEBUG - 2022-07-09 04:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:20:52 --> Total execution time: 0.0751
DEBUG - 2022-07-09 04:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:51:40 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:21:40 --> Total execution time: 0.0410
DEBUG - 2022-07-09 04:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:51:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 04:51:42 --> 404 Page Not Found: List_teacher/index
DEBUG - 2022-07-09 04:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:51:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 04:51:42 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 04:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:51:47 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:21:47 --> Total execution time: 0.0704
DEBUG - 2022-07-09 04:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:21:51 --> Total execution time: 0.0334
DEBUG - 2022-07-09 04:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:22:17 --> Total execution time: 0.0951
DEBUG - 2022-07-09 04:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:52:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 04:52:23 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-09 04:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:22:27 --> Total execution time: 0.0760
DEBUG - 2022-07-09 04:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:22:32 --> Total execution time: 0.0813
DEBUG - 2022-07-09 04:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:52:40 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:22:40 --> Total execution time: 0.0542
DEBUG - 2022-07-09 04:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:22:51 --> Total execution time: 0.0393
DEBUG - 2022-07-09 04:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:22:51 --> Total execution time: 0.0627
DEBUG - 2022-07-09 04:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:22:58 --> Total execution time: 0.0510
DEBUG - 2022-07-09 04:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:23:05 --> Total execution time: 0.0937
DEBUG - 2022-07-09 04:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:53:09 --> Total execution time: 0.0529
DEBUG - 2022-07-09 04:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:23:18 --> Total execution time: 0.0719
DEBUG - 2022-07-09 04:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:23:19 --> Total execution time: 0.0508
DEBUG - 2022-07-09 04:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:53:22 --> Total execution time: 0.0787
DEBUG - 2022-07-09 04:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:53:29 --> Total execution time: 0.0572
DEBUG - 2022-07-09 04:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:23:41 --> Total execution time: 0.1275
DEBUG - 2022-07-09 04:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:53:41 --> Total execution time: 0.0678
DEBUG - 2022-07-09 04:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:23:45 --> Total execution time: 0.0494
DEBUG - 2022-07-09 04:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:53:51 --> Total execution time: 0.0530
DEBUG - 2022-07-09 04:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:54:06 --> Total execution time: 0.0519
DEBUG - 2022-07-09 04:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:54:08 --> Total execution time: 0.0645
DEBUG - 2022-07-09 04:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:54:11 --> Total execution time: 0.0587
DEBUG - 2022-07-09 04:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:54:12 --> Total execution time: 0.0505
DEBUG - 2022-07-09 04:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:24:12 --> Total execution time: 0.0603
DEBUG - 2022-07-09 04:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:24:15 --> Total execution time: 0.0573
DEBUG - 2022-07-09 04:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:24:18 --> Total execution time: 0.0620
DEBUG - 2022-07-09 04:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:24:34 --> Total execution time: 0.0561
DEBUG - 2022-07-09 04:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:40 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:24:40 --> Total execution time: 0.0542
DEBUG - 2022-07-09 04:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:24:41 --> Total execution time: 0.0500
DEBUG - 2022-07-09 04:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:24:45 --> Total execution time: 0.0445
DEBUG - 2022-07-09 04:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:24:46 --> Total execution time: 0.0454
DEBUG - 2022-07-09 04:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:24:46 --> Total execution time: 0.0456
DEBUG - 2022-07-09 04:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:24:47 --> Total execution time: 0.0722
DEBUG - 2022-07-09 04:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:54:48 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:24:48 --> Total execution time: 0.0741
DEBUG - 2022-07-09 04:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:55:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 04:55:10 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-09 04:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:55:13 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:25:13 --> Total execution time: 0.0734
DEBUG - 2022-07-09 04:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:25:27 --> Total execution time: 0.1119
DEBUG - 2022-07-09 04:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:25:32 --> Total execution time: 0.0617
DEBUG - 2022-07-09 04:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:25:35 --> Total execution time: 0.0663
DEBUG - 2022-07-09 04:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:55:48 --> Total execution time: 0.0511
DEBUG - 2022-07-09 04:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:55:51 --> Total execution time: 0.0497
DEBUG - 2022-07-09 04:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:56:00 --> Total execution time: 0.0731
DEBUG - 2022-07-09 04:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:56:01 --> Total execution time: 0.0498
DEBUG - 2022-07-09 04:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:56:03 --> Total execution time: 0.0516
DEBUG - 2022-07-09 04:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:26:04 --> Total execution time: 0.0540
DEBUG - 2022-07-09 04:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:56:04 --> Total execution time: 0.0504
DEBUG - 2022-07-09 04:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:56:53 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:26:53 --> Total execution time: 0.0864
DEBUG - 2022-07-09 04:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:56:54 --> Total execution time: 0.0509
DEBUG - 2022-07-09 04:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:56:57 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:26:57 --> Total execution time: 0.1279
DEBUG - 2022-07-09 04:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:56:57 --> Total execution time: 0.0330
DEBUG - 2022-07-09 04:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:27:02 --> Total execution time: 0.0544
DEBUG - 2022-07-09 04:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:27:11 --> Total execution time: 0.0602
DEBUG - 2022-07-09 04:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:57:12 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:27:12 --> Total execution time: 0.0529
DEBUG - 2022-07-09 04:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 04:57:24 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-09 04:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 04:57:25 --> 404 Page Not Found: Blog/feed
DEBUG - 2022-07-09 04:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:27:31 --> Total execution time: 0.0588
DEBUG - 2022-07-09 04:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:27:49 --> Total execution time: 0.0733
DEBUG - 2022-07-09 04:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:28:13 --> Total execution time: 0.0499
DEBUG - 2022-07-09 04:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:58:51 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:28:51 --> Total execution time: 0.0525
DEBUG - 2022-07-09 04:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:59:17 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:29:17 --> Total execution time: 0.0392
DEBUG - 2022-07-09 04:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:59:21 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:29:21 --> Total execution time: 0.0360
DEBUG - 2022-07-09 04:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:29:23 --> Total execution time: 0.0369
DEBUG - 2022-07-09 04:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:29:24 --> Total execution time: 0.0608
DEBUG - 2022-07-09 04:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:29:31 --> Total execution time: 0.0660
DEBUG - 2022-07-09 04:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:29:35 --> Total execution time: 0.0534
DEBUG - 2022-07-09 04:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:29:39 --> Total execution time: 0.0689
DEBUG - 2022-07-09 04:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:59:41 --> No URI present. Default controller set.
DEBUG - 2022-07-09 04:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:29:41 --> Total execution time: 0.0485
DEBUG - 2022-07-09 04:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:29:42 --> Total execution time: 0.0269
DEBUG - 2022-07-09 04:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:29:44 --> Total execution time: 0.0513
DEBUG - 2022-07-09 04:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:29:48 --> Total execution time: 0.0479
DEBUG - 2022-07-09 04:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 04:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 04:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 04:59:50 --> Total execution time: 0.0527
DEBUG - 2022-07-09 05:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:00:00 --> Total execution time: 0.0926
DEBUG - 2022-07-09 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:30:02 --> Total execution time: 0.0808
DEBUG - 2022-07-09 05:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:30:25 --> Total execution time: 0.0562
DEBUG - 2022-07-09 05:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:00:31 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:30:31 --> Total execution time: 0.1323
DEBUG - 2022-07-09 05:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:30:51 --> Total execution time: 0.0845
DEBUG - 2022-07-09 05:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:30:51 --> Total execution time: 0.0955
DEBUG - 2022-07-09 05:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:30:52 --> Total execution time: 0.0513
DEBUG - 2022-07-09 05:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:30:57 --> Total execution time: 0.1132
DEBUG - 2022-07-09 05:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:30:58 --> Total execution time: 0.0802
DEBUG - 2022-07-09 05:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:31:01 --> Total execution time: 0.0554
DEBUG - 2022-07-09 05:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 05:01:01 --> 404 Page Not Found: Webgility/upgrade.php
DEBUG - 2022-07-09 05:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:31:08 --> Total execution time: 0.0574
DEBUG - 2022-07-09 05:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:31:12 --> Total execution time: 0.0365
DEBUG - 2022-07-09 05:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:31:24 --> Total execution time: 0.0748
DEBUG - 2022-07-09 05:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:31:37 --> Total execution time: 0.0610
DEBUG - 2022-07-09 05:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:31:44 --> Total execution time: 0.0634
DEBUG - 2022-07-09 05:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:31:46 --> Total execution time: 0.1843
DEBUG - 2022-07-09 05:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:32:11 --> Total execution time: 0.0642
DEBUG - 2022-07-09 05:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:32:13 --> Total execution time: 0.1593
DEBUG - 2022-07-09 05:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:32:15 --> Total execution time: 0.1135
DEBUG - 2022-07-09 05:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:02:21 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 15:32:21 --> Total execution time: 0.1637
DEBUG - 2022-07-09 05:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:32:21 --> Total execution time: 0.2832
DEBUG - 2022-07-09 05:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:32:34 --> Total execution time: 0.3692
DEBUG - 2022-07-09 05:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:32:36 --> Total execution time: 0.0354
DEBUG - 2022-07-09 05:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:32:52 --> Total execution time: 0.1304
DEBUG - 2022-07-09 05:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:32:59 --> Total execution time: 0.0751
DEBUG - 2022-07-09 05:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:04 --> Total execution time: 0.0699
DEBUG - 2022-07-09 05:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:06 --> Total execution time: 0.0621
DEBUG - 2022-07-09 05:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:08 --> Total execution time: 0.0517
DEBUG - 2022-07-09 05:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:20 --> Total execution time: 0.0574
DEBUG - 2022-07-09 05:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:20 --> Total execution time: 0.0664
DEBUG - 2022-07-09 05:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:20 --> Total execution time: 0.0574
DEBUG - 2022-07-09 05:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:23 --> Total execution time: 0.0579
DEBUG - 2022-07-09 05:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:24 --> Total execution time: 0.0561
DEBUG - 2022-07-09 05:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:24 --> Total execution time: 0.0496
DEBUG - 2022-07-09 05:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:24 --> Total execution time: 0.0649
DEBUG - 2022-07-09 05:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:27 --> Total execution time: 0.0562
DEBUG - 2022-07-09 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:33 --> Total execution time: 0.0930
DEBUG - 2022-07-09 05:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:34 --> Total execution time: 0.0527
DEBUG - 2022-07-09 05:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:38 --> Total execution time: 0.0727
DEBUG - 2022-07-09 05:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:38 --> Total execution time: 0.0588
DEBUG - 2022-07-09 05:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:48 --> Total execution time: 0.0610
DEBUG - 2022-07-09 05:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:48 --> Total execution time: 0.0818
DEBUG - 2022-07-09 05:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:49 --> Total execution time: 0.0487
DEBUG - 2022-07-09 05:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:03:50 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:33:50 --> Total execution time: 0.0452
DEBUG - 2022-07-09 05:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:34:17 --> Total execution time: 0.0580
DEBUG - 2022-07-09 05:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:34:28 --> Total execution time: 0.0568
DEBUG - 2022-07-09 05:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:34:29 --> Total execution time: 0.0694
DEBUG - 2022-07-09 05:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:34:37 --> Total execution time: 0.0567
DEBUG - 2022-07-09 05:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:34:41 --> Total execution time: 0.0558
DEBUG - 2022-07-09 05:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:34:44 --> Total execution time: 0.0636
DEBUG - 2022-07-09 05:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:35:01 --> Total execution time: 0.1730
DEBUG - 2022-07-09 05:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:36:28 --> Total execution time: 0.0642
DEBUG - 2022-07-09 05:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:36:42 --> Total execution time: 0.0579
DEBUG - 2022-07-09 05:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:37:52 --> Total execution time: 0.0547
DEBUG - 2022-07-09 05:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:37:56 --> Total execution time: 0.0556
DEBUG - 2022-07-09 05:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:39:02 --> Total execution time: 0.1578
DEBUG - 2022-07-09 05:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:09:49 --> Total execution time: 0.0543
DEBUG - 2022-07-09 05:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:10:06 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:40:06 --> Total execution time: 0.0664
DEBUG - 2022-07-09 05:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:10:14 --> Total execution time: 0.0997
DEBUG - 2022-07-09 05:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:40:40 --> Total execution time: 0.0340
DEBUG - 2022-07-09 05:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:40:44 --> Total execution time: 0.0497
DEBUG - 2022-07-09 05:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:40:47 --> Total execution time: 0.0561
DEBUG - 2022-07-09 05:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:41:10 --> Total execution time: 0.0582
DEBUG - 2022-07-09 05:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:12:08 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:42:08 --> Total execution time: 0.0660
DEBUG - 2022-07-09 05:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:12:09 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:42:09 --> Total execution time: 0.0560
DEBUG - 2022-07-09 05:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:42:20 --> Total execution time: 0.0429
DEBUG - 2022-07-09 05:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:42:30 --> Total execution time: 0.0547
DEBUG - 2022-07-09 05:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:12:37 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:42:38 --> Total execution time: 0.0574
DEBUG - 2022-07-09 05:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:42:39 --> Total execution time: 0.0788
DEBUG - 2022-07-09 05:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:42:44 --> Total execution time: 0.0730
DEBUG - 2022-07-09 05:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:42:58 --> Total execution time: 0.0580
DEBUG - 2022-07-09 05:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:12:59 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:42:59 --> Total execution time: 0.0395
DEBUG - 2022-07-09 05:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:43:03 --> Total execution time: 0.0665
DEBUG - 2022-07-09 05:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:43:16 --> Total execution time: 0.0539
DEBUG - 2022-07-09 05:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:43:21 --> Total execution time: 0.0806
DEBUG - 2022-07-09 05:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:43:34 --> Total execution time: 0.0925
DEBUG - 2022-07-09 05:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:43:48 --> Total execution time: 0.0819
DEBUG - 2022-07-09 05:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:44:13 --> Total execution time: 0.0768
DEBUG - 2022-07-09 05:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:44:14 --> Total execution time: 0.0593
DEBUG - 2022-07-09 05:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:44:18 --> Total execution time: 0.0742
DEBUG - 2022-07-09 05:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:44:23 --> Total execution time: 0.0639
DEBUG - 2022-07-09 05:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:44:28 --> Total execution time: 0.0552
DEBUG - 2022-07-09 05:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:44:31 --> Total execution time: 0.0614
DEBUG - 2022-07-09 05:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:44:35 --> Total execution time: 0.0547
DEBUG - 2022-07-09 05:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:44:51 --> Total execution time: 0.0577
DEBUG - 2022-07-09 05:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:45:01 --> Total execution time: 0.0686
DEBUG - 2022-07-09 05:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:45:06 --> Total execution time: 0.0640
DEBUG - 2022-07-09 05:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:45:19 --> Total execution time: 0.0561
DEBUG - 2022-07-09 05:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:45:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 05:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:45:20 --> Total execution time: 0.0641
DEBUG - 2022-07-09 05:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:45:37 --> Total execution time: 0.0850
DEBUG - 2022-07-09 05:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:45:50 --> Total execution time: 0.0598
DEBUG - 2022-07-09 05:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:15:56 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:45:56 --> Total execution time: 0.1261
DEBUG - 2022-07-09 05:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:46:09 --> Total execution time: 0.0547
DEBUG - 2022-07-09 05:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:16:10 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:46:10 --> Total execution time: 0.0623
DEBUG - 2022-07-09 05:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:46:13 --> Total execution time: 0.0666
DEBUG - 2022-07-09 05:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:47:16 --> Total execution time: 0.0681
DEBUG - 2022-07-09 05:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:47:36 --> Total execution time: 0.1492
DEBUG - 2022-07-09 05:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:47:45 --> Total execution time: 0.0508
DEBUG - 2022-07-09 05:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:47:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 05:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:47:46 --> Total execution time: 0.0454
DEBUG - 2022-07-09 05:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:48:14 --> Total execution time: 0.0841
DEBUG - 2022-07-09 05:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:48:47 --> Total execution time: 0.0497
DEBUG - 2022-07-09 05:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:49:02 --> Total execution time: 0.0513
DEBUG - 2022-07-09 05:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:49:04 --> Total execution time: 0.1384
DEBUG - 2022-07-09 05:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:49:12 --> Total execution time: 0.0498
DEBUG - 2022-07-09 05:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:19:13 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:49:13 --> Total execution time: 0.0614
DEBUG - 2022-07-09 05:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:19:24 --> Total execution time: 0.0545
DEBUG - 2022-07-09 05:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:19:26 --> Total execution time: 0.0601
DEBUG - 2022-07-09 05:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:19:26 --> Total execution time: 0.1297
DEBUG - 2022-07-09 05:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:19:29 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:49:29 --> Total execution time: 0.0505
DEBUG - 2022-07-09 05:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:49:38 --> Total execution time: 0.0542
DEBUG - 2022-07-09 05:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:19:41 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:49:41 --> Total execution time: 0.0554
DEBUG - 2022-07-09 05:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:49:51 --> Total execution time: 0.0507
DEBUG - 2022-07-09 05:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:49:58 --> Total execution time: 0.0511
DEBUG - 2022-07-09 05:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:50:04 --> Total execution time: 0.0532
DEBUG - 2022-07-09 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:20:22 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:50:22 --> Total execution time: 0.0586
DEBUG - 2022-07-09 05:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:50:32 --> Total execution time: 0.0605
DEBUG - 2022-07-09 05:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:50:41 --> Total execution time: 0.0543
DEBUG - 2022-07-09 05:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:50:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 05:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:50:42 --> Total execution time: 0.0537
DEBUG - 2022-07-09 05:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:51:05 --> Total execution time: 0.0528
DEBUG - 2022-07-09 05:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:51:23 --> Total execution time: 0.0445
DEBUG - 2022-07-09 05:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:51:29 --> Total execution time: 0.1430
DEBUG - 2022-07-09 05:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:51:31 --> Total execution time: 0.0520
DEBUG - 2022-07-09 05:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:51:41 --> Total execution time: 0.1409
DEBUG - 2022-07-09 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:22:09 --> Total execution time: 0.0587
DEBUG - 2022-07-09 05:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:23:01 --> Total execution time: 0.0607
DEBUG - 2022-07-09 05:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:23:14 --> Total execution time: 0.0538
DEBUG - 2022-07-09 05:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:53:46 --> Total execution time: 0.1238
DEBUG - 2022-07-09 05:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:24:19 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:54:19 --> Total execution time: 0.0535
DEBUG - 2022-07-09 05:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 05:24:19 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-09 05:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:24:21 --> Total execution time: 0.0554
DEBUG - 2022-07-09 05:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:24:50 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:54:50 --> Total execution time: 0.0469
DEBUG - 2022-07-09 05:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:24:58 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:54:59 --> Total execution time: 0.1401
DEBUG - 2022-07-09 05:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:55:08 --> Total execution time: 0.0483
DEBUG - 2022-07-09 05:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:55:21 --> Total execution time: 0.0635
DEBUG - 2022-07-09 05:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:57:03 --> Total execution time: 0.0480
DEBUG - 2022-07-09 05:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:57:29 --> Total execution time: 0.1410
DEBUG - 2022-07-09 05:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:27:38 --> Total execution time: 0.0496
DEBUG - 2022-07-09 05:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:27:46 --> Total execution time: 0.0450
DEBUG - 2022-07-09 05:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:27:53 --> Total execution time: 0.0561
DEBUG - 2022-07-09 05:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:28:09 --> Total execution time: 0.0550
DEBUG - 2022-07-09 05:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:28:12 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:58:12 --> Total execution time: 0.0352
DEBUG - 2022-07-09 05:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 05:28:16 --> 404 Page Not Found: Wp-content/wp-echo.php
DEBUG - 2022-07-09 05:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:28:27 --> Total execution time: 0.0573
DEBUG - 2022-07-09 05:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:28:41 --> Total execution time: 0.0518
DEBUG - 2022-07-09 05:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:29:03 --> Total execution time: 0.0518
DEBUG - 2022-07-09 05:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:29:38 --> Total execution time: 0.0494
DEBUG - 2022-07-09 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:29:41 --> Total execution time: 0.0498
DEBUG - 2022-07-09 05:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:30:01 --> Total execution time: 0.0876
DEBUG - 2022-07-09 05:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:30:38 --> Total execution time: 0.1116
DEBUG - 2022-07-09 05:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:30:41 --> Total execution time: 0.0829
DEBUG - 2022-07-09 05:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:31:08 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:01:08 --> Total execution time: 0.1278
DEBUG - 2022-07-09 05:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:01:12 --> Total execution time: 0.0558
DEBUG - 2022-07-09 05:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:01:21 --> Total execution time: 0.0620
DEBUG - 2022-07-09 05:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:01:25 --> Total execution time: 0.0625
DEBUG - 2022-07-09 05:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:01:44 --> Total execution time: 0.0540
DEBUG - 2022-07-09 05:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:01:52 --> Total execution time: 0.0872
DEBUG - 2022-07-09 05:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:02:24 --> Total execution time: 0.1366
DEBUG - 2022-07-09 05:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:02:36 --> Total execution time: 0.0829
DEBUG - 2022-07-09 05:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:02:42 --> Total execution time: 0.0474
DEBUG - 2022-07-09 05:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:02:48 --> Total execution time: 0.0357
DEBUG - 2022-07-09 05:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:03:00 --> Total execution time: 0.0603
DEBUG - 2022-07-09 05:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:03:04 --> Total execution time: 0.0644
DEBUG - 2022-07-09 05:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:03:10 --> Total execution time: 0.0879
DEBUG - 2022-07-09 05:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:03:19 --> Total execution time: 0.0536
DEBUG - 2022-07-09 05:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:03:27 --> Total execution time: 0.0312
DEBUG - 2022-07-09 05:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:03:28 --> Total execution time: 0.0643
DEBUG - 2022-07-09 05:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:03:38 --> Total execution time: 0.0686
DEBUG - 2022-07-09 05:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:03:42 --> Total execution time: 0.0707
DEBUG - 2022-07-09 05:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:03:42 --> Total execution time: 0.0702
DEBUG - 2022-07-09 05:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:03:44 --> Total execution time: 0.0789
DEBUG - 2022-07-09 05:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:03:58 --> Total execution time: 0.0550
DEBUG - 2022-07-09 05:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:04:24 --> Total execution time: 0.0679
DEBUG - 2022-07-09 05:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:04:32 --> Total execution time: 0.0618
DEBUG - 2022-07-09 05:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:05:36 --> Total execution time: 0.0548
DEBUG - 2022-07-09 05:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:06:05 --> Total execution time: 0.1302
DEBUG - 2022-07-09 05:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:06:11 --> Total execution time: 0.0646
DEBUG - 2022-07-09 05:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:07:46 --> Total execution time: 0.0485
DEBUG - 2022-07-09 05:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 05:38:31 --> 404 Page Not Found: Category/opinion
DEBUG - 2022-07-09 05:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:08:35 --> Total execution time: 0.0667
DEBUG - 2022-07-09 05:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:08:42 --> Total execution time: 0.0538
DEBUG - 2022-07-09 05:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:08:52 --> Total execution time: 0.0543
DEBUG - 2022-07-09 05:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:09:02 --> Total execution time: 0.0510
DEBUG - 2022-07-09 05:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:10:25 --> Total execution time: 0.1692
DEBUG - 2022-07-09 05:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:10:47 --> Total execution time: 0.0551
DEBUG - 2022-07-09 05:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:10:50 --> Total execution time: 0.0617
DEBUG - 2022-07-09 05:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:10:54 --> Total execution time: 0.0620
DEBUG - 2022-07-09 05:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:11:08 --> Total execution time: 0.1467
DEBUG - 2022-07-09 05:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:11:13 --> Total execution time: 0.0841
DEBUG - 2022-07-09 05:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:11:46 --> Total execution time: 0.0509
DEBUG - 2022-07-09 05:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:11:55 --> Total execution time: 0.0630
DEBUG - 2022-07-09 05:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:12:01 --> Total execution time: 0.0778
DEBUG - 2022-07-09 05:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:12:06 --> Total execution time: 0.0858
DEBUG - 2022-07-09 05:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:12:06 --> Total execution time: 0.0579
DEBUG - 2022-07-09 05:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:42:48 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:12:48 --> Total execution time: 0.1391
DEBUG - 2022-07-09 05:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:13:03 --> Total execution time: 0.0775
DEBUG - 2022-07-09 05:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:45:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 05:45:33 --> 404 Page Not Found: Category/lifestyle
DEBUG - 2022-07-09 05:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:46:50 --> Total execution time: 0.0561
DEBUG - 2022-07-09 05:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:46:56 --> Total execution time: 0.0524
DEBUG - 2022-07-09 05:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:46:56 --> Total execution time: 0.1152
DEBUG - 2022-07-09 05:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:47:31 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:17:31 --> Total execution time: 0.0547
DEBUG - 2022-07-09 05:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:23:28 --> Total execution time: 0.0561
DEBUG - 2022-07-09 05:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:23:29 --> Total execution time: 0.0577
DEBUG - 2022-07-09 05:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:23:30 --> Total execution time: 0.0498
DEBUG - 2022-07-09 05:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:54:43 --> No URI present. Default controller set.
DEBUG - 2022-07-09 05:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:24:43 --> Total execution time: 0.0503
DEBUG - 2022-07-09 05:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:24:48 --> Total execution time: 0.0513
DEBUG - 2022-07-09 05:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:25:02 --> Total execution time: 0.0640
DEBUG - 2022-07-09 05:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:25:05 --> Total execution time: 0.0626
DEBUG - 2022-07-09 05:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:25:08 --> Total execution time: 0.0872
DEBUG - 2022-07-09 05:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:55:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 05:55:10 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-09 05:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:55:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 05:55:16 --> 404 Page Not Found: Category/technology
DEBUG - 2022-07-09 05:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:25:19 --> Total execution time: 0.0750
DEBUG - 2022-07-09 05:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:25:22 --> Total execution time: 0.0565
DEBUG - 2022-07-09 05:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:25:25 --> Total execution time: 0.0832
DEBUG - 2022-07-09 05:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:25:28 --> Total execution time: 0.1065
DEBUG - 2022-07-09 05:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:26:13 --> Total execution time: 0.0530
DEBUG - 2022-07-09 05:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:26:22 --> Total execution time: 0.0511
DEBUG - 2022-07-09 05:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 05:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 05:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 05:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:26:30 --> Total execution time: 0.0683
DEBUG - 2022-07-09 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:00:02 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:30:02 --> Total execution time: 0.2911
DEBUG - 2022-07-09 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:30:02 --> Total execution time: 0.1356
DEBUG - 2022-07-09 06:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:30:26 --> Total execution time: 0.1288
DEBUG - 2022-07-09 06:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:30:39 --> Total execution time: 0.0608
DEBUG - 2022-07-09 06:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:30:44 --> Total execution time: 0.0617
DEBUG - 2022-07-09 06:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:30:58 --> Total execution time: 0.0555
DEBUG - 2022-07-09 06:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:30:59 --> Total execution time: 0.0847
DEBUG - 2022-07-09 06:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:01:37 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:31:37 --> Total execution time: 0.0407
DEBUG - 2022-07-09 06:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:02:06 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:32:06 --> Total execution time: 0.0616
DEBUG - 2022-07-09 06:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:32:12 --> Total execution time: 0.1525
DEBUG - 2022-07-09 06:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:02:12 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:32:13 --> Total execution time: 0.0494
DEBUG - 2022-07-09 06:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:02:20 --> Total execution time: 0.0573
DEBUG - 2022-07-09 06:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:02:21 --> Total execution time: 0.0516
DEBUG - 2022-07-09 06:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:02:21 --> Total execution time: 0.1146
DEBUG - 2022-07-09 06:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:03:23 --> Total execution time: 0.0487
DEBUG - 2022-07-09 06:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:03:25 --> Total execution time: 0.0573
DEBUG - 2022-07-09 06:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:03:25 --> Total execution time: 0.1298
DEBUG - 2022-07-09 06:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:04:22 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:34:22 --> Total execution time: 0.0406
DEBUG - 2022-07-09 06:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:34:31 --> Total execution time: 0.0651
DEBUG - 2022-07-09 06:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:34:56 --> Total execution time: 0.0592
DEBUG - 2022-07-09 06:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:35:10 --> Total execution time: 0.1349
DEBUG - 2022-07-09 06:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:12:35 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:42:35 --> Total execution time: 0.2023
DEBUG - 2022-07-09 06:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:12:40 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:42:40 --> Total execution time: 0.0711
DEBUG - 2022-07-09 06:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:42:52 --> Total execution time: 2.0188
DEBUG - 2022-07-09 06:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:12:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 06:12:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 06:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:44:46 --> Total execution time: 0.0442
DEBUG - 2022-07-09 06:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:15:34 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:45:34 --> Total execution time: 0.0526
DEBUG - 2022-07-09 06:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:45:39 --> Total execution time: 1.4478
DEBUG - 2022-07-09 06:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:47:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 06:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:47:02 --> Total execution time: 0.0580
DEBUG - 2022-07-09 06:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:17:50 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:47:50 --> Total execution time: 0.1404
DEBUG - 2022-07-09 06:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:17:56 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:47:56 --> Total execution time: 0.0499
DEBUG - 2022-07-09 06:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:48:20 --> Total execution time: 1.5379
DEBUG - 2022-07-09 06:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:18:23 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:48:23 --> Total execution time: 0.0477
DEBUG - 2022-07-09 06:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:18:39 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:48:39 --> Total execution time: 0.0538
DEBUG - 2022-07-09 06:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:18:43 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:48:43 --> Total execution time: 0.0544
DEBUG - 2022-07-09 06:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:48:51 --> Total execution time: 0.0546
DEBUG - 2022-07-09 06:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:49:21 --> Total execution time: 0.0679
DEBUG - 2022-07-09 06:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:49:27 --> Total execution time: 0.0706
DEBUG - 2022-07-09 06:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:49:33 --> Total execution time: 0.0634
DEBUG - 2022-07-09 06:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:50:35 --> Total execution time: 0.0633
DEBUG - 2022-07-09 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:50:39 --> Total execution time: 0.0746
DEBUG - 2022-07-09 06:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:51:17 --> Total execution time: 0.1557
DEBUG - 2022-07-09 06:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:51:35 --> Total execution time: 0.0596
DEBUG - 2022-07-09 06:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:51:39 --> Total execution time: 0.1378
DEBUG - 2022-07-09 06:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:52:40 --> Total execution time: 0.1507
DEBUG - 2022-07-09 06:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:22:40 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:52:40 --> Total execution time: 0.1715
DEBUG - 2022-07-09 06:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:52:46 --> Total execution time: 0.0566
DEBUG - 2022-07-09 06:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:52:47 --> Total execution time: 0.0566
DEBUG - 2022-07-09 06:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:52:55 --> Total execution time: 0.0570
DEBUG - 2022-07-09 06:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:53:02 --> Total execution time: 0.0652
DEBUG - 2022-07-09 06:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:53:02 --> Total execution time: 0.0528
DEBUG - 2022-07-09 06:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:23:18 --> Total execution time: 0.0567
DEBUG - 2022-07-09 06:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:53:19 --> Total execution time: 0.0607
DEBUG - 2022-07-09 06:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:53:27 --> Total execution time: 0.0674
DEBUG - 2022-07-09 06:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:53:28 --> Total execution time: 0.0578
DEBUG - 2022-07-09 06:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:23:31 --> Total execution time: 0.0777
DEBUG - 2022-07-09 06:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:53:33 --> Total execution time: 0.0729
DEBUG - 2022-07-09 06:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:53:36 --> Total execution time: 0.0558
DEBUG - 2022-07-09 06:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:53:53 --> Total execution time: 0.0845
DEBUG - 2022-07-09 06:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:57:33 --> Total execution time: 0.1204
DEBUG - 2022-07-09 06:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:57:38 --> Total execution time: 0.0704
DEBUG - 2022-07-09 06:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:58:53 --> Total execution time: 0.1630
DEBUG - 2022-07-09 06:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:28:59 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:58:59 --> Total execution time: 0.0445
DEBUG - 2022-07-09 06:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:29:14 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:59:14 --> Total execution time: 0.0431
DEBUG - 2022-07-09 06:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:29:40 --> Total execution time: 0.0571
DEBUG - 2022-07-09 06:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:29:42 --> Total execution time: 0.0658
DEBUG - 2022-07-09 06:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:29:42 --> Total execution time: 0.1284
DEBUG - 2022-07-09 06:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:29:49 --> Total execution time: 0.0514
DEBUG - 2022-07-09 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:29:55 --> Total execution time: 0.0555
DEBUG - 2022-07-09 06:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:32:27 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:02:28 --> Total execution time: 0.1953
DEBUG - 2022-07-09 06:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:02:51 --> Total execution time: 0.0623
DEBUG - 2022-07-09 06:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:33:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 06:33:49 --> 404 Page Not Found: Lessons/ad-account-disable
DEBUG - 2022-07-09 06:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:03:58 --> Total execution time: 0.0557
DEBUG - 2022-07-09 06:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:04:01 --> Total execution time: 0.0493
DEBUG - 2022-07-09 06:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:04:13 --> Total execution time: 0.0517
DEBUG - 2022-07-09 06:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:04:21 --> Total execution time: 0.0524
DEBUG - 2022-07-09 06:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:34:37 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:04:37 --> Total execution time: 0.0616
DEBUG - 2022-07-09 06:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:35:24 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:05:24 --> Total execution time: 0.0685
DEBUG - 2022-07-09 06:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:05:34 --> Total execution time: 0.0592
DEBUG - 2022-07-09 06:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:05:50 --> Total execution time: 0.0688
DEBUG - 2022-07-09 06:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:05:56 --> Total execution time: 0.0572
DEBUG - 2022-07-09 06:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:06:09 --> Total execution time: 0.0594
DEBUG - 2022-07-09 06:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:06:16 --> Total execution time: 0.0789
DEBUG - 2022-07-09 06:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:06:21 --> Total execution time: 0.0548
DEBUG - 2022-07-09 06:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:06:23 --> Total execution time: 0.0571
DEBUG - 2022-07-09 06:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:06:25 --> Total execution time: 0.0868
DEBUG - 2022-07-09 06:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:06:26 --> Total execution time: 0.0775
DEBUG - 2022-07-09 06:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:06:27 --> Total execution time: 0.0799
DEBUG - 2022-07-09 06:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:36:37 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:06:37 --> Total execution time: 0.0364
DEBUG - 2022-07-09 06:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:36:37 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:06:37 --> Total execution time: 0.0395
DEBUG - 2022-07-09 06:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:37:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 06:37:50 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-09 06:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:40:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 06:40:30 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-09 06:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:11:02 --> Total execution time: 0.2062
DEBUG - 2022-07-09 06:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:11:36 --> Total execution time: 0.0555
DEBUG - 2022-07-09 06:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:11:45 --> Total execution time: 0.0604
DEBUG - 2022-07-09 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:41:52 --> Total execution time: 0.0612
DEBUG - 2022-07-09 06:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:12:00 --> Total execution time: 0.0796
DEBUG - 2022-07-09 06:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:42:04 --> Total execution time: 0.0523
DEBUG - 2022-07-09 06:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:42:09 --> Total execution time: 0.0457
DEBUG - 2022-07-09 06:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:42:15 --> Total execution time: 0.0690
DEBUG - 2022-07-09 06:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:42:17 --> Total execution time: 0.0498
DEBUG - 2022-07-09 06:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:42:19 --> Total execution time: 0.0513
DEBUG - 2022-07-09 06:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:12:21 --> Total execution time: 0.0645
DEBUG - 2022-07-09 06:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:12:29 --> Total execution time: 0.0627
DEBUG - 2022-07-09 06:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:12:38 --> Total execution time: 0.0764
DEBUG - 2022-07-09 06:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:42:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 06:42:41 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-09 06:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:12:50 --> Total execution time: 0.0649
DEBUG - 2022-07-09 06:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:17:04 --> Total execution time: 0.1630
DEBUG - 2022-07-09 06:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:19:52 --> Total execution time: 0.0849
DEBUG - 2022-07-09 06:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:50:05 --> Total execution time: 0.0562
DEBUG - 2022-07-09 06:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:20:10 --> Total execution time: 0.0698
DEBUG - 2022-07-09 06:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:20:11 --> Total execution time: 0.0587
DEBUG - 2022-07-09 06:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:20:15 --> Total execution time: 0.0762
DEBUG - 2022-07-09 06:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:20:17 --> Total execution time: 0.0789
DEBUG - 2022-07-09 06:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:20:33 --> Total execution time: 0.1363
DEBUG - 2022-07-09 06:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:20:35 --> Total execution time: 0.0686
DEBUG - 2022-07-09 06:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:20:37 --> Total execution time: 0.0731
DEBUG - 2022-07-09 06:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:50:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 06:50:50 --> 404 Page Not Found: Category/features
DEBUG - 2022-07-09 06:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:21:02 --> Total execution time: 0.0746
DEBUG - 2022-07-09 06:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:21:03 --> Total execution time: 0.0905
DEBUG - 2022-07-09 06:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:23:51 --> Total execution time: 0.0660
DEBUG - 2022-07-09 06:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:24:01 --> Total execution time: 0.0588
DEBUG - 2022-07-09 06:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:54:47 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:24:47 --> Total execution time: 0.0408
DEBUG - 2022-07-09 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:54:48 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:24:48 --> Total execution time: 0.0560
DEBUG - 2022-07-09 06:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:54:50 --> No URI present. Default controller set.
DEBUG - 2022-07-09 06:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:24:50 --> Total execution time: 0.0530
DEBUG - 2022-07-09 06:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 06:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:24:54 --> Total execution time: 0.0509
DEBUG - 2022-07-09 06:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:25:08 --> Total execution time: 0.0789
DEBUG - 2022-07-09 06:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:25:08 --> Total execution time: 0.0797
DEBUG - 2022-07-09 06:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:25:14 --> Total execution time: 0.0692
DEBUG - 2022-07-09 06:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:29:42 --> Total execution time: 0.2532
DEBUG - 2022-07-09 06:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 06:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 06:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:29:44 --> Total execution time: 0.1031
DEBUG - 2022-07-09 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:30:03 --> Total execution time: 0.0862
DEBUG - 2022-07-09 07:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:30:26 --> Total execution time: 0.0708
DEBUG - 2022-07-09 07:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:31:10 --> Total execution time: 0.0384
DEBUG - 2022-07-09 07:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:31:41 --> Total execution time: 0.1340
DEBUG - 2022-07-09 07:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:02:24 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:32:24 --> Total execution time: 0.0424
DEBUG - 2022-07-09 07:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:02:24 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:32:24 --> Total execution time: 0.0309
DEBUG - 2022-07-09 07:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:33:15 --> Total execution time: 0.0583
DEBUG - 2022-07-09 07:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:33:18 --> Total execution time: 0.0590
DEBUG - 2022-07-09 07:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:33:19 --> Total execution time: 0.0988
DEBUG - 2022-07-09 07:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:33:26 --> Total execution time: 0.0599
DEBUG - 2022-07-09 07:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:33:52 --> Total execution time: 0.0910
DEBUG - 2022-07-09 07:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:34:03 --> Total execution time: 0.0510
DEBUG - 2022-07-09 07:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:04:13 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:34:14 --> Total execution time: 0.0587
DEBUG - 2022-07-09 07:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:35:04 --> Total execution time: 0.1720
DEBUG - 2022-07-09 07:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:35:06 --> Total execution time: 0.0909
DEBUG - 2022-07-09 07:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:35:42 --> Total execution time: 0.0897
DEBUG - 2022-07-09 07:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:35:42 --> Total execution time: 0.0761
DEBUG - 2022-07-09 07:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:35:43 --> Total execution time: 0.0687
DEBUG - 2022-07-09 07:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:35:50 --> Total execution time: 0.0827
DEBUG - 2022-07-09 07:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:35:50 --> Total execution time: 0.1733
DEBUG - 2022-07-09 07:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:35:50 --> Total execution time: 0.1227
DEBUG - 2022-07-09 07:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:06:25 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:36:25 --> Total execution time: 0.0431
DEBUG - 2022-07-09 07:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:07:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 07:07:00 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-09 07:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:37:30 --> Total execution time: 0.0637
DEBUG - 2022-07-09 07:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:37:43 --> Total execution time: 0.0552
DEBUG - 2022-07-09 07:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:08:11 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:38:11 --> Total execution time: 0.0611
DEBUG - 2022-07-09 07:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:38:12 --> Total execution time: 0.0658
DEBUG - 2022-07-09 07:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:08:12 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:38:12 --> Total execution time: 0.0493
DEBUG - 2022-07-09 07:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:38:20 --> Total execution time: 0.0813
DEBUG - 2022-07-09 07:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:09:03 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:39:03 --> Total execution time: 0.0778
DEBUG - 2022-07-09 07:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:09:06 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:39:06 --> Total execution time: 0.0687
DEBUG - 2022-07-09 07:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:39:23 --> Total execution time: 0.0511
DEBUG - 2022-07-09 07:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:39:35 --> Total execution time: 0.0599
DEBUG - 2022-07-09 07:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:39:40 --> Total execution time: 0.1133
DEBUG - 2022-07-09 07:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:39:51 --> Total execution time: 0.0667
DEBUG - 2022-07-09 07:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:39:54 --> Total execution time: 0.0755
DEBUG - 2022-07-09 07:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:40:13 --> Total execution time: 0.0927
DEBUG - 2022-07-09 07:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:40:16 --> Total execution time: 0.1257
DEBUG - 2022-07-09 07:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:40:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 17:40:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 17:40:18 --> Total execution time: 0.2295
DEBUG - 2022-07-09 07:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:40:25 --> Total execution time: 0.0580
DEBUG - 2022-07-09 07:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:40:27 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 07:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:40:31 --> Total execution time: 0.0528
DEBUG - 2022-07-09 07:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:40:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 17:40:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 17:40:33 --> Total execution time: 0.2179
DEBUG - 2022-07-09 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:40:37 --> Total execution time: 0.0549
DEBUG - 2022-07-09 07:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:10:46 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:40:46 --> Total execution time: 0.0559
DEBUG - 2022-07-09 07:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:41:08 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 07:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:41:08 --> Total execution time: 0.1065
DEBUG - 2022-07-09 07:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:11:31 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:41:31 --> Total execution time: 0.0559
DEBUG - 2022-07-09 07:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:11:35 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:41:35 --> Total execution time: 0.0564
DEBUG - 2022-07-09 07:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:42:35 --> Total execution time: 0.1555
DEBUG - 2022-07-09 07:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:12:47 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:42:47 --> Total execution time: 0.1327
DEBUG - 2022-07-09 07:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:12:48 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:42:48 --> Total execution time: 0.0674
DEBUG - 2022-07-09 07:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:12:49 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:42:49 --> Total execution time: 0.0555
DEBUG - 2022-07-09 07:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:42:59 --> Total execution time: 0.0845
DEBUG - 2022-07-09 07:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:13:06 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:43:06 --> Total execution time: 0.1311
DEBUG - 2022-07-09 07:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:43:07 --> Total execution time: 0.0750
DEBUG - 2022-07-09 07:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:43:39 --> Total execution time: 0.0517
DEBUG - 2022-07-09 07:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:43:42 --> Total execution time: 0.0618
DEBUG - 2022-07-09 07:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:43:52 --> Total execution time: 0.0597
DEBUG - 2022-07-09 07:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:43:58 --> Total execution time: 0.0552
DEBUG - 2022-07-09 07:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:44:00 --> Total execution time: 0.0531
DEBUG - 2022-07-09 07:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:44:02 --> Total execution time: 0.0483
DEBUG - 2022-07-09 07:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:44:05 --> Total execution time: 0.0521
DEBUG - 2022-07-09 07:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:44:13 --> Total execution time: 0.0608
DEBUG - 2022-07-09 07:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:44:14 --> Total execution time: 0.1230
DEBUG - 2022-07-09 07:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:44:27 --> Total execution time: 0.2039
DEBUG - 2022-07-09 07:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:15:07 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:45:07 --> Total execution time: 0.1303
DEBUG - 2022-07-09 07:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:45:14 --> Total execution time: 0.0459
DEBUG - 2022-07-09 07:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:45:18 --> Total execution time: 0.0676
DEBUG - 2022-07-09 07:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:15:34 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:45:34 --> Total execution time: 0.0887
DEBUG - 2022-07-09 07:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:46:35 --> Total execution time: 0.0666
DEBUG - 2022-07-09 07:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:46:42 --> Total execution time: 0.0796
DEBUG - 2022-07-09 07:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:17:55 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:47:55 --> Total execution time: 0.0386
DEBUG - 2022-07-09 07:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:49:10 --> Total execution time: 0.0499
DEBUG - 2022-07-09 07:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:49:58 --> Total execution time: 0.0609
DEBUG - 2022-07-09 07:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:50:36 --> Total execution time: 0.0831
DEBUG - 2022-07-09 07:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:50:40 --> Total execution time: 0.1005
DEBUG - 2022-07-09 07:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:50:43 --> Total execution time: 0.0475
DEBUG - 2022-07-09 07:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:51:53 --> Total execution time: 0.0470
DEBUG - 2022-07-09 07:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:52:04 --> Total execution time: 0.0512
DEBUG - 2022-07-09 07:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:52:09 --> Total execution time: 0.1005
DEBUG - 2022-07-09 07:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:52:14 --> Total execution time: 0.0745
DEBUG - 2022-07-09 07:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:52:42 --> Total execution time: 0.0780
DEBUG - 2022-07-09 07:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:52:50 --> Total execution time: 0.1570
DEBUG - 2022-07-09 07:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:23:07 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:53:07 --> Total execution time: 0.0594
DEBUG - 2022-07-09 07:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:53:39 --> Total execution time: 0.0559
DEBUG - 2022-07-09 07:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:53:55 --> Total execution time: 0.0763
DEBUG - 2022-07-09 07:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:54:03 --> Total execution time: 0.0736
DEBUG - 2022-07-09 07:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:54:05 --> Total execution time: 0.0731
DEBUG - 2022-07-09 07:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:55:58 --> Total execution time: 0.1570
DEBUG - 2022-07-09 07:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:57:35 --> Total execution time: 0.0537
DEBUG - 2022-07-09 07:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:57:41 --> Total execution time: 0.0751
DEBUG - 2022-07-09 07:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:57:45 --> Total execution time: 0.0607
DEBUG - 2022-07-09 07:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:59:02 --> Total execution time: 0.0525
DEBUG - 2022-07-09 07:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:00:40 --> Total execution time: 0.1357
DEBUG - 2022-07-09 07:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:00:46 --> Total execution time: 0.0560
DEBUG - 2022-07-09 07:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:00:54 --> Total execution time: 0.1017
DEBUG - 2022-07-09 07:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:02:29 --> Total execution time: 0.0659
DEBUG - 2022-07-09 07:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:03:10 --> Total execution time: 0.0455
DEBUG - 2022-07-09 07:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:03:11 --> Total execution time: 0.1270
DEBUG - 2022-07-09 07:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:03:20 --> Total execution time: 0.0531
DEBUG - 2022-07-09 07:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:03:28 --> Total execution time: 0.1527
DEBUG - 2022-07-09 07:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:03:34 --> Total execution time: 0.0835
DEBUG - 2022-07-09 07:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:03:38 --> Total execution time: 0.0707
DEBUG - 2022-07-09 07:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:03:46 --> Total execution time: 0.0766
DEBUG - 2022-07-09 07:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:03:50 --> Total execution time: 0.0689
DEBUG - 2022-07-09 07:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:05:34 --> Total execution time: 0.0574
DEBUG - 2022-07-09 07:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:06:09 --> Total execution time: 0.0590
DEBUG - 2022-07-09 07:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:06:53 --> Total execution time: 0.1245
DEBUG - 2022-07-09 07:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:07:39 --> Total execution time: 0.0388
DEBUG - 2022-07-09 07:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:07:50 --> Total execution time: 0.0549
DEBUG - 2022-07-09 07:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:07:57 --> Total execution time: 0.0525
DEBUG - 2022-07-09 07:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:10:12 --> Total execution time: 0.1569
DEBUG - 2022-07-09 07:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:10:21 --> Total execution time: 0.0583
DEBUG - 2022-07-09 07:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:11:05 --> Total execution time: 0.0613
DEBUG - 2022-07-09 07:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:11:25 --> Total execution time: 0.1309
DEBUG - 2022-07-09 07:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:11:53 --> Total execution time: 0.0622
DEBUG - 2022-07-09 07:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:12:10 --> Total execution time: 0.0711
DEBUG - 2022-07-09 07:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:12:28 --> Total execution time: 0.0561
DEBUG - 2022-07-09 07:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:12:40 --> Total execution time: 0.0610
DEBUG - 2022-07-09 07:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:12:52 --> Total execution time: 0.0580
DEBUG - 2022-07-09 07:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:13:19 --> Total execution time: 0.0632
DEBUG - 2022-07-09 07:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:13:30 --> Total execution time: 0.0810
DEBUG - 2022-07-09 07:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:13:46 --> Total execution time: 0.0606
DEBUG - 2022-07-09 07:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:18:04 --> Total execution time: 0.3207
DEBUG - 2022-07-09 07:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:18:27 --> Total execution time: 0.0659
DEBUG - 2022-07-09 07:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:48:55 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:18:55 --> Total execution time: 0.0575
DEBUG - 2022-07-09 07:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:49:18 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:19:18 --> Total execution time: 0.0403
DEBUG - 2022-07-09 07:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:19:18 --> Total execution time: 0.1001
DEBUG - 2022-07-09 07:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:19:26 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 07:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:19:26 --> Total execution time: 0.0561
DEBUG - 2022-07-09 07:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:49:41 --> Total execution time: 0.0793
DEBUG - 2022-07-09 07:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:49:43 --> Total execution time: 0.0577
DEBUG - 2022-07-09 07:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:49:43 --> Total execution time: 0.0921
DEBUG - 2022-07-09 07:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:19:55 --> Total execution time: 0.0566
DEBUG - 2022-07-09 07:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:20:00 --> Total execution time: 0.0637
DEBUG - 2022-07-09 07:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:20:01 --> Total execution time: 0.0600
DEBUG - 2022-07-09 07:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:50:11 --> Total execution time: 0.0731
DEBUG - 2022-07-09 07:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:50:18 --> Total execution time: 0.0800
DEBUG - 2022-07-09 07:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:20:44 --> Total execution time: 0.0516
DEBUG - 2022-07-09 07:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:20:53 --> Total execution time: 0.0537
DEBUG - 2022-07-09 07:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:20:58 --> Total execution time: 0.0465
DEBUG - 2022-07-09 07:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:21:00 --> Total execution time: 0.0497
DEBUG - 2022-07-09 07:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:21:00 --> Total execution time: 0.0465
DEBUG - 2022-07-09 07:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:21:06 --> Total execution time: 0.0720
DEBUG - 2022-07-09 07:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:21:16 --> Total execution time: 0.0819
DEBUG - 2022-07-09 07:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:21:54 --> Total execution time: 0.0376
DEBUG - 2022-07-09 07:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:21:59 --> Total execution time: 0.0610
DEBUG - 2022-07-09 07:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:22:27 --> Total execution time: 0.0680
DEBUG - 2022-07-09 07:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:22:37 --> Total execution time: 0.0953
DEBUG - 2022-07-09 07:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:22:42 --> Total execution time: 0.0812
DEBUG - 2022-07-09 07:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:53:41 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:23:41 --> Total execution time: 0.0375
DEBUG - 2022-07-09 07:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:23:45 --> Total execution time: 0.0634
DEBUG - 2022-07-09 07:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:24:06 --> Total execution time: 0.0545
DEBUG - 2022-07-09 07:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:24:18 --> Total execution time: 0.1601
DEBUG - 2022-07-09 07:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:24:31 --> Total execution time: 0.0793
DEBUG - 2022-07-09 07:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:24:34 --> Total execution time: 0.0822
DEBUG - 2022-07-09 07:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:54:43 --> Total execution time: 0.0423
DEBUG - 2022-07-09 07:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:55:47 --> Total execution time: 0.0566
DEBUG - 2022-07-09 07:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:55:49 --> Total execution time: 0.0572
DEBUG - 2022-07-09 07:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 07:55:49 --> Total execution time: 0.0534
DEBUG - 2022-07-09 07:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:26:27 --> Total execution time: 0.0378
DEBUG - 2022-07-09 07:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:56:56 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:26:56 --> Total execution time: 0.0462
DEBUG - 2022-07-09 07:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:27:26 --> Total execution time: 0.1632
DEBUG - 2022-07-09 07:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:27:42 --> Total execution time: 0.0615
DEBUG - 2022-07-09 07:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:27:58 --> Total execution time: 0.0549
DEBUG - 2022-07-09 07:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:28:06 --> Total execution time: 0.0955
DEBUG - 2022-07-09 07:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:58:08 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:28:08 --> Total execution time: 0.0536
DEBUG - 2022-07-09 07:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:28:20 --> Total execution time: 0.0686
DEBUG - 2022-07-09 07:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:28:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 07:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:28:40 --> Total execution time: 0.0592
DEBUG - 2022-07-09 07:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:58:58 --> No URI present. Default controller set.
DEBUG - 2022-07-09 07:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:28:58 --> Total execution time: 0.0548
DEBUG - 2022-07-09 07:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 07:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 07:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:29:04 --> Total execution time: 0.0802
DEBUG - 2022-07-09 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:30:02 --> Total execution time: 0.0808
DEBUG - 2022-07-09 08:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:00:14 --> Total execution time: 0.0779
DEBUG - 2022-07-09 08:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:00:20 --> Total execution time: 0.1602
DEBUG - 2022-07-09 08:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:33:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 08:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:33:10 --> Total execution time: 0.0888
DEBUG - 2022-07-09 08:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:04:56 --> Total execution time: 0.0544
DEBUG - 2022-07-09 08:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:05:04 --> Total execution time: 0.0720
DEBUG - 2022-07-09 08:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:36:15 --> Total execution time: 0.0753
DEBUG - 2022-07-09 08:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:36:36 --> Total execution time: 0.0774
DEBUG - 2022-07-09 08:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:36:40 --> Total execution time: 0.0840
DEBUG - 2022-07-09 08:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:36:43 --> Total execution time: 0.0898
DEBUG - 2022-07-09 08:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:36:56 --> Total execution time: 0.0713
DEBUG - 2022-07-09 08:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:37:06 --> Total execution time: 0.1078
DEBUG - 2022-07-09 08:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:37:35 --> Total execution time: 0.0566
DEBUG - 2022-07-09 08:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:37:43 --> Total execution time: 0.1078
DEBUG - 2022-07-09 08:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:37:54 --> Total execution time: 0.0562
DEBUG - 2022-07-09 08:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:38:34 --> Total execution time: 0.1502
DEBUG - 2022-07-09 08:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:08:47 --> Total execution time: 0.0547
DEBUG - 2022-07-09 08:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:09:10 --> Total execution time: 0.0491
DEBUG - 2022-07-09 08:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:09:31 --> Total execution time: 0.0594
DEBUG - 2022-07-09 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:09:38 --> Total execution time: 0.0503
DEBUG - 2022-07-09 08:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:09:41 --> Total execution time: 0.0603
DEBUG - 2022-07-09 08:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:39:44 --> Total execution time: 0.0754
DEBUG - 2022-07-09 08:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:40:49 --> Total execution time: 0.0564
DEBUG - 2022-07-09 08:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:41:06 --> Total execution time: 0.0798
DEBUG - 2022-07-09 08:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:41:28 --> Total execution time: 0.0555
DEBUG - 2022-07-09 08:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:41:32 --> Total execution time: 0.0592
DEBUG - 2022-07-09 08:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:41:44 --> Total execution time: 0.0611
DEBUG - 2022-07-09 08:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:41:54 --> Total execution time: 0.0522
DEBUG - 2022-07-09 08:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:43:17 --> Total execution time: 0.0546
DEBUG - 2022-07-09 08:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:43:37 --> Total execution time: 0.0507
DEBUG - 2022-07-09 08:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:43:53 --> Total execution time: 0.0486
DEBUG - 2022-07-09 08:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:43:57 --> Total execution time: 0.0492
DEBUG - 2022-07-09 08:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:44:05 --> Total execution time: 0.0505
DEBUG - 2022-07-09 08:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:44:14 --> Total execution time: 0.0444
DEBUG - 2022-07-09 08:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:45:07 --> Total execution time: 0.1310
DEBUG - 2022-07-09 08:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:15:24 --> No URI present. Default controller set.
DEBUG - 2022-07-09 08:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:45:24 --> Total execution time: 0.0401
DEBUG - 2022-07-09 08:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:16:05 --> Total execution time: 0.0410
DEBUG - 2022-07-09 08:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:16:06 --> Total execution time: 0.0653
DEBUG - 2022-07-09 08:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:16:06 --> Total execution time: 0.1072
DEBUG - 2022-07-09 08:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:16:15 --> No URI present. Default controller set.
DEBUG - 2022-07-09 08:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:46:15 --> Total execution time: 0.0377
DEBUG - 2022-07-09 08:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:16:17 --> No URI present. Default controller set.
DEBUG - 2022-07-09 08:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:46:17 --> Total execution time: 0.0523
DEBUG - 2022-07-09 08:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:46:31 --> Total execution time: 0.0708
DEBUG - 2022-07-09 08:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:16:40 --> No URI present. Default controller set.
DEBUG - 2022-07-09 08:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:46:40 --> Total execution time: 0.0552
DEBUG - 2022-07-09 08:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:18:32 --> No URI present. Default controller set.
DEBUG - 2022-07-09 08:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:48:32 --> Total execution time: 0.0379
DEBUG - 2022-07-09 08:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:18:35 --> No URI present. Default controller set.
DEBUG - 2022-07-09 08:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:48:35 --> Total execution time: 0.0371
DEBUG - 2022-07-09 08:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:19:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 08:19:35 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-09 08:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:50:30 --> Total execution time: 0.1449
DEBUG - 2022-07-09 08:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:50:36 --> Total execution time: 0.0574
DEBUG - 2022-07-09 08:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:50:59 --> Total execution time: 0.0727
DEBUG - 2022-07-09 08:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:22:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 08:22:14 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-09 08:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:23:13 --> No URI present. Default controller set.
DEBUG - 2022-07-09 08:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:53:13 --> Total execution time: 0.0409
DEBUG - 2022-07-09 08:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:23:17 --> No URI present. Default controller set.
DEBUG - 2022-07-09 08:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:53:17 --> Total execution time: 0.0528
DEBUG - 2022-07-09 08:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:53:27 --> Total execution time: 0.0413
DEBUG - 2022-07-09 08:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:53:39 --> Total execution time: 0.1327
DEBUG - 2022-07-09 08:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:53:56 --> Total execution time: 0.0900
DEBUG - 2022-07-09 08:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:54:10 --> Total execution time: 0.0593
DEBUG - 2022-07-09 08:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:54:10 --> Total execution time: 0.0675
DEBUG - 2022-07-09 08:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:54:13 --> Total execution time: 0.0741
DEBUG - 2022-07-09 08:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:54:16 --> Total execution time: 0.0635
DEBUG - 2022-07-09 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:54:18 --> Total execution time: 0.1046
DEBUG - 2022-07-09 08:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:54:22 --> Total execution time: 0.0565
DEBUG - 2022-07-09 08:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:24:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 08:24:24 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-09 08:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:54:25 --> Total execution time: 0.0991
DEBUG - 2022-07-09 08:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:54:40 --> Total execution time: 0.0571
DEBUG - 2022-07-09 08:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:54:43 --> Total execution time: 0.0721
DEBUG - 2022-07-09 08:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:54:46 --> Total execution time: 0.0576
DEBUG - 2022-07-09 08:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:54:49 --> Total execution time: 0.0527
DEBUG - 2022-07-09 08:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:54:52 --> Total execution time: 0.0590
DEBUG - 2022-07-09 08:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:24:57 --> No URI present. Default controller set.
DEBUG - 2022-07-09 08:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:54:57 --> Total execution time: 0.1271
DEBUG - 2022-07-09 08:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:25:18 --> No URI present. Default controller set.
DEBUG - 2022-07-09 08:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:55:18 --> Total execution time: 0.0788
DEBUG - 2022-07-09 08:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:55:37 --> Total execution time: 0.1548
DEBUG - 2022-07-09 08:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:55:46 --> Total execution time: 0.0619
DEBUG - 2022-07-09 08:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:55:49 --> Total execution time: 0.0796
DEBUG - 2022-07-09 08:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:56:03 --> Total execution time: 0.0787
DEBUG - 2022-07-09 08:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:56:09 --> Total execution time: 0.0541
DEBUG - 2022-07-09 08:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:56:13 --> Total execution time: 0.0608
DEBUG - 2022-07-09 08:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:56:23 --> Total execution time: 0.0776
DEBUG - 2022-07-09 08:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:56:44 --> Total execution time: 0.0532
DEBUG - 2022-07-09 08:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:56:45 --> Total execution time: 0.0550
DEBUG - 2022-07-09 08:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:56:49 --> Total execution time: 0.0625
DEBUG - 2022-07-09 08:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:56:51 --> Total execution time: 0.0710
DEBUG - 2022-07-09 08:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:56:58 --> Total execution time: 0.0714
DEBUG - 2022-07-09 08:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:57:01 --> Total execution time: 0.0612
DEBUG - 2022-07-09 08:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:57:03 --> Total execution time: 0.0584
DEBUG - 2022-07-09 08:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:57:06 --> Total execution time: 0.0547
DEBUG - 2022-07-09 08:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:57:08 --> Total execution time: 0.0699
DEBUG - 2022-07-09 08:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:57:10 --> Total execution time: 0.0716
DEBUG - 2022-07-09 08:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:57:13 --> Total execution time: 0.0531
DEBUG - 2022-07-09 08:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:57:19 --> Total execution time: 0.1369
DEBUG - 2022-07-09 08:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:00:34 --> Total execution time: 0.2181
DEBUG - 2022-07-09 08:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:00:45 --> Total execution time: 0.0617
DEBUG - 2022-07-09 08:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:00:56 --> Total execution time: 0.0813
DEBUG - 2022-07-09 08:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:01:06 --> Total execution time: 0.0529
DEBUG - 2022-07-09 08:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:01:17 --> Total execution time: 0.0610
DEBUG - 2022-07-09 08:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:01:19 --> Total execution time: 0.0621
DEBUG - 2022-07-09 08:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:01:36 --> Total execution time: 0.1020
DEBUG - 2022-07-09 08:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:02:18 --> Total execution time: 0.0574
DEBUG - 2022-07-09 08:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:02:26 --> Total execution time: 0.0944
DEBUG - 2022-07-09 08:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:08:15 --> Total execution time: 0.1297
DEBUG - 2022-07-09 08:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:08:18 --> Total execution time: 0.1311
DEBUG - 2022-07-09 08:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:08:26 --> Total execution time: 0.0571
DEBUG - 2022-07-09 08:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:08:35 --> Total execution time: 0.0546
DEBUG - 2022-07-09 08:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:08:36 --> Total execution time: 0.0643
DEBUG - 2022-07-09 08:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:08:38 --> Total execution time: 0.0588
DEBUG - 2022-07-09 08:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:38:46 --> Total execution time: 0.0601
DEBUG - 2022-07-09 08:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:08:46 --> Total execution time: 0.0562
DEBUG - 2022-07-09 08:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:08:50 --> Total execution time: 0.0699
DEBUG - 2022-07-09 08:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:08:59 --> Total execution time: 0.0621
DEBUG - 2022-07-09 08:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:09:13 --> Total execution time: 0.0548
DEBUG - 2022-07-09 08:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:09:16 --> Total execution time: 0.0611
DEBUG - 2022-07-09 08:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:39:17 --> Total execution time: 0.1085
DEBUG - 2022-07-09 08:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:09:25 --> Total execution time: 0.0599
DEBUG - 2022-07-09 08:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:39:38 --> Total execution time: 0.0530
DEBUG - 2022-07-09 08:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:09:43 --> Total execution time: 0.0544
DEBUG - 2022-07-09 08:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:40:14 --> No URI present. Default controller set.
DEBUG - 2022-07-09 08:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:10:14 --> Total execution time: 0.0472
DEBUG - 2022-07-09 08:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:40:16 --> No URI present. Default controller set.
DEBUG - 2022-07-09 08:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:10:16 --> Total execution time: 0.0520
DEBUG - 2022-07-09 08:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:10:20 --> Total execution time: 0.1278
DEBUG - 2022-07-09 08:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:10:28 --> Total execution time: 0.0687
DEBUG - 2022-07-09 08:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:10:31 --> Total execution time: 0.0887
DEBUG - 2022-07-09 08:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:10:32 --> Total execution time: 0.0626
DEBUG - 2022-07-09 08:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:10:53 --> Total execution time: 0.0650
DEBUG - 2022-07-09 08:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:11:10 --> Total execution time: 0.0585
DEBUG - 2022-07-09 08:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:11:14 --> Total execution time: 0.0458
DEBUG - 2022-07-09 08:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:11:15 --> Total execution time: 0.0970
DEBUG - 2022-07-09 08:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:11:22 --> Total execution time: 0.0733
DEBUG - 2022-07-09 08:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:11:27 --> Total execution time: 0.0582
DEBUG - 2022-07-09 08:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:41:33 --> Total execution time: 0.0532
DEBUG - 2022-07-09 08:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:11:37 --> Total execution time: 0.0585
DEBUG - 2022-07-09 08:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:11:41 --> Total execution time: 0.0614
DEBUG - 2022-07-09 08:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:12:24 --> Total execution time: 0.0555
DEBUG - 2022-07-09 08:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:13:10 --> Total execution time: 0.0381
DEBUG - 2022-07-09 08:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:13:42 --> Total execution time: 0.0721
DEBUG - 2022-07-09 08:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:13:54 --> Total execution time: 0.0536
DEBUG - 2022-07-09 08:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:14:00 --> Total execution time: 0.0579
DEBUG - 2022-07-09 08:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:44:07 --> Total execution time: 0.0583
DEBUG - 2022-07-09 08:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:44:12 --> Total execution time: 0.0535
DEBUG - 2022-07-09 08:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:44:22 --> Total execution time: 0.0526
DEBUG - 2022-07-09 08:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:44:45 --> Total execution time: 0.0483
DEBUG - 2022-07-09 08:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:45:11 --> Total execution time: 0.0556
DEBUG - 2022-07-09 08:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:15:45 --> Total execution time: 0.0393
DEBUG - 2022-07-09 08:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:15:47 --> Total execution time: 0.0584
DEBUG - 2022-07-09 08:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:15:56 --> Total execution time: 0.0492
DEBUG - 2022-07-09 08:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:15:58 --> Total execution time: 0.0608
DEBUG - 2022-07-09 08:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:16:03 --> Total execution time: 0.0777
DEBUG - 2022-07-09 08:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:16:17 --> Total execution time: 0.0511
DEBUG - 2022-07-09 08:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:16:23 --> Total execution time: 0.2338
DEBUG - 2022-07-09 08:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:16:30 --> Total execution time: 0.1239
DEBUG - 2022-07-09 08:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:16:39 --> Total execution time: 0.0638
DEBUG - 2022-07-09 08:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:16:52 --> Total execution time: 0.0869
DEBUG - 2022-07-09 08:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:17:03 --> Total execution time: 0.0551
DEBUG - 2022-07-09 08:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:17:12 --> Total execution time: 0.0509
DEBUG - 2022-07-09 08:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:17:13 --> Total execution time: 0.0580
DEBUG - 2022-07-09 08:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:17:28 --> Total execution time: 0.0622
DEBUG - 2022-07-09 08:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:17:51 --> Total execution time: 0.0501
DEBUG - 2022-07-09 08:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:18:13 --> Total execution time: 0.0528
DEBUG - 2022-07-09 08:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:48:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 08:48:28 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-09 08:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:20:07 --> Total execution time: 0.0391
DEBUG - 2022-07-09 08:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:20:08 --> Total execution time: 0.0522
DEBUG - 2022-07-09 08:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:21:32 --> Total execution time: 0.1023
DEBUG - 2022-07-09 08:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:21:47 --> Total execution time: 0.0499
DEBUG - 2022-07-09 08:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:21:47 --> Total execution time: 0.0523
DEBUG - 2022-07-09 08:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:22:59 --> Total execution time: 0.0361
DEBUG - 2022-07-09 08:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:53:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 08:53:09 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-09 08:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:53:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 08:53:09 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-09 08:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:53:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 08:53:09 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-09 08:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:53:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 08:53:09 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-09 08:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:55:18 --> No URI present. Default controller set.
DEBUG - 2022-07-09 08:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:25:18 --> Total execution time: 0.1095
DEBUG - 2022-07-09 08:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:25:29 --> Total execution time: 0.0563
DEBUG - 2022-07-09 08:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:55:48 --> No URI present. Default controller set.
DEBUG - 2022-07-09 08:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:25:48 --> Total execution time: 0.0389
DEBUG - 2022-07-09 08:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:26:02 --> Total execution time: 0.0780
DEBUG - 2022-07-09 08:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:26:06 --> Total execution time: 0.0709
DEBUG - 2022-07-09 08:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:26:23 --> Total execution time: 0.0929
DEBUG - 2022-07-09 08:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:26:39 --> Total execution time: 0.0940
DEBUG - 2022-07-09 08:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 08:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:26:48 --> Total execution time: 0.1039
DEBUG - 2022-07-09 08:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:27:03 --> Total execution time: 0.0630
DEBUG - 2022-07-09 08:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:27:12 --> Total execution time: 0.0847
DEBUG - 2022-07-09 08:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:27:55 --> Total execution time: 0.0753
DEBUG - 2022-07-09 08:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 08:58:43 --> No URI present. Default controller set.
DEBUG - 2022-07-09 08:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 08:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:28:43 --> Total execution time: 0.0563
DEBUG - 2022-07-09 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:30:02 --> Total execution time: 0.0972
DEBUG - 2022-07-09 09:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:30:09 --> Total execution time: 0.1755
DEBUG - 2022-07-09 09:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:30:44 --> Total execution time: 0.1363
DEBUG - 2022-07-09 09:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:30:58 --> Total execution time: 0.0718
DEBUG - 2022-07-09 09:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:01:08 --> Total execution time: 0.0514
DEBUG - 2022-07-09 09:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:01:22 --> Total execution time: 0.0499
DEBUG - 2022-07-09 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:31:27 --> Total execution time: 0.1452
DEBUG - 2022-07-09 09:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:01:36 --> Total execution time: 0.0593
DEBUG - 2022-07-09 09:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:01:39 --> Total execution time: 0.0498
DEBUG - 2022-07-09 09:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:01:41 --> Total execution time: 0.0540
DEBUG - 2022-07-09 09:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:31:45 --> Total execution time: 0.0797
DEBUG - 2022-07-09 09:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:33:02 --> Total execution time: 0.0734
DEBUG - 2022-07-09 09:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:04:07 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:34:08 --> Total execution time: 0.1295
DEBUG - 2022-07-09 09:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:04:08 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:34:08 --> Total execution time: 0.0655
DEBUG - 2022-07-09 09:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:34:13 --> Total execution time: 0.1205
DEBUG - 2022-07-09 09:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:34:18 --> Total execution time: 0.0640
DEBUG - 2022-07-09 09:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:34:36 --> Total execution time: 0.0707
DEBUG - 2022-07-09 09:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:34:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 09:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:34:37 --> Total execution time: 0.0525
DEBUG - 2022-07-09 09:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:35:01 --> Total execution time: 0.0560
DEBUG - 2022-07-09 09:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:05:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 09:05:21 --> 404 Page Not Found: My-account/index
DEBUG - 2022-07-09 09:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:05:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 09:05:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 09:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:05:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 09:05:28 --> 404 Page Not Found: My-account/index
DEBUG - 2022-07-09 09:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:37:10 --> Total execution time: 0.0577
DEBUG - 2022-07-09 09:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:07:38 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:37:38 --> Total execution time: 0.0502
DEBUG - 2022-07-09 09:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:10:21 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:40:21 --> Total execution time: 0.1109
DEBUG - 2022-07-09 09:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:10:22 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:40:22 --> Total execution time: 0.0434
DEBUG - 2022-07-09 09:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:40:30 --> Total execution time: 0.1361
DEBUG - 2022-07-09 09:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:10:33 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:40:33 --> Total execution time: 0.0727
DEBUG - 2022-07-09 09:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:11:17 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:41:17 --> Total execution time: 0.0408
DEBUG - 2022-07-09 09:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:11:25 --> Total execution time: 0.0539
DEBUG - 2022-07-09 09:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:11:27 --> Total execution time: 0.0612
DEBUG - 2022-07-09 09:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:11:27 --> Total execution time: 0.1212
DEBUG - 2022-07-09 09:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:12:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 09:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:42:30 --> Total execution time: 1.9184
DEBUG - 2022-07-09 09:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:12:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 09:12:33 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 09:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:43:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 09:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:43:06 --> Total execution time: 0.0596
DEBUG - 2022-07-09 09:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:43:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 19:43:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 19:43:07 --> Total execution time: 0.2106
DEBUG - 2022-07-09 09:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:43:16 --> Total execution time: 0.0669
DEBUG - 2022-07-09 09:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:43:27 --> Total execution time: 0.0641
DEBUG - 2022-07-09 09:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:43:32 --> Total execution time: 0.0826
DEBUG - 2022-07-09 09:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:43:48 --> Total execution time: 0.0446
DEBUG - 2022-07-09 09:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:43:50 --> Total execution time: 0.0432
DEBUG - 2022-07-09 09:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:44:04 --> Total execution time: 0.0556
DEBUG - 2022-07-09 09:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:44:10 --> Total execution time: 0.0840
DEBUG - 2022-07-09 09:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:14:11 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:44:11 --> Total execution time: 0.0367
DEBUG - 2022-07-09 09:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:44:17 --> Total execution time: 0.0503
DEBUG - 2022-07-09 09:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:44:26 --> Total execution time: 0.0538
DEBUG - 2022-07-09 09:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:15:18 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:45:18 --> Total execution time: 0.0379
DEBUG - 2022-07-09 09:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:45:27 --> Total execution time: 0.0370
DEBUG - 2022-07-09 09:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:45:34 --> Total execution time: 0.0578
DEBUG - 2022-07-09 09:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:15:35 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:45:35 --> Total execution time: 0.0790
DEBUG - 2022-07-09 09:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:45:37 --> Total execution time: 0.0513
DEBUG - 2022-07-09 09:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:45:46 --> Total execution time: 0.0506
DEBUG - 2022-07-09 09:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:15:49 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:45:49 --> Total execution time: 0.1293
DEBUG - 2022-07-09 09:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:45:50 --> Total execution time: 0.1456
DEBUG - 2022-07-09 09:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:15:50 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:45:50 --> Total execution time: 0.0799
DEBUG - 2022-07-09 09:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:45:50 --> Total execution time: 0.0604
DEBUG - 2022-07-09 09:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:45:53 --> Total execution time: 0.0503
DEBUG - 2022-07-09 09:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:45:54 --> Total execution time: 0.0585
DEBUG - 2022-07-09 09:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:45:58 --> Total execution time: 0.0502
DEBUG - 2022-07-09 09:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:46:01 --> Total execution time: 0.0519
DEBUG - 2022-07-09 09:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:46:10 --> Total execution time: 0.0815
DEBUG - 2022-07-09 09:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:46:12 --> Total execution time: 0.0600
DEBUG - 2022-07-09 09:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:46:23 --> Total execution time: 0.1397
DEBUG - 2022-07-09 09:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:46:26 --> Total execution time: 0.0341
DEBUG - 2022-07-09 09:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:46:30 --> Total execution time: 0.0826
DEBUG - 2022-07-09 09:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:46:36 --> Total execution time: 0.0568
DEBUG - 2022-07-09 09:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:46:41 --> Total execution time: 0.0641
DEBUG - 2022-07-09 09:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:46:43 --> Total execution time: 0.0622
DEBUG - 2022-07-09 09:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:46:46 --> Total execution time: 0.0808
DEBUG - 2022-07-09 09:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:46:50 --> Total execution time: 0.0572
DEBUG - 2022-07-09 09:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:46:53 --> Total execution time: 0.1347
DEBUG - 2022-07-09 09:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:46:54 --> Total execution time: 0.1081
DEBUG - 2022-07-09 09:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:46:54 --> Total execution time: 0.0502
DEBUG - 2022-07-09 09:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:47:20 --> Total execution time: 0.0525
DEBUG - 2022-07-09 09:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:47:22 --> Total execution time: 0.0626
DEBUG - 2022-07-09 09:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:17:35 --> Total execution time: 0.0520
DEBUG - 2022-07-09 09:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:17:50 --> Total execution time: 0.0640
DEBUG - 2022-07-09 09:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:48:10 --> Total execution time: 0.0657
DEBUG - 2022-07-09 09:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:48:24 --> Total execution time: 0.0777
DEBUG - 2022-07-09 09:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:48:28 --> Total execution time: 0.0778
DEBUG - 2022-07-09 09:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:48:38 --> Total execution time: 0.0585
DEBUG - 2022-07-09 09:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:49:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 09:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:49:05 --> Total execution time: 0.0768
DEBUG - 2022-07-09 09:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:50:01 --> Total execution time: 0.0608
DEBUG - 2022-07-09 09:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:50:06 --> Total execution time: 0.0716
DEBUG - 2022-07-09 09:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:50:13 --> Total execution time: 0.0823
DEBUG - 2022-07-09 09:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:50:19 --> Total execution time: 0.0746
DEBUG - 2022-07-09 09:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:50:21 --> Total execution time: 0.0718
DEBUG - 2022-07-09 09:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:50:21 --> Total execution time: 0.0717
DEBUG - 2022-07-09 09:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:20:28 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:50:29 --> Total execution time: 0.0401
DEBUG - 2022-07-09 09:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:20:46 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:50:47 --> Total execution time: 0.0362
DEBUG - 2022-07-09 09:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:50:53 --> Total execution time: 0.1485
DEBUG - 2022-07-09 09:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:50:55 --> Total execution time: 0.0873
DEBUG - 2022-07-09 09:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:51:01 --> Total execution time: 0.0900
DEBUG - 2022-07-09 09:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:51:09 --> Total execution time: 0.0510
DEBUG - 2022-07-09 09:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:51:17 --> Total execution time: 0.0586
DEBUG - 2022-07-09 09:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:51:30 --> Total execution time: 0.0604
DEBUG - 2022-07-09 09:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:51:33 --> Total execution time: 0.0703
DEBUG - 2022-07-09 09:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:51:50 --> Total execution time: 0.0561
DEBUG - 2022-07-09 09:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:51:52 --> Total execution time: 0.0963
DEBUG - 2022-07-09 09:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:51:55 --> Total execution time: 0.0830
DEBUG - 2022-07-09 09:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:51:58 --> Total execution time: 0.0772
DEBUG - 2022-07-09 09:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:52:06 --> Total execution time: 0.0542
DEBUG - 2022-07-09 09:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:52:14 --> Total execution time: 0.0546
DEBUG - 2022-07-09 09:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:25:30 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:55:30 --> Total execution time: 0.1195
DEBUG - 2022-07-09 09:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:55:33 --> Total execution time: 0.0408
DEBUG - 2022-07-09 09:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:55:57 --> Total execution time: 0.0555
DEBUG - 2022-07-09 09:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:56:00 --> Total execution time: 0.0572
DEBUG - 2022-07-09 09:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:56:08 --> Total execution time: 0.0623
DEBUG - 2022-07-09 09:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:56:19 --> Total execution time: 0.0549
DEBUG - 2022-07-09 09:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:57:13 --> Total execution time: 0.1500
DEBUG - 2022-07-09 09:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:57:29 --> Total execution time: 0.0547
DEBUG - 2022-07-09 09:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:28:14 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:58:14 --> Total execution time: 0.0381
DEBUG - 2022-07-09 09:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:58:20 --> Total execution time: 0.0513
DEBUG - 2022-07-09 09:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:58:26 --> Total execution time: 0.0563
DEBUG - 2022-07-09 09:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:58:33 --> Total execution time: 0.0797
DEBUG - 2022-07-09 09:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:59:12 --> Total execution time: 0.0605
DEBUG - 2022-07-09 09:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:59:16 --> Total execution time: 0.0528
DEBUG - 2022-07-09 09:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:59:21 --> Total execution time: 0.0560
DEBUG - 2022-07-09 09:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:59:28 --> Total execution time: 0.0537
DEBUG - 2022-07-09 09:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:00:21 --> Total execution time: 0.1186
DEBUG - 2022-07-09 09:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:30:42 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:00:42 --> Total execution time: 0.1289
DEBUG - 2022-07-09 09:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:30:55 --> Total execution time: 0.0554
DEBUG - 2022-07-09 09:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:30:58 --> Total execution time: 0.0571
DEBUG - 2022-07-09 09:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:30:58 --> Total execution time: 0.1013
DEBUG - 2022-07-09 09:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:00:59 --> Total execution time: 0.0752
DEBUG - 2022-07-09 09:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:01:02 --> Total execution time: 0.0562
DEBUG - 2022-07-09 09:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:01:09 --> Total execution time: 0.0560
DEBUG - 2022-07-09 09:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:31:11 --> Total execution time: 0.0509
DEBUG - 2022-07-09 09:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:31:13 --> Total execution time: 0.0793
DEBUG - 2022-07-09 09:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:31:13 --> Total execution time: 0.0989
DEBUG - 2022-07-09 09:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:01:17 --> Total execution time: 0.0546
DEBUG - 2022-07-09 09:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:01:26 --> Total execution time: 0.0739
DEBUG - 2022-07-09 09:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:01:54 --> Total execution time: 0.0543
DEBUG - 2022-07-09 09:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:32:03 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:02:04 --> Total execution time: 0.0406
DEBUG - 2022-07-09 09:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:02:22 --> Total execution time: 0.0550
DEBUG - 2022-07-09 09:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:02:35 --> Total execution time: 0.0559
DEBUG - 2022-07-09 09:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:32:36 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:02:36 --> Total execution time: 0.0615
DEBUG - 2022-07-09 09:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:02:38 --> Total execution time: 0.0351
DEBUG - 2022-07-09 09:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:02:46 --> Total execution time: 0.0552
DEBUG - 2022-07-09 09:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:02:59 --> Total execution time: 0.0778
DEBUG - 2022-07-09 09:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:03:01 --> Total execution time: 0.0703
DEBUG - 2022-07-09 09:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:03:06 --> Total execution time: 0.0629
DEBUG - 2022-07-09 09:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:33:11 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:03:11 --> Total execution time: 0.0549
DEBUG - 2022-07-09 09:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:03:12 --> Total execution time: 0.0623
DEBUG - 2022-07-09 09:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:03:20 --> Total execution time: 0.0685
DEBUG - 2022-07-09 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:03:28 --> Total execution time: 0.0868
DEBUG - 2022-07-09 09:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:03:43 --> Total execution time: 0.0598
DEBUG - 2022-07-09 09:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:03:48 --> Total execution time: 0.0543
DEBUG - 2022-07-09 09:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:33:56 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:03:56 --> Total execution time: 0.0620
DEBUG - 2022-07-09 09:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:34:25 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:04:26 --> Total execution time: 0.0523
DEBUG - 2022-07-09 09:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:35:28 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:05:28 --> Total execution time: 0.0399
DEBUG - 2022-07-09 09:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:37:18 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:07:18 --> Total execution time: 0.0591
DEBUG - 2022-07-09 09:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:07:31 --> Total execution time: 0.0534
DEBUG - 2022-07-09 09:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:07:39 --> Total execution time: 0.0540
DEBUG - 2022-07-09 09:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:07:46 --> Total execution time: 0.0571
DEBUG - 2022-07-09 09:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:08:07 --> Total execution time: 0.0744
DEBUG - 2022-07-09 09:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:10:39 --> Total execution time: 0.0682
DEBUG - 2022-07-09 09:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:10:48 --> Total execution time: 0.0559
DEBUG - 2022-07-09 09:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:11:33 --> Total execution time: 0.0536
DEBUG - 2022-07-09 09:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:11:33 --> Total execution time: 0.0559
DEBUG - 2022-07-09 09:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:11:58 --> Total execution time: 0.0612
DEBUG - 2022-07-09 09:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:42:18 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:12:18 --> Total execution time: 0.0400
DEBUG - 2022-07-09 09:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:12:35 --> Total execution time: 0.0659
DEBUG - 2022-07-09 09:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:13:20 --> Total execution time: 0.0614
DEBUG - 2022-07-09 09:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:13:58 --> Total execution time: 0.0544
DEBUG - 2022-07-09 09:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:14:22 --> Total execution time: 0.0528
DEBUG - 2022-07-09 09:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:15:17 --> Total execution time: 0.0568
DEBUG - 2022-07-09 09:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:15:54 --> Total execution time: 0.0554
DEBUG - 2022-07-09 09:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:16:08 --> Total execution time: 0.0795
DEBUG - 2022-07-09 09:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:16:15 --> Total execution time: 0.0583
DEBUG - 2022-07-09 09:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:46:47 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:16:47 --> Total execution time: 0.1261
DEBUG - 2022-07-09 09:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:16:49 --> Total execution time: 0.0581
DEBUG - 2022-07-09 09:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:47:02 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:17:02 --> Total execution time: 0.1305
DEBUG - 2022-07-09 09:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:17:04 --> Total execution time: 0.0665
DEBUG - 2022-07-09 09:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:17:25 --> Total execution time: 0.0587
DEBUG - 2022-07-09 09:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:17:45 --> Total execution time: 0.0599
DEBUG - 2022-07-09 09:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:47:51 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:17:51 --> Total execution time: 0.1362
DEBUG - 2022-07-09 09:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:18:57 --> Total execution time: 0.0472
DEBUG - 2022-07-09 09:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:19:11 --> Total execution time: 0.0714
DEBUG - 2022-07-09 09:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:19:21 --> Total execution time: 0.0723
DEBUG - 2022-07-09 09:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:19:28 --> Total execution time: 0.1005
DEBUG - 2022-07-09 09:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:49:41 --> Total execution time: 0.0649
DEBUG - 2022-07-09 09:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:19:42 --> Total execution time: 0.0582
DEBUG - 2022-07-09 09:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:49:43 --> Total execution time: 0.0575
DEBUG - 2022-07-09 09:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:49:43 --> Total execution time: 0.0841
DEBUG - 2022-07-09 09:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:20:31 --> Total execution time: 0.0707
DEBUG - 2022-07-09 09:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:21:07 --> Total execution time: 0.1365
DEBUG - 2022-07-09 09:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:51:40 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:21:41 --> Total execution time: 0.0785
DEBUG - 2022-07-09 09:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:51:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 09:51:52 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-09 09:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:51:53 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:21:53 --> Total execution time: 0.0354
DEBUG - 2022-07-09 09:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:51:56 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:21:56 --> Total execution time: 0.0587
DEBUG - 2022-07-09 09:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:52:04 --> Total execution time: 0.0796
DEBUG - 2022-07-09 09:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:52:07 --> Total execution time: 0.0569
DEBUG - 2022-07-09 09:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:52:07 --> Total execution time: 0.1029
DEBUG - 2022-07-09 09:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:52:12 --> Total execution time: 0.1366
DEBUG - 2022-07-09 09:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:52:14 --> Total execution time: 0.0565
DEBUG - 2022-07-09 09:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:52:14 --> Total execution time: 0.0788
DEBUG - 2022-07-09 09:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:52:15 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:22:15 --> Total execution time: 0.0401
DEBUG - 2022-07-09 09:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:53:07 --> Total execution time: 0.0545
DEBUG - 2022-07-09 09:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:53:16 --> Total execution time: 0.0829
DEBUG - 2022-07-09 09:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:53:51 --> No URI present. Default controller set.
DEBUG - 2022-07-09 09:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:23:51 --> Total execution time: 0.0456
DEBUG - 2022-07-09 09:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:24:26 --> Total execution time: 0.0806
DEBUG - 2022-07-09 09:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:25:09 --> Total execution time: 0.0860
DEBUG - 2022-07-09 09:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:25:20 --> Total execution time: 0.0534
DEBUG - 2022-07-09 09:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:25:31 --> Total execution time: 0.0446
DEBUG - 2022-07-09 09:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:26:51 --> Total execution time: 0.0546
DEBUG - 2022-07-09 09:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 09:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:27:03 --> Total execution time: 0.0523
DEBUG - 2022-07-09 09:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:27:14 --> Total execution time: 0.0672
DEBUG - 2022-07-09 09:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:28:05 --> Total execution time: 0.0870
DEBUG - 2022-07-09 09:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:28:18 --> Total execution time: 0.0343
DEBUG - 2022-07-09 09:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:28:35 --> Total execution time: 0.0604
DEBUG - 2022-07-09 09:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:28:41 --> Total execution time: 0.0740
DEBUG - 2022-07-09 09:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 09:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 09:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:29:08 --> Total execution time: 0.0646
DEBUG - 2022-07-09 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:30:02 --> Total execution time: 0.0499
DEBUG - 2022-07-09 10:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:30:18 --> Total execution time: 0.0760
DEBUG - 2022-07-09 10:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:30:28 --> Total execution time: 0.0693
DEBUG - 2022-07-09 10:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:30:31 --> Total execution time: 0.0649
DEBUG - 2022-07-09 10:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:01:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 10:01:02 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-09 10:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:02:56 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:32:56 --> Total execution time: 0.1084
DEBUG - 2022-07-09 10:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:02:57 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:32:57 --> Total execution time: 0.0803
DEBUG - 2022-07-09 10:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:33:05 --> Total execution time: 0.0561
DEBUG - 2022-07-09 10:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:03:19 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:33:19 --> Total execution time: 0.0396
DEBUG - 2022-07-09 10:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:03:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 10:03:43 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-09 10:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:05:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 10:05:52 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-09 10:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:36:09 --> Total execution time: 0.0574
DEBUG - 2022-07-09 10:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:36:16 --> Total execution time: 0.0535
DEBUG - 2022-07-09 10:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:36:19 --> Total execution time: 0.0592
DEBUG - 2022-07-09 10:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:41:06 --> Total execution time: 0.1852
DEBUG - 2022-07-09 10:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:41:42 --> Total execution time: 0.0591
DEBUG - 2022-07-09 10:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:41:54 --> Total execution time: 0.0665
DEBUG - 2022-07-09 10:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:41:58 --> Total execution time: 0.0953
DEBUG - 2022-07-09 10:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:42:41 --> Total execution time: 0.0551
DEBUG - 2022-07-09 10:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:42:45 --> Total execution time: 0.0582
DEBUG - 2022-07-09 10:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:42:52 --> Total execution time: 0.0618
DEBUG - 2022-07-09 10:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:13:02 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:43:02 --> Total execution time: 0.0472
DEBUG - 2022-07-09 10:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:43:12 --> Total execution time: 0.0362
DEBUG - 2022-07-09 10:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:13:37 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:43:37 --> Total execution time: 0.0536
DEBUG - 2022-07-09 10:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:19:34 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:49:34 --> Total execution time: 0.1199
DEBUG - 2022-07-09 10:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:19:51 --> Total execution time: 0.0593
DEBUG - 2022-07-09 10:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:19:55 --> Total execution time: 0.0670
DEBUG - 2022-07-09 10:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:19:55 --> Total execution time: 0.1270
DEBUG - 2022-07-09 10:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:21:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 10:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:51:59 --> Total execution time: 2.0250
DEBUG - 2022-07-09 10:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:22:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 10:22:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 10:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:52:52 --> Total execution time: 0.1428
DEBUG - 2022-07-09 10:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:52:58 --> Total execution time: 0.0936
DEBUG - 2022-07-09 10:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:52:59 --> Total execution time: 0.0836
DEBUG - 2022-07-09 10:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:54:37 --> Total execution time: 0.0586
DEBUG - 2022-07-09 10:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:54:39 --> Total execution time: 0.0544
DEBUG - 2022-07-09 10:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:54:44 --> Total execution time: 0.0901
DEBUG - 2022-07-09 10:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:54:47 --> Total execution time: 0.0694
DEBUG - 2022-07-09 10:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:54:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 10:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:54:49 --> Total execution time: 0.0549
DEBUG - 2022-07-09 10:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:54:50 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 20:54:50 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 20:54:50 --> Total execution time: 0.1954
DEBUG - 2022-07-09 10:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:55:20 --> Total execution time: 0.0330
DEBUG - 2022-07-09 10:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:26:32 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:56:32 --> Total execution time: 0.1256
DEBUG - 2022-07-09 10:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:57:30 --> Total execution time: 0.0560
DEBUG - 2022-07-09 10:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:57:31 --> Total execution time: 0.0524
DEBUG - 2022-07-09 10:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:57:37 --> Total execution time: 0.0504
DEBUG - 2022-07-09 10:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:29:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 10:29:40 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-09 10:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:30:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 10:30:22 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-09 10:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 10:31:05 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-09 10:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:31:29 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:01:29 --> Total execution time: 0.0394
DEBUG - 2022-07-09 10:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:01:33 --> Total execution time: 0.0361
DEBUG - 2022-07-09 10:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:01:42 --> Total execution time: 0.0709
DEBUG - 2022-07-09 10:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:01:52 --> Total execution time: 0.0609
DEBUG - 2022-07-09 10:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:01:56 --> Total execution time: 0.0867
DEBUG - 2022-07-09 10:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:02:04 --> Total execution time: 0.0573
DEBUG - 2022-07-09 10:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:32:20 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:02:20 --> Total execution time: 0.0641
DEBUG - 2022-07-09 10:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:32:20 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:02:20 --> Total execution time: 0.0586
DEBUG - 2022-07-09 10:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:02:29 --> Total execution time: 0.0394
DEBUG - 2022-07-09 10:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:02:32 --> Total execution time: 0.0527
DEBUG - 2022-07-09 10:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:03:28 --> Total execution time: 0.0621
DEBUG - 2022-07-09 10:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:03:33 --> Total execution time: 0.0630
DEBUG - 2022-07-09 10:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:03:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 10:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:03:34 --> Total execution time: 0.0467
DEBUG - 2022-07-09 10:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:33:47 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:03:47 --> Total execution time: 0.0383
DEBUG - 2022-07-09 10:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:34:01 --> Total execution time: 0.1077
DEBUG - 2022-07-09 10:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:34:03 --> Total execution time: 0.0631
DEBUG - 2022-07-09 10:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:34:03 --> Total execution time: 0.1204
DEBUG - 2022-07-09 10:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:35:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 10:35:13 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-09 10:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:35:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 10:35:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 10:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:05:45 --> Total execution time: 0.0613
DEBUG - 2022-07-09 10:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:05:49 --> Total execution time: 0.0588
DEBUG - 2022-07-09 10:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:06:00 --> Total execution time: 0.0550
DEBUG - 2022-07-09 10:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:06:05 --> Total execution time: 0.0679
DEBUG - 2022-07-09 10:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:06:10 --> Total execution time: 0.0651
DEBUG - 2022-07-09 10:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:36:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 10:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:06:12 --> Total execution time: 0.0858
DEBUG - 2022-07-09 10:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:06:14 --> Total execution time: 1.5693
DEBUG - 2022-07-09 10:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:36:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 10:36:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 10:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:06:53 --> Total execution time: 0.1841
DEBUG - 2022-07-09 10:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:07:33 --> Total execution time: 0.0522
DEBUG - 2022-07-09 10:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:38:16 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:08:16 --> Total execution time: 0.0469
DEBUG - 2022-07-09 10:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:38:17 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:08:17 --> Total execution time: 0.0403
DEBUG - 2022-07-09 10:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:08:25 --> Total execution time: 0.0337
DEBUG - 2022-07-09 10:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:08:37 --> Total execution time: 0.0529
DEBUG - 2022-07-09 10:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:08:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 10:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:08:45 --> Total execution time: 0.0654
DEBUG - 2022-07-09 10:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:08:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 21:08:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 21:08:46 --> Total execution time: 0.1838
DEBUG - 2022-07-09 10:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:08:51 --> Total execution time: 0.0519
DEBUG - 2022-07-09 10:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:38:59 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:08:59 --> Total execution time: 0.0555
DEBUG - 2022-07-09 10:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:09:06 --> Total execution time: 0.1357
DEBUG - 2022-07-09 10:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:09:14 --> Total execution time: 0.0858
DEBUG - 2022-07-09 10:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:09:30 --> Total execution time: 0.0897
DEBUG - 2022-07-09 10:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:09:38 --> Total execution time: 0.0767
DEBUG - 2022-07-09 10:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:39:45 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:09:45 --> Total execution time: 0.0850
DEBUG - 2022-07-09 10:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:09:48 --> Total execution time: 0.0798
DEBUG - 2022-07-09 10:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:09:54 --> Total execution time: 0.0559
DEBUG - 2022-07-09 10:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:10:04 --> Total execution time: 0.0596
DEBUG - 2022-07-09 10:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:40:12 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:10:13 --> Total execution time: 0.0633
DEBUG - 2022-07-09 10:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:10:22 --> Total execution time: 0.0620
DEBUG - 2022-07-09 10:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:10:31 --> Total execution time: 0.0545
DEBUG - 2022-07-09 10:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:40:33 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:10:33 --> Total execution time: 0.0606
DEBUG - 2022-07-09 10:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:10:36 --> Total execution time: 0.0528
DEBUG - 2022-07-09 10:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:10:38 --> Total execution time: 0.0967
DEBUG - 2022-07-09 10:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:10:38 --> Total execution time: 0.0818
DEBUG - 2022-07-09 10:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:10:40 --> Total execution time: 0.0517
DEBUG - 2022-07-09 10:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:40:44 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:10:44 --> Total execution time: 0.0564
DEBUG - 2022-07-09 10:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:10:46 --> Total execution time: 0.0500
DEBUG - 2022-07-09 10:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:41:48 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:11:48 --> Total execution time: 0.0390
DEBUG - 2022-07-09 10:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:43:32 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:13:32 --> Total execution time: 0.0374
DEBUG - 2022-07-09 10:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:43:54 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:13:54 --> Total execution time: 0.0883
DEBUG - 2022-07-09 10:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:44:06 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:14:06 --> Total execution time: 0.0434
DEBUG - 2022-07-09 10:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:14:49 --> Total execution time: 0.1393
DEBUG - 2022-07-09 10:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:44:56 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:14:56 --> Total execution time: 0.0360
DEBUG - 2022-07-09 10:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:01 --> Total execution time: 0.0984
DEBUG - 2022-07-09 10:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:05 --> Total execution time: 0.0628
DEBUG - 2022-07-09 10:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:05 --> Total execution time: 0.0644
DEBUG - 2022-07-09 10:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:10 --> Total execution time: 0.0600
DEBUG - 2022-07-09 10:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:45:18 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:18 --> Total execution time: 0.0521
DEBUG - 2022-07-09 10:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:45:19 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:19 --> Total execution time: 0.0375
DEBUG - 2022-07-09 10:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:23 --> Total execution time: 0.0582
DEBUG - 2022-07-09 10:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:24 --> Total execution time: 0.0336
DEBUG - 2022-07-09 10:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:27 --> Total execution time: 0.0634
DEBUG - 2022-07-09 10:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:33 --> Total execution time: 0.0602
DEBUG - 2022-07-09 10:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:41 --> Total execution time: 0.0557
DEBUG - 2022-07-09 10:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:44 --> Total execution time: 0.0582
DEBUG - 2022-07-09 10:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:47 --> Total execution time: 0.0625
DEBUG - 2022-07-09 10:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:52 --> Total execution time: 0.0517
DEBUG - 2022-07-09 10:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:46:41 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:16:41 --> Total execution time: 0.0404
DEBUG - 2022-07-09 10:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:47:20 --> Total execution time: 0.0622
DEBUG - 2022-07-09 10:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:47:22 --> Total execution time: 0.0585
DEBUG - 2022-07-09 10:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:47:22 --> Total execution time: 0.1300
DEBUG - 2022-07-09 10:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:47:59 --> Total execution time: 0.0521
DEBUG - 2022-07-09 10:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:48:01 --> Total execution time: 0.0519
DEBUG - 2022-07-09 10:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:48:01 --> Total execution time: 0.1400
DEBUG - 2022-07-09 10:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:48:36 --> Total execution time: 0.0551
DEBUG - 2022-07-09 10:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:48:38 --> Total execution time: 0.0592
DEBUG - 2022-07-09 10:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:48:38 --> Total execution time: 0.1049
DEBUG - 2022-07-09 10:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:49:14 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:19:14 --> Total execution time: 0.0627
DEBUG - 2022-07-09 10:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:49:19 --> Total execution time: 0.0522
DEBUG - 2022-07-09 10:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:49:21 --> Total execution time: 0.0773
DEBUG - 2022-07-09 10:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:49:21 --> Total execution time: 0.1418
DEBUG - 2022-07-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:50:01 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:20:01 --> Total execution time: 0.1156
DEBUG - 2022-07-09 10:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:50:08 --> Total execution time: 0.0745
DEBUG - 2022-07-09 10:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:50:09 --> Total execution time: 0.0587
DEBUG - 2022-07-09 10:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:50:09 --> Total execution time: 0.1177
DEBUG - 2022-07-09 10:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:50:42 --> Total execution time: 0.0638
DEBUG - 2022-07-09 10:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:50:43 --> Total execution time: 0.0503
DEBUG - 2022-07-09 10:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:50:43 --> Total execution time: 0.0977
DEBUG - 2022-07-09 10:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:50:47 --> Total execution time: 0.0465
DEBUG - 2022-07-09 10:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:50:49 --> Total execution time: 0.0549
DEBUG - 2022-07-09 10:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:50:49 --> Total execution time: 0.0952
DEBUG - 2022-07-09 10:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:50:54 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:20:54 --> Total execution time: 0.0535
DEBUG - 2022-07-09 10:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:51:16 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:21:16 --> Total execution time: 0.0553
DEBUG - 2022-07-09 10:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:51:27 --> Total execution time: 0.0390
DEBUG - 2022-07-09 10:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:51:29 --> Total execution time: 0.0678
DEBUG - 2022-07-09 10:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:51:29 --> Total execution time: 0.1089
DEBUG - 2022-07-09 10:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:52:06 --> Total execution time: 0.0631
DEBUG - 2022-07-09 10:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:52:08 --> Total execution time: 0.0563
DEBUG - 2022-07-09 10:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:52:08 --> Total execution time: 0.1217
DEBUG - 2022-07-09 10:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:52:16 --> Total execution time: 0.0578
DEBUG - 2022-07-09 10:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:24:58 --> Total execution time: 0.1568
DEBUG - 2022-07-09 10:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:25:00 --> Total execution time: 0.0558
DEBUG - 2022-07-09 10:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:25:42 --> Total execution time: 0.0815
DEBUG - 2022-07-09 10:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:25:45 --> Total execution time: 0.1392
DEBUG - 2022-07-09 10:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:55:50 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:25:50 --> Total execution time: 0.0441
DEBUG - 2022-07-09 10:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:58:30 --> No URI present. Default controller set.
DEBUG - 2022-07-09 10:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:28:30 --> Total execution time: 0.1098
DEBUG - 2022-07-09 10:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:28:34 --> Total execution time: 0.0386
DEBUG - 2022-07-09 10:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 10:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:28:43 --> Total execution time: 0.0708
DEBUG - 2022-07-09 10:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:28:47 --> Total execution time: 0.0643
DEBUG - 2022-07-09 10:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:28:53 --> Total execution time: 0.0662
DEBUG - 2022-07-09 10:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:29:03 --> Total execution time: 0.1184
DEBUG - 2022-07-09 10:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:29:32 --> Total execution time: 0.0559
DEBUG - 2022-07-09 10:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 10:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 10:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:29:35 --> Total execution time: 0.0691
DEBUG - 2022-07-09 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:30:02 --> Total execution time: 0.0801
DEBUG - 2022-07-09 11:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:30:07 --> Total execution time: 0.0640
DEBUG - 2022-07-09 11:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:31:20 --> Total execution time: 0.1443
DEBUG - 2022-07-09 11:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:04:00 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:34:00 --> Total execution time: 0.0917
DEBUG - 2022-07-09 11:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:04:01 --> Total execution time: 0.0425
DEBUG - 2022-07-09 11:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:04:03 --> Total execution time: 0.0550
DEBUG - 2022-07-09 11:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:04:03 --> Total execution time: 0.0749
DEBUG - 2022-07-09 11:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:06:23 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:36:23 --> Total execution time: 0.1846
DEBUG - 2022-07-09 11:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:06:36 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:36:36 --> Total execution time: 0.0371
DEBUG - 2022-07-09 11:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:07:04 --> Total execution time: 0.0525
DEBUG - 2022-07-09 11:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:37:12 --> Total execution time: 0.0506
DEBUG - 2022-07-09 11:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:07:13 --> Total execution time: 0.0598
DEBUG - 2022-07-09 11:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:07:13 --> Total execution time: 0.1077
DEBUG - 2022-07-09 11:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:09:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 11:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:39:18 --> Total execution time: 2.0473
DEBUG - 2022-07-09 11:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:09:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 11:09:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 11:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:44:59 --> Total execution time: 0.1946
DEBUG - 2022-07-09 11:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:15:33 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:45:33 --> Total execution time: 0.1456
DEBUG - 2022-07-09 11:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:16:38 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:46:38 --> Total execution time: 0.0530
DEBUG - 2022-07-09 11:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:16:49 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:46:49 --> Total execution time: 0.0571
DEBUG - 2022-07-09 11:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:16:51 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:46:51 --> Total execution time: 0.0360
DEBUG - 2022-07-09 11:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:17:01 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:47:01 --> Total execution time: 0.0585
DEBUG - 2022-07-09 11:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:47:20 --> Total execution time: 0.0343
DEBUG - 2022-07-09 11:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:47:46 --> Total execution time: 1.4835
DEBUG - 2022-07-09 11:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:48:01 --> Total execution time: 1.4482
DEBUG - 2022-07-09 11:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:18:26 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:48:26 --> Total execution time: 0.0681
DEBUG - 2022-07-09 11:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:48:37 --> Total execution time: 0.0625
DEBUG - 2022-07-09 11:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:48:54 --> Total execution time: 0.0558
DEBUG - 2022-07-09 11:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:50:41 --> Total execution time: 0.0749
DEBUG - 2022-07-09 11:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:56:18 --> Total execution time: 0.0489
DEBUG - 2022-07-09 11:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:26:25 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:56:25 --> Total execution time: 0.0388
DEBUG - 2022-07-09 11:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:26:26 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:56:26 --> Total execution time: 0.0303
DEBUG - 2022-07-09 11:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:56:33 --> Total execution time: 0.0515
DEBUG - 2022-07-09 11:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:56:48 --> Total execution time: 0.0604
DEBUG - 2022-07-09 11:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:56:52 --> Total execution time: 0.0774
DEBUG - 2022-07-09 11:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:57:20 --> Total execution time: 0.0508
DEBUG - 2022-07-09 11:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:57:21 --> Total execution time: 0.0498
DEBUG - 2022-07-09 11:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:27:29 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:57:29 --> Total execution time: 0.0366
DEBUG - 2022-07-09 11:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:57:35 --> Total execution time: 0.0515
DEBUG - 2022-07-09 11:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:57:53 --> Total execution time: 0.0575
DEBUG - 2022-07-09 11:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:28:05 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:05 --> Total execution time: 0.0422
DEBUG - 2022-07-09 11:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:06 --> Total execution time: 0.0901
DEBUG - 2022-07-09 11:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:28:20 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:20 --> Total execution time: 0.0542
DEBUG - 2022-07-09 11:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:31 --> Total execution time: 1.8936
DEBUG - 2022-07-09 11:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:28:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 11:28:35 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 11:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:28:47 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:47 --> Total execution time: 0.0541
DEBUG - 2022-07-09 11:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:29:46 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:59:46 --> Total execution time: 0.0438
DEBUG - 2022-07-09 11:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:29:53 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:59:53 --> Total execution time: 0.0584
DEBUG - 2022-07-09 11:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:59:54 --> Total execution time: 0.0728
DEBUG - 2022-07-09 11:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:59:58 --> Total execution time: 0.0497
DEBUG - 2022-07-09 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:30:02 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:00:02 --> Total execution time: 0.1311
DEBUG - 2022-07-09 11:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:30:04 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:00:04 --> Total execution time: 0.0680
DEBUG - 2022-07-09 11:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:00:43 --> Total execution time: 0.0617
DEBUG - 2022-07-09 11:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:00:54 --> Total execution time: 0.1704
DEBUG - 2022-07-09 11:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:01:05 --> Total execution time: 0.0569
DEBUG - 2022-07-09 11:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:01:19 --> Total execution time: 0.0527
DEBUG - 2022-07-09 11:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:31:20 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:01:20 --> Total execution time: 0.0360
DEBUG - 2022-07-09 11:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:31:29 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:01:30 --> Total execution time: 0.0561
DEBUG - 2022-07-09 11:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:31:37 --> Total execution time: 0.0541
DEBUG - 2022-07-09 11:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:31:41 --> Total execution time: 0.0589
DEBUG - 2022-07-09 11:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:31:41 --> Total execution time: 0.0515
DEBUG - 2022-07-09 11:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:31:41 --> Total execution time: 0.1125
DEBUG - 2022-07-09 11:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:31:42 --> Total execution time: 0.0553
DEBUG - 2022-07-09 11:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:31:42 --> Total execution time: 0.1112
DEBUG - 2022-07-09 11:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:31:54 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:01:54 --> Total execution time: 0.0620
DEBUG - 2022-07-09 11:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:33:13 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:03:13 --> Total execution time: 0.0393
DEBUG - 2022-07-09 11:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:14 --> Total execution time: 0.0532
DEBUG - 2022-07-09 11:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:17 --> Total execution time: 0.0539
DEBUG - 2022-07-09 11:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:17 --> Total execution time: 0.1284
DEBUG - 2022-07-09 11:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:33:30 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:03:30 --> Total execution time: 0.0419
DEBUG - 2022-07-09 11:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:03:31 --> Total execution time: 0.0577
DEBUG - 2022-07-09 11:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:03:36 --> Total execution time: 0.0510
DEBUG - 2022-07-09 11:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:03:40 --> Total execution time: 0.0522
DEBUG - 2022-07-09 11:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:33:53 --> Total execution time: 0.0583
DEBUG - 2022-07-09 11:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:34:08 --> Total execution time: 0.0546
DEBUG - 2022-07-09 11:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:34:08 --> Total execution time: 0.1248
DEBUG - 2022-07-09 11:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:04:08 --> Total execution time: 0.1706
DEBUG - 2022-07-09 11:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:04:23 --> Total execution time: 0.0526
DEBUG - 2022-07-09 11:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:04:27 --> Total execution time: 0.0510
DEBUG - 2022-07-09 11:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:04:32 --> Total execution time: 0.0918
DEBUG - 2022-07-09 11:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:04:55 --> Total execution time: 0.0559
DEBUG - 2022-07-09 11:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:05:04 --> Total execution time: 0.0724
DEBUG - 2022-07-09 11:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:05:07 --> Total execution time: 0.1507
DEBUG - 2022-07-09 11:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:05:07 --> Total execution time: 0.0501
DEBUG - 2022-07-09 11:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:05:52 --> Total execution time: 0.0830
DEBUG - 2022-07-09 11:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:05:52 --> Total execution time: 0.0507
DEBUG - 2022-07-09 11:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:06:10 --> Total execution time: 0.0570
DEBUG - 2022-07-09 11:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:06:17 --> Total execution time: 0.0616
DEBUG - 2022-07-09 11:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:06:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 11:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:06:18 --> Total execution time: 0.0545
DEBUG - 2022-07-09 11:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:07:44 --> Total execution time: 0.0648
DEBUG - 2022-07-09 11:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:08:05 --> Total execution time: 0.0357
DEBUG - 2022-07-09 11:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:08:27 --> Total execution time: 0.1291
DEBUG - 2022-07-09 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:09:12 --> Total execution time: 0.0576
DEBUG - 2022-07-09 11:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:09:16 --> Total execution time: 0.0675
DEBUG - 2022-07-09 11:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:09:26 --> Total execution time: 0.0507
DEBUG - 2022-07-09 11:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:09:29 --> Total execution time: 0.0384
DEBUG - 2022-07-09 11:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:09:30 --> Total execution time: 0.0507
DEBUG - 2022-07-09 11:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:09:41 --> Total execution time: 0.0689
DEBUG - 2022-07-09 11:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:39:49 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:09:49 --> Total execution time: 0.0563
DEBUG - 2022-07-09 11:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:10:02 --> Total execution time: 0.0674
DEBUG - 2022-07-09 11:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:41:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 11:41:42 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-09 11:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:12:09 --> Total execution time: 0.0517
DEBUG - 2022-07-09 11:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:12:13 --> Total execution time: 0.0570
DEBUG - 2022-07-09 11:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:42:25 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:12:25 --> Total execution time: 0.1259
DEBUG - 2022-07-09 11:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:12:29 --> Total execution time: 0.0456
DEBUG - 2022-07-09 11:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:12:41 --> Total execution time: 0.0519
DEBUG - 2022-07-09 11:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:13:08 --> Total execution time: 0.0588
DEBUG - 2022-07-09 11:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:13:10 --> Total execution time: 0.0511
DEBUG - 2022-07-09 11:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:13:30 --> Total execution time: 0.0553
DEBUG - 2022-07-09 11:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:13:32 --> Total execution time: 0.1308
DEBUG - 2022-07-09 11:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:13:40 --> Total execution time: 0.0550
DEBUG - 2022-07-09 11:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:13:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 11:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:13:41 --> Total execution time: 0.0507
DEBUG - 2022-07-09 11:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 11:44:13 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-09 11:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:15:11 --> Total execution time: 0.0533
DEBUG - 2022-07-09 11:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:45:32 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:15:32 --> Total execution time: 0.0416
DEBUG - 2022-07-09 11:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:15:40 --> Total execution time: 0.0494
DEBUG - 2022-07-09 11:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:15:53 --> Total execution time: 0.0589
DEBUG - 2022-07-09 11:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:15:56 --> Total execution time: 0.0575
DEBUG - 2022-07-09 11:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:46:00 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:01 --> Total execution time: 0.0386
DEBUG - 2022-07-09 11:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:04 --> Total execution time: 0.0812
DEBUG - 2022-07-09 11:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 11:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:16 --> Total execution time: 0.0608
DEBUG - 2022-07-09 11:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:18 --> Total execution time: 0.0565
DEBUG - 2022-07-09 11:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:26 --> Total execution time: 0.0865
DEBUG - 2022-07-09 11:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:46:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 11:46:26 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-09 11:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:28 --> Total execution time: 0.0654
DEBUG - 2022-07-09 11:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:35 --> Total execution time: 0.0820
DEBUG - 2022-07-09 11:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:37 --> Total execution time: 0.0575
DEBUG - 2022-07-09 11:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:40 --> Total execution time: 0.0553
DEBUG - 2022-07-09 11:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:44 --> Total execution time: 0.0590
DEBUG - 2022-07-09 11:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:47 --> Total execution time: 0.0556
DEBUG - 2022-07-09 11:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:50 --> Total execution time: 0.0629
DEBUG - 2022-07-09 11:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:52 --> Total execution time: 0.0593
DEBUG - 2022-07-09 11:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:57 --> Total execution time: 0.0529
DEBUG - 2022-07-09 11:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:17:04 --> Total execution time: 0.0533
DEBUG - 2022-07-09 11:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:17:20 --> Total execution time: 0.0557
DEBUG - 2022-07-09 11:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:17:21 --> Total execution time: 0.0521
DEBUG - 2022-07-09 11:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:17:30 --> Total execution time: 0.1318
DEBUG - 2022-07-09 11:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:17:34 --> Total execution time: 0.0607
DEBUG - 2022-07-09 11:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:17:36 --> Total execution time: 0.0600
DEBUG - 2022-07-09 11:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:48:48 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:18:48 --> Total execution time: 0.0395
DEBUG - 2022-07-09 11:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:20:02 --> Total execution time: 0.1384
DEBUG - 2022-07-09 11:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:52:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 11:52:09 --> 404 Page Not Found: Lp-profile/courses
DEBUG - 2022-07-09 11:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:52:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 11:52:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 11:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:23:19 --> Total execution time: 0.2089
DEBUG - 2022-07-09 11:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:23:21 --> Total execution time: 0.0649
DEBUG - 2022-07-09 11:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:23:47 --> Total execution time: 0.1333
DEBUG - 2022-07-09 11:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:24:46 --> Total execution time: 0.0511
DEBUG - 2022-07-09 11:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:55:31 --> No URI present. Default controller set.
DEBUG - 2022-07-09 11:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:25:31 --> Total execution time: 0.0522
DEBUG - 2022-07-09 11:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:28:56 --> Total execution time: 0.2046
DEBUG - 2022-07-09 11:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:28:56 --> Total execution time: 0.0617
DEBUG - 2022-07-09 11:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:29:04 --> Total execution time: 0.0730
DEBUG - 2022-07-09 11:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:29:35 --> Total execution time: 0.0568
DEBUG - 2022-07-09 11:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:29:39 --> Total execution time: 0.1402
DEBUG - 2022-07-09 11:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 11:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 11:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:29:48 --> Total execution time: 0.0534
DEBUG - 2022-07-09 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:30:03 --> Total execution time: 0.0552
DEBUG - 2022-07-09 12:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:05:36 --> No URI present. Default controller set.
DEBUG - 2022-07-09 12:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:35:36 --> Total execution time: 0.1080
DEBUG - 2022-07-09 12:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:36:22 --> Total execution time: 0.0589
DEBUG - 2022-07-09 12:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:06:59 --> No URI present. Default controller set.
DEBUG - 2022-07-09 12:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:36:59 --> Total execution time: 0.0530
DEBUG - 2022-07-09 12:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:37:03 --> Total execution time: 0.0374
DEBUG - 2022-07-09 12:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:37:24 --> Total execution time: 0.0587
DEBUG - 2022-07-09 12:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:37:33 --> Total execution time: 0.0375
DEBUG - 2022-07-09 12:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:37:35 --> Total execution time: 0.0870
DEBUG - 2022-07-09 12:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:37:43 --> Total execution time: 0.0651
DEBUG - 2022-07-09 12:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:37:45 --> Total execution time: 0.0597
DEBUG - 2022-07-09 12:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:10:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 12:10:12 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-09 12:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:41:21 --> Total execution time: 0.0786
DEBUG - 2022-07-09 12:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:11:25 --> No URI present. Default controller set.
DEBUG - 2022-07-09 12:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:41:25 --> Total execution time: 0.0321
DEBUG - 2022-07-09 12:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:41:58 --> Total execution time: 0.0503
DEBUG - 2022-07-09 12:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:42:03 --> Total execution time: 0.0507
DEBUG - 2022-07-09 12:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:17:35 --> Total execution time: 0.0895
DEBUG - 2022-07-09 12:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:17:39 --> No URI present. Default controller set.
DEBUG - 2022-07-09 12:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:47:39 --> Total execution time: 0.1315
DEBUG - 2022-07-09 12:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:47:46 --> Total execution time: 0.0632
DEBUG - 2022-07-09 12:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:47:59 --> Total execution time: 0.0611
DEBUG - 2022-07-09 12:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:48:06 --> Total execution time: 0.0603
DEBUG - 2022-07-09 12:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:48:11 --> Total execution time: 0.0514
DEBUG - 2022-07-09 12:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:49:30 --> Total execution time: 0.1479
DEBUG - 2022-07-09 12:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:49:44 --> Total execution time: 0.0768
DEBUG - 2022-07-09 12:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:49:46 --> Total execution time: 0.0924
DEBUG - 2022-07-09 12:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:49:51 --> Total execution time: 0.0770
DEBUG - 2022-07-09 12:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:49:53 --> Total execution time: 0.0967
DEBUG - 2022-07-09 12:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:49:59 --> Total execution time: 0.0705
DEBUG - 2022-07-09 12:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:50:03 --> Total execution time: 0.1484
DEBUG - 2022-07-09 12:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:50:05 --> Total execution time: 0.1291
DEBUG - 2022-07-09 12:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:20:33 --> No URI present. Default controller set.
DEBUG - 2022-07-09 12:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:50:33 --> Total execution time: 0.0385
DEBUG - 2022-07-09 12:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:50:40 --> Total execution time: 0.0545
DEBUG - 2022-07-09 12:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:51:50 --> Total execution time: 0.0679
DEBUG - 2022-07-09 12:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:51:57 --> Total execution time: 0.0864
DEBUG - 2022-07-09 12:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:22:09 --> No URI present. Default controller set.
DEBUG - 2022-07-09 12:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:52:09 --> Total execution time: 0.0576
DEBUG - 2022-07-09 12:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:22:56 --> No URI present. Default controller set.
DEBUG - 2022-07-09 12:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:52:56 --> Total execution time: 0.0537
DEBUG - 2022-07-09 12:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:52:56 --> Total execution time: 0.0343
DEBUG - 2022-07-09 12:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:53:53 --> Total execution time: 0.1015
DEBUG - 2022-07-09 12:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:54:30 --> Total execution time: 0.1132
DEBUG - 2022-07-09 12:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:56:37 --> Total execution time: 0.0538
DEBUG - 2022-07-09 12:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:07:39 --> Total execution time: 0.1131
DEBUG - 2022-07-09 12:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:10:04 --> Total execution time: 0.1901
DEBUG - 2022-07-09 12:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:11:07 --> Total execution time: 0.0615
DEBUG - 2022-07-09 12:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:11:11 --> Total execution time: 0.0587
DEBUG - 2022-07-09 12:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:11:17 --> Total execution time: 0.0563
DEBUG - 2022-07-09 12:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:43:07 --> No URI present. Default controller set.
DEBUG - 2022-07-09 12:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:13:07 --> Total execution time: 0.0460
DEBUG - 2022-07-09 12:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:43:22 --> Total execution time: 0.0385
DEBUG - 2022-07-09 12:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:43:23 --> Total execution time: 0.0520
DEBUG - 2022-07-09 12:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:43:23 --> Total execution time: 0.1116
DEBUG - 2022-07-09 12:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:43:26 --> No URI present. Default controller set.
DEBUG - 2022-07-09 12:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:13:26 --> Total execution time: 0.0521
DEBUG - 2022-07-09 12:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:43:35 --> Total execution time: 0.0517
DEBUG - 2022-07-09 12:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:43:36 --> Total execution time: 0.0592
DEBUG - 2022-07-09 12:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:43:36 --> Total execution time: 0.0999
DEBUG - 2022-07-09 12:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:43:46 --> No URI present. Default controller set.
DEBUG - 2022-07-09 12:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:13:46 --> Total execution time: 0.0508
DEBUG - 2022-07-09 12:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:18:59 --> Total execution time: 0.1048
DEBUG - 2022-07-09 12:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:20:30 --> Total execution time: 0.0399
DEBUG - 2022-07-09 12:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:20:35 --> Total execution time: 0.0848
DEBUG - 2022-07-09 12:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:21:38 --> Total execution time: 0.0638
DEBUG - 2022-07-09 12:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:21:49 --> Total execution time: 0.0782
DEBUG - 2022-07-09 12:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:23:02 --> Total execution time: 0.0708
DEBUG - 2022-07-09 12:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:23:05 --> Total execution time: 0.0949
DEBUG - 2022-07-09 12:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:23:25 --> Total execution time: 0.0581
DEBUG - 2022-07-09 12:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:25:36 --> Total execution time: 0.0492
DEBUG - 2022-07-09 12:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:56:32 --> No URI present. Default controller set.
DEBUG - 2022-07-09 12:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:26:32 --> Total execution time: 0.0468
DEBUG - 2022-07-09 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:26:36 --> Total execution time: 0.0621
DEBUG - 2022-07-09 12:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:26:57 --> Total execution time: 0.0499
DEBUG - 2022-07-09 12:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 12:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:27:13 --> Total execution time: 0.0563
DEBUG - 2022-07-09 12:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:28:17 --> Total execution time: 0.0566
DEBUG - 2022-07-09 12:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 12:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 12:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:28:33 --> Total execution time: 0.1448
DEBUG - 2022-07-09 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:30:02 --> Total execution time: 0.0794
DEBUG - 2022-07-09 13:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:37:22 --> Total execution time: 0.0547
DEBUG - 2022-07-09 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:12:14 --> Total execution time: 0.1952
DEBUG - 2022-07-09 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:42:14 --> Total execution time: 0.0539
DEBUG - 2022-07-09 13:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:17:06 --> No URI present. Default controller set.
DEBUG - 2022-07-09 13:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:47:06 --> Total execution time: 0.1232
DEBUG - 2022-07-09 13:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:17:18 --> No URI present. Default controller set.
DEBUG - 2022-07-09 13:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:47:18 --> Total execution time: 0.0428
DEBUG - 2022-07-09 13:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:47:24 --> Total execution time: 0.0622
DEBUG - 2022-07-09 13:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:47:50 --> Total execution time: 0.0518
DEBUG - 2022-07-09 13:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:50:28 --> Total execution time: 0.0570
DEBUG - 2022-07-09 13:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:22:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 13:22:11 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-09 13:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:24:05 --> No URI present. Default controller set.
DEBUG - 2022-07-09 13:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:54:05 --> Total execution time: 0.1815
DEBUG - 2022-07-09 13:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:24:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 13:24:47 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-09 13:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:26:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 13:26:55 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-09 13:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:29:03 --> No URI present. Default controller set.
DEBUG - 2022-07-09 13:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:59:03 --> Total execution time: 0.0898
DEBUG - 2022-07-09 13:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:30:21 --> No URI present. Default controller set.
DEBUG - 2022-07-09 13:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:30:41 --> No URI present. Default controller set.
DEBUG - 2022-07-09 13:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:41:34 --> No URI present. Default controller set.
DEBUG - 2022-07-09 13:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:45:11 --> No URI present. Default controller set.
DEBUG - 2022-07-09 13:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:50:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 13:50:39 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-09 13:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:56:04 --> Total execution time: 0.0512
DEBUG - 2022-07-09 13:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:56:05 --> Total execution time: 0.0824
DEBUG - 2022-07-09 13:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:56:05 --> Total execution time: 0.1418
DEBUG - 2022-07-09 13:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 13:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 13:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 13:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 14:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 14:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 14:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 14:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 14:12:03 --> No URI present. Default controller set.
DEBUG - 2022-07-09 14:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 14:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 14:12:38 --> No URI present. Default controller set.
DEBUG - 2022-07-09 14:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 14:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 14:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 14:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 14:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 14:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 14:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 14:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 14:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 14:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 14:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 14:16:34 --> 404 Page Not Found: Content/pages
DEBUG - 2022-07-09 14:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 14:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 14:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 14:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 14:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 14:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 14:32:43 --> No URI present. Default controller set.
DEBUG - 2022-07-09 14:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 14:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 15:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 15:01:29 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-09 15:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 15:03:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 15:03:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 15:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 15:04:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 15:04:00 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-09 15:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 15:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 15:06:07 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-09 15:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 15:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 15:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 15:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 15:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 15:29:43 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-09 15:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 15:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 15:43:37 --> 404 Page Not Found: Product/super-gold-membership
DEBUG - 2022-07-09 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:18:27 --> No URI present. Default controller set.
DEBUG - 2022-07-09 16:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 16:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 16:19:08 --> 404 Page Not Found: Refund/index
DEBUG - 2022-07-09 16:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 16:22:21 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-09 16:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:22:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 16:22:25 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-09 16:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:29:55 --> No URI present. Default controller set.
DEBUG - 2022-07-09 16:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 16:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 16:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 16:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 16:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 16:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 16:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 16:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 16:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 16:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:40:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 16:40:24 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-09 16:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:42:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 16:42:57 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-09 16:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:45:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 16:45:12 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-09 16:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:49:16 --> No URI present. Default controller set.
DEBUG - 2022-07-09 16:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 16:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:52:08 --> No URI present. Default controller set.
DEBUG - 2022-07-09 16:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 16:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:52:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 16:52:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 16:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:55:36 --> No URI present. Default controller set.
DEBUG - 2022-07-09 16:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 16:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:55:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 16:55:37 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 16:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:59:52 --> No URI present. Default controller set.
DEBUG - 2022-07-09 16:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 16:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 16:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 16:59:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 16:59:52 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 17:00:09 --> No URI present. Default controller set.
DEBUG - 2022-07-09 17:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 17:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 17:00:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 17:00:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 17:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 17:02:58 --> No URI present. Default controller set.
DEBUG - 2022-07-09 17:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 17:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 17:02:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 17:02:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 17:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 17:05:27 --> No URI present. Default controller set.
DEBUG - 2022-07-09 17:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 17:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 17:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 17:05:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 17:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 17:09:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 17:09:20 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-09 17:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 17:12:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 17:12:28 --> 404 Page Not Found: Product/super-gold-membership
DEBUG - 2022-07-09 17:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 17:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 17:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 17:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 17:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 17:22:25 --> No URI present. Default controller set.
DEBUG - 2022-07-09 17:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 17:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 17:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 17:55:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 17:55:50 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-09 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 18:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 18:03:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 18:03:01 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-09 18:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 18:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 18:21:50 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-09 18:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 18:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 18:24:29 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-09 18:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 18:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 18:26:38 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-09 18:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 18:51:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 18:51:17 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-09 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 19:16:49 --> No URI present. Default controller set.
DEBUG - 2022-07-09 19:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 19:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 19:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 19:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 19:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 19:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:24:26 --> Total execution time: 0.0617
DEBUG - 2022-07-09 19:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 19:27:48 --> No URI present. Default controller set.
DEBUG - 2022-07-09 19:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 19:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 19:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 19:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 19:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 19:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 19:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 19:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 19:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 19:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 19:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 19:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 19:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 19:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 19:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 19:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 19:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 19:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 19:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 19:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 19:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 19:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 19:54:50 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-09 19:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 19:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 19:55:05 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-09 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:05:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 20:05:41 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-09 20:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:08:14 --> Total execution time: 0.0679
DEBUG - 2022-07-09 20:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:08:15 --> Total execution time: 0.0981
DEBUG - 2022-07-09 20:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:08:15 --> Total execution time: 0.1174
DEBUG - 2022-07-09 20:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:08:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 20:08:22 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-09 20:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:08:23 --> No URI present. Default controller set.
DEBUG - 2022-07-09 20:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:08:32 --> Total execution time: 0.0468
DEBUG - 2022-07-09 20:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:08:33 --> Total execution time: 0.0509
DEBUG - 2022-07-09 20:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:08:34 --> Total execution time: 0.0723
DEBUG - 2022-07-09 20:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:10:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 20:10:33 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-09 20:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:16:47 --> No URI present. Default controller set.
DEBUG - 2022-07-09 20:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:16:49 --> No URI present. Default controller set.
DEBUG - 2022-07-09 20:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:19:33 --> No URI present. Default controller set.
DEBUG - 2022-07-09 20:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:21:14 --> No URI present. Default controller set.
DEBUG - 2022-07-09 20:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:21:51 --> No URI present. Default controller set.
DEBUG - 2022-07-09 20:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:29:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 20:29:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 20:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:35:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 20:35:06 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-09 20:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:39:23 --> No URI present. Default controller set.
DEBUG - 2022-07-09 20:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 20:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 20:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 20:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:03:06 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:07:08 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:09:28 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:09:48 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:10:15 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:12:01 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:13:03 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:13:33 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:15:32 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:15:40 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:15:40 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:18:09 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:20:37 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:21:03 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:24:53 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:26:58 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:31:12 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:37:17 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:37:18 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:45:18 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:45:52 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:47:22 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 21:48:23 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-09 21:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:51:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 21:51:09 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-09 21:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:53:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 21:53:24 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-09 21:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:55:09 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:57:37 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:58:25 --> No URI present. Default controller set.
DEBUG - 2022-07-09 21:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:43 --> Total execution time: 0.0580
DEBUG - 2022-07-09 21:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:44 --> Total execution time: 0.0566
DEBUG - 2022-07-09 21:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:58:44 --> Total execution time: 0.1179
DEBUG - 2022-07-09 21:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 21:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 21:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 21:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:02:49 --> Total execution time: 0.0890
DEBUG - 2022-07-09 22:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:03:04 --> Total execution time: 0.1232
DEBUG - 2022-07-09 22:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:04:27 --> Total execution time: 0.0709
DEBUG - 2022-07-09 22:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:04:31 --> Total execution time: 0.0739
DEBUG - 2022-07-09 22:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:16:09 --> No URI present. Default controller set.
DEBUG - 2022-07-09 22:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 22:18:37 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-09 22:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:27:20 --> No URI present. Default controller set.
DEBUG - 2022-07-09 22:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:27:22 --> No URI present. Default controller set.
DEBUG - 2022-07-09 22:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:30:06 --> No URI present. Default controller set.
DEBUG - 2022-07-09 22:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:30:06 --> No URI present. Default controller set.
DEBUG - 2022-07-09 22:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:47:15 --> No URI present. Default controller set.
DEBUG - 2022-07-09 22:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:47:18 --> No URI present. Default controller set.
DEBUG - 2022-07-09 22:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:49:25 --> No URI present. Default controller set.
DEBUG - 2022-07-09 22:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:49:33 --> Total execution time: 0.0550
DEBUG - 2022-07-09 22:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:49:35 --> Total execution time: 0.0962
DEBUG - 2022-07-09 22:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:49:35 --> Total execution time: 0.1054
DEBUG - 2022-07-09 22:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:51:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 22:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:51:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 22:51:26 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 22:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:54:37 --> No URI present. Default controller set.
DEBUG - 2022-07-09 22:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:55:14 --> No URI present. Default controller set.
DEBUG - 2022-07-09 22:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:59:45 --> No URI present. Default controller set.
DEBUG - 2022-07-09 22:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:59:52 --> Total execution time: 0.0531
DEBUG - 2022-07-09 22:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 22:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 22:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:59:54 --> Total execution time: 0.0596
DEBUG - 2022-07-09 22:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 22:59:54 --> Total execution time: 0.1149
DEBUG - 2022-07-09 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:01:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 23:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:02:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 23:02:32 --> 404 Page Not Found: Wp-content/ave.php
DEBUG - 2022-07-09 23:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:07:06 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:07:07 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:07:26 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:08:20 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:08:45 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:09:45 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:12:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 23:12:39 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-09 23:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:12:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 23:12:42 --> 404 Page Not Found: Learning-friendship-and-fun-for-everyone/index
DEBUG - 2022-07-09 23:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:13:35 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:14:16 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:14:58 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:14:59 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:15:19 --> Total execution time: 0.0540
DEBUG - 2022-07-09 23:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:15:21 --> Total execution time: 0.0563
DEBUG - 2022-07-09 23:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:15:21 --> Total execution time: 0.1249
DEBUG - 2022-07-09 23:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:15:29 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:15:44 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:15:50 --> Total execution time: 0.0626
DEBUG - 2022-07-09 23:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:15:52 --> Total execution time: 0.0613
DEBUG - 2022-07-09 23:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:15:52 --> Total execution time: 0.1324
DEBUG - 2022-07-09 23:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:15:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 23:15:56 --> 404 Page Not Found: Course/clickbank-mastery
DEBUG - 2022-07-09 23:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:16:30 --> Total execution time: 0.0508
DEBUG - 2022-07-09 23:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:16:31 --> Total execution time: 0.0507
DEBUG - 2022-07-09 23:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:16:31 --> Total execution time: 0.1032
DEBUG - 2022-07-09 23:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:17:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-09 23:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:17:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 23:17:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-09 23:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:32:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 23:32:03 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-09 23:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:34:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 23:34:46 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-09 23:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:36:04 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:36:04 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 23:36:58 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-09 23:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:50:34 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:55:28 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:55:38 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:56:16 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:57:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 23:57:20 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-09 23:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:57:42 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:57:44 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:58:36 --> Total execution time: 0.0497
DEBUG - 2022-07-09 23:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:58:37 --> Total execution time: 0.0662
DEBUG - 2022-07-09 23:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:58:37 --> Total execution time: 0.1121
DEBUG - 2022-07-09 23:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:58:52 --> Total execution time: 0.0622
DEBUG - 2022-07-09 23:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:59:08 --> No URI present. Default controller set.
DEBUG - 2022-07-09 23:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-09 23:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-09 23:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-09 23:59:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-09 23:59:11 --> 404 Page Not Found: Robotstxt/index
