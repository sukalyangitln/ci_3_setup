<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-23 06:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 06:16:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 06:16:15 --> 404 Page Not Found: Company-profile/index
DEBUG - 2022-04-23 06:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 06:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 06:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 06:16:24 --> Total execution time: 0.5710
DEBUG - 2022-04-23 06:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 06:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 06:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 06:16:24 --> Total execution time: 0.0602
DEBUG - 2022-04-23 06:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 06:16:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 06:16:31 --> 404 Page Not Found: user/Leaderboard/index
DEBUG - 2022-04-23 06:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 06:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 06:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 06:16:33 --> Total execution time: 0.0536
DEBUG - 2022-04-23 06:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 06:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 06:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 06:16:37 --> Total execution time: 0.0802
DEBUG - 2022-04-23 06:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 06:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 06:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 06:16:46 --> Total execution time: 0.0783
DEBUG - 2022-04-23 19:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 19:10:44 --> Total execution time: 0.2589
DEBUG - 2022-04-23 19:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 19:10:47 --> Total execution time: 0.0559
DEBUG - 2022-04-23 19:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:10:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:10:49 --> 404 Page Not Found: user/Leaderboard/index
DEBUG - 2022-04-23 19:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 19:10:51 --> Total execution time: 0.0757
DEBUG - 2022-04-23 19:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 19:10:53 --> Total execution time: 0.0523
DEBUG - 2022-04-23 19:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:10:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:10:54 --> 404 Page Not Found: user/Leaderboard/index
DEBUG - 2022-04-23 19:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 19:10:56 --> Total execution time: 0.0700
DEBUG - 2022-04-23 19:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 19:10:57 --> Total execution time: 0.0649
DEBUG - 2022-04-23 19:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 19:10:59 --> Total execution time: 0.0500
DEBUG - 2022-04-23 19:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 22:43:53 --> Total execution time: 0.0529
DEBUG - 2022-04-23 19:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:13:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:13:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:13:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:13:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:13:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:13:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:13:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:13:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:13:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:13:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-23 19:13:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 19:14:58 --> Total execution time: 0.0496
DEBUG - 2022-04-23 19:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:15:00 --> UTF-8 Support Enabled
ERROR - 2022-04-23 19:15:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:15:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:15:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:15:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:15:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:15:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:15:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:15:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:15:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:15:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:15:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-23 19:15:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-23 19:15:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:15:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-23 19:15:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:15:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:15:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-23 19:15:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:15:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 22:50:13 --> Total execution time: 0.0550
DEBUG - 2022-04-23 19:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 22:50:51 --> Total execution time: 0.0498
DEBUG - 2022-04-23 19:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 22:50:51 --> Total execution time: 0.0591
DEBUG - 2022-04-23 19:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:21:04 --> UTF-8 Support Enabled
ERROR - 2022-04-23 19:21:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-23 19:21:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:21:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:21:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-23 19:21:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:21:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 22:51:33 --> Total execution time: 0.0542
DEBUG - 2022-04-23 19:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 22:51:33 --> Total execution time: 0.0499
DEBUG - 2022-04-23 19:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:21:33 --> UTF-8 Support Enabled
ERROR - 2022-04-23 19:21:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:21:33 --> UTF-8 Support Enabled
ERROR - 2022-04-23 19:21:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-23 19:21:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:21:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:21:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-23 19:21:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:21:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:21:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-23 19:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 22:51:39 --> Total execution time: 0.0557
DEBUG - 2022-04-23 19:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 22:51:39 --> Total execution time: 0.0609
DEBUG - 2022-04-23 19:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:23:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 19:23:13 --> 404 Page Not Found: User-login/index
DEBUG - 2022-04-23 19:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 22:53:15 --> Total execution time: 0.0490
DEBUG - 2022-04-23 19:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 22:53:16 --> Total execution time: 0.0559
DEBUG - 2022-04-23 19:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 22:53:33 --> Total execution time: 0.0578
DEBUG - 2022-04-23 19:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 22:53:33 --> Total execution time: 0.0684
DEBUG - 2022-04-23 19:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 19:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 19:23:34 --> Total execution time: 0.0612
DEBUG - 2022-04-23 19:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 22:53:36 --> Total execution time: 0.0673
DEBUG - 2022-04-23 19:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 19:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 19:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-23 22:53:36 --> Total execution time: 0.0559
