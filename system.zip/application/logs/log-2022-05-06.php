<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-06 01:44:23 --> Total execution time: 0.0713
DEBUG - 2022-05-06 01:44:31 --> Total execution time: 0.0440
DEBUG - 2022-05-06 01:44:40 --> Total execution time: 0.0924
DEBUG - 2022-05-06 01:44:47 --> Total execution time: 0.8506
DEBUG - 2022-05-06 01:44:52 --> Total execution time: 0.9367
DEBUG - 2022-05-06 01:46:03 --> Total execution time: 0.8857
DEBUG - 2022-05-06 01:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 01:22:41 --> No URI present. Default controller set.
DEBUG - 2022-05-06 01:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 01:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 06:52:42 --> Total execution time: 1.1200
DEBUG - 2022-05-06 04:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 04:14:20 --> No URI present. Default controller set.
DEBUG - 2022-05-06 04:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 04:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 09:44:21 --> Total execution time: 1.3710
DEBUG - 2022-05-06 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 04:19:49 --> No URI present. Default controller set.
DEBUG - 2022-05-06 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 04:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 09:49:49 --> Total execution time: 0.8518
DEBUG - 2022-05-06 05:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 05:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 05:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 05:41:11 --> Total execution time: 1.2580
DEBUG - 2022-05-06 05:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 05:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 05:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 05:41:12 --> Total execution time: 0.0273
DEBUG - 2022-05-06 05:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 05:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 05:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 05:41:13 --> Total execution time: 0.0284
DEBUG - 2022-05-06 05:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 05:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 05:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 05:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 05:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 05:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 05:41:39 --> Total execution time: 0.0279
DEBUG - 2022-05-06 05:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 05:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 05:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 11:11:42 --> Total execution time: 0.0728
DEBUG - 2022-05-06 05:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 05:42:00 --> No URI present. Default controller set.
DEBUG - 2022-05-06 05:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 05:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 11:12:01 --> Total execution time: 0.0675
DEBUG - 2022-05-06 05:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 05:42:39 --> No URI present. Default controller set.
DEBUG - 2022-05-06 05:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 05:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 11:12:39 --> Total execution time: 0.1056
DEBUG - 2022-05-06 09:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 09:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 09:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:48:08 --> Total execution time: 1.2230
DEBUG - 2022-05-06 09:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 09:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 09:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 09:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 09:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 09:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:48:30 --> Total execution time: 0.1044
DEBUG - 2022-05-06 09:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 09:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 09:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:48:35 --> Total execution time: 0.0562
DEBUG - 2022-05-06 09:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 09:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 09:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:48:39 --> Total execution time: 0.0410
DEBUG - 2022-05-06 09:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 09:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 09:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:51:08 --> Total execution time: 0.7836
DEBUG - 2022-05-06 09:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 09:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 09:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:51:28 --> Total execution time: 0.0298
DEBUG - 2022-05-06 09:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 09:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 09:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:51:48 --> Total execution time: 0.0306
DEBUG - 2022-05-06 09:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 09:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 09:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:01:17 --> Total execution time: 0.8115
DEBUG - 2022-05-06 09:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 09:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 09:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:01:30 --> Total execution time: 0.0403
DEBUG - 2022-05-06 09:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 09:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 09:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 09:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 09:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 09:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:01:42 --> Total execution time: 0.0622
DEBUG - 2022-05-06 09:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 09:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 09:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:01:48 --> Total execution time: 0.0425
DEBUG - 2022-05-06 09:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 09:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 09:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:02:00 --> Total execution time: 0.0344
DEBUG - 2022-05-06 10:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:52:58 --> Total execution time: 0.9790
DEBUG - 2022-05-06 10:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:54:21 --> Total execution time: 0.0298
DEBUG - 2022-05-06 10:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:54:59 --> Total execution time: 0.0363
DEBUG - 2022-05-06 10:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 10:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:55:50 --> Total execution time: 0.1893
DEBUG - 2022-05-06 10:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:56:08 --> Total execution time: 0.0509
DEBUG - 2022-05-06 10:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:01:04 --> Total execution time: 0.8394
DEBUG - 2022-05-06 10:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:01:16 --> Total execution time: 0.0325
DEBUG - 2022-05-06 10:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:08:09 --> Total execution time: 0.9176
DEBUG - 2022-05-06 10:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:10:51 --> Total execution time: 0.8406
DEBUG - 2022-05-06 10:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:11:33 --> Total execution time: 0.1109
DEBUG - 2022-05-06 10:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:11:44 --> Total execution time: 0.0324
DEBUG - 2022-05-06 10:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:18:06 --> Total execution time: 0.8586
DEBUG - 2022-05-06 10:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:18:29 --> Total execution time: 0.0369
DEBUG - 2022-05-06 10:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 10:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:18:35 --> Total execution time: 0.0461
DEBUG - 2022-05-06 10:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:18:46 --> Total execution time: 0.0678
DEBUG - 2022-05-06 10:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:19:06 --> Total execution time: 0.0322
DEBUG - 2022-05-06 10:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:19:13 --> Total execution time: 0.0452
DEBUG - 2022-05-06 10:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 10:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 10:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:19:23 --> Total execution time: 0.0301
DEBUG - 2022-05-06 11:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 11:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 11:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:57:16 --> Total execution time: 0.9016
DEBUG - 2022-05-06 11:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 11:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 11:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:57:47 --> Total execution time: 0.0288
DEBUG - 2022-05-06 11:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 11:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 11:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:58:06 --> Total execution time: 0.0297
DEBUG - 2022-05-06 11:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 11:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 11:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 11:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 11:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 11:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:58:40 --> Total execution time: 0.0617
DEBUG - 2022-05-06 11:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 11:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 11:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:59:23 --> Total execution time: 0.0732
DEBUG - 2022-05-06 11:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 11:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 11:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:59:28 --> Total execution time: 0.0306
DEBUG - 2022-05-06 11:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 11:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 11:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:59:31 --> Total execution time: 0.0310
DEBUG - 2022-05-06 11:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 11:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 11:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:59:38 --> Total execution time: 0.0502
DEBUG - 2022-05-06 11:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 11:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 11:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:59:47 --> Total execution time: 0.0323
DEBUG - 2022-05-06 11:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 11:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 11:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 11:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 11:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 11:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:59:53 --> Total execution time: 0.0312
DEBUG - 2022-05-06 11:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 11:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 11:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 11:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 11:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 11:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:00:06 --> Total execution time: 0.0312
DEBUG - 2022-05-06 12:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 12:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 12:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:59:24 --> Total execution time: 0.8715
DEBUG - 2022-05-06 12:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 12:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 12:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:03:19 --> Total execution time: 0.9328
DEBUG - 2022-05-06 12:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 12:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 12:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 12:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 12:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 12:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:03:40 --> Total execution time: 0.0616
DEBUG - 2022-05-06 12:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 12:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 12:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:03:45 --> Total execution time: 0.0410
DEBUG - 2022-05-06 12:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 12:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 12:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:03:48 --> Total execution time: 0.0391
DEBUG - 2022-05-06 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 12:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 12:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:25:06 --> Total execution time: 1.5110
DEBUG - 2022-05-06 13:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 13:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 13:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 13:23:14 --> Total execution time: 0.8510
DEBUG - 2022-05-06 13:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 13:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 13:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 13:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 13:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 13:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:53:28 --> Total execution time: 0.2028
DEBUG - 2022-05-06 13:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 13:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 13:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:53:41 --> Total execution time: 2.6340
DEBUG - 2022-05-06 13:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 13:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 13:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:15:35 --> Total execution time: 3.4596
DEBUG - 2022-05-06 13:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 13:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 13:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:16:07 --> Total execution time: 0.0520
DEBUG - 2022-05-06 13:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 13:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 13:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 13:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 13:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 13:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:22:32 --> Total execution time: 0.0657
DEBUG - 2022-05-06 13:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 13:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 13:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 13:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 13:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 13:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:29:55 --> Total execution time: 0.0531
DEBUG - 2022-05-06 14:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:34:58 --> Total execution time: 0.0538
DEBUG - 2022-05-06 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:35:59 --> Total execution time: 0.0697
DEBUG - 2022-05-06 14:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:37:25 --> Total execution time: 0.0306
DEBUG - 2022-05-06 14:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:39:56 --> Total execution time: 0.0572
DEBUG - 2022-05-06 14:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:42:23 --> Total execution time: 0.0538
DEBUG - 2022-05-06 14:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:44:11 --> Total execution time: 0.0290
DEBUG - 2022-05-06 14:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:46:01 --> Total execution time: 0.0342
DEBUG - 2022-05-06 14:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:16:48 --> Total execution time: 0.0306
DEBUG - 2022-05-06 14:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:47:14 --> Total execution time: 0.0300
DEBUG - 2022-05-06 14:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:48:29 --> Total execution time: 0.0383
DEBUG - 2022-05-06 14:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:49:29 --> Total execution time: 2.5353
DEBUG - 2022-05-06 14:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:57:02 --> Total execution time: 0.8277
DEBUG - 2022-05-06 14:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:08:25 --> Total execution time: 0.0564
DEBUG - 2022-05-06 14:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:49:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-06 20:19:59 --> Severity: Notice --> Undefined property: Admin_Settings::$User_logins /home/gvprods/public_html/v1/gvv3/application/controllers/Admin/settings/Admin_Settings.php 78
ERROR - 2022-05-06 20:19:59 --> Severity: error --> Exception: Call to a member function updateWhere() on null /home/gvprods/public_html/v1/gvv3/application/controllers/Admin/settings/Admin_Settings.php 78
ERROR - 2022-05-06 20:19:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/core/Common.php 564
DEBUG - 2022-05-06 14:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:20:36 --> Total execution time: 11.0754
DEBUG - 2022-05-06 14:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:20:38 --> Total execution time: 0.0560
DEBUG - 2022-05-06 14:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:21:18 --> Total execution time: 2.6588
DEBUG - 2022-05-06 14:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:21:50 --> Total execution time: 2.4544
DEBUG - 2022-05-06 14:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:22:16 --> Total execution time: 2.4307
DEBUG - 2022-05-06 14:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:23:45 --> Total execution time: 0.0317
DEBUG - 2022-05-06 14:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:24:24 --> Total execution time: 0.0299
DEBUG - 2022-05-06 14:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:25:23 --> Total execution time: 0.0300
DEBUG - 2022-05-06 14:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:26:22 --> Total execution time: 0.0322
DEBUG - 2022-05-06 14:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:26:59 --> Total execution time: 0.0470
DEBUG - 2022-05-06 14:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 14:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 14:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 14:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:27:44 --> Total execution time: 0.0311
DEBUG - 2022-05-06 15:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:32:03 --> Total execution time: 0.0380
DEBUG - 2022-05-06 15:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:32:41 --> Total execution time: 0.0653
DEBUG - 2022-05-06 15:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:33:06 --> Total execution time: 0.0298
DEBUG - 2022-05-06 15:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:33:49 --> Total execution time: 0.0309
DEBUG - 2022-05-06 15:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:34:31 --> Total execution time: 0.0305
DEBUG - 2022-05-06 15:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:35:11 --> Total execution time: 0.0303
DEBUG - 2022-05-06 15:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:36:06 --> Total execution time: 0.0313
DEBUG - 2022-05-06 15:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:36:35 --> Total execution time: 0.0310
DEBUG - 2022-05-06 15:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:37:04 --> Total execution time: 0.0301
DEBUG - 2022-05-06 15:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:37:27 --> Total execution time: 0.0319
DEBUG - 2022-05-06 15:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:37:35 --> Total execution time: 0.0299
DEBUG - 2022-05-06 15:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:38:04 --> Total execution time: 0.0308
DEBUG - 2022-05-06 15:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:39:50 --> Total execution time: 0.0578
DEBUG - 2022-05-06 15:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:40:18 --> Total execution time: 0.0302
DEBUG - 2022-05-06 15:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:40:34 --> Total execution time: 0.0313
DEBUG - 2022-05-06 15:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:41:09 --> Total execution time: 0.2745
DEBUG - 2022-05-06 15:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:41:10 --> Total execution time: 0.0438
DEBUG - 2022-05-06 15:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:41:53 --> Total execution time: 0.0359
DEBUG - 2022-05-06 15:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:41:55 --> Total execution time: 0.0322
DEBUG - 2022-05-06 15:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:43:41 --> Total execution time: 0.0569
DEBUG - 2022-05-06 15:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:45:23 --> Total execution time: 0.0516
DEBUG - 2022-05-06 15:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:23:16 --> No URI present. Default controller set.
DEBUG - 2022-05-06 15:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:53:17 --> Total execution time: 1.0806
DEBUG - 2022-05-06 15:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:23:30 --> Total execution time: 0.0379
DEBUG - 2022-05-06 15:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:54:02 --> Total execution time: 0.0784
DEBUG - 2022-05-06 15:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:54:10 --> Total execution time: 2.7355
DEBUG - 2022-05-06 15:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 20:54:18 --> Total execution time: 0.0582
DEBUG - 2022-05-06 15:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:00:06 --> Total execution time: 0.0609
DEBUG - 2022-05-06 15:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:00:33 --> Total execution time: 0.5021
DEBUG - 2022-05-06 15:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:00:41 --> Total execution time: 0.0304
DEBUG - 2022-05-06 15:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:30:50 --> No URI present. Default controller set.
DEBUG - 2022-05-06 15:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:00:50 --> Total execution time: 0.0673
DEBUG - 2022-05-06 15:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:31:06 --> No URI present. Default controller set.
DEBUG - 2022-05-06 15:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:01:06 --> Total execution time: 0.0336
DEBUG - 2022-05-06 15:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:31:06 --> No URI present. Default controller set.
DEBUG - 2022-05-06 15:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:01:06 --> Total execution time: 0.0856
DEBUG - 2022-05-06 15:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:32:37 --> No URI present. Default controller set.
DEBUG - 2022-05-06 15:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:02:38 --> Total execution time: 0.8316
DEBUG - 2022-05-06 15:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:04:39 --> Total execution time: 0.0547
DEBUG - 2022-05-06 15:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:05:32 --> Total execution time: 0.0577
DEBUG - 2022-05-06 15:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:06:20 --> Total execution time: 0.0616
DEBUG - 2022-05-06 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:07:08 --> Total execution time: 0.0549
DEBUG - 2022-05-06 15:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:09:17 --> Total execution time: 0.1386
DEBUG - 2022-05-06 15:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:10:16 --> Total execution time: 0.0546
DEBUG - 2022-05-06 15:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:10:56 --> Total execution time: 0.0315
DEBUG - 2022-05-06 15:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:11:41 --> Total execution time: 0.0542
DEBUG - 2022-05-06 15:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:12:22 --> Total execution time: 0.0552
DEBUG - 2022-05-06 15:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:13:54 --> Total execution time: 0.0656
DEBUG - 2022-05-06 15:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:14:40 --> Total execution time: 0.8271
DEBUG - 2022-05-06 15:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:15:07 --> Total execution time: 0.0521
DEBUG - 2022-05-06 15:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:16:17 --> Total execution time: 0.0709
DEBUG - 2022-05-06 15:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:16:57 --> Total execution time: 0.0526
DEBUG - 2022-05-06 15:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:17:38 --> Total execution time: 0.0529
DEBUG - 2022-05-06 15:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:18:22 --> Total execution time: 0.0334
DEBUG - 2022-05-06 15:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:19:33 --> Total execution time: 0.0554
DEBUG - 2022-05-06 15:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:20:16 --> Total execution time: 0.0312
DEBUG - 2022-05-06 15:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:20:54 --> Total execution time: 0.0305
DEBUG - 2022-05-06 15:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:22:03 --> Total execution time: 0.0333
DEBUG - 2022-05-06 15:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:22:41 --> Total execution time: 0.0331
DEBUG - 2022-05-06 15:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:23:17 --> Total execution time: 0.0303
DEBUG - 2022-05-06 15:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:23:56 --> Total execution time: 0.0306
DEBUG - 2022-05-06 15:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:24:31 --> Total execution time: 0.0298
DEBUG - 2022-05-06 15:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:25:14 --> Total execution time: 0.0295
DEBUG - 2022-05-06 15:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:25:43 --> Total execution time: 0.0286
DEBUG - 2022-05-06 15:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:26:27 --> Total execution time: 0.0529
DEBUG - 2022-05-06 15:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:27:01 --> Total execution time: 0.0342
DEBUG - 2022-05-06 15:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:27:35 --> Total execution time: 0.0344
DEBUG - 2022-05-06 15:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:28:29 --> Total execution time: 0.0309
DEBUG - 2022-05-06 15:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:29:27 --> Total execution time: 0.0335
DEBUG - 2022-05-06 15:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 15:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 15:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 15:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:29:57 --> Total execution time: 0.0334
DEBUG - 2022-05-06 16:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:30:32 --> Total execution time: 0.0321
DEBUG - 2022-05-06 16:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:31:26 --> Total execution time: 0.0315
DEBUG - 2022-05-06 16:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:32:04 --> Total execution time: 0.0333
DEBUG - 2022-05-06 16:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:32:55 --> Total execution time: 0.0310
DEBUG - 2022-05-06 16:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:33:43 --> Total execution time: 0.0303
DEBUG - 2022-05-06 16:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:34:17 --> Total execution time: 0.0315
DEBUG - 2022-05-06 16:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:34:47 --> Total execution time: 0.0324
DEBUG - 2022-05-06 16:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:35:32 --> Total execution time: 0.0296
DEBUG - 2022-05-06 16:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:37:04 --> Total execution time: 0.0343
DEBUG - 2022-05-06 16:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:38:28 --> Total execution time: 0.0305
DEBUG - 2022-05-06 16:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:39:00 --> Total execution time: 0.0308
DEBUG - 2022-05-06 16:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:39:37 --> Total execution time: 0.0313
DEBUG - 2022-05-06 16:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:40:17 --> Total execution time: 0.0327
DEBUG - 2022-05-06 16:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:40:54 --> Total execution time: 0.0291
DEBUG - 2022-05-06 16:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:41:33 --> Total execution time: 0.0379
DEBUG - 2022-05-06 16:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:42:06 --> Total execution time: 0.0375
DEBUG - 2022-05-06 16:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:42:43 --> Total execution time: 0.0308
DEBUG - 2022-05-06 16:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:43:17 --> Total execution time: 0.0299
DEBUG - 2022-05-06 16:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:43:45 --> Total execution time: 0.0288
DEBUG - 2022-05-06 16:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:44:21 --> Total execution time: 0.0322
DEBUG - 2022-05-06 16:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:45:23 --> Total execution time: 0.0307
DEBUG - 2022-05-06 16:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:45:59 --> Total execution time: 0.0314
DEBUG - 2022-05-06 16:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:46:25 --> Total execution time: 0.0318
DEBUG - 2022-05-06 16:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:46:57 --> Total execution time: 0.0303
DEBUG - 2022-05-06 16:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:47:27 --> Total execution time: 0.0374
DEBUG - 2022-05-06 16:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:48:06 --> Total execution time: 0.0383
DEBUG - 2022-05-06 16:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:49:02 --> Total execution time: 0.0603
DEBUG - 2022-05-06 16:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:49:31 --> Total execution time: 0.0344
DEBUG - 2022-05-06 16:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:50:16 --> Total execution time: 0.0357
DEBUG - 2022-05-06 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:50:48 --> Total execution time: 0.0296
DEBUG - 2022-05-06 16:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:51:16 --> Total execution time: 0.0291
DEBUG - 2022-05-06 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:51:53 --> Total execution time: 0.0302
DEBUG - 2022-05-06 16:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:52:26 --> Total execution time: 0.0312
DEBUG - 2022-05-06 16:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:53:21 --> Total execution time: 0.0302
DEBUG - 2022-05-06 16:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:53:56 --> Total execution time: 0.0356
DEBUG - 2022-05-06 16:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:54:47 --> Total execution time: 0.0303
DEBUG - 2022-05-06 16:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:55:32 --> Total execution time: 0.0530
DEBUG - 2022-05-06 16:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:56:58 --> Total execution time: 0.0305
DEBUG - 2022-05-06 16:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:57:55 --> Total execution time: 0.0298
DEBUG - 2022-05-06 16:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 21:58:53 --> Total execution time: 0.0301
DEBUG - 2022-05-06 16:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:00:00 --> Total execution time: 0.0334
DEBUG - 2022-05-06 16:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:00:56 --> Total execution time: 0.1398
DEBUG - 2022-05-06 16:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:01:39 --> Total execution time: 0.0295
DEBUG - 2022-05-06 16:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:02:27 --> Total execution time: 0.0342
DEBUG - 2022-05-06 16:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:03:02 --> Total execution time: 0.0298
DEBUG - 2022-05-06 16:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:03:29 --> Total execution time: 0.0282
DEBUG - 2022-05-06 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:04:03 --> Total execution time: 0.0313
DEBUG - 2022-05-06 16:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:04:39 --> Total execution time: 0.0324
DEBUG - 2022-05-06 16:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:05:30 --> Total execution time: 0.0333
DEBUG - 2022-05-06 16:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:06:19 --> Total execution time: 0.0306
DEBUG - 2022-05-06 16:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:07:05 --> Total execution time: 0.0587
DEBUG - 2022-05-06 16:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:07:58 --> Total execution time: 0.0294
DEBUG - 2022-05-06 16:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:08:48 --> Total execution time: 0.0299
DEBUG - 2022-05-06 16:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:09:25 --> Total execution time: 0.0311
DEBUG - 2022-05-06 16:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 16:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 16:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 16:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:10:01 --> Total execution time: 0.0353
DEBUG - 2022-05-06 17:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:24:46 --> No URI present. Default controller set.
DEBUG - 2022-05-06 17:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:54:47 --> Total execution time: 0.9001
DEBUG - 2022-05-06 17:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:57:13 --> Total execution time: 0.0705
DEBUG - 2022-05-06 17:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:57:45 --> Total execution time: 0.0304
DEBUG - 2022-05-06 17:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:58:16 --> Total execution time: 0.0299
DEBUG - 2022-05-06 17:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:58:45 --> Total execution time: 0.0305
DEBUG - 2022-05-06 17:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:59:23 --> Total execution time: 0.0295
DEBUG - 2022-05-06 17:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 22:59:54 --> Total execution time: 0.0304
DEBUG - 2022-05-06 17:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:01:50 --> Total execution time: 0.0284
DEBUG - 2022-05-06 17:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:02:31 --> Total execution time: 0.0517
DEBUG - 2022-05-06 17:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:03:03 --> Total execution time: 0.0286
DEBUG - 2022-05-06 17:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:03:30 --> Total execution time: 0.0351
DEBUG - 2022-05-06 17:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:04:02 --> Total execution time: 0.0317
DEBUG - 2022-05-06 17:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:04:36 --> Total execution time: 0.0300
DEBUG - 2022-05-06 17:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:05:05 --> Total execution time: 0.1007
DEBUG - 2022-05-06 17:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:05:33 --> Total execution time: 0.0303
DEBUG - 2022-05-06 17:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:06:03 --> Total execution time: 0.0298
DEBUG - 2022-05-06 17:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:06:42 --> Total execution time: 0.0307
DEBUG - 2022-05-06 17:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:07:17 --> Total execution time: 0.0307
DEBUG - 2022-05-06 17:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:07:44 --> Total execution time: 0.0310
DEBUG - 2022-05-06 17:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:08:34 --> Total execution time: 0.0308
DEBUG - 2022-05-06 17:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:09:28 --> Total execution time: 0.0293
DEBUG - 2022-05-06 17:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:10:05 --> Total execution time: 0.0309
DEBUG - 2022-05-06 17:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:10:34 --> Total execution time: 0.0296
DEBUG - 2022-05-06 17:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:11:09 --> Total execution time: 0.0305
DEBUG - 2022-05-06 17:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:11:48 --> Total execution time: 0.0587
DEBUG - 2022-05-06 17:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:12:26 --> Total execution time: 0.0314
DEBUG - 2022-05-06 17:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:12:59 --> Total execution time: 0.0339
DEBUG - 2022-05-06 17:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:13:28 --> Total execution time: 0.0301
DEBUG - 2022-05-06 17:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:14:02 --> Total execution time: 0.0300
DEBUG - 2022-05-06 17:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:14:54 --> Total execution time: 0.0303
DEBUG - 2022-05-06 17:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:15:25 --> Total execution time: 0.0300
DEBUG - 2022-05-06 17:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:16:01 --> Total execution time: 0.0291
DEBUG - 2022-05-06 17:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:16:26 --> Total execution time: 0.0292
DEBUG - 2022-05-06 17:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:16:57 --> Total execution time: 0.0309
DEBUG - 2022-05-06 17:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:17:32 --> Total execution time: 0.0351
DEBUG - 2022-05-06 17:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:18:06 --> Total execution time: 0.0285
DEBUG - 2022-05-06 17:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:18:51 --> Total execution time: 0.0300
DEBUG - 2022-05-06 17:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:19:39 --> Total execution time: 0.0524
DEBUG - 2022-05-06 17:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:20:18 --> Total execution time: 0.0303
DEBUG - 2022-05-06 17:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:20:51 --> Total execution time: 0.0291
DEBUG - 2022-05-06 17:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:21:56 --> Total execution time: 0.0312
DEBUG - 2022-05-06 17:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:22:29 --> Total execution time: 0.0295
DEBUG - 2022-05-06 17:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:23:03 --> Total execution time: 0.0328
DEBUG - 2022-05-06 17:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:23:36 --> Total execution time: 0.0297
DEBUG - 2022-05-06 17:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:24:10 --> Total execution time: 0.0300
DEBUG - 2022-05-06 17:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:24:43 --> Total execution time: 0.0358
DEBUG - 2022-05-06 17:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:25:29 --> Total execution time: 0.0309
DEBUG - 2022-05-06 17:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:26:00 --> Total execution time: 0.0302
DEBUG - 2022-05-06 17:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:26:28 --> Total execution time: 0.0305
DEBUG - 2022-05-06 17:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:27:08 --> Total execution time: 0.0309
DEBUG - 2022-05-06 17:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:27:41 --> Total execution time: 0.0304
DEBUG - 2022-05-06 17:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:28:15 --> Total execution time: 0.0291
DEBUG - 2022-05-06 17:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:28:46 --> Total execution time: 0.0321
DEBUG - 2022-05-06 17:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:29:19 --> Total execution time: 0.0295
DEBUG - 2022-05-06 17:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 17:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 17:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 17:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:29:57 --> Total execution time: 0.0330
DEBUG - 2022-05-06 18:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:31:10 --> Total execution time: 0.0663
DEBUG - 2022-05-06 18:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:32:01 --> Total execution time: 0.0642
DEBUG - 2022-05-06 18:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:32:27 --> Total execution time: 0.0321
DEBUG - 2022-05-06 18:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:32:59 --> Total execution time: 0.0586
DEBUG - 2022-05-06 18:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:34:15 --> Total execution time: 0.0568
DEBUG - 2022-05-06 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:37:29 --> Total execution time: 3.6734
DEBUG - 2022-05-06 18:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:38:35 --> Total execution time: 0.1221
DEBUG - 2022-05-06 18:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:39:09 --> Total execution time: 0.0316
DEBUG - 2022-05-06 18:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:39:47 --> Total execution time: 0.0372
DEBUG - 2022-05-06 18:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:40:21 --> Total execution time: 0.0300
DEBUG - 2022-05-06 18:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:40:59 --> Total execution time: 0.0339
DEBUG - 2022-05-06 18:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:41:33 --> Total execution time: 0.0299
DEBUG - 2022-05-06 18:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:42:02 --> Total execution time: 0.0336
DEBUG - 2022-05-06 18:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:42:45 --> Total execution time: 0.0324
DEBUG - 2022-05-06 18:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:43:16 --> Total execution time: 0.0549
DEBUG - 2022-05-06 18:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:43:41 --> Total execution time: 0.0524
DEBUG - 2022-05-06 18:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:44:20 --> Total execution time: 0.7191
DEBUG - 2022-05-06 18:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:44:48 --> Total execution time: 0.0592
DEBUG - 2022-05-06 18:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:45:23 --> Total execution time: 0.0313
DEBUG - 2022-05-06 18:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:45:50 --> Total execution time: 0.1045
DEBUG - 2022-05-06 18:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:46:43 --> Total execution time: 0.0613
DEBUG - 2022-05-06 18:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:47:16 --> Total execution time: 0.0677
DEBUG - 2022-05-06 18:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:47:55 --> Total execution time: 0.0299
DEBUG - 2022-05-06 18:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:48:29 --> Total execution time: 0.0308
DEBUG - 2022-05-06 18:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:49:23 --> Total execution time: 0.0527
DEBUG - 2022-05-06 18:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:49:53 --> Total execution time: 0.0524
DEBUG - 2022-05-06 18:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:50:23 --> Total execution time: 0.0535
DEBUG - 2022-05-06 18:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:51:04 --> Total execution time: 0.0324
DEBUG - 2022-05-06 18:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:51:42 --> Total execution time: 0.0289
DEBUG - 2022-05-06 18:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:52:31 --> Total execution time: 0.0542
DEBUG - 2022-05-06 18:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:53:02 --> Total execution time: 0.0301
DEBUG - 2022-05-06 18:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:53:37 --> Total execution time: 0.0311
DEBUG - 2022-05-06 18:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:54:13 --> Total execution time: 0.0304
DEBUG - 2022-05-06 18:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:54:59 --> Total execution time: 0.0609
DEBUG - 2022-05-06 18:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:55:34 --> Total execution time: 0.0538
DEBUG - 2022-05-06 18:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:56:04 --> Total execution time: 0.0749
DEBUG - 2022-05-06 18:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:56:39 --> Total execution time: 0.0696
DEBUG - 2022-05-06 18:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:57:14 --> Total execution time: 0.0529
DEBUG - 2022-05-06 18:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:57:45 --> Total execution time: 0.0567
DEBUG - 2022-05-06 18:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:58:15 --> Total execution time: 0.0392
DEBUG - 2022-05-06 18:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:58:54 --> Total execution time: 0.0585
DEBUG - 2022-05-06 18:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 23:59:37 --> Total execution time: 0.0292
DEBUG - 2022-05-06 18:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 18:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 18:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 18:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 19:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 19:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 19:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 19:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 19:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 19:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 19:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 19:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 19:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 19:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 19:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 19:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 19:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 19:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 19:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 19:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 19:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 19:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 19:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 19:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 19:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 19:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 19:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 19:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 19:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 19:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 19:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 19:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 19:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 19:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-06 19:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-06 19:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-06 19:05:11 --> Encryption: Auto-configured driver 'openssl'.
