<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-11-11 00:00:26 --> Total execution time: 0.1682
DEBUG - 2022-11-11 00:01:03 --> Total execution time: 0.2065
DEBUG - 2022-11-11 00:01:17 --> Total execution time: 0.2009
DEBUG - 2022-11-11 00:01:21 --> Total execution time: 0.2163
DEBUG - 2022-11-11 00:11:28 --> Total execution time: 0.1141
DEBUG - 2022-11-11 00:15:52 --> Total execution time: 0.1480
DEBUG - 2022-11-11 00:30:05 --> Total execution time: 1.9782
DEBUG - 2022-11-11 00:32:44 --> Total execution time: 0.5661
DEBUG - 2022-11-11 00:32:49 --> Total execution time: 0.1627
DEBUG - 2022-11-11 00:33:45 --> Total execution time: 0.1880
DEBUG - 2022-11-11 00:34:13 --> Total execution time: 0.1714
DEBUG - 2022-11-11 00:35:09 --> Total execution time: 0.1133
DEBUG - 2022-11-11 00:35:26 --> Total execution time: 0.1134
DEBUG - 2022-11-11 00:37:04 --> Total execution time: 0.2478
DEBUG - 2022-11-11 00:37:25 --> Total execution time: 0.2357
DEBUG - 2022-11-11 00:38:03 --> Total execution time: 0.4723
DEBUG - 2022-11-11 00:38:12 --> Total execution time: 0.1701
DEBUG - 2022-11-11 00:39:19 --> Total execution time: 0.1653
DEBUG - 2022-11-11 00:40:29 --> Total execution time: 0.2014
DEBUG - 2022-11-11 00:40:36 --> Total execution time: 0.2098
DEBUG - 2022-11-11 00:53:45 --> Total execution time: 0.6935
DEBUG - 2022-11-11 00:55:42 --> Total execution time: 0.1630
DEBUG - 2022-11-11 00:55:42 --> Total execution time: 0.1631
DEBUG - 2022-11-11 00:55:56 --> Total execution time: 0.2126
DEBUG - 2022-11-11 00:56:02 --> Total execution time: 0.1680
DEBUG - 2022-11-11 00:56:15 --> Total execution time: 0.1666
DEBUG - 2022-11-11 00:57:09 --> Total execution time: 0.1938
DEBUG - 2022-11-11 00:57:28 --> Total execution time: 0.1774
DEBUG - 2022-11-11 00:58:58 --> Total execution time: 0.1802
DEBUG - 2022-11-11 01:04:52 --> Total execution time: 0.9362
DEBUG - 2022-11-11 01:11:16 --> Total execution time: 0.4930
DEBUG - 2022-11-11 01:30:04 --> Total execution time: 1.1359
DEBUG - 2022-11-11 01:39:53 --> Total execution time: 0.1829
DEBUG - 2022-11-11 01:49:25 --> Total execution time: 0.4560
DEBUG - 2022-11-11 01:49:32 --> Total execution time: 0.2042
DEBUG - 2022-11-11 01:49:33 --> Total execution time: 0.1596
DEBUG - 2022-11-11 01:49:39 --> Total execution time: 0.1666
DEBUG - 2022-11-11 01:49:50 --> Total execution time: 0.1628
DEBUG - 2022-11-11 01:49:51 --> Total execution time: 0.1627
DEBUG - 2022-11-11 01:50:11 --> Total execution time: 0.1703
DEBUG - 2022-11-11 02:06:26 --> Total execution time: 0.5666
DEBUG - 2022-11-11 02:06:31 --> Total execution time: 0.1685
DEBUG - 2022-11-11 02:30:02 --> Total execution time: 0.7225
DEBUG - 2022-11-11 02:47:31 --> Total execution time: 0.4991
DEBUG - 2022-11-11 02:47:31 --> Total execution time: 0.1094
DEBUG - 2022-11-11 02:49:09 --> Total execution time: 0.4384
DEBUG - 2022-11-11 03:27:05 --> Total execution time: 1.5122
DEBUG - 2022-11-11 03:27:05 --> Total execution time: 2.8939
DEBUG - 2022-11-11 03:30:02 --> Total execution time: 0.6303
DEBUG - 2022-11-11 03:49:48 --> Total execution time: 0.5267
DEBUG - 2022-11-11 03:49:59 --> Total execution time: 0.1962
DEBUG - 2022-11-11 03:50:00 --> Total execution time: 0.1676
DEBUG - 2022-11-11 03:50:06 --> Total execution time: 0.1979
DEBUG - 2022-11-11 03:50:14 --> Total execution time: 0.1761
DEBUG - 2022-11-11 03:50:24 --> Total execution time: 0.1842
DEBUG - 2022-11-11 03:50:28 --> Total execution time: 0.1631
DEBUG - 2022-11-11 03:50:43 --> Total execution time: 0.2363
DEBUG - 2022-11-11 03:50:51 --> Total execution time: 0.1702
DEBUG - 2022-11-11 03:51:02 --> Total execution time: 0.1685
DEBUG - 2022-11-11 03:51:03 --> Total execution time: 0.1716
DEBUG - 2022-11-11 03:51:03 --> Total execution time: 0.1641
DEBUG - 2022-11-11 03:51:20 --> Total execution time: 0.1659
DEBUG - 2022-11-11 03:51:27 --> Total execution time: 0.1733
DEBUG - 2022-11-11 03:51:35 --> Total execution time: 0.1666
DEBUG - 2022-11-11 03:51:40 --> Total execution time: 0.1969
DEBUG - 2022-11-11 03:51:50 --> Total execution time: 0.2241
DEBUG - 2022-11-11 03:51:59 --> Total execution time: 0.1833
DEBUG - 2022-11-11 03:52:14 --> Total execution time: 0.2260
DEBUG - 2022-11-11 03:52:23 --> Total execution time: 0.2311
DEBUG - 2022-11-11 03:52:34 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-11 03:52:34 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-11-11 03:52:35 --> Total execution time: 0.2022
DEBUG - 2022-11-11 04:30:02 --> Total execution time: 0.7669
DEBUG - 2022-11-11 05:07:14 --> Total execution time: 0.5968
DEBUG - 2022-11-11 05:08:54 --> Total execution time: 0.1220
DEBUG - 2022-11-11 05:10:01 --> Total execution time: 0.1207
DEBUG - 2022-11-11 05:10:07 --> Total execution time: 0.1084
DEBUG - 2022-11-11 05:10:11 --> Total execution time: 0.1068
DEBUG - 2022-11-11 05:10:26 --> Total execution time: 0.1873
DEBUG - 2022-11-11 05:10:34 --> Total execution time: 0.2201
DEBUG - 2022-11-11 05:10:38 --> Total execution time: 0.1717
DEBUG - 2022-11-11 05:10:42 --> Total execution time: 0.1847
DEBUG - 2022-11-11 05:10:43 --> Total execution time: 0.1727
DEBUG - 2022-11-11 05:18:13 --> Total execution time: 0.1837
DEBUG - 2022-11-11 05:19:03 --> Total execution time: 0.1682
DEBUG - 2022-11-11 05:19:04 --> Total execution time: 0.1928
DEBUG - 2022-11-11 05:30:03 --> Total execution time: 0.7366
DEBUG - 2022-11-11 05:34:28 --> Total execution time: 0.4665
DEBUG - 2022-11-11 05:34:39 --> Total execution time: 0.1880
DEBUG - 2022-11-11 05:34:40 --> Total execution time: 0.1724
DEBUG - 2022-11-11 05:34:44 --> Total execution time: 0.2281
DEBUG - 2022-11-11 05:49:45 --> Total execution time: 0.6139
DEBUG - 2022-11-11 05:53:54 --> Total execution time: 0.4715
DEBUG - 2022-11-11 06:05:58 --> Total execution time: 0.4603
DEBUG - 2022-11-11 06:06:30 --> Total execution time: 0.1638
DEBUG - 2022-11-11 06:07:29 --> Total execution time: 0.1615
DEBUG - 2022-11-11 06:16:24 --> Total execution time: 0.5931
DEBUG - 2022-11-11 06:16:31 --> Total execution time: 0.1075
DEBUG - 2022-11-11 06:17:51 --> Total execution time: 0.2122
DEBUG - 2022-11-11 06:18:31 --> Total execution time: 0.2060
DEBUG - 2022-11-11 06:18:39 --> Total execution time: 0.1735
DEBUG - 2022-11-11 06:18:53 --> Total execution time: 0.1776
DEBUG - 2022-11-11 06:20:49 --> Total execution time: 0.1754
DEBUG - 2022-11-11 06:30:03 --> Total execution time: 1.0554
DEBUG - 2022-11-11 06:34:09 --> Total execution time: 0.5329
DEBUG - 2022-11-11 06:34:15 --> Total execution time: 0.1164
DEBUG - 2022-11-11 06:34:41 --> Total execution time: 0.1997
DEBUG - 2022-11-11 06:34:46 --> Total execution time: 0.2391
DEBUG - 2022-11-11 06:34:52 --> Total execution time: 0.1753
DEBUG - 2022-11-11 06:35:02 --> Total execution time: 0.1720
DEBUG - 2022-11-11 06:35:11 --> Total execution time: 0.2102
DEBUG - 2022-11-11 06:35:25 --> Total execution time: 0.2441
DEBUG - 2022-11-11 06:35:40 --> Total execution time: 0.1657
DEBUG - 2022-11-11 06:38:40 --> Total execution time: 0.1698
DEBUG - 2022-11-11 06:45:28 --> Total execution time: 0.1968
DEBUG - 2022-11-11 06:46:05 --> Total execution time: 0.1708
DEBUG - 2022-11-11 06:46:22 --> Total execution time: 0.2228
DEBUG - 2022-11-11 06:46:27 --> Total execution time: 0.1890
DEBUG - 2022-11-11 06:46:30 --> Total execution time: 0.1726
DEBUG - 2022-11-11 06:46:37 --> Total execution time: 0.1135
DEBUG - 2022-11-11 06:48:05 --> Total execution time: 0.1727
DEBUG - 2022-11-11 06:48:10 --> Total execution time: 0.2094
DEBUG - 2022-11-11 06:53:00 --> Total execution time: 0.1052
DEBUG - 2022-11-11 06:53:36 --> Total execution time: 0.1655
DEBUG - 2022-11-11 06:54:06 --> Total execution time: 0.1605
DEBUG - 2022-11-11 06:54:11 --> Total execution time: 0.1598
DEBUG - 2022-11-11 06:54:22 --> Total execution time: 0.1588
DEBUG - 2022-11-11 06:54:26 --> Total execution time: 0.1610
DEBUG - 2022-11-11 06:54:36 --> Total execution time: 0.1024
DEBUG - 2022-11-11 06:54:59 --> Total execution time: 0.1901
DEBUG - 2022-11-11 06:55:02 --> Total execution time: 0.1099
DEBUG - 2022-11-11 06:55:03 --> Total execution time: 0.1004
DEBUG - 2022-11-11 06:55:03 --> Total execution time: 0.1178
DEBUG - 2022-11-11 06:55:13 --> Total execution time: 0.1989
DEBUG - 2022-11-11 06:55:15 --> Total execution time: 0.0998
DEBUG - 2022-11-11 06:56:09 --> Total execution time: 0.2236
DEBUG - 2022-11-11 06:56:11 --> Total execution time: 0.0999
DEBUG - 2022-11-11 06:56:57 --> Total execution time: 0.1689
DEBUG - 2022-11-11 06:57:50 --> Total execution time: 0.1817
DEBUG - 2022-11-11 06:58:04 --> Total execution time: 0.4473
DEBUG - 2022-11-11 06:58:22 --> Total execution time: 0.1781
DEBUG - 2022-11-11 06:58:25 --> Total execution time: 0.0992
DEBUG - 2022-11-11 06:58:45 --> Total execution time: 0.1129
DEBUG - 2022-11-11 06:58:50 --> Total execution time: 0.1730
DEBUG - 2022-11-11 06:59:02 --> Total execution time: 0.1577
DEBUG - 2022-11-11 07:00:24 --> Total execution time: 0.1094
DEBUG - 2022-11-11 07:06:40 --> Total execution time: 0.4420
DEBUG - 2022-11-11 07:07:16 --> Total execution time: 0.1672
DEBUG - 2022-11-11 07:10:00 --> Total execution time: 0.1647
DEBUG - 2022-11-11 07:10:19 --> Total execution time: 0.1694
DEBUG - 2022-11-11 07:12:00 --> Total execution time: 0.1672
DEBUG - 2022-11-11 07:12:13 --> Total execution time: 0.4882
DEBUG - 2022-11-11 07:12:32 --> Total execution time: 0.2580
DEBUG - 2022-11-11 07:12:35 --> Total execution time: 0.1003
DEBUG - 2022-11-11 07:13:05 --> Total execution time: 0.2094
DEBUG - 2022-11-11 07:13:47 --> Total execution time: 0.1799
DEBUG - 2022-11-11 07:13:49 --> Total execution time: 0.1012
DEBUG - 2022-11-11 07:13:58 --> Total execution time: 0.1760
DEBUG - 2022-11-11 07:14:05 --> Total execution time: 0.2041
DEBUG - 2022-11-11 07:14:07 --> Total execution time: 0.1000
DEBUG - 2022-11-11 07:14:30 --> Total execution time: 0.1866
DEBUG - 2022-11-11 07:19:56 --> Total execution time: 0.1104
DEBUG - 2022-11-11 07:19:57 --> Total execution time: 0.1020
DEBUG - 2022-11-11 07:20:03 --> Total execution time: 0.2133
DEBUG - 2022-11-11 07:20:09 --> Total execution time: 0.1709
DEBUG - 2022-11-11 07:20:14 --> Total execution time: 0.2032
DEBUG - 2022-11-11 07:20:25 --> Total execution time: 0.1015
DEBUG - 2022-11-11 07:20:31 --> Total execution time: 0.1883
DEBUG - 2022-11-11 07:20:49 --> Total execution time: 0.1740
DEBUG - 2022-11-11 07:20:50 --> Total execution time: 0.1790
DEBUG - 2022-11-11 07:20:51 --> Total execution time: 0.1958
DEBUG - 2022-11-11 07:21:04 --> Total execution time: 0.1594
DEBUG - 2022-11-11 07:21:19 --> Total execution time: 0.1681
DEBUG - 2022-11-11 07:21:29 --> Total execution time: 0.2039
DEBUG - 2022-11-11 07:23:22 --> Total execution time: 0.1652
DEBUG - 2022-11-11 07:23:23 --> Total execution time: 0.1701
DEBUG - 2022-11-11 07:23:54 --> Total execution time: 0.0981
DEBUG - 2022-11-11 07:26:27 --> Total execution time: 0.1135
DEBUG - 2022-11-11 07:30:02 --> Total execution time: 0.1680
DEBUG - 2022-11-11 05:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:31:20 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:01:20 --> Total execution time: 0.6548
DEBUG - 2022-11-11 05:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:01:26 --> Total execution time: 0.2254
DEBUG - 2022-11-11 05:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:34:11 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:04:12 --> Total execution time: 0.9310
DEBUG - 2022-11-11 05:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:36:28 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:06:29 --> Total execution time: 0.6392
DEBUG - 2022-11-11 05:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:06:39 --> Total execution time: 0.2154
DEBUG - 2022-11-11 05:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:36:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 05:36:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 05:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:06:46 --> Total execution time: 0.2279
DEBUG - 2022-11-11 05:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:07:00 --> Total execution time: 0.7569
DEBUG - 2022-11-11 05:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:37:07 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:07:07 --> Total execution time: 0.1367
DEBUG - 2022-11-11 05:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:37:23 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:07:23 --> Total execution time: 0.1314
DEBUG - 2022-11-11 05:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:37:31 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:07:31 --> Total execution time: 0.1294
DEBUG - 2022-11-11 05:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:37:39 --> Total execution time: 0.1867
DEBUG - 2022-11-11 05:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:37:41 --> Total execution time: 0.2806
DEBUG - 2022-11-11 05:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:37:41 --> Total execution time: 0.2303
DEBUG - 2022-11-11 05:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:38:45 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:08:45 --> Total execution time: 0.1518
DEBUG - 2022-11-11 05:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:38:45 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:08:45 --> Total execution time: 0.1435
DEBUG - 2022-11-11 05:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:39:14 --> Total execution time: 0.1821
DEBUG - 2022-11-11 05:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:39:16 --> Total execution time: 0.2575
DEBUG - 2022-11-11 05:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:39:16 --> Total execution time: 0.1913
DEBUG - 2022-11-11 05:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:10:06 --> Total execution time: 2.4310
DEBUG - 2022-11-11 05:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 05:40:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 05:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:10:22 --> Total execution time: 0.2348
DEBUG - 2022-11-11 05:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:10:29 --> Total execution time: 0.2534
DEBUG - 2022-11-11 05:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:10:30 --> Total execution time: 0.2211
DEBUG - 2022-11-11 05:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:10:46 --> Total execution time: 0.1922
DEBUG - 2022-11-11 05:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:10:51 --> Total execution time: 0.2757
DEBUG - 2022-11-11 05:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:02 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:11:02 --> Total execution time: 0.1349
DEBUG - 2022-11-11 05:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:11:05 --> Total execution time: 0.1906
DEBUG - 2022-11-11 05:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:11:10 --> Total execution time: 0.1974
DEBUG - 2022-11-11 05:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:41:17 --> Total execution time: 0.1873
DEBUG - 2022-11-11 05:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:11:21 --> Total execution time: 0.1827
DEBUG - 2022-11-11 05:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:41:21 --> Total execution time: 0.1964
DEBUG - 2022-11-11 05:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:41:31 --> Total execution time: 0.1967
DEBUG - 2022-11-11 05:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:41:34 --> Total execution time: 0.1923
DEBUG - 2022-11-11 05:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:41:37 --> Total execution time: 0.2586
DEBUG - 2022-11-11 05:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:11:38 --> Total execution time: 0.1910
DEBUG - 2022-11-11 05:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:41:40 --> Total execution time: 0.2005
DEBUG - 2022-11-11 05:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:41:41 --> Total execution time: 0.2344
DEBUG - 2022-11-11 05:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:11:49 --> Total execution time: 0.1905
DEBUG - 2022-11-11 05:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:11:51 --> Total execution time: 0.2589
DEBUG - 2022-11-11 05:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:11:51 --> Total execution time: 0.2646
DEBUG - 2022-11-11 05:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:42:32 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:12:32 --> Total execution time: 0.1426
DEBUG - 2022-11-11 05:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:12:35 --> Total execution time: 0.2303
DEBUG - 2022-11-11 05:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:12:37 --> Total execution time: 0.2015
DEBUG - 2022-11-11 05:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:12:39 --> Total execution time: 0.2296
DEBUG - 2022-11-11 05:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:12:44 --> Total execution time: 0.1893
DEBUG - 2022-11-11 05:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:42:49 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:12:49 --> Total execution time: 0.1384
DEBUG - 2022-11-11 05:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:42:50 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:12:50 --> Total execution time: 0.1270
DEBUG - 2022-11-11 05:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:12:50 --> Total execution time: 0.2048
DEBUG - 2022-11-11 05:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:12:54 --> Total execution time: 0.2004
DEBUG - 2022-11-11 05:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:12:56 --> Total execution time: 0.2169
DEBUG - 2022-11-11 05:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:13:03 --> Total execution time: 0.2171
DEBUG - 2022-11-11 05:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:13:09 --> Total execution time: 0.2248
DEBUG - 2022-11-11 05:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:13:11 --> Total execution time: 0.1984
DEBUG - 2022-11-11 05:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:13:20 --> Total execution time: 0.1925
DEBUG - 2022-11-11 05:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:13:20 --> Total execution time: 0.2033
DEBUG - 2022-11-11 05:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:13:28 --> Total execution time: 0.2087
DEBUG - 2022-11-11 05:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:13:49 --> Total execution time: 0.1329
DEBUG - 2022-11-11 05:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:14:03 --> Total execution time: 0.4139
DEBUG - 2022-11-11 05:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:14:09 --> Total execution time: 0.1968
DEBUG - 2022-11-11 05:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:14:12 --> Total execution time: 0.2123
DEBUG - 2022-11-11 05:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:14:14 --> Total execution time: 0.2732
DEBUG - 2022-11-11 05:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:14:21 --> Total execution time: 0.2995
DEBUG - 2022-11-11 05:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:14:22 --> Total execution time: 0.2043
DEBUG - 2022-11-11 05:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:14:24 --> Total execution time: 0.1816
DEBUG - 2022-11-11 05:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:29 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:14:29 --> Total execution time: 0.1319
DEBUG - 2022-11-11 05:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:14:34 --> Total execution time: 0.1938
DEBUG - 2022-11-11 05:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:35 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:14:35 --> Total execution time: 0.1330
DEBUG - 2022-11-11 05:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:14:41 --> Total execution time: 0.1861
DEBUG - 2022-11-11 05:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:14:49 --> Total execution time: 0.2217
DEBUG - 2022-11-11 05:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:14:51 --> Total execution time: 0.2386
DEBUG - 2022-11-11 05:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:14:58 --> Total execution time: 0.1896
DEBUG - 2022-11-11 05:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:45:02 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:15:02 --> Total execution time: 0.2320
DEBUG - 2022-11-11 05:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:15:05 --> Total execution time: 0.2019
DEBUG - 2022-11-11 05:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:15:11 --> Total execution time: 0.2029
DEBUG - 2022-11-11 05:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:15:16 --> Total execution time: 0.3828
DEBUG - 2022-11-11 05:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:16:09 --> Total execution time: 0.1945
DEBUG - 2022-11-11 05:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:46:27 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:16:27 --> Total execution time: 0.1220
DEBUG - 2022-11-11 05:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:46:36 --> Total execution time: 0.1885
DEBUG - 2022-11-11 05:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:46:38 --> Total execution time: 0.2072
DEBUG - 2022-11-11 05:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:46:39 --> Total execution time: 0.1909
DEBUG - 2022-11-11 05:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:47:21 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:17:21 --> Total execution time: 0.1935
DEBUG - 2022-11-11 05:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:47:27 --> Total execution time: 0.1851
DEBUG - 2022-11-11 05:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:47:29 --> Total execution time: 0.1936
DEBUG - 2022-11-11 05:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:47:30 --> Total execution time: 0.2037
DEBUG - 2022-11-11 05:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:47:43 --> Total execution time: 0.1905
DEBUG - 2022-11-11 05:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:47:44 --> Total execution time: 0.2124
DEBUG - 2022-11-11 05:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:47:46 --> Total execution time: 0.1899
DEBUG - 2022-11-11 05:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:47:46 --> Total execution time: 0.2386
DEBUG - 2022-11-11 05:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:48:45 --> Total execution time: 0.1865
DEBUG - 2022-11-11 05:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:48:47 --> Total execution time: 0.2789
DEBUG - 2022-11-11 05:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:48:48 --> Total execution time: 0.1963
DEBUG - 2022-11-11 05:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:49:06 --> Total execution time: 0.2030
DEBUG - 2022-11-11 05:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:49:08 --> Total execution time: 0.1986
DEBUG - 2022-11-11 05:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:49:08 --> Total execution time: 0.1978
DEBUG - 2022-11-11 05:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:49:29 --> Total execution time: 0.1947
DEBUG - 2022-11-11 05:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:49:30 --> Total execution time: 0.2289
DEBUG - 2022-11-11 05:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:49:31 --> Total execution time: 0.2107
DEBUG - 2022-11-11 05:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:49:31 --> Total execution time: 0.3952
DEBUG - 2022-11-11 05:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:49:32 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:19:32 --> Total execution time: 0.1881
DEBUG - 2022-11-11 05:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:49:32 --> Total execution time: 0.2053
DEBUG - 2022-11-11 05:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:49:33 --> Total execution time: 0.4635
DEBUG - 2022-11-11 05:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:49:35 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:19:35 --> Total execution time: 0.1897
DEBUG - 2022-11-11 05:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:50:23 --> Total execution time: 0.1994
DEBUG - 2022-11-11 05:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:50:25 --> Total execution time: 0.2071
DEBUG - 2022-11-11 05:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:50:25 --> Total execution time: 0.1935
DEBUG - 2022-11-11 05:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:51:07 --> Total execution time: 0.1956
DEBUG - 2022-11-11 05:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:51:08 --> Total execution time: 0.2030
DEBUG - 2022-11-11 05:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:51:09 --> Total execution time: 0.1830
DEBUG - 2022-11-11 05:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 05:51:19 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-11-11 05:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:21:37 --> Total execution time: 0.4605
DEBUG - 2022-11-11 05:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:51:42 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:21:42 --> Total execution time: 0.4593
DEBUG - 2022-11-11 05:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:21:44 --> Total execution time: 0.2118
DEBUG - 2022-11-11 05:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:21:48 --> Total execution time: 0.2568
DEBUG - 2022-11-11 05:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:51:50 --> Total execution time: 0.1852
DEBUG - 2022-11-11 05:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:21:55 --> Total execution time: 0.2342
DEBUG - 2022-11-11 05:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:51:58 --> Total execution time: 0.2013
DEBUG - 2022-11-11 05:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:51:58 --> Total execution time: 0.3750
DEBUG - 2022-11-11 05:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:52:30 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:22:30 --> Total execution time: 0.1323
DEBUG - 2022-11-11 05:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:23:51 --> Total execution time: 2.0182
DEBUG - 2022-11-11 05:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 05:53:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 05:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:55:24 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:25:24 --> Total execution time: 0.1856
DEBUG - 2022-11-11 05:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:55:33 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:25:34 --> Total execution time: 0.1242
DEBUG - 2022-11-11 05:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:25:41 --> Total execution time: 1.7332
DEBUG - 2022-11-11 05:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:56:25 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:26:25 --> Total execution time: 0.1459
DEBUG - 2022-11-11 05:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:57:06 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:27:06 --> Total execution time: 0.1787
DEBUG - 2022-11-11 05:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:27:10 --> Total execution time: 0.1261
DEBUG - 2022-11-11 05:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:27:12 --> Total execution time: 0.1291
DEBUG - 2022-11-11 05:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:27:21 --> Total execution time: 0.2252
DEBUG - 2022-11-11 05:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:27:22 --> Total execution time: 0.2246
DEBUG - 2022-11-11 05:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:27:29 --> Total execution time: 0.2756
DEBUG - 2022-11-11 05:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:27:31 --> Total execution time: 0.1964
DEBUG - 2022-11-11 05:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:27:37 --> Total execution time: 0.2841
DEBUG - 2022-11-11 05:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:27:44 --> Total execution time: 0.2714
DEBUG - 2022-11-11 05:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:27:59 --> Total execution time: 0.2007
DEBUG - 2022-11-11 05:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:58:06 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:28:06 --> Total execution time: 0.1297
DEBUG - 2022-11-11 05:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:58:15 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:28:16 --> Total execution time: 0.1499
DEBUG - 2022-11-11 05:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:58:16 --> Total execution time: 0.1926
DEBUG - 2022-11-11 05:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:58:18 --> Total execution time: 0.1949
DEBUG - 2022-11-11 05:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:58:18 --> Total execution time: 0.1850
DEBUG - 2022-11-11 05:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:58:39 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:28:39 --> Total execution time: 0.1886
DEBUG - 2022-11-11 05:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:28:47 --> Total execution time: 0.4818
DEBUG - 2022-11-11 05:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:29:18 --> Total execution time: 0.2907
DEBUG - 2022-11-11 05:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:29:18 --> Total execution time: 0.2126
DEBUG - 2022-11-11 05:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 05:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:59:29 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:29:29 --> Total execution time: 0.1370
DEBUG - 2022-11-11 05:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:59:30 --> No URI present. Default controller set.
DEBUG - 2022-11-11 05:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:29:30 --> Total execution time: 0.2147
DEBUG - 2022-11-11 05:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:29:40 --> Total execution time: 0.1839
DEBUG - 2022-11-11 05:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 05:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 05:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:29:55 --> Total execution time: 0.2014
DEBUG - 2022-11-11 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:30:03 --> Total execution time: 0.1955
DEBUG - 2022-11-11 06:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:00:28 --> Total execution time: 0.4756
DEBUG - 2022-11-11 06:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:00:31 --> Total execution time: 0.2609
DEBUG - 2022-11-11 06:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:00:31 --> Total execution time: 0.4444
DEBUG - 2022-11-11 06:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:00:38 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:30:38 --> Total execution time: 0.1280
DEBUG - 2022-11-11 06:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:00:40 --> Total execution time: 0.2165
DEBUG - 2022-11-11 06:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:00:42 --> Total execution time: 0.2019
DEBUG - 2022-11-11 06:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:00:42 --> Total execution time: 0.1835
DEBUG - 2022-11-11 06:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:30:45 --> Total execution time: 0.2313
DEBUG - 2022-11-11 06:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:30:47 --> Total execution time: 0.1491
DEBUG - 2022-11-11 06:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:00:58 --> Total execution time: 0.1967
DEBUG - 2022-11-11 06:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:00:59 --> Total execution time: 0.1847
DEBUG - 2022-11-11 06:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:01:00 --> Total execution time: 0.2010
DEBUG - 2022-11-11 06:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:01:18 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:31:18 --> Total execution time: 0.1430
DEBUG - 2022-11-11 06:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:31:18 --> Total execution time: 0.2200
DEBUG - 2022-11-11 06:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:31:19 --> Total execution time: 0.2648
DEBUG - 2022-11-11 06:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:31:25 --> Total execution time: 0.2336
DEBUG - 2022-11-11 06:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:31:29 --> Total execution time: 0.1916
DEBUG - 2022-11-11 06:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:31:34 --> Total execution time: 0.1923
DEBUG - 2022-11-11 06:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:31:45 --> Total execution time: 0.2032
DEBUG - 2022-11-11 06:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:31:51 --> Total execution time: 0.2032
DEBUG - 2022-11-11 06:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:01:55 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:31:55 --> Total execution time: 0.4579
DEBUG - 2022-11-11 06:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:32:02 --> Total execution time: 0.1873
DEBUG - 2022-11-11 06:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:32:10 --> Total execution time: 0.2403
DEBUG - 2022-11-11 06:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:32:20 --> Total execution time: 0.2021
DEBUG - 2022-11-11 06:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:02:33 --> Total execution time: 0.1818
DEBUG - 2022-11-11 06:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:02:37 --> Total execution time: 0.1888
DEBUG - 2022-11-11 06:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:02:39 --> Total execution time: 0.1878
DEBUG - 2022-11-11 06:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:02:39 --> Total execution time: 0.4251
DEBUG - 2022-11-11 06:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:32:44 --> Total execution time: 0.3394
DEBUG - 2022-11-11 06:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:32:50 --> Total execution time: 0.2303
DEBUG - 2022-11-11 06:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:32:53 --> Total execution time: 0.2384
DEBUG - 2022-11-11 06:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:33:07 --> Total execution time: 0.1281
DEBUG - 2022-11-11 06:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:33:12 --> Total execution time: 0.1824
DEBUG - 2022-11-11 06:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:33:18 --> Total execution time: 0.1857
DEBUG - 2022-11-11 06:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:33:20 --> Total execution time: 0.1901
DEBUG - 2022-11-11 06:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:33:27 --> Total execution time: 0.1866
DEBUG - 2022-11-11 06:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:29 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:33:29 --> Total execution time: 0.1292
DEBUG - 2022-11-11 06:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:33:31 --> Total execution time: 0.2081
DEBUG - 2022-11-11 06:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:33:31 --> Total execution time: 0.1933
DEBUG - 2022-11-11 06:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:33:36 --> Total execution time: 0.1281
DEBUG - 2022-11-11 06:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:33:36 --> Total execution time: 0.1952
DEBUG - 2022-11-11 06:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:33:39 --> Total execution time: 0.2300
DEBUG - 2022-11-11 06:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:33:45 --> Total execution time: 0.2104
DEBUG - 2022-11-11 06:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:33:48 --> Total execution time: 0.2704
DEBUG - 2022-11-11 06:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 06:03:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 06:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:33:53 --> Total execution time: 0.2500
DEBUG - 2022-11-11 06:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:33:55 --> Total execution time: 0.2381
DEBUG - 2022-11-11 06:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:04:02 --> Total execution time: 0.1955
DEBUG - 2022-11-11 06:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:34:02 --> Total execution time: 0.2126
DEBUG - 2022-11-11 06:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:04:03 --> Total execution time: 0.2009
DEBUG - 2022-11-11 06:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:04:03 --> Total execution time: 0.4242
DEBUG - 2022-11-11 06:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:34:11 --> Total execution time: 0.2586
DEBUG - 2022-11-11 06:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:34:14 --> Total execution time: 0.2389
DEBUG - 2022-11-11 06:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:34:26 --> Total execution time: 0.1829
DEBUG - 2022-11-11 06:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:34:28 --> Total execution time: 0.1943
DEBUG - 2022-11-11 06:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:34:28 --> Total execution time: 0.2568
DEBUG - 2022-11-11 06:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:34:30 --> Total execution time: 0.1980
DEBUG - 2022-11-11 06:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:34 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:34:34 --> Total execution time: 0.1397
DEBUG - 2022-11-11 06:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:34:41 --> Total execution time: 0.2785
DEBUG - 2022-11-11 06:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:34:42 --> Total execution time: 0.1819
DEBUG - 2022-11-11 06:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:34:54 --> Total execution time: 0.1901
DEBUG - 2022-11-11 06:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:35:01 --> Total execution time: 0.1889
DEBUG - 2022-11-11 06:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:35:04 --> Total execution time: 0.2641
DEBUG - 2022-11-11 06:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:35:06 --> Total execution time: 0.1534
DEBUG - 2022-11-11 06:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:35:14 --> Total execution time: 0.1980
DEBUG - 2022-11-11 06:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:35:19 --> Total execution time: 0.1956
DEBUG - 2022-11-11 06:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:35:20 --> Total execution time: 0.2347
DEBUG - 2022-11-11 06:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:35:22 --> Total execution time: 0.1859
DEBUG - 2022-11-11 06:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:35:25 --> Total execution time: 0.2228
DEBUG - 2022-11-11 06:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:31 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:35:31 --> Total execution time: 0.1986
DEBUG - 2022-11-11 06:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:35:33 --> Total execution time: 0.2076
DEBUG - 2022-11-11 06:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:35:37 --> Total execution time: 0.1783
DEBUG - 2022-11-11 06:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:35:50 --> Total execution time: 0.1953
DEBUG - 2022-11-11 06:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:35:50 --> Total execution time: 0.2002
DEBUG - 2022-11-11 06:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:02 --> Total execution time: 2.2636
DEBUG - 2022-11-11 06:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:08 --> Total execution time: 0.1910
DEBUG - 2022-11-11 06:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:15 --> Total execution time: 0.1958
DEBUG - 2022-11-11 06:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:16 --> Total execution time: 0.2156
DEBUG - 2022-11-11 06:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:18 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:18 --> Total execution time: 0.1460
DEBUG - 2022-11-11 06:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:24 --> Total execution time: 0.1825
DEBUG - 2022-11-11 06:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:27 --> Total execution time: 0.1933
DEBUG - 2022-11-11 06:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:30 --> Total execution time: 0.2794
DEBUG - 2022-11-11 06:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:31 --> Total execution time: 0.1940
DEBUG - 2022-11-11 06:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:35 --> Total execution time: 0.1909
DEBUG - 2022-11-11 06:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:36 --> Total execution time: 0.1810
DEBUG - 2022-11-11 06:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:36 --> Total execution time: 0.1903
DEBUG - 2022-11-11 06:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:40 --> Total execution time: 0.4997
DEBUG - 2022-11-11 06:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:44 --> Total execution time: 0.2020
DEBUG - 2022-11-11 06:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:48 --> Total execution time: 0.2622
DEBUG - 2022-11-11 06:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:49 --> Total execution time: 0.1976
DEBUG - 2022-11-11 06:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:36:58 --> Total execution time: 0.2328
DEBUG - 2022-11-11 06:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:37:05 --> Total execution time: 0.2247
DEBUG - 2022-11-11 06:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:37:06 --> Total execution time: 0.1906
DEBUG - 2022-11-11 06:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:37:06 --> Total execution time: 0.1886
DEBUG - 2022-11-11 06:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:07:09 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:37:10 --> Total execution time: 0.1589
DEBUG - 2022-11-11 06:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:37:18 --> Total execution time: 0.1941
DEBUG - 2022-11-11 06:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:37:21 --> Total execution time: 0.1895
DEBUG - 2022-11-11 06:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:07:22 --> Total execution time: 0.1964
DEBUG - 2022-11-11 06:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:07:23 --> Total execution time: 0.2170
DEBUG - 2022-11-11 06:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:07:24 --> Total execution time: 0.1835
DEBUG - 2022-11-11 06:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:37:39 --> Total execution time: 0.2147
DEBUG - 2022-11-11 06:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:07:59 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:37:59 --> Total execution time: 0.1342
DEBUG - 2022-11-11 06:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:38:02 --> Total execution time: 0.1912
DEBUG - 2022-11-11 06:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:38:04 --> Total execution time: 0.2020
DEBUG - 2022-11-11 06:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:08:17 --> Total execution time: 0.1979
DEBUG - 2022-11-11 06:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:08:18 --> Total execution time: 0.1908
DEBUG - 2022-11-11 06:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:08:19 --> Total execution time: 0.4053
DEBUG - 2022-11-11 06:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:38:20 --> Total execution time: 0.2268
DEBUG - 2022-11-11 06:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:38:28 --> Total execution time: 0.1184
DEBUG - 2022-11-11 06:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:38:32 --> Total execution time: 0.2175
DEBUG - 2022-11-11 06:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:38:34 --> Total execution time: 0.2034
DEBUG - 2022-11-11 06:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:38:36 --> Total execution time: 0.4685
DEBUG - 2022-11-11 06:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:38:45 --> Total execution time: 0.2431
DEBUG - 2022-11-11 06:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:38:59 --> Total execution time: 0.1882
DEBUG - 2022-11-11 06:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:38:59 --> Total execution time: 0.2498
DEBUG - 2022-11-11 06:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:39:03 --> Total execution time: 1.7456
DEBUG - 2022-11-11 06:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:39:06 --> Total execution time: 0.1933
DEBUG - 2022-11-11 06:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:39:11 --> Total execution time: 0.2419
DEBUG - 2022-11-11 06:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:39:17 --> Total execution time: 0.1928
DEBUG - 2022-11-11 06:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:39:30 --> Total execution time: 0.2650
DEBUG - 2022-11-11 06:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:40:08 --> Total execution time: 0.2393
DEBUG - 2022-11-11 06:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:40:14 --> Total execution time: 0.2175
DEBUG - 2022-11-11 06:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:10:27 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:40:27 --> Total execution time: 0.1325
DEBUG - 2022-11-11 06:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:10:28 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:40:28 --> Total execution time: 0.1319
DEBUG - 2022-11-11 06:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:40:34 --> Total execution time: 0.1910
DEBUG - 2022-11-11 06:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:10:34 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:40:34 --> Total execution time: 0.1467
DEBUG - 2022-11-11 06:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:10:44 --> Total execution time: 0.2390
DEBUG - 2022-11-11 06:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:40:48 --> Total execution time: 0.2239
DEBUG - 2022-11-11 06:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:40:50 --> Total execution time: 0.2039
DEBUG - 2022-11-11 06:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:40:50 --> Total execution time: 0.1967
DEBUG - 2022-11-11 06:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:10:50 --> Total execution time: 0.1905
DEBUG - 2022-11-11 06:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:10:51 --> Total execution time: 0.4370
DEBUG - 2022-11-11 06:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:40:58 --> Total execution time: 0.2816
DEBUG - 2022-11-11 06:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:41:04 --> Total execution time: 0.2392
DEBUG - 2022-11-11 06:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:41:19 --> Total execution time: 0.2287
DEBUG - 2022-11-11 06:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:41:28 --> Total execution time: 0.2177
DEBUG - 2022-11-11 06:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:11:35 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:41:35 --> Total execution time: 0.2307
DEBUG - 2022-11-11 06:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:41:39 --> Total execution time: 0.2002
DEBUG - 2022-11-11 06:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:41:48 --> Total execution time: 0.1879
DEBUG - 2022-11-11 06:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:42:29 --> Total execution time: 1.8190
DEBUG - 2022-11-11 06:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:42:40 --> Total execution time: 0.5069
DEBUG - 2022-11-11 06:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:42:43 --> Total execution time: 0.2051
DEBUG - 2022-11-11 06:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:42:44 --> Total execution time: 0.8932
DEBUG - 2022-11-11 06:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:42:46 --> Total execution time: 0.4996
DEBUG - 2022-11-11 06:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:42:47 --> Total execution time: 0.2183
DEBUG - 2022-11-11 06:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:42:49 --> Total execution time: 0.2716
DEBUG - 2022-11-11 06:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:42:51 --> Total execution time: 0.2289
DEBUG - 2022-11-11 06:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:42:54 --> Total execution time: 0.2027
DEBUG - 2022-11-11 06:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:42:58 --> Total execution time: 0.2525
DEBUG - 2022-11-11 06:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:42:59 --> Total execution time: 0.2311
DEBUG - 2022-11-11 06:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:43:00 --> Total execution time: 0.1978
DEBUG - 2022-11-11 06:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:43:06 --> Total execution time: 0.1897
DEBUG - 2022-11-11 06:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:43:09 --> Total execution time: 0.2373
DEBUG - 2022-11-11 06:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:13:23 --> Total execution time: 0.2301
DEBUG - 2022-11-11 06:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:13:33 --> Total execution time: 0.2592
DEBUG - 2022-11-11 06:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:43:38 --> Total execution time: 0.4908
DEBUG - 2022-11-11 06:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:44:54 --> Total execution time: 0.2516
DEBUG - 2022-11-11 06:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:44:56 --> Total execution time: 0.2263
DEBUG - 2022-11-11 06:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:45:00 --> Total execution time: 0.2269
DEBUG - 2022-11-11 06:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 17:45:01 --> Total execution time: 0.2170
DEBUG - 2022-11-11 06:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:45:02 --> Total execution time: 0.4716
DEBUG - 2022-11-11 06:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:45:02 --> Total execution time: 0.7518
DEBUG - 2022-11-11 06:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:45:03 --> Total execution time: 1.0066
DEBUG - 2022-11-11 06:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:45:05 --> Total execution time: 0.2348
DEBUG - 2022-11-11 06:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:45:42 --> Total execution time: 0.2197
DEBUG - 2022-11-11 06:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:45:42 --> Total execution time: 0.2137
DEBUG - 2022-11-11 06:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:15:47 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:45:47 --> Total execution time: 0.1392
DEBUG - 2022-11-11 06:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:15:48 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:45:48 --> Total execution time: 0.1868
DEBUG - 2022-11-11 06:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:45:49 --> Total execution time: 0.2246
DEBUG - 2022-11-11 06:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:15:59 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:45:59 --> Total execution time: 0.2086
DEBUG - 2022-11-11 06:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:46:21 --> Total execution time: 0.2211
DEBUG - 2022-11-11 06:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:46:30 --> Total execution time: 0.3010
DEBUG - 2022-11-11 06:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:46:30 --> Total execution time: 0.2102
DEBUG - 2022-11-11 06:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:46:39 --> Total execution time: 0.1871
DEBUG - 2022-11-11 06:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:46:51 --> Total execution time: 0.1895
DEBUG - 2022-11-11 06:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:47:18 --> Total execution time: 0.2334
DEBUG - 2022-11-11 06:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:47:26 --> Total execution time: 0.2304
DEBUG - 2022-11-11 06:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:47:42 --> Total execution time: 0.2152
DEBUG - 2022-11-11 06:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:47:49 --> Total execution time: 0.2113
DEBUG - 2022-11-11 06:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:47:52 --> Total execution time: 0.2668
DEBUG - 2022-11-11 06:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:47:53 --> Total execution time: 0.2025
DEBUG - 2022-11-11 06:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:48:03 --> Total execution time: 0.1760
DEBUG - 2022-11-11 06:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:48:03 --> Total execution time: 0.1815
DEBUG - 2022-11-11 06:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:48:11 --> Total execution time: 0.2181
DEBUG - 2022-11-11 06:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:18:23 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:48:23 --> Total execution time: 0.1262
DEBUG - 2022-11-11 06:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:48:34 --> Total execution time: 0.1782
DEBUG - 2022-11-11 06:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:18:38 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:48:38 --> Total execution time: 0.1271
DEBUG - 2022-11-11 06:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:48:42 --> Total execution time: 0.1872
DEBUG - 2022-11-11 06:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:48:55 --> Total execution time: 0.2027
DEBUG - 2022-11-11 06:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:49:02 --> Total execution time: 0.2189
DEBUG - 2022-11-11 06:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:49:43 --> Total execution time: 0.1747
DEBUG - 2022-11-11 06:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:49:51 --> Total execution time: 0.1780
DEBUG - 2022-11-11 06:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:51:08 --> Total execution time: 0.5304
DEBUG - 2022-11-11 06:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:51:10 --> Total execution time: 0.4514
DEBUG - 2022-11-11 06:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:51:19 --> Total execution time: 0.1882
DEBUG - 2022-11-11 06:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:51:28 --> Total execution time: 0.1748
DEBUG - 2022-11-11 06:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:21:35 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:51:36 --> Total execution time: 0.1549
DEBUG - 2022-11-11 06:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:22:10 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:52:10 --> Total execution time: 0.1148
DEBUG - 2022-11-11 06:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:52:13 --> Total execution time: 0.1666
DEBUG - 2022-11-11 06:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:22:14 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:52:14 --> Total execution time: 0.1779
DEBUG - 2022-11-11 06:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:22:15 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:52:15 --> Total execution time: 0.4804
DEBUG - 2022-11-11 06:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:52:19 --> Total execution time: 0.1870
DEBUG - 2022-11-11 06:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:22:59 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:52:59 --> Total execution time: 0.4563
DEBUG - 2022-11-11 06:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:53:01 --> Total execution time: 0.2467
DEBUG - 2022-11-11 06:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:53:09 --> Total execution time: 0.3186
DEBUG - 2022-11-11 06:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:53:45 --> Total execution time: 3.5230
DEBUG - 2022-11-11 06:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:54:22 --> Total execution time: 0.3512
DEBUG - 2022-11-11 06:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:54:28 --> Total execution time: 0.4850
DEBUG - 2022-11-11 06:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:54:29 --> Total execution time: 0.1929
DEBUG - 2022-11-11 06:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:54:38 --> Total execution time: 0.4541
DEBUG - 2022-11-11 06:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:24:52 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:54:52 --> Total execution time: 0.1495
DEBUG - 2022-11-11 06:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:24:53 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:54:53 --> Total execution time: 0.1088
DEBUG - 2022-11-11 06:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:54:59 --> Total execution time: 0.1730
DEBUG - 2022-11-11 06:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:55:14 --> Total execution time: 0.4602
DEBUG - 2022-11-11 06:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:55:23 --> Total execution time: 0.1973
DEBUG - 2022-11-11 06:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:55:26 --> Total execution time: 0.1906
DEBUG - 2022-11-11 06:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:55:33 --> Total execution time: 0.1902
DEBUG - 2022-11-11 06:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:56:06 --> Total execution time: 0.1062
DEBUG - 2022-11-11 06:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:56:06 --> Total execution time: 0.1876
DEBUG - 2022-11-11 06:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:56:14 --> Total execution time: 0.1755
DEBUG - 2022-11-11 06:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:56:39 --> Total execution time: 0.1747
DEBUG - 2022-11-11 06:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:04 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:57:05 --> Total execution time: 0.6035
DEBUG - 2022-11-11 06:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:57:09 --> Total execution time: 0.1691
DEBUG - 2022-11-11 06:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:57:10 --> Total execution time: 0.1626
DEBUG - 2022-11-11 06:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:57:21 --> Total execution time: 0.4924
DEBUG - 2022-11-11 06:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:57:21 --> Total execution time: 0.1892
DEBUG - 2022-11-11 06:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:27:27 --> Total execution time: 0.1751
DEBUG - 2022-11-11 06:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:27:28 --> Total execution time: 0.1734
DEBUG - 2022-11-11 06:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:57:33 --> Total execution time: 0.1726
DEBUG - 2022-11-11 06:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:57:35 --> Total execution time: 0.3167
DEBUG - 2022-11-11 06:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 06:27:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 06:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:27:47 --> Total execution time: 0.1795
DEBUG - 2022-11-11 06:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:57:49 --> Total execution time: 0.1932
DEBUG - 2022-11-11 06:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:57:54 --> Total execution time: 0.1745
DEBUG - 2022-11-11 06:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:57:56 --> Total execution time: 0.4345
DEBUG - 2022-11-11 06:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:57:58 --> Total execution time: 0.2758
DEBUG - 2022-11-11 06:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:58:01 --> Total execution time: 0.2080
DEBUG - 2022-11-11 06:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:28:02 --> Total execution time: 0.1723
DEBUG - 2022-11-11 06:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:28:05 --> Total execution time: 0.1745
DEBUG - 2022-11-11 06:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:28:05 --> Total execution time: 0.4032
DEBUG - 2022-11-11 06:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:58:07 --> Total execution time: 0.2726
DEBUG - 2022-11-11 06:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:58:07 --> Total execution time: 0.2023
DEBUG - 2022-11-11 06:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:58:10 --> Total execution time: 0.2479
DEBUG - 2022-11-11 06:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:58:13 --> Total execution time: 0.4081
DEBUG - 2022-11-11 06:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:58:17 --> Total execution time: 0.4469
DEBUG - 2022-11-11 06:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:58:21 --> Total execution time: 0.1966
DEBUG - 2022-11-11 06:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:58:29 --> Total execution time: 0.1728
DEBUG - 2022-11-11 06:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:58:34 --> Total execution time: 0.2546
DEBUG - 2022-11-11 06:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:58:39 --> Total execution time: 0.1675
DEBUG - 2022-11-11 06:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:58:51 --> Total execution time: 0.1719
DEBUG - 2022-11-11 06:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:58:57 --> Total execution time: 0.1948
DEBUG - 2022-11-11 06:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:59:00 --> Total execution time: 0.1879
DEBUG - 2022-11-11 06:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:59:05 --> Total execution time: 0.2148
DEBUG - 2022-11-11 06:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:09 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:59:09 --> Total execution time: 0.1737
DEBUG - 2022-11-11 06:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:59:12 --> Total execution time: 0.1896
DEBUG - 2022-11-11 06:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:59:16 --> Total execution time: 0.2221
DEBUG - 2022-11-11 06:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:59:18 --> Total execution time: 0.2011
DEBUG - 2022-11-11 06:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:59:20 --> Total execution time: 0.1885
DEBUG - 2022-11-11 06:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:59:20 --> Total execution time: 0.2215
DEBUG - 2022-11-11 06:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:59:20 --> Total execution time: 0.1956
DEBUG - 2022-11-11 06:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:59:31 --> Total execution time: 0.2251
DEBUG - 2022-11-11 06:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:59:36 --> Total execution time: 0.2210
DEBUG - 2022-11-11 06:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:59:38 --> Total execution time: 0.2204
DEBUG - 2022-11-11 06:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:59:47 --> Total execution time: 0.1752
DEBUG - 2022-11-11 06:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:59:49 --> Total execution time: 0.1684
DEBUG - 2022-11-11 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:59:57 --> Total execution time: 0.2330
DEBUG - 2022-11-11 06:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:59:59 --> Total execution time: 0.5120
DEBUG - 2022-11-11 06:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:00:11 --> Total execution time: 0.1877
DEBUG - 2022-11-11 06:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:00:33 --> Total execution time: 0.1860
DEBUG - 2022-11-11 06:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:00:35 --> Total execution time: 0.2043
DEBUG - 2022-11-11 06:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:30:43 --> Total execution time: 0.1806
DEBUG - 2022-11-11 06:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:30:46 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:00:46 --> Total execution time: 0.1665
DEBUG - 2022-11-11 06:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:00:49 --> Total execution time: 0.1654
DEBUG - 2022-11-11 06:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:00:57 --> Total execution time: 0.2017
DEBUG - 2022-11-11 06:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:00:59 --> Total execution time: 0.1931
DEBUG - 2022-11-11 06:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:01 --> Total execution time: 0.3495
DEBUG - 2022-11-11 06:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:05 --> Total execution time: 0.1593
DEBUG - 2022-11-11 06:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:10 --> Total execution time: 0.1826
DEBUG - 2022-11-11 06:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:20 --> Total execution time: 0.1818
DEBUG - 2022-11-11 06:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:25 --> Total execution time: 0.1704
DEBUG - 2022-11-11 06:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:26 --> Total execution time: 0.1773
DEBUG - 2022-11-11 06:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:30 --> Total execution time: 0.2577
DEBUG - 2022-11-11 06:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:31 --> Total execution time: 0.2793
DEBUG - 2022-11-11 06:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:31 --> Total execution time: 0.3035
DEBUG - 2022-11-11 06:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:33 --> Total execution time: 0.7226
DEBUG - 2022-11-11 06:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:34 --> Total execution time: 0.2244
DEBUG - 2022-11-11 06:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:37 --> Total execution time: 0.1666
DEBUG - 2022-11-11 06:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:41 --> Total execution time: 0.1606
DEBUG - 2022-11-11 06:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:44 --> Total execution time: 0.1652
DEBUG - 2022-11-11 06:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:44 --> Total execution time: 0.3734
DEBUG - 2022-11-11 06:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:45 --> Total execution time: 0.1896
DEBUG - 2022-11-11 06:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:54 --> Total execution time: 0.1969
DEBUG - 2022-11-11 06:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:55 --> Total execution time: 0.2148
DEBUG - 2022-11-11 06:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:55 --> Total execution time: 0.2966
DEBUG - 2022-11-11 06:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:57 --> Total execution time: 0.4344
DEBUG - 2022-11-11 06:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 06:31:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 06:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:01:59 --> Total execution time: 0.4009
DEBUG - 2022-11-11 18:02:00 --> Total execution time: 1.8336
DEBUG - 2022-11-11 06:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:32:02 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:02:03 --> Total execution time: 0.1520
DEBUG - 2022-11-11 06:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:32:04 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:02:05 --> Total execution time: 0.1703
DEBUG - 2022-11-11 06:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:02:08 --> Total execution time: 0.1901
DEBUG - 2022-11-11 06:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:02:14 --> Total execution time: 0.2508
DEBUG - 2022-11-11 06:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:02:16 --> Total execution time: 0.1665
DEBUG - 2022-11-11 06:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:02:21 --> Total execution time: 0.1902
DEBUG - 2022-11-11 06:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:02:31 --> Total execution time: 0.2629
DEBUG - 2022-11-11 06:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:02:34 --> Total execution time: 0.4137
DEBUG - 2022-11-11 06:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:32:49 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:02:49 --> Total execution time: 0.6061
DEBUG - 2022-11-11 06:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:03 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:03:04 --> Total execution time: 0.1989
DEBUG - 2022-11-11 06:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:05 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:03:05 --> Total execution time: 0.1674
DEBUG - 2022-11-11 06:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:03:08 --> Total execution time: 0.6631
DEBUG - 2022-11-11 06:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:03:13 --> Total execution time: 0.1742
DEBUG - 2022-11-11 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:17 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:03:18 --> Total execution time: 0.2012
DEBUG - 2022-11-11 06:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:18 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:03:18 --> Total execution time: 0.1732
DEBUG - 2022-11-11 06:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:03:23 --> Total execution time: 0.1757
DEBUG - 2022-11-11 06:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:33:28 --> Total execution time: 0.1737
DEBUG - 2022-11-11 06:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:33:33 --> Total execution time: 0.1782
DEBUG - 2022-11-11 06:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:37 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:03:37 --> Total execution time: 0.1717
DEBUG - 2022-11-11 06:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:33:38 --> Total execution time: 0.1698
DEBUG - 2022-11-11 06:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:03:48 --> Total execution time: 0.2345
DEBUG - 2022-11-11 06:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:03:58 --> Total execution time: 0.1641
DEBUG - 2022-11-11 06:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:34:01 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:04:01 --> Total execution time: 0.1737
DEBUG - 2022-11-11 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:04:07 --> Total execution time: 0.1716
DEBUG - 2022-11-11 06:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:34:10 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:04:10 --> Total execution time: 0.1129
DEBUG - 2022-11-11 06:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:04:12 --> Total execution time: 0.2120
DEBUG - 2022-11-11 06:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:04:15 --> Total execution time: 0.1570
DEBUG - 2022-11-11 06:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:04:21 --> Total execution time: 0.1820
DEBUG - 2022-11-11 06:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:04:29 --> Total execution time: 0.2343
DEBUG - 2022-11-11 06:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:04:39 --> Total execution time: 0.1757
DEBUG - 2022-11-11 06:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:04:43 --> Total execution time: 0.2070
DEBUG - 2022-11-11 06:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:04:49 --> Total execution time: 0.3229
DEBUG - 2022-11-11 06:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:05:02 --> Total execution time: 0.2357
DEBUG - 2022-11-11 06:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:05:04 --> Total execution time: 0.2011
DEBUG - 2022-11-11 06:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:05:15 --> Total execution time: 0.1822
DEBUG - 2022-11-11 06:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:35:18 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:05:18 --> Total execution time: 0.1142
DEBUG - 2022-11-11 06:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:35:18 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:05:18 --> Total execution time: 0.1723
DEBUG - 2022-11-11 06:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:05:23 --> Total execution time: 0.2501
DEBUG - 2022-11-11 06:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:05:35 --> Total execution time: 0.1191
DEBUG - 2022-11-11 06:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:05:44 --> Total execution time: 0.2088
DEBUG - 2022-11-11 06:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:05:45 --> Total execution time: 0.1857
DEBUG - 2022-11-11 06:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:05:59 --> Total execution time: 0.1705
DEBUG - 2022-11-11 06:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:36:00 --> Total execution time: 0.1678
DEBUG - 2022-11-11 06:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:36:02 --> Total execution time: 0.2106
DEBUG - 2022-11-11 06:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:36:02 --> Total execution time: 0.1646
DEBUG - 2022-11-11 06:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:06:03 --> Total execution time: 0.1867
DEBUG - 2022-11-11 06:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:06:13 --> Total execution time: 0.1868
DEBUG - 2022-11-11 06:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:06:22 --> Total execution time: 0.2171
DEBUG - 2022-11-11 06:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:36:25 --> Total execution time: 0.1626
DEBUG - 2022-11-11 06:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:06:29 --> Total execution time: 0.1736
DEBUG - 2022-11-11 06:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:06:36 --> Total execution time: 0.2447
DEBUG - 2022-11-11 06:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:06:56 --> Total execution time: 0.1773
DEBUG - 2022-11-11 06:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:06:57 --> Total execution time: 0.1740
DEBUG - 2022-11-11 06:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:37:20 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:07:20 --> Total execution time: 0.1336
DEBUG - 2022-11-11 06:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:07:23 --> Total execution time: 2.1231
DEBUG - 2022-11-11 06:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:07:32 --> Total execution time: 0.2676
DEBUG - 2022-11-11 06:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:37:46 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:07:46 --> Total execution time: 0.1073
DEBUG - 2022-11-11 06:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:09:55 --> Total execution time: 0.1700
DEBUG - 2022-11-11 06:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:09:58 --> Total execution time: 0.1580
DEBUG - 2022-11-11 06:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:40:03 --> Total execution time: 0.1789
DEBUG - 2022-11-11 06:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:40:09 --> Total execution time: 0.1698
DEBUG - 2022-11-11 06:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:40:11 --> Total execution time: 0.1655
DEBUG - 2022-11-11 06:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:40:14 --> Total execution time: 0.1831
DEBUG - 2022-11-11 06:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:40:15 --> Total execution time: 0.2065
DEBUG - 2022-11-11 06:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:40:15 --> Total execution time: 0.1738
DEBUG - 2022-11-11 06:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:40:21 --> Total execution time: 0.1696
DEBUG - 2022-11-11 06:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:10:32 --> Total execution time: 0.1649
DEBUG - 2022-11-11 06:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:10:36 --> Total execution time: 0.2129
DEBUG - 2022-11-11 06:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:10:39 --> Total execution time: 0.2314
DEBUG - 2022-11-11 06:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:10:41 --> Total execution time: 0.1951
DEBUG - 2022-11-11 06:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:10:48 --> Total execution time: 0.2683
DEBUG - 2022-11-11 06:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:10:57 --> Total execution time: 0.1739
DEBUG - 2022-11-11 06:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:10:59 --> Total execution time: 0.1987
DEBUG - 2022-11-11 06:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:11:08 --> Total execution time: 0.1924
DEBUG - 2022-11-11 06:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:11:10 --> Total execution time: 0.1717
DEBUG - 2022-11-11 06:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:11:12 --> Total execution time: 0.3582
DEBUG - 2022-11-11 06:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:12:17 --> Total execution time: 0.2746
DEBUG - 2022-11-11 06:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:12:24 --> Total execution time: 0.2361
DEBUG - 2022-11-11 06:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:13:05 --> Total execution time: 0.2899
DEBUG - 2022-11-11 06:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:13:08 --> Total execution time: 0.2119
DEBUG - 2022-11-11 06:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:13:27 --> Total execution time: 0.1755
DEBUG - 2022-11-11 06:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:29 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:13:32 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-11 06:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:13:33 --> Total execution time: 0.3331
DEBUG - 2022-11-11 18:13:33 --> Total execution time: 3.3995
DEBUG - 2022-11-11 06:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:13:40 --> Total execution time: 0.1935
DEBUG - 2022-11-11 06:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:13:42 --> Total execution time: 1.2906
DEBUG - 2022-11-11 06:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:13:46 --> Total execution time: 0.2744
DEBUG - 2022-11-11 06:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:13:48 --> Total execution time: 0.5619
DEBUG - 2022-11-11 06:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 06:43:50 --> 404 Page Not Found: Sitemap_1xml/index
DEBUG - 2022-11-11 06:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:13:54 --> Total execution time: 0.1912
DEBUG - 2022-11-11 06:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:43:57 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:13:57 --> Total execution time: 0.1094
DEBUG - 2022-11-11 06:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:14:05 --> Total execution time: 0.1802
DEBUG - 2022-11-11 06:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:14:18 --> Total execution time: 0.2110
DEBUG - 2022-11-11 06:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:44:23 --> Total execution time: 0.1713
DEBUG - 2022-11-11 06:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:44:23 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:14:23 --> Total execution time: 0.1215
DEBUG - 2022-11-11 06:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:44:25 --> Total execution time: 0.3407
DEBUG - 2022-11-11 06:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:44:25 --> Total execution time: 0.2015
DEBUG - 2022-11-11 06:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:14:40 --> Total execution time: 0.1630
DEBUG - 2022-11-11 06:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:46:05 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:16:06 --> Total execution time: 0.2678
DEBUG - 2022-11-11 06:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:16:12 --> Total execution time: 0.2117
DEBUG - 2022-11-11 06:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:46:19 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:16:19 --> Total execution time: 0.1187
DEBUG - 2022-11-11 06:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:16:23 --> Total execution time: 0.1688
DEBUG - 2022-11-11 06:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:16:30 --> Total execution time: 0.2784
DEBUG - 2022-11-11 06:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:16:31 --> Total execution time: 0.1827
DEBUG - 2022-11-11 06:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:16:44 --> Total execution time: 0.2648
DEBUG - 2022-11-11 06:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:17:07 --> Total execution time: 0.2080
DEBUG - 2022-11-11 06:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:17:13 --> Total execution time: 0.1067
DEBUG - 2022-11-11 06:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:17:14 --> Total execution time: 0.1902
DEBUG - 2022-11-11 06:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:17:43 --> Total execution time: 0.1258
DEBUG - 2022-11-11 06:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:17:48 --> Total execution time: 0.2140
DEBUG - 2022-11-11 06:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:17:55 --> Total execution time: 0.1775
DEBUG - 2022-11-11 06:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:18:05 --> Total execution time: 0.3394
DEBUG - 2022-11-11 06:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:18:15 --> Total execution time: 0.2575
DEBUG - 2022-11-11 06:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:18:25 --> Total execution time: 0.1815
DEBUG - 2022-11-11 06:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:48:32 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:48:32 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:18:32 --> Total execution time: 0.1267
DEBUG - 2022-11-11 18:18:32 --> Total execution time: 0.1202
DEBUG - 2022-11-11 06:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:18:37 --> Total execution time: 0.1944
DEBUG - 2022-11-11 06:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:18:48 --> Total execution time: 0.2601
DEBUG - 2022-11-11 06:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:48:50 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:18:50 --> Total execution time: 0.1314
DEBUG - 2022-11-11 06:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:18:57 --> Total execution time: 0.2421
DEBUG - 2022-11-11 06:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:49:00 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:19:00 --> Total execution time: 0.1374
DEBUG - 2022-11-11 06:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:49:03 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:19:03 --> Total execution time: 0.1810
DEBUG - 2022-11-11 06:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:49:43 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:19:43 --> Total execution time: 0.1388
DEBUG - 2022-11-11 06:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:19:43 --> Total execution time: 2.8924
DEBUG - 2022-11-11 06:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:19:46 --> Total execution time: 0.1665
DEBUG - 2022-11-11 06:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:19:47 --> Total execution time: 0.1944
DEBUG - 2022-11-11 06:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:49:55 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:19:56 --> Total execution time: 0.1887
DEBUG - 2022-11-11 06:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:19:58 --> Total execution time: 0.2722
DEBUG - 2022-11-11 06:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:50:07 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:20:07 --> Total execution time: 0.1302
DEBUG - 2022-11-11 06:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:20:28 --> Total execution time: 0.2460
DEBUG - 2022-11-11 06:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:20:56 --> Total execution time: 0.6259
DEBUG - 2022-11-11 06:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:21:21 --> Total execution time: 0.3814
DEBUG - 2022-11-11 06:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:21:23 --> Total execution time: 0.2701
DEBUG - 2022-11-11 06:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:52:07 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:22:09 --> Total execution time: 1.9520
DEBUG - 2022-11-11 06:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:53:07 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:23:08 --> Total execution time: 0.8645
DEBUG - 2022-11-11 06:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:53:31 --> Total execution time: 0.7821
DEBUG - 2022-11-11 06:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:53:33 --> Total execution time: 0.2293
DEBUG - 2022-11-11 06:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:53:34 --> Total execution time: 0.1837
DEBUG - 2022-11-11 06:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:53:43 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:23:43 --> Total execution time: 0.1800
DEBUG - 2022-11-11 06:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:24:32 --> Total execution time: 0.2552
DEBUG - 2022-11-11 06:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:24:43 --> Total execution time: 0.2341
DEBUG - 2022-11-11 06:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:24:46 --> Total execution time: 0.2147
DEBUG - 2022-11-11 06:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:25:06 --> Total execution time: 0.4163
DEBUG - 2022-11-11 06:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:25:20 --> Total execution time: 1.1838
DEBUG - 2022-11-11 06:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:25:21 --> Total execution time: 2.1747
DEBUG - 2022-11-11 06:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 06:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:25:35 --> Total execution time: 0.2066
DEBUG - 2022-11-11 06:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:55:44 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:25:45 --> Total execution time: 0.1484
DEBUG - 2022-11-11 06:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:25:48 --> Total execution time: 0.9680
DEBUG - 2022-11-11 06:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:27:06 --> Total execution time: 6.1183
DEBUG - 2022-11-11 06:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:58:54 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:28:54 --> Total execution time: 0.9481
DEBUG - 2022-11-11 06:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 06:58:56 --> No URI present. Default controller set.
DEBUG - 2022-11-11 06:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 06:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:28:56 --> Total execution time: 0.1991
DEBUG - 2022-11-11 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:00:03 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:00:05 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:30:08 --> Total execution time: 4.7214
DEBUG - 2022-11-11 18:30:08 --> Total execution time: 5.0409
DEBUG - 2022-11-11 07:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:30:08 --> Total execution time: 2.9196
DEBUG - 2022-11-11 07:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:00:11 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:30:11 --> Total execution time: 0.2752
DEBUG - 2022-11-11 07:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:00:17 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:30:18 --> Total execution time: 0.2074
DEBUG - 2022-11-11 07:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:00:40 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:30:40 --> Total execution time: 0.5214
DEBUG - 2022-11-11 07:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:30:46 --> Total execution time: 1.0259
DEBUG - 2022-11-11 07:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:30:56 --> Total execution time: 0.4013
DEBUG - 2022-11-11 07:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:01:24 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:31:24 --> Total execution time: 0.1734
DEBUG - 2022-11-11 07:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:01:25 --> Total execution time: 0.4490
DEBUG - 2022-11-11 07:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:31:28 --> Total execution time: 0.3233
DEBUG - 2022-11-11 07:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:01:33 --> Total execution time: 0.2740
DEBUG - 2022-11-11 07:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:01:33 --> Total execution time: 0.4806
DEBUG - 2022-11-11 07:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:31:33 --> Total execution time: 0.1682
DEBUG - 2022-11-11 07:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:31:41 --> Total execution time: 0.3170
DEBUG - 2022-11-11 07:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:31:42 --> Total execution time: 0.1920
DEBUG - 2022-11-11 07:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:01:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 07:01:48 --> 404 Page Not Found: Onphp/index
DEBUG - 2022-11-11 07:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:31:48 --> Total execution time: 0.3145
DEBUG - 2022-11-11 07:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:32:09 --> Total execution time: 0.2775
DEBUG - 2022-11-11 07:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:32:19 --> Total execution time: 0.7359
DEBUG - 2022-11-11 07:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:32:20 --> Total execution time: 0.2801
DEBUG - 2022-11-11 07:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:32:35 --> Total execution time: 0.4154
DEBUG - 2022-11-11 07:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:32:46 --> Total execution time: 0.3673
DEBUG - 2022-11-11 07:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:32:47 --> Total execution time: 0.2686
DEBUG - 2022-11-11 07:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:32:52 --> Total execution time: 0.2452
DEBUG - 2022-11-11 07:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:03:14 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:33:14 --> Total execution time: 0.4385
DEBUG - 2022-11-11 07:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:33:14 --> Total execution time: 0.5167
DEBUG - 2022-11-11 07:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:33:24 --> Total execution time: 0.2101
DEBUG - 2022-11-11 07:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:33:30 --> Total execution time: 0.2249
DEBUG - 2022-11-11 07:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:33:40 --> Total execution time: 0.4473
DEBUG - 2022-11-11 07:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:33:41 --> Total execution time: 0.1625
DEBUG - 2022-11-11 07:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:33:44 --> Total execution time: 0.5541
DEBUG - 2022-11-11 07:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:33:44 --> Total execution time: 0.1644
DEBUG - 2022-11-11 07:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:33:47 --> Total execution time: 0.2985
DEBUG - 2022-11-11 07:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:33:54 --> Total execution time: 0.1764
DEBUG - 2022-11-11 07:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:34:01 --> Total execution time: 2.4127
DEBUG - 2022-11-11 07:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:34:02 --> Total execution time: 0.1980
DEBUG - 2022-11-11 07:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:34:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-11 07:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:34:05 --> Total execution time: 0.2106
DEBUG - 2022-11-11 07:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:04:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 07:04:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 07:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:34:15 --> Total execution time: 0.2081
DEBUG - 2022-11-11 07:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:34:20 --> Total execution time: 0.2247
DEBUG - 2022-11-11 07:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:34:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-11 07:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:34:45 --> Total execution time: 0.1944
DEBUG - 2022-11-11 07:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:34:54 --> Total execution time: 0.2057
DEBUG - 2022-11-11 07:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:35:08 --> Total execution time: 0.1720
DEBUG - 2022-11-11 07:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:35:09 --> Total execution time: 0.1678
DEBUG - 2022-11-11 07:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:05:17 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:35:18 --> Total execution time: 0.1027
DEBUG - 2022-11-11 18:35:18 --> Total execution time: 0.2237
DEBUG - 2022-11-11 07:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:05:23 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:35:23 --> Total execution time: 0.1032
DEBUG - 2022-11-11 07:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:05:27 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:05:27 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:35:27 --> Total execution time: 0.1976
DEBUG - 2022-11-11 07:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:35:27 --> Total execution time: 0.1668
DEBUG - 2022-11-11 07:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:35:33 --> Total execution time: 0.1797
DEBUG - 2022-11-11 07:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:35:40 --> Total execution time: 0.1659
DEBUG - 2022-11-11 07:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:35:50 --> Total execution time: 0.1925
DEBUG - 2022-11-11 07:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:35:57 --> Total execution time: 0.2073
DEBUG - 2022-11-11 07:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:35:58 --> Total execution time: 0.1679
DEBUG - 2022-11-11 07:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:36:09 --> Total execution time: 0.1771
DEBUG - 2022-11-11 07:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:36:11 --> Total execution time: 0.1815
DEBUG - 2022-11-11 07:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:36:23 --> Total execution time: 0.1616
DEBUG - 2022-11-11 07:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:06:30 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:36:30 --> Total execution time: 0.1672
DEBUG - 2022-11-11 07:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:00 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:37:01 --> Total execution time: 0.5662
DEBUG - 2022-11-11 07:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:01 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:37:02 --> Total execution time: 0.2022
DEBUG - 2022-11-11 07:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:37:09 --> Total execution time: 0.1702
DEBUG - 2022-11-11 07:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:15 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:37:15 --> Total execution time: 0.1464
DEBUG - 2022-11-11 07:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:37:19 --> Total execution time: 0.1338
DEBUG - 2022-11-11 07:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:37:23 --> Total execution time: 0.2687
DEBUG - 2022-11-11 07:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:37:24 --> Total execution time: 0.1881
DEBUG - 2022-11-11 07:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:37:29 --> Total execution time: 0.2445
DEBUG - 2022-11-11 07:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:37:32 --> Total execution time: 0.2372
DEBUG - 2022-11-11 07:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:37:40 --> Total execution time: 0.1955
DEBUG - 2022-11-11 07:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:37:40 --> Total execution time: 0.2224
DEBUG - 2022-11-11 07:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:37:46 --> Total execution time: 0.2311
DEBUG - 2022-11-11 07:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:37:51 --> Total execution time: 0.2401
DEBUG - 2022-11-11 07:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:37:57 --> Total execution time: 0.1588
DEBUG - 2022-11-11 07:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:38:10 --> Total execution time: 0.1940
DEBUG - 2022-11-11 07:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:38:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-11 07:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:38:23 --> Total execution time: 0.3361
DEBUG - 2022-11-11 07:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:38:47 --> Total execution time: 0.2340
DEBUG - 2022-11-11 07:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:38:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-11 07:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:38:55 --> Total execution time: 0.1994
DEBUG - 2022-11-11 07:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:39:11 --> Total execution time: 0.1076
DEBUG - 2022-11-11 07:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:39:23 --> Total execution time: 0.4514
DEBUG - 2022-11-11 07:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:39:24 --> Total execution time: 0.1673
DEBUG - 2022-11-11 07:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:39:40 --> Total execution time: 0.1948
DEBUG - 2022-11-11 07:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:39:47 --> Total execution time: 0.1805
DEBUG - 2022-11-11 07:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:39:57 --> Total execution time: 0.4594
DEBUG - 2022-11-11 07:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:40:02 --> Total execution time: 0.2814
DEBUG - 2022-11-11 07:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:40:14 --> Total execution time: 0.1660
DEBUG - 2022-11-11 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:40:39 --> Total execution time: 0.2306
DEBUG - 2022-11-11 07:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:40:41 --> Total execution time: 0.4069
DEBUG - 2022-11-11 07:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:40:49 --> Total execution time: 0.2258
DEBUG - 2022-11-11 07:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:41:16 --> Total execution time: 0.2816
DEBUG - 2022-11-11 07:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:41:16 --> Total execution time: 0.5218
DEBUG - 2022-11-11 07:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:41:27 --> Total execution time: 0.1760
DEBUG - 2022-11-11 07:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:41:35 --> Total execution time: 0.4431
DEBUG - 2022-11-11 07:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:11:43 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:41:43 --> Total execution time: 0.1121
DEBUG - 2022-11-11 07:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:11:44 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:41:45 --> Total execution time: 0.1825
DEBUG - 2022-11-11 07:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:11:46 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:41:46 --> Total execution time: 0.1201
DEBUG - 2022-11-11 07:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:41:49 --> Total execution time: 0.2051
DEBUG - 2022-11-11 07:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:41:57 --> Total execution time: 0.1768
DEBUG - 2022-11-11 07:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:03 --> Total execution time: 0.1803
DEBUG - 2022-11-11 07:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:04 --> Total execution time: 0.3746
DEBUG - 2022-11-11 07:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:04 --> Total execution time: 0.1694
DEBUG - 2022-11-11 07:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:42:05 --> Total execution time: 0.2817
DEBUG - 2022-11-11 07:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:05 --> Total execution time: 0.1871
DEBUG - 2022-11-11 07:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:11 --> Total execution time: 0.1920
DEBUG - 2022-11-11 07:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:13 --> Total execution time: 0.2917
DEBUG - 2022-11-11 07:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:42:13 --> Total execution time: 0.1757
DEBUG - 2022-11-11 07:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:13 --> Total execution time: 0.5314
DEBUG - 2022-11-11 07:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:42:14 --> Total execution time: 0.5096
DEBUG - 2022-11-11 07:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:14 --> Total execution time: 0.1713
DEBUG - 2022-11-11 07:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:17 --> Total execution time: 0.1942
DEBUG - 2022-11-11 07:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:18 --> Total execution time: 0.2297
DEBUG - 2022-11-11 07:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:19 --> Total execution time: 0.1621
DEBUG - 2022-11-11 07:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:19 --> Total execution time: 0.2011
DEBUG - 2022-11-11 07:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:19 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:19 --> Total execution time: 0.1086
DEBUG - 2022-11-11 07:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:25 --> Total execution time: 0.2098
DEBUG - 2022-11-11 07:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:32 --> Total execution time: 0.2067
DEBUG - 2022-11-11 07:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:37 --> Total execution time: 0.1814
DEBUG - 2022-11-11 07:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:38 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:38 --> Total execution time: 0.2640
DEBUG - 2022-11-11 07:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:41 --> Total execution time: 0.1951
DEBUG - 2022-11-11 07:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:41 --> Total execution time: 0.1693
DEBUG - 2022-11-11 07:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:47 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:47 --> Total execution time: 0.1286
DEBUG - 2022-11-11 07:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:49 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:49 --> Total execution time: 0.1151
DEBUG - 2022-11-11 07:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:12:51 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:51 --> Total execution time: 0.1146
DEBUG - 2022-11-11 07:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:43:00 --> Total execution time: 0.1599
DEBUG - 2022-11-11 07:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:43:05 --> Total execution time: 0.1657
DEBUG - 2022-11-11 07:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:43:07 --> Total execution time: 0.1761
DEBUG - 2022-11-11 07:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:43:13 --> Total execution time: 0.2083
DEBUG - 2022-11-11 07:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:13:16 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:43:16 --> Total execution time: 0.1847
DEBUG - 2022-11-11 07:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:43:16 --> Total execution time: 0.1130
DEBUG - 2022-11-11 07:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:43:25 --> Total execution time: 0.2252
DEBUG - 2022-11-11 07:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:43:25 --> Total execution time: 0.1890
DEBUG - 2022-11-11 07:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:43:26 --> Total execution time: 0.1833
DEBUG - 2022-11-11 07:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:43:28 --> Total execution time: 0.2265
DEBUG - 2022-11-11 07:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:43:37 --> Total execution time: 0.2040
DEBUG - 2022-11-11 07:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:45:27 --> Total execution time: 0.1702
DEBUG - 2022-11-11 07:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:47:12 --> Total execution time: 0.1953
DEBUG - 2022-11-11 07:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:47:22 --> Total execution time: 0.1792
DEBUG - 2022-11-11 07:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:47:39 --> Total execution time: 0.1713
DEBUG - 2022-11-11 07:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:47:41 --> Total execution time: 0.2158
DEBUG - 2022-11-11 07:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:47:43 --> Total execution time: 0.1749
DEBUG - 2022-11-11 07:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:47:51 --> Total execution time: 0.1890
DEBUG - 2022-11-11 07:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:18:04 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:04 --> Total execution time: 0.4473
DEBUG - 2022-11-11 07:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:08 --> Total execution time: 0.1658
DEBUG - 2022-11-11 07:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:15 --> Total execution time: 0.1878
DEBUG - 2022-11-11 07:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:16 --> Total execution time: 0.1746
DEBUG - 2022-11-11 07:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:21 --> Total execution time: 0.1757
DEBUG - 2022-11-11 07:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:26 --> Total execution time: 0.1657
DEBUG - 2022-11-11 07:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:18:39 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:39 --> Total execution time: 0.1147
DEBUG - 2022-11-11 07:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:50 --> Total execution time: 0.1727
DEBUG - 2022-11-11 07:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:58 --> Total execution time: 0.4511
DEBUG - 2022-11-11 07:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:49:09 --> Total execution time: 0.2448
DEBUG - 2022-11-11 07:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:19:10 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:49:10 --> Total execution time: 0.1653
DEBUG - 2022-11-11 07:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:19:11 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:49:11 --> Total execution time: 0.1708
DEBUG - 2022-11-11 07:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:49:44 --> Total execution time: 0.4413
DEBUG - 2022-11-11 07:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:49:56 --> Total execution time: 0.2308
DEBUG - 2022-11-11 07:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:50:01 --> Total execution time: 0.2868
DEBUG - 2022-11-11 07:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:50:09 --> Total execution time: 0.2032
DEBUG - 2022-11-11 07:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:50:12 --> Total execution time: 0.1725
DEBUG - 2022-11-11 07:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:50:29 --> Total execution time: 0.1712
DEBUG - 2022-11-11 07:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:50:38 --> Total execution time: 0.1815
DEBUG - 2022-11-11 07:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:50:44 --> Total execution time: 0.1734
DEBUG - 2022-11-11 07:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:50:47 --> Total execution time: 0.2043
DEBUG - 2022-11-11 07:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:21:20 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:51:20 --> Total execution time: 0.1016
DEBUG - 2022-11-11 07:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:21:22 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:51:22 --> Total execution time: 0.4468
DEBUG - 2022-11-11 07:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:51:34 --> Total execution time: 0.1658
DEBUG - 2022-11-11 07:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:51:37 --> Total execution time: 0.1798
DEBUG - 2022-11-11 07:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:51:37 --> Total execution time: 0.1613
DEBUG - 2022-11-11 07:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:21:58 --> Total execution time: 0.1688
DEBUG - 2022-11-11 07:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:22:00 --> Total execution time: 0.1849
DEBUG - 2022-11-11 07:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:22:01 --> Total execution time: 0.2768
DEBUG - 2022-11-11 07:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:52:07 --> Total execution time: 0.1658
DEBUG - 2022-11-11 07:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:52:24 --> Total execution time: 0.1854
DEBUG - 2022-11-11 07:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:52:27 --> Total execution time: 0.1753
DEBUG - 2022-11-11 07:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:52:46 --> Total execution time: 0.1886
DEBUG - 2022-11-11 07:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:00 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:53:01 --> Total execution time: 0.4514
DEBUG - 2022-11-11 07:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:53:18 --> Total execution time: 0.1770
DEBUG - 2022-11-11 07:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:24 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:53:24 --> Total execution time: 0.2363
DEBUG - 2022-11-11 07:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:23:31 --> Total execution time: 0.1651
DEBUG - 2022-11-11 07:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 07:23:34 --> 404 Page Not Found: Contact/index
DEBUG - 2022-11-11 07:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:34 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:53:34 --> Total execution time: 0.1117
DEBUG - 2022-11-11 07:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:53:35 --> Total execution time: 0.1611
DEBUG - 2022-11-11 07:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:53:36 --> Total execution time: 0.1846
DEBUG - 2022-11-11 07:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:23:59 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:53:59 --> Total execution time: 0.1731
DEBUG - 2022-11-11 07:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:54:43 --> Total execution time: 0.4805
DEBUG - 2022-11-11 07:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:24:48 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:54:48 --> Total execution time: 0.1224
DEBUG - 2022-11-11 07:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:54:56 --> Total execution time: 0.1826
DEBUG - 2022-11-11 07:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:55:04 --> Total execution time: 0.1868
DEBUG - 2022-11-11 07:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:55:06 --> Total execution time: 0.1821
DEBUG - 2022-11-11 07:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:55:14 --> Total execution time: 0.1776
DEBUG - 2022-11-11 07:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:55:20 --> Total execution time: 0.1786
DEBUG - 2022-11-11 07:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:55:28 --> Total execution time: 0.1677
DEBUG - 2022-11-11 07:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 07:25:53 --> 404 Page Not Found: Courses-v3/index
DEBUG - 2022-11-11 07:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:57:31 --> Total execution time: 0.5156
DEBUG - 2022-11-11 07:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:27:46 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:57:47 --> Total execution time: 0.3074
DEBUG - 2022-11-11 07:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:27:56 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:57:58 --> Total execution time: 1.8985
DEBUG - 2022-11-11 07:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:27:59 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:57:59 --> Total execution time: 0.2603
DEBUG - 2022-11-11 07:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:58:09 --> Total execution time: 0.4573
DEBUG - 2022-11-11 07:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:28:46 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:58:46 --> Total execution time: 0.4769
DEBUG - 2022-11-11 07:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:58:50 --> Total execution time: 0.2415
DEBUG - 2022-11-11 07:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:58:56 --> Total execution time: 0.1808
DEBUG - 2022-11-11 07:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:59:04 --> Total execution time: 0.2099
DEBUG - 2022-11-11 07:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:59:07 --> Total execution time: 0.2288
DEBUG - 2022-11-11 07:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:59:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-11 07:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:59:21 --> Total execution time: 0.2330
DEBUG - 2022-11-11 07:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:59:30 --> Total execution time: 0.1969
DEBUG - 2022-11-11 07:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:00:22 --> Total execution time: 0.1189
DEBUG - 2022-11-11 07:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:01:14 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-11 07:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:01:14 --> Total execution time: 0.2657
DEBUG - 2022-11-11 07:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:01:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-11 07:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:01:52 --> Total execution time: 0.2284
DEBUG - 2022-11-11 07:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:02:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-11 07:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:02:28 --> Total execution time: 0.2083
DEBUG - 2022-11-11 07:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:02:36 --> Total execution time: 0.5277
DEBUG - 2022-11-11 07:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:34:56 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:04:56 --> Total execution time: 0.5400
DEBUG - 2022-11-11 07:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:36:29 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:06:29 --> Total execution time: 0.4834
DEBUG - 2022-11-11 07:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:06:41 --> Total execution time: 0.1795
DEBUG - 2022-11-11 07:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:36:46 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:06:46 --> Total execution time: 0.2013
DEBUG - 2022-11-11 07:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:06:49 --> Total execution time: 0.1782
DEBUG - 2022-11-11 07:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:06:56 --> Total execution time: 0.1730
DEBUG - 2022-11-11 07:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:36:57 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:06:57 --> Total execution time: 0.1641
DEBUG - 2022-11-11 07:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:07:05 --> Total execution time: 0.1703
DEBUG - 2022-11-11 07:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:07:17 --> Total execution time: 0.1961
DEBUG - 2022-11-11 07:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:07:26 --> Total execution time: 0.1909
DEBUG - 2022-11-11 07:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:07:48 --> Total execution time: 0.2534
DEBUG - 2022-11-11 07:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:08:49 --> Total execution time: 0.1628
DEBUG - 2022-11-11 07:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:09:36 --> Total execution time: 0.1647
DEBUG - 2022-11-11 07:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:09:57 --> Total execution time: 0.1598
DEBUG - 2022-11-11 07:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:09:58 --> Total execution time: 0.1663
DEBUG - 2022-11-11 07:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:10:02 --> Total execution time: 0.1743
DEBUG - 2022-11-11 07:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:10:02 --> Total execution time: 0.4964
DEBUG - 2022-11-11 07:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:40:12 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:10:13 --> Total execution time: 0.2144
DEBUG - 2022-11-11 07:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:10:22 --> Total execution time: 0.1710
DEBUG - 2022-11-11 07:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:40:55 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:10:56 --> Total execution time: 0.3815
DEBUG - 2022-11-11 07:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:11:15 --> Total execution time: 0.1694
DEBUG - 2022-11-11 07:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:11:38 --> Total execution time: 0.1663
DEBUG - 2022-11-11 07:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:12:51 --> Total execution time: 0.1660
DEBUG - 2022-11-11 07:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:44:58 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:14:58 --> Total execution time: 0.1595
DEBUG - 2022-11-11 07:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:15:32 --> Total execution time: 0.5786
DEBUG - 2022-11-11 07:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:45:38 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:15:38 --> Total execution time: 0.1668
DEBUG - 2022-11-11 07:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:45:55 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:15:55 --> Total execution time: 0.1759
DEBUG - 2022-11-11 07:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:46:07 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:16:07 --> Total execution time: 0.1646
DEBUG - 2022-11-11 07:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:16:24 --> Total execution time: 0.4429
DEBUG - 2022-11-11 07:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:16:30 --> Total execution time: 0.1735
DEBUG - 2022-11-11 07:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:47:19 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:17:19 --> Total execution time: 0.1635
DEBUG - 2022-11-11 07:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:48:24 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:18:24 --> Total execution time: 0.1112
DEBUG - 2022-11-11 07:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:18:32 --> Total execution time: 0.4428
DEBUG - 2022-11-11 07:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:18:35 --> Total execution time: 0.1661
DEBUG - 2022-11-11 07:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:19:00 --> Total execution time: 0.1687
DEBUG - 2022-11-11 07:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:19:37 --> Total execution time: 0.1632
DEBUG - 2022-11-11 07:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:20:12 --> Total execution time: 0.1737
DEBUG - 2022-11-11 07:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:20:35 --> Total execution time: 0.1760
DEBUG - 2022-11-11 07:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:20:55 --> Total execution time: 0.1962
DEBUG - 2022-11-11 07:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:21:08 --> Total execution time: 0.1686
DEBUG - 2022-11-11 07:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:21:14 --> Total execution time: 0.1580
DEBUG - 2022-11-11 07:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:51:24 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:21:25 --> Total execution time: 0.4967
DEBUG - 2022-11-11 07:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:21:25 --> Total execution time: 0.4436
DEBUG - 2022-11-11 07:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:51:29 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:21:29 --> Total execution time: 0.1748
DEBUG - 2022-11-11 07:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:21:30 --> Total execution time: 0.1773
DEBUG - 2022-11-11 07:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:51:30 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:21:30 --> Total execution time: 0.1620
DEBUG - 2022-11-11 07:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:21:37 --> Total execution time: 0.1890
DEBUG - 2022-11-11 07:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:21:46 --> Total execution time: 0.2411
DEBUG - 2022-11-11 07:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:21:46 --> Total execution time: 0.1652
DEBUG - 2022-11-11 07:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:52:12 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:22:13 --> Total execution time: 0.4602
DEBUG - 2022-11-11 07:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:22:43 --> Total execution time: 0.1654
DEBUG - 2022-11-11 07:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:52:53 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:22:53 --> Total execution time: 0.1677
DEBUG - 2022-11-11 07:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:52:53 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:22:53 --> Total execution time: 0.1714
DEBUG - 2022-11-11 07:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:52:54 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:22:54 --> Total execution time: 0.1798
DEBUG - 2022-11-11 07:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:53:01 --> Total execution time: 0.1726
DEBUG - 2022-11-11 07:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:53:05 --> Total execution time: 0.1746
DEBUG - 2022-11-11 07:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:53:06 --> Total execution time: 0.1803
DEBUG - 2022-11-11 07:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:55:31 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:25:32 --> Total execution time: 1.0543
DEBUG - 2022-11-11 07:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:56:14 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:26:14 --> Total execution time: 0.1361
DEBUG - 2022-11-11 07:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:56:45 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:26:45 --> Total execution time: 0.1175
DEBUG - 2022-11-11 07:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:56:46 --> No URI present. Default controller set.
DEBUG - 2022-11-11 07:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:26:46 --> Total execution time: 0.1132
DEBUG - 2022-11-11 07:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:27:00 --> Total execution time: 0.2249
DEBUG - 2022-11-11 07:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 07:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:27:28 --> Total execution time: 0.2192
DEBUG - 2022-11-11 07:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:27:46 --> Total execution time: 0.2035
DEBUG - 2022-11-11 07:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:28:03 --> Total execution time: 0.1987
DEBUG - 2022-11-11 07:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:29:37 --> Total execution time: 0.2286
DEBUG - 2022-11-11 07:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:29:42 --> Total execution time: 0.1738
DEBUG - 2022-11-11 07:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:29:52 --> Total execution time: 0.5241
DEBUG - 2022-11-11 07:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 07:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 07:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:29:58 --> Total execution time: 0.1723
DEBUG - 2022-11-11 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:30:03 --> Total execution time: 0.2159
DEBUG - 2022-11-11 08:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:30:35 --> Total execution time: 0.2041
DEBUG - 2022-11-11 08:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:31:05 --> Total execution time: 0.1934
DEBUG - 2022-11-11 08:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:32:00 --> Total execution time: 0.5222
DEBUG - 2022-11-11 08:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:32:10 --> Total execution time: 0.3240
DEBUG - 2022-11-11 08:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:32:20 --> Total execution time: 0.2233
DEBUG - 2022-11-11 08:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:32:23 --> Total execution time: 0.1959
DEBUG - 2022-11-11 08:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:32:27 --> Total execution time: 0.2132
DEBUG - 2022-11-11 08:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:32:50 --> Total execution time: 0.4795
DEBUG - 2022-11-11 08:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:32:57 --> Total execution time: 0.2059
DEBUG - 2022-11-11 08:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:33:25 --> Total execution time: 0.1867
DEBUG - 2022-11-11 08:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:03:27 --> Total execution time: 0.3716
DEBUG - 2022-11-11 08:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:03:33 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:33:33 --> Total execution time: 0.5235
DEBUG - 2022-11-11 08:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:03:35 --> Total execution time: 0.3558
DEBUG - 2022-11-11 08:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:33:38 --> Total execution time: 0.1865
DEBUG - 2022-11-11 08:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:33:40 --> Total execution time: 0.1162
DEBUG - 2022-11-11 08:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:33:42 --> Total execution time: 0.1176
DEBUG - 2022-11-11 08:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:33:49 --> Total execution time: 0.4560
DEBUG - 2022-11-11 08:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:34:03 --> Total execution time: 0.7583
DEBUG - 2022-11-11 08:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:34:20 --> Total execution time: 1.1605
DEBUG - 2022-11-11 08:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:34:26 --> Total execution time: 0.2114
DEBUG - 2022-11-11 08:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:34:31 --> Total execution time: 0.1885
DEBUG - 2022-11-11 08:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:34:32 --> Total execution time: 0.2189
DEBUG - 2022-11-11 08:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:34:40 --> Total execution time: 0.2737
DEBUG - 2022-11-11 08:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:04:54 --> Total execution time: 0.1700
DEBUG - 2022-11-11 08:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:04:56 --> Total execution time: 0.2336
DEBUG - 2022-11-11 08:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:04:57 --> Total execution time: 0.1893
DEBUG - 2022-11-11 08:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:34:58 --> Total execution time: 0.1733
DEBUG - 2022-11-11 08:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:35:04 --> Total execution time: 0.1719
DEBUG - 2022-11-11 08:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:35:08 --> Total execution time: 0.1851
DEBUG - 2022-11-11 08:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:35:12 --> Total execution time: 0.1747
DEBUG - 2022-11-11 08:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:35:17 --> Total execution time: 0.2188
DEBUG - 2022-11-11 08:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:35:22 --> Total execution time: 0.1895
DEBUG - 2022-11-11 08:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:05:27 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:35:27 --> Total execution time: 0.1811
DEBUG - 2022-11-11 08:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:35:33 --> Total execution time: 0.1757
DEBUG - 2022-11-11 08:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:35:45 --> Total execution time: 0.1805
DEBUG - 2022-11-11 08:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:35:52 --> Total execution time: 0.2018
DEBUG - 2022-11-11 08:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:35:58 --> Total execution time: 0.3489
DEBUG - 2022-11-11 08:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:36:01 --> Total execution time: 0.2573
DEBUG - 2022-11-11 08:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:36:19 --> Total execution time: 0.2677
DEBUG - 2022-11-11 08:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:36:28 --> Total execution time: 0.1183
DEBUG - 2022-11-11 08:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:36:34 --> Total execution time: 0.1753
DEBUG - 2022-11-11 08:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:36:39 --> Total execution time: 0.4892
DEBUG - 2022-11-11 08:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:36:39 --> Total execution time: 0.2528
DEBUG - 2022-11-11 08:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:37:01 --> Total execution time: 0.1940
DEBUG - 2022-11-11 08:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:37:01 --> Total execution time: 0.2299
DEBUG - 2022-11-11 08:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:37:06 --> Total execution time: 0.2342
DEBUG - 2022-11-11 08:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:37:09 --> Total execution time: 0.2069
DEBUG - 2022-11-11 08:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:37:23 --> Total execution time: 0.1832
DEBUG - 2022-11-11 08:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:37:27 --> Total execution time: 0.1738
DEBUG - 2022-11-11 08:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:37:47 --> Total execution time: 0.3143
DEBUG - 2022-11-11 08:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:08:05 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:38:05 --> Total execution time: 0.4518
DEBUG - 2022-11-11 08:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:38:12 --> Total execution time: 0.1249
DEBUG - 2022-11-11 08:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:08:15 --> Total execution time: 0.1705
DEBUG - 2022-11-11 08:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:08:23 --> Total execution time: 0.1953
DEBUG - 2022-11-11 08:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:08:25 --> Total execution time: 0.1648
DEBUG - 2022-11-11 08:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:38:29 --> Total execution time: 0.2058
DEBUG - 2022-11-11 08:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:38:40 --> Total execution time: 0.1954
DEBUG - 2022-11-11 08:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:38:51 --> Total execution time: 0.1944
DEBUG - 2022-11-11 08:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:39:03 --> Total execution time: 0.2286
DEBUG - 2022-11-11 08:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:39:11 --> Total execution time: 0.1918
DEBUG - 2022-11-11 08:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:39:18 --> Total execution time: 0.1882
DEBUG - 2022-11-11 08:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:39:20 --> Total execution time: 0.1223
DEBUG - 2022-11-11 08:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:09:32 --> Total execution time: 0.2327
DEBUG - 2022-11-11 08:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:39:33 --> Total execution time: 0.1790
DEBUG - 2022-11-11 08:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:09:36 --> Total execution time: 0.1845
DEBUG - 2022-11-11 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:09:38 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:39:38 --> Total execution time: 0.1933
DEBUG - 2022-11-11 08:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:09:50 --> Total execution time: 0.1932
DEBUG - 2022-11-11 08:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:40:00 --> Total execution time: 0.1825
DEBUG - 2022-11-11 08:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:40:03 --> Total execution time: 0.7189
DEBUG - 2022-11-11 08:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:40:19 --> Total execution time: 0.1948
DEBUG - 2022-11-11 08:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:40:30 --> Total execution time: 0.4861
DEBUG - 2022-11-11 08:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:40:32 --> Total execution time: 0.2671
DEBUG - 2022-11-11 08:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:40:36 --> Total execution time: 0.2086
DEBUG - 2022-11-11 08:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:10:38 --> Total execution time: 0.1955
DEBUG - 2022-11-11 08:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:10:39 --> Total execution time: 0.1680
DEBUG - 2022-11-11 08:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:40:50 --> Total execution time: 0.2914
DEBUG - 2022-11-11 08:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:11:02 --> Total execution time: 0.1794
DEBUG - 2022-11-11 08:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:11:09 --> Total execution time: 0.1851
DEBUG - 2022-11-11 08:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:41:11 --> Total execution time: 0.1546
DEBUG - 2022-11-11 08:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:41:39 --> Total execution time: 2.1412
DEBUG - 2022-11-11 08:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:41:44 --> Total execution time: 0.1786
DEBUG - 2022-11-11 08:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:41:52 --> Total execution time: 0.2079
DEBUG - 2022-11-11 08:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:42:07 --> Total execution time: 0.2086
DEBUG - 2022-11-11 08:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:42:13 --> Total execution time: 0.1796
DEBUG - 2022-11-11 08:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:42:38 --> Total execution time: 0.1924
DEBUG - 2022-11-11 08:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:12:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 08:12:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 08:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:12:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 08:12:51 --> 404 Page Not Found: Update-profile-basic-info/index
DEBUG - 2022-11-11 08:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:43:08 --> Total execution time: 0.2067
DEBUG - 2022-11-11 08:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:43:21 --> Total execution time: 0.2188
DEBUG - 2022-11-11 08:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:43:26 --> Total execution time: 0.1661
DEBUG - 2022-11-11 08:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:43:36 --> Total execution time: 0.1752
DEBUG - 2022-11-11 08:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:14:03 --> Total execution time: 0.2228
DEBUG - 2022-11-11 08:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:44:10 --> Total execution time: 0.5592
DEBUG - 2022-11-11 08:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:44:27 --> Total execution time: 0.5161
DEBUG - 2022-11-11 08:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:44:28 --> Total execution time: 0.1765
DEBUG - 2022-11-11 08:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:44:58 --> Total execution time: 0.2046
DEBUG - 2022-11-11 08:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:45:02 --> Total execution time: 0.6134
DEBUG - 2022-11-11 08:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:15:18 --> Total execution time: 0.2055
DEBUG - 2022-11-11 08:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:45:31 --> Total execution time: 0.1675
DEBUG - 2022-11-11 08:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:15:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 08:15:42 --> 404 Page Not Found: Refund/index
DEBUG - 2022-11-11 08:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:45:59 --> Total execution time: 0.2530
DEBUG - 2022-11-11 08:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:46:16 --> Total execution time: 0.1802
DEBUG - 2022-11-11 08:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:16:19 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:46:20 --> Total execution time: 0.1207
DEBUG - 2022-11-11 08:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:46:22 --> Total execution time: 0.2072
DEBUG - 2022-11-11 08:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:46:30 --> Total execution time: 0.1644
DEBUG - 2022-11-11 08:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:46:32 --> Total execution time: 0.2009
DEBUG - 2022-11-11 08:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:46:38 --> Total execution time: 0.2445
DEBUG - 2022-11-11 08:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:17:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 08:17:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 08:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:47:13 --> Total execution time: 0.1061
DEBUG - 2022-11-11 08:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:47:16 --> Total execution time: 0.1626
DEBUG - 2022-11-11 08:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:47:27 --> Total execution time: 0.2102
DEBUG - 2022-11-11 08:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:17:28 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:47:28 --> Total execution time: 0.1125
DEBUG - 2022-11-11 08:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:47:29 --> Total execution time: 0.1763
DEBUG - 2022-11-11 08:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:47:34 --> Total execution time: 0.2516
DEBUG - 2022-11-11 08:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:19:39 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:49:40 --> Total execution time: 0.1233
DEBUG - 2022-11-11 08:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:19:47 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:49:48 --> Total execution time: 0.1297
DEBUG - 2022-11-11 08:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:19:57 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:49:57 --> Total execution time: 0.1109
DEBUG - 2022-11-11 08:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:50:01 --> Total execution time: 0.4592
DEBUG - 2022-11-11 08:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:50:08 --> Total execution time: 0.1278
DEBUG - 2022-11-11 08:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:20:14 --> Total execution time: 0.1660
DEBUG - 2022-11-11 08:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:20:19 --> Total execution time: 0.1669
DEBUG - 2022-11-11 08:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:20:25 --> Total execution time: 0.1642
DEBUG - 2022-11-11 08:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:20:36 --> Total execution time: 0.1784
DEBUG - 2022-11-11 08:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:20:49 --> Total execution time: 0.1731
DEBUG - 2022-11-11 08:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:20:53 --> Total execution time: 0.2058
DEBUG - 2022-11-11 08:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:51:04 --> Total execution time: 0.1229
DEBUG - 2022-11-11 08:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:51:04 --> Total execution time: 0.1076
DEBUG - 2022-11-11 08:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:21:04 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:51:04 --> Total execution time: 0.2290
DEBUG - 2022-11-11 08:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:51:10 --> Total execution time: 0.2003
DEBUG - 2022-11-11 08:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:51:16 --> Total execution time: 0.3052
DEBUG - 2022-11-11 08:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:51:20 --> Total execution time: 0.1777
DEBUG - 2022-11-11 08:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:21:40 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:51:41 --> Total execution time: 0.1703
DEBUG - 2022-11-11 08:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:21:50 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:51:50 --> Total execution time: 0.1201
DEBUG - 2022-11-11 08:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:51:57 --> Total execution time: 0.1147
DEBUG - 2022-11-11 08:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:22:01 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:52:02 --> Total execution time: 0.3066
DEBUG - 2022-11-11 08:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:52:04 --> Total execution time: 0.2009
DEBUG - 2022-11-11 08:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:52:08 --> Total execution time: 0.2076
DEBUG - 2022-11-11 08:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:52:12 --> Total execution time: 0.1664
DEBUG - 2022-11-11 08:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:22:18 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:52:18 --> Total execution time: 0.4511
DEBUG - 2022-11-11 08:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:52:23 --> Total execution time: 0.1718
DEBUG - 2022-11-11 08:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:52:25 --> Total execution time: 0.2045
DEBUG - 2022-11-11 08:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:52:41 --> Total execution time: 0.2399
DEBUG - 2022-11-11 08:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:52:46 --> Total execution time: 0.1682
DEBUG - 2022-11-11 08:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:22:46 --> Total execution time: 0.1827
DEBUG - 2022-11-11 08:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:23:02 --> Total execution time: 0.2103
DEBUG - 2022-11-11 08:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:23:02 --> Total execution time: 0.4240
DEBUG - 2022-11-11 08:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:53:18 --> Total execution time: 0.1746
DEBUG - 2022-11-11 08:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:23:23 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:53:23 --> Total execution time: 0.1695
DEBUG - 2022-11-11 08:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:53:29 --> Total execution time: 0.1748
DEBUG - 2022-11-11 08:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:23:32 --> Total execution time: 0.1667
DEBUG - 2022-11-11 08:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:23:37 --> Total execution time: 0.1849
DEBUG - 2022-11-11 08:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:53:38 --> Total execution time: 0.1111
DEBUG - 2022-11-11 08:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:23:50 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:53:50 --> Total execution time: 0.1718
DEBUG - 2022-11-11 08:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:24:08 --> Total execution time: 0.1824
DEBUG - 2022-11-11 08:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:24:10 --> Total execution time: 0.1776
DEBUG - 2022-11-11 08:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:24:11 --> Total execution time: 0.3401
DEBUG - 2022-11-11 08:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 08:24:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 08:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:24:31 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:54:31 --> Total execution time: 0.1108
DEBUG - 2022-11-11 08:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:24:32 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:54:32 --> Total execution time: 0.1107
DEBUG - 2022-11-11 08:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:54:44 --> Total execution time: 0.1758
DEBUG - 2022-11-11 08:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:24:45 --> Total execution time: 0.2186
DEBUG - 2022-11-11 08:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:54:51 --> Total execution time: 0.2035
DEBUG - 2022-11-11 08:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:24:54 --> Total execution time: 0.3159
DEBUG - 2022-11-11 08:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:54:55 --> Total execution time: 0.1950
DEBUG - 2022-11-11 08:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:55:07 --> Total execution time: 0.2185
DEBUG - 2022-11-11 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:55:14 --> Total execution time: 0.2069
DEBUG - 2022-11-11 08:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:55:18 --> Total execution time: 0.3121
DEBUG - 2022-11-11 08:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:55:21 --> Total execution time: 0.2150
DEBUG - 2022-11-11 08:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:55:25 --> Total execution time: 0.1981
DEBUG - 2022-11-11 08:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:55:32 --> Total execution time: 0.2124
DEBUG - 2022-11-11 08:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:55:55 --> Total execution time: 0.2054
DEBUG - 2022-11-11 08:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:56:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-11 08:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:56:18 --> Total execution time: 0.1869
DEBUG - 2022-11-11 08:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:56:41 --> Total execution time: 1.9790
DEBUG - 2022-11-11 08:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:26:55 --> Total execution time: 0.1679
DEBUG - 2022-11-11 08:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:27:01 --> Total execution time: 0.1970
DEBUG - 2022-11-11 08:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:57:01 --> Total execution time: 0.2175
DEBUG - 2022-11-11 08:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 08:27:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 08:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:27:26 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:57:26 --> Total execution time: 0.3652
DEBUG - 2022-11-11 08:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:57:33 --> Total execution time: 0.1708
DEBUG - 2022-11-11 08:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:57:35 --> Total execution time: 0.1716
DEBUG - 2022-11-11 08:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:57:40 --> Total execution time: 0.2363
DEBUG - 2022-11-11 08:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:57:48 --> Total execution time: 0.1914
DEBUG - 2022-11-11 08:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:27:54 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:57:54 --> Total execution time: 0.4458
DEBUG - 2022-11-11 08:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:57:57 --> Total execution time: 0.1793
DEBUG - 2022-11-11 08:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:57:58 --> Total execution time: 0.1860
DEBUG - 2022-11-11 08:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:58:00 --> Total execution time: 0.1780
DEBUG - 2022-11-11 08:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:58:08 --> Total execution time: 0.2503
DEBUG - 2022-11-11 08:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:58:08 --> Total execution time: 0.2159
DEBUG - 2022-11-11 08:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:28:10 --> Total execution time: 0.2000
DEBUG - 2022-11-11 08:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:11 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:58:11 --> Total execution time: 0.1671
DEBUG - 2022-11-11 08:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:28:13 --> Total execution time: 0.1861
DEBUG - 2022-11-11 08:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:28:13 --> Total execution time: 0.1972
DEBUG - 2022-11-11 08:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:58:19 --> Total execution time: 0.2177
DEBUG - 2022-11-11 08:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:58:24 --> Total execution time: 0.1781
DEBUG - 2022-11-11 08:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:58:27 --> Total execution time: 0.1946
DEBUG - 2022-11-11 08:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 08:28:33 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-11-11 08:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:34 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:58:34 --> Total execution time: 0.1080
DEBUG - 2022-11-11 08:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 08:28:34 --> 404 Page Not Found: Sitemap_1xml/index
DEBUG - 2022-11-11 08:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:58:40 --> Total execution time: 0.2104
DEBUG - 2022-11-11 08:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:58:50 --> Total execution time: 0.4813
DEBUG - 2022-11-11 08:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:59:11 --> Total execution time: 0.1690
DEBUG - 2022-11-11 08:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:29:16 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:59:16 --> Total execution time: 0.1256
DEBUG - 2022-11-11 08:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:59:17 --> Total execution time: 0.2773
DEBUG - 2022-11-11 08:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:59:18 --> Total execution time: 0.2481
DEBUG - 2022-11-11 08:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:59:19 --> Total execution time: 0.1718
DEBUG - 2022-11-11 08:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:29:20 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:59:21 --> Total execution time: 0.1755
DEBUG - 2022-11-11 08:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:59:37 --> Total execution time: 0.1754
DEBUG - 2022-11-11 08:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:29:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 08:29:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 08:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:30:02 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:00:02 --> Total execution time: 0.1357
DEBUG - 2022-11-11 08:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:30:28 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:00:29 --> Total execution time: 0.1782
DEBUG - 2022-11-11 08:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:30:43 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:00:43 --> Total execution time: 0.1707
DEBUG - 2022-11-11 08:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:30:59 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:00:59 --> Total execution time: 0.1829
DEBUG - 2022-11-11 08:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:01:17 --> Total execution time: 0.2096
DEBUG - 2022-11-11 08:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:01:30 --> Total execution time: 0.1694
DEBUG - 2022-11-11 08:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:02:04 --> Total execution time: 0.2561
DEBUG - 2022-11-11 08:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:02:24 --> Total execution time: 0.2360
DEBUG - 2022-11-11 08:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:03:11 --> Total execution time: 0.1994
DEBUG - 2022-11-11 08:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:34:08 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:04:09 --> Total execution time: 0.4628
DEBUG - 2022-11-11 08:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:04:14 --> Total execution time: 0.4613
DEBUG - 2022-11-11 08:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:04:19 --> Total execution time: 0.2162
DEBUG - 2022-11-11 08:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:04:24 --> Total execution time: 2.3826
DEBUG - 2022-11-11 08:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:04:41 --> Total execution time: 0.1660
DEBUG - 2022-11-11 08:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:05:13 --> Total execution time: 0.1884
DEBUG - 2022-11-11 08:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:05:23 --> Total execution time: 0.1887
DEBUG - 2022-11-11 08:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:06:57 --> Total execution time: 0.4721
DEBUG - 2022-11-11 08:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:37:01 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:07:02 --> Total execution time: 0.1108
DEBUG - 2022-11-11 08:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:07:14 --> Total execution time: 0.1978
DEBUG - 2022-11-11 08:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:07:27 --> Total execution time: 0.1909
DEBUG - 2022-11-11 08:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:08:02 --> Total execution time: 0.2498
DEBUG - 2022-11-11 08:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:08:09 --> Total execution time: 0.2265
DEBUG - 2022-11-11 08:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:08:19 --> Total execution time: 0.1650
DEBUG - 2022-11-11 08:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:08:58 --> Total execution time: 0.1659
DEBUG - 2022-11-11 08:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:09:25 --> Total execution time: 0.2528
DEBUG - 2022-11-11 08:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:39:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 08:39:26 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-11-11 08:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:09:39 --> Total execution time: 0.1662
DEBUG - 2022-11-11 08:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:09:42 --> Total execution time: 0.2110
DEBUG - 2022-11-11 08:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:09:47 --> Total execution time: 0.4945
DEBUG - 2022-11-11 08:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:09:52 --> Total execution time: 0.1665
DEBUG - 2022-11-11 08:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:09:55 --> Total execution time: 0.1689
DEBUG - 2022-11-11 08:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:10:00 --> Total execution time: 0.1913
DEBUG - 2022-11-11 08:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:10:06 --> Total execution time: 0.1721
DEBUG - 2022-11-11 08:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:10:16 --> Total execution time: 0.1828
DEBUG - 2022-11-11 08:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:10:17 --> Total execution time: 0.1764
DEBUG - 2022-11-11 08:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:10:22 --> Total execution time: 0.1769
DEBUG - 2022-11-11 08:40:22 --> Total execution time: 0.1188
DEBUG - 2022-11-11 08:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:10:25 --> Total execution time: 0.1808
DEBUG - 2022-11-11 08:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:40:28 --> Total execution time: 0.1754
DEBUG - 2022-11-11 08:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:40:28 --> Total execution time: 0.4357
DEBUG - 2022-11-11 08:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:10:29 --> Total execution time: 0.1800
DEBUG - 2022-11-11 08:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:10:32 --> Total execution time: 0.1733
DEBUG - 2022-11-11 08:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:10:36 --> Total execution time: 0.1657
DEBUG - 2022-11-11 08:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:10:39 --> Total execution time: 0.2155
DEBUG - 2022-11-11 08:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:10:48 --> Total execution time: 0.1722
DEBUG - 2022-11-11 08:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:54 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:10:54 --> Total execution time: 0.2071
DEBUG - 2022-11-11 08:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:10:55 --> Total execution time: 0.2496
DEBUG - 2022-11-11 08:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:04 --> Total execution time: 0.1653
DEBUG - 2022-11-11 08:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:08 --> Total execution time: 0.1781
DEBUG - 2022-11-11 08:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:08 --> Total execution time: 0.1829
DEBUG - 2022-11-11 08:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:12 --> Total execution time: 0.1789
DEBUG - 2022-11-11 08:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:17 --> Total execution time: 0.1830
DEBUG - 2022-11-11 08:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:21 --> Total execution time: 0.1759
DEBUG - 2022-11-11 08:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:25 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:25 --> Total execution time: 0.1780
DEBUG - 2022-11-11 08:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:26 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:26 --> Total execution time: 0.2241
DEBUG - 2022-11-11 08:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:26 --> Total execution time: 0.2382
DEBUG - 2022-11-11 08:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:26 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:27 --> Total execution time: 0.1782
DEBUG - 2022-11-11 08:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:27 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:27 --> Total execution time: 0.1840
DEBUG - 2022-11-11 08:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:27 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:28 --> Total execution time: 0.1997
DEBUG - 2022-11-11 08:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:28 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:28 --> Total execution time: 0.1705
DEBUG - 2022-11-11 08:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:29 --> Total execution time: 0.2137
DEBUG - 2022-11-11 08:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:33 --> Total execution time: 0.1801
DEBUG - 2022-11-11 08:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:34 --> Total execution time: 0.1715
DEBUG - 2022-11-11 08:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:38 --> Total execution time: 0.1692
DEBUG - 2022-11-11 08:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:39 --> Total execution time: 0.1704
DEBUG - 2022-11-11 08:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:40 --> Total execution time: 0.1799
DEBUG - 2022-11-11 08:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:41 --> Total execution time: 0.2066
DEBUG - 2022-11-11 08:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:41 --> Total execution time: 0.2708
DEBUG - 2022-11-11 08:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:41 --> Total execution time: 0.3331
DEBUG - 2022-11-11 08:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:41 --> Total execution time: 0.1897
DEBUG - 2022-11-11 08:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:11:47 --> Total execution time: 0.1658
DEBUG - 2022-11-11 08:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:12:16 --> Total execution time: 0.2302
DEBUG - 2022-11-11 08:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:12:27 --> Total execution time: 0.4747
DEBUG - 2022-11-11 08:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:12:36 --> Total execution time: 0.1792
DEBUG - 2022-11-11 08:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:13:31 --> Total execution time: 0.4922
DEBUG - 2022-11-11 08:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:44:03 --> Total execution time: 0.1808
DEBUG - 2022-11-11 08:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:44:10 --> Total execution time: 0.2360
DEBUG - 2022-11-11 08:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:14:26 --> Total execution time: 0.1938
DEBUG - 2022-11-11 08:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:14:31 --> Total execution time: 0.1929
DEBUG - 2022-11-11 08:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:14:49 --> Total execution time: 0.2330
DEBUG - 2022-11-11 08:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:14:59 --> Total execution time: 0.3158
DEBUG - 2022-11-11 08:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:45:22 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:15:23 --> Total execution time: 0.4661
DEBUG - 2022-11-11 08:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:16:02 --> Total execution time: 0.1974
DEBUG - 2022-11-11 08:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:16:17 --> Total execution time: 0.2367
DEBUG - 2022-11-11 08:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:16:25 --> Total execution time: 0.2360
DEBUG - 2022-11-11 08:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:16:29 --> Total execution time: 0.1970
DEBUG - 2022-11-11 08:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:16:36 --> Total execution time: 0.1786
DEBUG - 2022-11-11 08:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:16:44 --> Total execution time: 0.2105
DEBUG - 2022-11-11 08:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:47:18 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:17:19 --> Total execution time: 0.4804
DEBUG - 2022-11-11 08:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:17:36 --> Total execution time: 0.4869
DEBUG - 2022-11-11 08:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:17:45 --> Total execution time: 0.2009
DEBUG - 2022-11-11 08:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:18:13 --> Total execution time: 0.2143
DEBUG - 2022-11-11 08:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:48:45 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:18:45 --> Total execution time: 0.1898
DEBUG - 2022-11-11 08:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:49:47 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:19:47 --> Total execution time: 0.1319
DEBUG - 2022-11-11 08:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:19:52 --> Total execution time: 0.1174
DEBUG - 2022-11-11 08:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:21:49 --> Total execution time: 0.4341
DEBUG - 2022-11-11 08:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:52:18 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:22:18 --> Total execution time: 0.1227
DEBUG - 2022-11-11 08:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:22:21 --> Total execution time: 0.5242
DEBUG - 2022-11-11 08:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:22:28 --> Total execution time: 0.1722
DEBUG - 2022-11-11 08:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:52:53 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:22:53 --> Total execution time: 0.1860
DEBUG - 2022-11-11 08:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:22:53 --> Total execution time: 0.1295
DEBUG - 2022-11-11 08:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:23:06 --> Total execution time: 0.1746
DEBUG - 2022-11-11 08:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:23:18 --> Total execution time: 0.1954
DEBUG - 2022-11-11 08:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:23:19 --> Total execution time: 0.1751
DEBUG - 2022-11-11 08:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:23:28 --> Total execution time: 0.1824
DEBUG - 2022-11-11 08:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:23:30 --> Total execution time: 0.2075
DEBUG - 2022-11-11 08:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:24:21 --> Total execution time: 0.1681
DEBUG - 2022-11-11 08:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:24:24 --> Total execution time: 0.1662
DEBUG - 2022-11-11 08:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:24:27 --> Total execution time: 0.1921
DEBUG - 2022-11-11 08:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:54:39 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:24:39 --> Total execution time: 0.1239
DEBUG - 2022-11-11 08:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:24:41 --> Total execution time: 0.1748
DEBUG - 2022-11-11 08:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:24:41 --> Total execution time: 0.1722
DEBUG - 2022-11-11 08:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:24:54 --> Total execution time: 0.5173
DEBUG - 2022-11-11 08:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:55:10 --> Total execution time: 0.1715
DEBUG - 2022-11-11 08:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:25:28 --> Total execution time: 0.2310
DEBUG - 2022-11-11 08:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:56:09 --> Total execution time: 0.1701
DEBUG - 2022-11-11 08:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:26:23 --> Total execution time: 0.2215
DEBUG - 2022-11-11 08:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:26:33 --> Total execution time: 0.1600
DEBUG - 2022-11-11 08:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:56:47 --> Total execution time: 0.3483
DEBUG - 2022-11-11 08:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:56:47 --> Total execution time: 1.5880
DEBUG - 2022-11-11 08:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:56:48 --> Total execution time: 0.1744
DEBUG - 2022-11-11 08:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:56:48 --> Total execution time: 0.1666
DEBUG - 2022-11-11 08:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:56:48 --> Total execution time: 0.1989
DEBUG - 2022-11-11 08:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:56:49 --> Total execution time: 0.1836
DEBUG - 2022-11-11 08:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:56:49 --> Total execution time: 0.3142
DEBUG - 2022-11-11 08:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:56:58 --> Total execution time: 0.1701
DEBUG - 2022-11-11 08:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:56:59 --> Total execution time: 1.1619
DEBUG - 2022-11-11 08:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:27:00 --> Total execution time: 0.1742
DEBUG - 2022-11-11 08:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:57:04 --> Total execution time: 0.1747
DEBUG - 2022-11-11 08:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:57:07 --> Total execution time: 0.1869
DEBUG - 2022-11-11 08:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:57:07 --> Total execution time: 0.5230
DEBUG - 2022-11-11 08:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:57:41 --> No URI present. Default controller set.
DEBUG - 2022-11-11 08:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:27:41 --> Total execution time: 3.1097
DEBUG - 2022-11-11 20:27:41 --> Total execution time: 0.3203
DEBUG - 2022-11-11 08:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:27:41 --> Total execution time: 0.1765
DEBUG - 2022-11-11 08:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:27:47 --> Total execution time: 0.2362
DEBUG - 2022-11-11 08:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:27:51 --> Total execution time: 0.1993
DEBUG - 2022-11-11 08:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:28:10 --> Total execution time: 0.1795
DEBUG - 2022-11-11 08:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:28:14 --> Total execution time: 2.3437
DEBUG - 2022-11-11 08:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:28:24 --> Total execution time: 0.1785
DEBUG - 2022-11-11 08:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:28:28 --> Total execution time: 0.2077
DEBUG - 2022-11-11 08:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:58:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 08:58:33 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 08:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:28:34 --> Total execution time: 0.1859
DEBUG - 2022-11-11 08:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:28:39 --> Total execution time: 0.1734
DEBUG - 2022-11-11 08:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:28:42 --> Total execution time: 0.5392
DEBUG - 2022-11-11 08:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:28:46 --> Total execution time: 0.2316
DEBUG - 2022-11-11 08:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:28:46 --> Total execution time: 0.2276
DEBUG - 2022-11-11 08:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:58:56 --> Total execution time: 0.1760
DEBUG - 2022-11-11 08:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:58:58 --> Total execution time: 0.2013
DEBUG - 2022-11-11 08:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:58:58 --> Total execution time: 0.4365
DEBUG - 2022-11-11 08:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:29:14 --> Total execution time: 0.1890
DEBUG - 2022-11-11 08:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:29:22 --> Total execution time: 0.2629
DEBUG - 2022-11-11 08:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:29:41 --> Total execution time: 2.0102
DEBUG - 2022-11-11 08:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:59:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 08:59:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 08:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:29:50 --> Total execution time: 0.1733
DEBUG - 2022-11-11 08:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 08:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:29:51 --> Total execution time: 0.2149
DEBUG - 2022-11-11 08:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 08:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 08:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:29:53 --> Total execution time: 0.1823
DEBUG - 2022-11-11 09:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:30:00 --> Total execution time: 0.1761
DEBUG - 2022-11-11 09:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:30:00 --> Total execution time: 0.1977
DEBUG - 2022-11-11 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:30:03 --> Total execution time: 0.2076
DEBUG - 2022-11-11 09:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:30:12 --> Total execution time: 0.1992
DEBUG - 2022-11-11 09:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:30:16 --> Total execution time: 0.1807
DEBUG - 2022-11-11 09:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:30:19 --> Total execution time: 0.1995
DEBUG - 2022-11-11 09:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:30:27 --> Total execution time: 0.1911
DEBUG - 2022-11-11 09:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:30:39 --> Total execution time: 0.1869
DEBUG - 2022-11-11 09:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:30:40 --> Total execution time: 0.1815
DEBUG - 2022-11-11 09:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:30:47 --> Total execution time: 0.1676
DEBUG - 2022-11-11 09:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:30:51 --> Total execution time: 0.2250
DEBUG - 2022-11-11 09:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:31:03 --> Total execution time: 0.2316
DEBUG - 2022-11-11 09:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:01:07 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:31:07 --> Total execution time: 0.5889
DEBUG - 2022-11-11 09:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:31:09 --> Total execution time: 0.3449
DEBUG - 2022-11-11 09:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:31:10 --> Total execution time: 0.1912
DEBUG - 2022-11-11 09:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:31:10 --> Total execution time: 0.1828
DEBUG - 2022-11-11 09:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:31:11 --> Total execution time: 0.2111
DEBUG - 2022-11-11 09:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:31:16 --> Total execution time: 0.1754
DEBUG - 2022-11-11 09:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:31:21 --> Total execution time: 0.1816
DEBUG - 2022-11-11 09:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:31:25 --> Total execution time: 0.2188
DEBUG - 2022-11-11 09:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:31:32 --> Total execution time: 0.1796
DEBUG - 2022-11-11 09:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:01:41 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:31:41 --> Total execution time: 0.1310
DEBUG - 2022-11-11 09:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:31:44 --> Total execution time: 0.1797
DEBUG - 2022-11-11 09:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:31:47 --> Total execution time: 0.2073
DEBUG - 2022-11-11 09:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:31:47 --> Total execution time: 0.2027
DEBUG - 2022-11-11 09:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:31:55 --> Total execution time: 0.1777
DEBUG - 2022-11-11 09:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:04 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:32:04 --> Total execution time: 0.1839
DEBUG - 2022-11-11 09:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:32:08 --> Total execution time: 0.1788
DEBUG - 2022-11-11 09:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:32:16 --> Total execution time: 0.1909
DEBUG - 2022-11-11 09:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:32:18 --> Total execution time: 0.1751
DEBUG - 2022-11-11 09:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:32:18 --> Total execution time: 0.1709
DEBUG - 2022-11-11 09:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:32:22 --> Total execution time: 0.2390
DEBUG - 2022-11-11 09:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:24 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:32:24 --> Total execution time: 0.1475
DEBUG - 2022-11-11 09:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:32:26 --> Total execution time: 0.2222
DEBUG - 2022-11-11 09:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:32:28 --> Total execution time: 0.2438
DEBUG - 2022-11-11 09:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:32:29 --> Total execution time: 0.2199
DEBUG - 2022-11-11 09:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:32:33 --> Total execution time: 0.1708
DEBUG - 2022-11-11 09:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:39 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:32:39 --> Total execution time: 0.1645
DEBUG - 2022-11-11 09:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:32:44 --> Total execution time: 0.1829
DEBUG - 2022-11-11 09:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:32:51 --> Total execution time: 0.1821
DEBUG - 2022-11-11 20:32:52 --> Total execution time: 1.5862
DEBUG - 2022-11-11 09:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:33:03 --> Total execution time: 0.1728
DEBUG - 2022-11-11 09:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:33:35 --> Total execution time: 0.1745
DEBUG - 2022-11-11 09:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:04:12 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:34:12 --> Total execution time: 0.1655
DEBUG - 2022-11-11 09:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:04:30 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:34:30 --> Total execution time: 0.1644
DEBUG - 2022-11-11 09:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:04:34 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:34:34 --> Total execution time: 0.1066
DEBUG - 2022-11-11 09:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:34:37 --> Total execution time: 0.5563
DEBUG - 2022-11-11 09:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:34:38 --> Total execution time: 0.2052
DEBUG - 2022-11-11 09:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:35:01 --> Total execution time: 0.1670
DEBUG - 2022-11-11 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:35:16 --> Total execution time: 0.1654
DEBUG - 2022-11-11 09:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:05:19 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:35:19 --> Total execution time: 0.1694
DEBUG - 2022-11-11 09:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:06:09 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:36:09 --> Total execution time: 0.1716
DEBUG - 2022-11-11 09:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:06:10 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:36:10 --> Total execution time: 0.4810
DEBUG - 2022-11-11 09:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:36:21 --> Total execution time: 0.1612
DEBUG - 2022-11-11 09:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:36:23 --> Total execution time: 1.6895
DEBUG - 2022-11-11 09:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:36:25 --> Total execution time: 0.1810
DEBUG - 2022-11-11 09:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:36:35 --> Total execution time: 0.1592
DEBUG - 2022-11-11 09:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:06:38 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:36:38 --> Total execution time: 0.1660
DEBUG - 2022-11-11 09:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:36:45 --> Total execution time: 0.2056
DEBUG - 2022-11-11 09:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:37:01 --> Total execution time: 0.2104
DEBUG - 2022-11-11 09:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:37:11 --> Total execution time: 0.2100
DEBUG - 2022-11-11 09:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:07:30 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:37:31 --> Total execution time: 0.1245
DEBUG - 2022-11-11 09:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:07:41 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:37:42 --> Total execution time: 0.1034
DEBUG - 2022-11-11 09:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:08:10 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:38:10 --> Total execution time: 0.1142
DEBUG - 2022-11-11 09:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:38:15 --> Total execution time: 0.1708
DEBUG - 2022-11-11 09:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:08:21 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:38:21 --> Total execution time: 0.1180
DEBUG - 2022-11-11 09:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:08:26 --> Total execution time: 0.1769
DEBUG - 2022-11-11 09:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:08:27 --> Total execution time: 0.2049
DEBUG - 2022-11-11 09:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:08:28 --> Total execution time: 0.1845
DEBUG - 2022-11-11 09:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:38:37 --> Total execution time: 0.1682
DEBUG - 2022-11-11 09:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:38:58 --> Total execution time: 0.2319
DEBUG - 2022-11-11 09:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:40:53 --> Total execution time: 1.7351
DEBUG - 2022-11-11 09:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 09:10:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 09:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:41:14 --> Total execution time: 0.4827
DEBUG - 2022-11-11 20:41:15 --> Total execution time: 1.8418
DEBUG - 2022-11-11 09:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:11:46 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:41:46 --> Total execution time: 0.2206
DEBUG - 2022-11-11 09:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:42:00 --> Total execution time: 1.8231
DEBUG - 2022-11-11 09:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:12:01 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:42:01 --> Total execution time: 0.1848
DEBUG - 2022-11-11 09:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:42:14 --> Total execution time: 0.2020
DEBUG - 2022-11-11 09:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:12:15 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:42:15 --> Total execution time: 0.1725
DEBUG - 2022-11-11 09:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:42:19 --> Total execution time: 0.1587
DEBUG - 2022-11-11 09:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:42:20 --> Total execution time: 0.2095
DEBUG - 2022-11-11 09:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:42:29 --> Total execution time: 0.1836
DEBUG - 2022-11-11 09:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:42:52 --> Total execution time: 0.1713
DEBUG - 2022-11-11 09:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:42:53 --> Total execution time: 0.1918
DEBUG - 2022-11-11 09:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:13:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 09:13:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 09:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:43:15 --> Total execution time: 0.5171
DEBUG - 2022-11-11 09:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:43:51 --> Total execution time: 0.1923
DEBUG - 2022-11-11 09:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:44:07 --> Total execution time: 0.1764
DEBUG - 2022-11-11 09:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:44:11 --> Total execution time: 0.2534
DEBUG - 2022-11-11 09:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:44:56 --> Total execution time: 0.1001
DEBUG - 2022-11-11 09:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:03 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:04 --> Total execution time: 0.4456
DEBUG - 2022-11-11 09:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:09 --> Total execution time: 0.1166
DEBUG - 2022-11-11 09:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:11 --> Total execution time: 0.1664
DEBUG - 2022-11-11 09:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:11 --> Total execution time: 0.2024
DEBUG - 2022-11-11 09:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:18 --> Total execution time: 0.2165
DEBUG - 2022-11-11 09:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:22 --> Total execution time: 0.2527
DEBUG - 2022-11-11 09:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:23 --> Total execution time: 0.2069
DEBUG - 2022-11-11 09:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:26 --> Total execution time: 0.1739
DEBUG - 2022-11-11 09:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:32 --> Total execution time: 0.2065
DEBUG - 2022-11-11 09:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:35 --> Total execution time: 0.2113
DEBUG - 2022-11-11 09:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:36 --> Total execution time: 0.2420
DEBUG - 2022-11-11 09:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:37 --> Total execution time: 0.1767
DEBUG - 2022-11-11 09:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:38 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:38 --> Total execution time: 0.1178
DEBUG - 2022-11-11 09:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 09:15:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 09:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:46 --> Total execution time: 0.2069
DEBUG - 2022-11-11 09:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:46 --> Total execution time: 0.2045
DEBUG - 2022-11-11 09:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:47 --> Total execution time: 0.2430
DEBUG - 2022-11-11 09:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:45:58 --> Total execution time: 0.2231
DEBUG - 2022-11-11 09:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:16:04 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:46:04 --> Total execution time: 0.1697
DEBUG - 2022-11-11 09:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:16:10 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:46:10 --> Total execution time: 0.1085
DEBUG - 2022-11-11 09:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:46:17 --> Total execution time: 2.2519
DEBUG - 2022-11-11 09:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:46:31 --> Total execution time: 0.4493
DEBUG - 2022-11-11 09:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:48:29 --> Total execution time: 0.1677
DEBUG - 2022-11-11 09:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:48:36 --> Total execution time: 2.1019
DEBUG - 2022-11-11 09:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:18:40 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:48:41 --> Total execution time: 0.1180
DEBUG - 2022-11-11 09:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:18:44 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:48:44 --> Total execution time: 0.1698
DEBUG - 2022-11-11 09:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:48:51 --> Total execution time: 0.1050
DEBUG - 2022-11-11 09:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:48:52 --> Total execution time: 0.1721
DEBUG - 2022-11-11 09:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:49:06 --> Total execution time: 0.1688
DEBUG - 2022-11-11 09:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:49:16 --> Total execution time: 0.2066
DEBUG - 2022-11-11 09:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:49:35 --> Total execution time: 0.1747
DEBUG - 2022-11-11 09:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:49:40 --> Total execution time: 0.1776
DEBUG - 2022-11-11 09:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:19:42 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:49:42 --> Total execution time: 0.5315
DEBUG - 2022-11-11 09:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:49:43 --> Total execution time: 0.1876
DEBUG - 2022-11-11 09:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:19:43 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:49:43 --> Total execution time: 0.1912
DEBUG - 2022-11-11 09:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:49:49 --> Total execution time: 0.1720
DEBUG - 2022-11-11 09:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:49:54 --> Total execution time: 0.1901
DEBUG - 2022-11-11 09:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:49:59 --> Total execution time: 0.4363
DEBUG - 2022-11-11 09:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:20:03 --> Total execution time: 0.1817
DEBUG - 2022-11-11 09:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:50:07 --> Total execution time: 0.1979
DEBUG - 2022-11-11 09:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:50:10 --> Total execution time: 0.1825
DEBUG - 2022-11-11 09:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:50:55 --> Total execution time: 0.1656
DEBUG - 2022-11-11 09:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:51:12 --> Total execution time: 0.1695
DEBUG - 2022-11-11 09:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:51:17 --> Total execution time: 0.2128
DEBUG - 2022-11-11 09:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:51:25 --> Total execution time: 0.2340
DEBUG - 2022-11-11 09:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:51:33 --> Total execution time: 0.1635
DEBUG - 2022-11-11 09:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:51:43 --> Total execution time: 0.1775
DEBUG - 2022-11-11 09:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:22:23 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:52:23 --> Total execution time: 0.1296
DEBUG - 2022-11-11 09:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:22:26 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:52:26 --> Total execution time: 0.1604
DEBUG - 2022-11-11 09:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:53:10 --> Total execution time: 0.1591
DEBUG - 2022-11-11 09:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:53:15 --> Total execution time: 0.1619
DEBUG - 2022-11-11 09:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:53:31 --> Total execution time: 0.1691
DEBUG - 2022-11-11 09:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:32 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:53:33 --> Total execution time: 0.4506
DEBUG - 2022-11-11 09:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:41 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:53:41 --> Total execution time: 0.1304
DEBUG - 2022-11-11 09:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:53:42 --> Total execution time: 0.1590
DEBUG - 2022-11-11 09:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:53:43 --> Total execution time: 0.2143
DEBUG - 2022-11-11 09:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:53:43 --> Total execution time: 0.4726
DEBUG - 2022-11-11 09:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:53:46 --> Total execution time: 0.1755
DEBUG - 2022-11-11 09:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:53:48 --> Total execution time: 0.1707
DEBUG - 2022-11-11 09:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:53:50 --> Total execution time: 0.2228
DEBUG - 2022-11-11 09:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:53:52 --> Total execution time: 0.1869
DEBUG - 2022-11-11 09:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:53:53 --> Total execution time: 0.1691
DEBUG - 2022-11-11 09:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:53:55 --> Total execution time: 0.1660
DEBUG - 2022-11-11 09:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:57 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:53:57 --> Total execution time: 0.1720
DEBUG - 2022-11-11 09:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:53:58 --> Total execution time: 0.1729
DEBUG - 2022-11-11 09:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:00 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:54:00 --> Total execution time: 0.1121
DEBUG - 2022-11-11 09:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:00 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:54:00 --> Total execution time: 0.1236
DEBUG - 2022-11-11 09:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:01 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:54:01 --> Total execution time: 0.1623
DEBUG - 2022-11-11 09:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:54:07 --> Total execution time: 0.1651
DEBUG - 2022-11-11 09:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:54:08 --> Total execution time: 0.1667
DEBUG - 2022-11-11 09:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:54:08 --> Total execution time: 0.1655
DEBUG - 2022-11-11 09:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:54:10 --> Total execution time: 0.1655
DEBUG - 2022-11-11 09:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:54:10 --> Total execution time: 0.1722
DEBUG - 2022-11-11 09:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:54:28 --> Total execution time: 0.1697
DEBUG - 2022-11-11 09:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:54:30 --> Total execution time: 0.1625
DEBUG - 2022-11-11 09:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:54:33 --> Total execution time: 0.2296
DEBUG - 2022-11-11 09:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:54:44 --> Total execution time: 0.1677
DEBUG - 2022-11-11 09:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:47 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:54:47 --> Total execution time: 0.1019
DEBUG - 2022-11-11 09:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:54:51 --> Total execution time: 0.1650
DEBUG - 2022-11-11 09:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:24:55 --> Total execution time: 0.1673
DEBUG - 2022-11-11 09:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:24:57 --> Total execution time: 0.1739
DEBUG - 2022-11-11 09:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:24:57 --> Total execution time: 0.1613
DEBUG - 2022-11-11 09:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:55:11 --> Total execution time: 0.1673
DEBUG - 2022-11-11 09:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:55:13 --> Total execution time: 0.1636
DEBUG - 2022-11-11 09:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:55:36 --> Total execution time: 0.1692
DEBUG - 2022-11-11 09:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 20:55:57 --> Total execution time: 1.6572
DEBUG - 2022-11-11 09:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:55:57 --> Total execution time: 0.5128
DEBUG - 2022-11-11 09:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 09:26:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 09:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:56:06 --> Total execution time: 0.2030
DEBUG - 2022-11-11 09:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:56:07 --> Total execution time: 0.1737
DEBUG - 2022-11-11 09:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:56:08 --> Total execution time: 0.1737
DEBUG - 2022-11-11 09:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:56:11 --> Total execution time: 0.1708
DEBUG - 2022-11-11 09:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:56:15 --> Total execution time: 0.1810
DEBUG - 2022-11-11 09:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:56:30 --> Total execution time: 0.1783
DEBUG - 2022-11-11 09:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:56:31 --> Total execution time: 0.3312
DEBUG - 2022-11-11 09:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:56:36 --> Total execution time: 0.1640
DEBUG - 2022-11-11 09:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:56:38 --> Total execution time: 0.2102
DEBUG - 2022-11-11 09:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:56:40 --> Total execution time: 0.2051
DEBUG - 2022-11-11 09:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:54 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:56:54 --> Total execution time: 0.1634
DEBUG - 2022-11-11 09:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:56:54 --> Total execution time: 0.4518
DEBUG - 2022-11-11 09:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:56:56 --> Total execution time: 0.2206
DEBUG - 2022-11-11 09:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:27:08 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:57:08 --> Total execution time: 0.1683
DEBUG - 2022-11-11 09:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:57:18 --> Total execution time: 0.1630
DEBUG - 2022-11-11 09:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:57:19 --> Total execution time: 0.1698
DEBUG - 2022-11-11 09:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:57:25 --> Total execution time: 0.1976
DEBUG - 2022-11-11 09:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:57:29 --> Total execution time: 0.2193
DEBUG - 2022-11-11 09:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:57:35 --> Total execution time: 0.2097
DEBUG - 2022-11-11 09:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:57:44 --> Total execution time: 0.2059
DEBUG - 2022-11-11 09:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:57:48 --> Total execution time: 0.4677
DEBUG - 2022-11-11 09:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:27:56 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:57:56 --> Total execution time: 0.1851
DEBUG - 2022-11-11 09:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:57:58 --> Total execution time: 0.1835
DEBUG - 2022-11-11 09:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:58:01 --> Total execution time: 0.2016
DEBUG - 2022-11-11 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:58:03 --> Total execution time: 0.2163
DEBUG - 2022-11-11 09:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:58:05 --> Total execution time: 0.1961
DEBUG - 2022-11-11 09:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:58:09 --> Total execution time: 0.1585
DEBUG - 2022-11-11 09:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:58:34 --> Total execution time: 0.1699
DEBUG - 2022-11-11 09:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:59:01 --> Total execution time: 0.1775
DEBUG - 2022-11-11 09:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:59:04 --> Total execution time: 0.4518
DEBUG - 2022-11-11 09:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:59:06 --> Total execution time: 0.1618
DEBUG - 2022-11-11 09:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:59:14 --> Total execution time: 0.2973
DEBUG - 2022-11-11 09:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:29:32 --> Total execution time: 0.1706
DEBUG - 2022-11-11 09:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:59:35 --> Total execution time: 0.2911
DEBUG - 2022-11-11 09:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:29:44 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 20:59:44 --> Total execution time: 0.1117
DEBUG - 2022-11-11 09:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:30:41 --> Total execution time: 0.1750
DEBUG - 2022-11-11 09:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:31:18 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:01:18 --> Total execution time: 0.1361
DEBUG - 2022-11-11 09:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:01:40 --> Total execution time: 0.1752
DEBUG - 2022-11-11 09:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:31:44 --> Total execution time: 0.1770
DEBUG - 2022-11-11 09:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:31:44 --> Total execution time: 0.3619
DEBUG - 2022-11-11 09:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:01:52 --> Total execution time: 0.1738
DEBUG - 2022-11-11 09:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:31:54 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:01:54 --> Total execution time: 0.1691
DEBUG - 2022-11-11 09:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:01:56 --> Total execution time: 0.1677
DEBUG - 2022-11-11 09:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:31:58 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:01:58 --> Total execution time: 0.1130
DEBUG - 2022-11-11 09:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:02:05 --> Total execution time: 0.1845
DEBUG - 2022-11-11 09:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:02:07 --> Total execution time: 0.2189
DEBUG - 2022-11-11 09:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:02:11 --> Total execution time: 0.1799
DEBUG - 2022-11-11 09:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:32:11 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:02:11 --> Total execution time: 0.1593
DEBUG - 2022-11-11 09:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:02:21 --> Total execution time: 0.1991
DEBUG - 2022-11-11 09:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:02:26 --> Total execution time: 0.1792
DEBUG - 2022-11-11 09:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:02:26 --> Total execution time: 0.1667
DEBUG - 2022-11-11 09:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:32:45 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:02:46 --> Total execution time: 0.1852
DEBUG - 2022-11-11 09:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:33:34 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:03:35 --> Total execution time: 0.4445
DEBUG - 2022-11-11 09:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:03:40 --> Total execution time: 0.1650
DEBUG - 2022-11-11 09:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:03:40 --> Total execution time: 0.1589
DEBUG - 2022-11-11 09:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:03:49 --> Total execution time: 0.1845
DEBUG - 2022-11-11 09:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:03:50 --> Total execution time: 0.1660
DEBUG - 2022-11-11 09:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:04:04 --> Total execution time: 0.1889
DEBUG - 2022-11-11 09:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:04:11 --> Total execution time: 0.2159
DEBUG - 2022-11-11 09:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:04:30 --> Total execution time: 0.2079
DEBUG - 2022-11-11 09:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:04:46 --> Total execution time: 0.1861
DEBUG - 2022-11-11 09:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:04:51 --> Total execution time: 0.1928
DEBUG - 2022-11-11 09:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:04:52 --> Total execution time: 0.1958
DEBUG - 2022-11-11 09:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:04:57 --> Total execution time: 0.2220
DEBUG - 2022-11-11 09:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:05:01 --> Total execution time: 0.1724
DEBUG - 2022-11-11 09:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:05:04 --> Total execution time: 0.1356
DEBUG - 2022-11-11 09:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:05:09 --> Total execution time: 0.1789
DEBUG - 2022-11-11 09:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:19 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:05:19 --> Total execution time: 0.2304
DEBUG - 2022-11-11 09:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:20 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:05:20 --> Total execution time: 0.2270
DEBUG - 2022-11-11 09:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:05:25 --> Total execution time: 0.1868
DEBUG - 2022-11-11 09:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:05:26 --> Total execution time: 0.2339
DEBUG - 2022-11-11 09:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:05:26 --> Total execution time: 0.1883
DEBUG - 2022-11-11 09:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:05:27 --> Total execution time: 0.1817
DEBUG - 2022-11-11 09:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:05:28 --> Total execution time: 0.1804
DEBUG - 2022-11-11 09:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:05:34 --> Total execution time: 0.2123
DEBUG - 2022-11-11 09:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:05:35 --> Total execution time: 0.1847
DEBUG - 2022-11-11 09:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:05:47 --> Total execution time: 0.2388
DEBUG - 2022-11-11 09:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:05:50 --> Total execution time: 0.1714
DEBUG - 2022-11-11 09:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:05:54 --> Total execution time: 0.1647
DEBUG - 2022-11-11 09:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:36:02 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:06:03 --> Total execution time: 0.4504
DEBUG - 2022-11-11 09:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:36:06 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:06:06 --> Total execution time: 0.1706
DEBUG - 2022-11-11 09:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:06:12 --> Total execution time: 0.2258
DEBUG - 2022-11-11 09:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:06:19 --> Total execution time: 0.4625
DEBUG - 2022-11-11 09:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:06:49 --> Total execution time: 0.1944
DEBUG - 2022-11-11 09:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:37:13 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:07:13 --> Total execution time: 0.1111
DEBUG - 2022-11-11 09:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:37:20 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:07:20 --> Total execution time: 0.1853
DEBUG - 2022-11-11 09:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:07:42 --> Total execution time: 0.1978
DEBUG - 2022-11-11 09:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:37:57 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:07:58 --> Total execution time: 0.1152
DEBUG - 2022-11-11 09:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:38:32 --> Total execution time: 0.1702
DEBUG - 2022-11-11 09:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:38:35 --> Total execution time: 0.1680
DEBUG - 2022-11-11 09:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:38:35 --> Total execution time: 0.1691
DEBUG - 2022-11-11 09:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:38:37 --> Total execution time: 0.1650
DEBUG - 2022-11-11 09:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:38:39 --> Total execution time: 0.1648
DEBUG - 2022-11-11 09:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:38:39 --> Total execution time: 0.3829
DEBUG - 2022-11-11 09:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:08:41 --> Total execution time: 0.1968
DEBUG - 2022-11-11 09:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:08:48 --> Total execution time: 0.1924
DEBUG - 2022-11-11 09:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:09:26 --> Total execution time: 0.1583
DEBUG - 2022-11-11 09:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:09:28 --> Total execution time: 0.1941
DEBUG - 2022-11-11 09:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:39:30 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:09:30 --> Total execution time: 0.1210
DEBUG - 2022-11-11 09:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:09:39 --> Total execution time: 0.1857
DEBUG - 2022-11-11 09:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:10:33 --> Total execution time: 0.1716
DEBUG - 2022-11-11 09:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:40:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 09:40:38 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 09:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:40:54 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:10:54 --> Total execution time: 0.1081
DEBUG - 2022-11-11 09:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:11:01 --> Total execution time: 0.2135
DEBUG - 2022-11-11 09:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:11:15 --> Total execution time: 0.2232
DEBUG - 2022-11-11 09:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:11:25 --> Total execution time: 0.2428
DEBUG - 2022-11-11 09:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:12:10 --> Total execution time: 2.3671
DEBUG - 2022-11-11 09:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:42:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 09:42:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 09:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:12:47 --> Total execution time: 0.4539
DEBUG - 2022-11-11 09:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:12:48 --> Total execution time: 0.2024
DEBUG - 2022-11-11 09:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:13:45 --> Total execution time: 0.1983
DEBUG - 2022-11-11 09:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:43:52 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:13:53 --> Total execution time: 0.4634
DEBUG - 2022-11-11 09:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:13:54 --> Total execution time: 0.1808
DEBUG - 2022-11-11 09:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:13:59 --> Total execution time: 0.1772
DEBUG - 2022-11-11 09:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:01 --> Total execution time: 0.1820
DEBUG - 2022-11-11 09:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:09 --> Total execution time: 0.1730
DEBUG - 2022-11-11 09:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:12 --> Total execution time: 0.1748
DEBUG - 2022-11-11 09:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:13 --> Total execution time: 0.2175
DEBUG - 2022-11-11 09:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:14 --> Total execution time: 0.1904
DEBUG - 2022-11-11 09:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:15 --> Total execution time: 0.1671
DEBUG - 2022-11-11 09:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:19 --> Total execution time: 0.1766
DEBUG - 2022-11-11 09:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:20 --> Total execution time: 0.1820
DEBUG - 2022-11-11 09:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:26 --> Total execution time: 0.1985
DEBUG - 2022-11-11 09:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:27 --> Total execution time: 0.1899
DEBUG - 2022-11-11 09:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:35 --> Total execution time: 0.4593
DEBUG - 2022-11-11 09:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:36 --> Total execution time: 0.1590
DEBUG - 2022-11-11 09:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:37 --> Total execution time: 0.1717
DEBUG - 2022-11-11 09:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:37 --> Total execution time: 0.2001
DEBUG - 2022-11-11 09:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:37 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:37 --> Total execution time: 0.1749
DEBUG - 2022-11-11 09:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:38 --> Total execution time: 0.3835
DEBUG - 2022-11-11 09:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:38 --> Total execution time: 0.4070
DEBUG - 2022-11-11 09:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:38 --> Total execution time: 0.5626
DEBUG - 2022-11-11 09:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:38 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:39 --> Total execution time: 0.1686
DEBUG - 2022-11-11 09:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:14:45 --> Total execution time: 0.1638
DEBUG - 2022-11-11 09:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:20:15 --> Total execution time: 0.4252
DEBUG - 2022-11-11 09:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:20:47 --> Total execution time: 1.0728
DEBUG - 2022-11-11 09:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:21:05 --> Total execution time: 0.2062
DEBUG - 2022-11-11 09:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:21:05 --> Total execution time: 0.7203
DEBUG - 2022-11-11 09:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:21:09 --> Total execution time: 0.4538
DEBUG - 2022-11-11 09:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:21:29 --> Total execution time: 0.2016
DEBUG - 2022-11-11 09:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:51:39 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:21:39 --> Total execution time: 0.4599
DEBUG - 2022-11-11 09:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:21:48 --> Total execution time: 1.9628
DEBUG - 2022-11-11 09:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:52:38 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:22:38 --> Total execution time: 0.1815
DEBUG - 2022-11-11 09:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:22:43 --> Total execution time: 1.8971
DEBUG - 2022-11-11 09:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:52:47 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:22:47 --> Total execution time: 0.4789
DEBUG - 2022-11-11 09:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:23:00 --> Total execution time: 0.1895
DEBUG - 2022-11-11 09:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:23:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-11 09:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:23:04 --> Total execution time: 0.1964
DEBUG - 2022-11-11 09:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:23:12 --> Total execution time: 0.1845
DEBUG - 2022-11-11 09:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:23:17 --> Total execution time: 0.1796
DEBUG - 2022-11-11 09:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:23:24 --> Total execution time: 0.1722
DEBUG - 2022-11-11 09:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:23:27 --> Total execution time: 0.1871
DEBUG - 2022-11-11 09:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:23:32 --> Total execution time: 0.1727
DEBUG - 2022-11-11 09:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:23:55 --> Total execution time: 0.1663
DEBUG - 2022-11-11 09:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:24:04 --> Total execution time: 0.4620
DEBUG - 2022-11-11 09:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:24:07 --> Total execution time: 0.1735
DEBUG - 2022-11-11 09:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:54:15 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:24:16 --> Total execution time: 0.1668
DEBUG - 2022-11-11 09:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:54:21 --> Total execution time: 0.1726
DEBUG - 2022-11-11 09:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:54:24 --> Total execution time: 0.1721
DEBUG - 2022-11-11 09:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:54:25 --> Total execution time: 0.1732
DEBUG - 2022-11-11 09:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:27:21 --> Total execution time: 0.4852
DEBUG - 2022-11-11 09:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:27:31 --> Total execution time: 0.1953
DEBUG - 2022-11-11 09:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:28:02 --> Total execution time: 0.1056
DEBUG - 2022-11-11 09:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:58:17 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:28:17 --> Total execution time: 0.4428
DEBUG - 2022-11-11 09:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 09:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:28:24 --> Total execution time: 0.1838
DEBUG - 2022-11-11 09:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:59:40 --> No URI present. Default controller set.
DEBUG - 2022-11-11 09:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:29:40 --> Total execution time: 0.4481
DEBUG - 2022-11-11 09:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:29:44 --> Total execution time: 0.4504
DEBUG - 2022-11-11 09:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 09:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 09:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:29:46 --> Total execution time: 0.2005
DEBUG - 2022-11-11 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:30:02 --> Total execution time: 0.1364
DEBUG - 2022-11-11 10:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:30:15 --> Total execution time: 0.2249
DEBUG - 2022-11-11 10:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:00:24 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:30:24 --> Total execution time: 0.4378
DEBUG - 2022-11-11 10:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:30:29 --> Total execution time: 0.1747
DEBUG - 2022-11-11 10:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:02:50 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:32:50 --> Total execution time: 0.1916
DEBUG - 2022-11-11 10:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:32:56 --> Total execution time: 0.1790
DEBUG - 2022-11-11 10:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:33:02 --> Total execution time: 0.1721
DEBUG - 2022-11-11 10:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:33:09 --> Total execution time: 0.1917
DEBUG - 2022-11-11 10:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:03:23 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:33:23 --> Total execution time: 0.1160
DEBUG - 2022-11-11 10:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:33:28 --> Total execution time: 0.1218
DEBUG - 2022-11-11 10:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:33:37 --> Total execution time: 0.1801
DEBUG - 2022-11-11 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:33:38 --> Total execution time: 0.1713
DEBUG - 2022-11-11 10:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:33:47 --> Total execution time: 0.1825
DEBUG - 2022-11-11 10:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:33:55 --> Total execution time: 0.1666
DEBUG - 2022-11-11 10:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:34:00 --> Total execution time: 0.1768
DEBUG - 2022-11-11 10:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:34:09 --> Total execution time: 0.1878
DEBUG - 2022-11-11 10:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:34:10 --> Total execution time: 0.1809
DEBUG - 2022-11-11 10:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:34:17 --> Total execution time: 0.1788
DEBUG - 2022-11-11 10:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:34:20 --> Total execution time: 0.1743
DEBUG - 2022-11-11 10:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:34:23 --> Total execution time: 0.2100
DEBUG - 2022-11-11 10:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:34:29 --> Total execution time: 0.1890
DEBUG - 2022-11-11 10:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:06:20 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:36:20 --> Total execution time: 0.4410
DEBUG - 2022-11-11 10:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:36:55 --> Total execution time: 2.2776
DEBUG - 2022-11-11 10:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:38:05 --> Total execution time: 1.6811
DEBUG - 2022-11-11 10:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:39:45 --> Total execution time: 0.4407
DEBUG - 2022-11-11 10:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:39:54 --> Total execution time: 0.1149
DEBUG - 2022-11-11 10:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:40:49 --> Total execution time: 0.2305
DEBUG - 2022-11-11 10:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:41:03 --> Total execution time: 0.1794
DEBUG - 2022-11-11 10:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:41:12 --> Total execution time: 0.1716
DEBUG - 2022-11-11 10:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:41:19 --> Total execution time: 0.1764
DEBUG - 2022-11-11 10:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:41:46 --> Total execution time: 0.1748
DEBUG - 2022-11-11 10:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:41:49 --> Total execution time: 0.1619
DEBUG - 2022-11-11 10:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:41:52 --> Total execution time: 0.1732
DEBUG - 2022-11-11 10:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:43:58 --> Total execution time: 0.4592
DEBUG - 2022-11-11 10:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:44:19 --> Total execution time: 0.1755
DEBUG - 2022-11-11 10:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:14:20 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:44:20 --> Total execution time: 0.4633
DEBUG - 2022-11-11 10:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:44:30 --> Total execution time: 0.1700
DEBUG - 2022-11-11 10:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:44:35 --> Total execution time: 0.4817
DEBUG - 2022-11-11 10:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:44:38 --> Total execution time: 0.1863
DEBUG - 2022-11-11 10:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:44:42 --> Total execution time: 0.1869
DEBUG - 2022-11-11 10:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:44:53 --> Total execution time: 0.1637
DEBUG - 2022-11-11 10:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:44:55 --> Total execution time: 0.1770
DEBUG - 2022-11-11 10:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:45:03 --> Total execution time: 0.2201
DEBUG - 2022-11-11 10:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:16:14 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:46:14 --> Total execution time: 0.1371
DEBUG - 2022-11-11 10:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:16:15 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:46:15 --> Total execution time: 0.1231
DEBUG - 2022-11-11 10:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:46:28 --> Total execution time: 0.1267
DEBUG - 2022-11-11 10:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:46:48 --> Total execution time: 0.1711
DEBUG - 2022-11-11 10:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:16:55 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:46:55 --> Total execution time: 0.1722
DEBUG - 2022-11-11 10:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:18:08 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:48:08 --> Total execution time: 0.1107
DEBUG - 2022-11-11 10:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:19:06 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:49:06 --> Total execution time: 0.1078
DEBUG - 2022-11-11 10:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:19:20 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:49:20 --> Total execution time: 0.1235
DEBUG - 2022-11-11 10:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:50:11 --> Total execution time: 0.1684
DEBUG - 2022-11-11 10:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:50:12 --> Total execution time: 0.1589
DEBUG - 2022-11-11 10:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:20:42 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:50:42 --> Total execution time: 0.1143
DEBUG - 2022-11-11 10:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:51:27 --> Total execution time: 0.4467
DEBUG - 2022-11-11 10:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:51:30 --> Total execution time: 0.1628
DEBUG - 2022-11-11 10:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:21:37 --> Total execution time: 0.1700
DEBUG - 2022-11-11 10:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:21:44 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:51:44 --> Total execution time: 0.4566
DEBUG - 2022-11-11 10:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:51:45 --> Total execution time: 0.4559
DEBUG - 2022-11-11 10:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:51:47 --> Total execution time: 0.2463
DEBUG - 2022-11-11 10:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:51:52 --> Total execution time: 0.2125
DEBUG - 2022-11-11 10:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:51:53 --> Total execution time: 0.2058
DEBUG - 2022-11-11 10:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:51:56 --> Total execution time: 0.2056
DEBUG - 2022-11-11 10:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:51:58 --> Total execution time: 0.1995
DEBUG - 2022-11-11 10:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:52:00 --> Total execution time: 0.1981
DEBUG - 2022-11-11 10:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:52:20 --> Total execution time: 0.2084
DEBUG - 2022-11-11 10:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:52:32 --> Total execution time: 0.2855
DEBUG - 2022-11-11 10:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:22:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 10:22:54 --> 404 Page Not Found: Well-known/traffic-advice
DEBUG - 2022-11-11 10:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:22:55 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:52:55 --> Total execution time: 0.1065
DEBUG - 2022-11-11 10:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:22:58 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:52:58 --> Total execution time: 0.1671
DEBUG - 2022-11-11 10:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:53:05 --> Total execution time: 0.1593
DEBUG - 2022-11-11 10:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:53:14 --> Total execution time: 0.1871
DEBUG - 2022-11-11 10:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:53:22 --> Total execution time: 0.1798
DEBUG - 2022-11-11 10:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:23:52 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:53:52 --> Total execution time: 0.1051
DEBUG - 2022-11-11 10:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:23:59 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:53:59 --> Total execution time: 0.1648
DEBUG - 2022-11-11 10:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:01 --> Total execution time: 0.3207
DEBUG - 2022-11-11 10:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:02 --> Total execution time: 0.2420
DEBUG - 2022-11-11 10:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:04 --> Total execution time: 0.2267
DEBUG - 2022-11-11 10:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:05 --> Total execution time: 0.1731
DEBUG - 2022-11-11 10:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:05 --> Total execution time: 0.0991
DEBUG - 2022-11-11 10:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:05 --> Total execution time: 0.1610
DEBUG - 2022-11-11 10:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:08 --> Total execution time: 0.2091
DEBUG - 2022-11-11 10:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:09 --> Total execution time: 0.2110
DEBUG - 2022-11-11 10:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:09 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:09 --> Total execution time: 0.1095
DEBUG - 2022-11-11 10:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:10 --> Total execution time: 0.2062
DEBUG - 2022-11-11 10:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:10 --> Total execution time: 0.2163
DEBUG - 2022-11-11 10:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:12 --> Total execution time: 0.2092
DEBUG - 2022-11-11 10:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:13 --> Total execution time: 0.2308
DEBUG - 2022-11-11 10:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:13 --> Total execution time: 0.2120
DEBUG - 2022-11-11 10:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:14 --> Total execution time: 0.1984
DEBUG - 2022-11-11 10:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:14 --> Total execution time: 0.2331
DEBUG - 2022-11-11 10:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:15 --> Total execution time: 0.1925
DEBUG - 2022-11-11 10:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:15 --> Total execution time: 0.3135
DEBUG - 2022-11-11 10:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:16 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:16 --> Total execution time: 0.2131
DEBUG - 2022-11-11 10:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:21 --> Total execution time: 0.1985
DEBUG - 2022-11-11 10:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:25 --> Total execution time: 0.1726
DEBUG - 2022-11-11 10:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:30 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:30 --> Total execution time: 0.1130
DEBUG - 2022-11-11 10:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:36 --> Total execution time: 0.3096
DEBUG - 2022-11-11 10:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:41 --> Total execution time: 0.1933
DEBUG - 2022-11-11 10:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:47 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:47 --> Total execution time: 0.1346
DEBUG - 2022-11-11 10:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:52 --> Total execution time: 0.4528
DEBUG - 2022-11-11 10:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:54:59 --> Total execution time: 0.1701
DEBUG - 2022-11-11 10:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:55:00 --> Total execution time: 0.1820
DEBUG - 2022-11-11 10:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:55:13 --> Total execution time: 0.1676
DEBUG - 2022-11-11 10:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:55:19 --> Total execution time: 0.1679
DEBUG - 2022-11-11 10:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:55:27 --> Total execution time: 0.1849
DEBUG - 2022-11-11 10:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:55:29 --> Total execution time: 0.1725
DEBUG - 2022-11-11 10:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:55:32 --> Total execution time: 0.1678
DEBUG - 2022-11-11 10:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:25:35 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:55:35 --> Total execution time: 0.1753
DEBUG - 2022-11-11 10:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:25:44 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:55:44 --> Total execution time: 0.1751
DEBUG - 2022-11-11 10:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:25:47 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:55:48 --> Total execution time: 0.1404
DEBUG - 2022-11-11 10:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:25:52 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:55:53 --> Total execution time: 0.4443
DEBUG - 2022-11-11 10:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:25:58 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:55:58 --> Total execution time: 0.2615
DEBUG - 2022-11-11 10:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:05 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:05 --> Total execution time: 0.2055
DEBUG - 2022-11-11 10:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:06 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:06 --> Total execution time: 0.2001
DEBUG - 2022-11-11 10:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:06 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:06 --> Total execution time: 0.1907
DEBUG - 2022-11-11 10:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:09 --> Total execution time: 0.1665
DEBUG - 2022-11-11 10:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:10 --> Total execution time: 0.1730
DEBUG - 2022-11-11 10:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:12 --> Total execution time: 0.3351
DEBUG - 2022-11-11 10:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:13 --> Total execution time: 0.1748
DEBUG - 2022-11-11 10:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:16 --> Total execution time: 0.2459
DEBUG - 2022-11-11 10:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:20 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:20 --> Total execution time: 0.1730
DEBUG - 2022-11-11 10:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:23 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:23 --> Total execution time: 0.1657
DEBUG - 2022-11-11 10:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:24 --> Total execution time: 0.4564
DEBUG - 2022-11-11 10:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:28 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:29 --> Total execution time: 0.1803
DEBUG - 2022-11-11 10:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:31 --> Total execution time: 0.2108
DEBUG - 2022-11-11 10:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:32 --> Total execution time: 0.1818
DEBUG - 2022-11-11 10:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:33 --> Total execution time: 0.1672
DEBUG - 2022-11-11 10:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:35 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:35 --> Total execution time: 0.1815
DEBUG - 2022-11-11 10:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:56:44 --> Total execution time: 0.1626
DEBUG - 2022-11-11 10:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:57:07 --> Total execution time: 0.4752
DEBUG - 2022-11-11 10:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:57:09 --> Total execution time: 0.2052
DEBUG - 2022-11-11 10:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:57:14 --> Total execution time: 0.2023
DEBUG - 2022-11-11 10:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:57:20 --> Total execution time: 0.2378
DEBUG - 2022-11-11 10:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:27:21 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:57:21 --> Total execution time: 0.1651
DEBUG - 2022-11-11 10:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:57:27 --> Total execution time: 0.1584
DEBUG - 2022-11-11 10:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:27:35 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:57:35 --> Total execution time: 0.1662
DEBUG - 2022-11-11 10:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:57:44 --> Total execution time: 0.4761
DEBUG - 2022-11-11 10:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:27:48 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:57:48 --> Total execution time: 0.1614
DEBUG - 2022-11-11 10:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:27:50 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:57:50 --> Total execution time: 0.1950
DEBUG - 2022-11-11 10:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:57:52 --> Total execution time: 0.2160
DEBUG - 2022-11-11 10:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:27:53 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:57:53 --> Total execution time: 0.1972
DEBUG - 2022-11-11 10:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:28:01 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:58:01 --> Total execution time: 0.1741
DEBUG - 2022-11-11 10:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:28:24 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:58:24 --> Total execution time: 0.4575
DEBUG - 2022-11-11 10:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:28:31 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:58:32 --> Total execution time: 0.1677
DEBUG - 2022-11-11 10:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:28:41 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:58:41 --> Total execution time: 0.1757
DEBUG - 2022-11-11 10:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:28:55 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:58:55 --> Total execution time: 0.2088
DEBUG - 2022-11-11 10:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:28:56 --> Total execution time: 0.1726
DEBUG - 2022-11-11 10:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:58:58 --> Total execution time: 0.1670
DEBUG - 2022-11-11 10:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:59:04 --> Total execution time: 0.1634
DEBUG - 2022-11-11 10:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:29:15 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:59:15 --> Total execution time: 0.2121
DEBUG - 2022-11-11 10:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:59:15 --> Total execution time: 0.2122
DEBUG - 2022-11-11 10:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:29:16 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:59:16 --> Total execution time: 0.1739
DEBUG - 2022-11-11 10:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:59:20 --> Total execution time: 0.1847
DEBUG - 2022-11-11 10:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:59:25 --> Total execution time: 0.1870
DEBUG - 2022-11-11 10:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:29:34 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:59:34 --> Total execution time: 0.1639
DEBUG - 2022-11-11 10:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:29:39 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:59:39 --> Total execution time: 0.1793
DEBUG - 2022-11-11 10:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 21:59:53 --> Total execution time: 0.1771
DEBUG - 2022-11-11 10:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:00:07 --> Total execution time: 0.1725
DEBUG - 2022-11-11 10:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:30:11 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:00:11 --> Total execution time: 0.1695
DEBUG - 2022-11-11 10:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:30:13 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:00:14 --> Total execution time: 0.1797
DEBUG - 2022-11-11 10:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:00:15 --> Total execution time: 0.1681
DEBUG - 2022-11-11 10:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:30:18 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:00:18 --> Total execution time: 0.1727
DEBUG - 2022-11-11 10:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:30:26 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:00:26 --> Total execution time: 0.1610
DEBUG - 2022-11-11 10:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:30:32 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:00:32 --> Total execution time: 0.1929
DEBUG - 2022-11-11 10:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:00:36 --> Total execution time: 0.1875
DEBUG - 2022-11-11 10:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:00:42 --> Total execution time: 0.1652
DEBUG - 2022-11-11 10:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:30:45 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:00:45 --> Total execution time: 0.2164
DEBUG - 2022-11-11 10:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:00:59 --> Total execution time: 0.1732
DEBUG - 2022-11-11 10:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:01:11 --> Total execution time: 0.1737
DEBUG - 2022-11-11 10:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:31:16 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:01:16 --> Total execution time: 0.1184
DEBUG - 2022-11-11 10:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:31:16 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:01:16 --> Total execution time: 0.1662
DEBUG - 2022-11-11 10:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:01:21 --> Total execution time: 0.1719
DEBUG - 2022-11-11 10:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:31:22 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:01:22 --> Total execution time: 0.2439
DEBUG - 2022-11-11 10:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:31:25 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:01:26 --> Total execution time: 0.1892
DEBUG - 2022-11-11 10:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:01:30 --> Total execution time: 0.1901
DEBUG - 2022-11-11 10:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:01:35 --> Total execution time: 0.2055
DEBUG - 2022-11-11 10:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:31:36 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:01:37 --> Total execution time: 0.1674
DEBUG - 2022-11-11 10:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:31:37 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:01:38 --> Total execution time: 0.1341
DEBUG - 2022-11-11 10:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:01:46 --> Total execution time: 0.1717
DEBUG - 2022-11-11 10:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:01:54 --> Total execution time: 0.1688
DEBUG - 2022-11-11 10:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:01 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:02:01 --> Total execution time: 0.1786
DEBUG - 2022-11-11 10:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:02:05 --> Total execution time: 0.1608
DEBUG - 2022-11-11 10:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:11 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:02:11 --> Total execution time: 0.1120
DEBUG - 2022-11-11 10:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:13 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:02:13 --> Total execution time: 0.1922
DEBUG - 2022-11-11 10:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:02:18 --> Total execution time: 0.2243
DEBUG - 2022-11-11 10:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:19 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:02:20 --> Total execution time: 0.1712
DEBUG - 2022-11-11 10:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:22 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:02:22 --> Total execution time: 0.1679
DEBUG - 2022-11-11 10:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:02:23 --> Total execution time: 0.5121
DEBUG - 2022-11-11 10:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:34 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:02:34 --> Total execution time: 0.1064
DEBUG - 2022-11-11 10:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:02:34 --> Total execution time: 0.1898
DEBUG - 2022-11-11 10:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:02:41 --> Total execution time: 0.1739
DEBUG - 2022-11-11 10:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:02:46 --> Total execution time: 0.1170
DEBUG - 2022-11-11 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:02:48 --> Total execution time: 0.1739
DEBUG - 2022-11-11 10:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:02:49 --> Total execution time: 0.1816
DEBUG - 2022-11-11 10:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:03:01 --> Total execution time: 0.2076
DEBUG - 2022-11-11 10:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:10 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:03:11 --> Total execution time: 0.1607
DEBUG - 2022-11-11 10:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:15 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:03:15 --> Total execution time: 0.1751
DEBUG - 2022-11-11 10:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:03:19 --> Total execution time: 0.2894
DEBUG - 2022-11-11 10:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:03:23 --> Total execution time: 0.1715
DEBUG - 2022-11-11 10:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:03:28 --> Total execution time: 0.1898
DEBUG - 2022-11-11 10:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:03:39 --> Total execution time: 0.1716
DEBUG - 2022-11-11 10:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:03:49 --> Total execution time: 0.1806
DEBUG - 2022-11-11 10:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:03:52 --> Total execution time: 0.2071
DEBUG - 2022-11-11 10:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:03:55 --> Total execution time: 0.1716
DEBUG - 2022-11-11 10:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:03:56 --> Total execution time: 0.1780
DEBUG - 2022-11-11 10:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:03:57 --> Total execution time: 0.1731
DEBUG - 2022-11-11 10:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:34:00 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:04:01 --> Total execution time: 0.1816
DEBUG - 2022-11-11 10:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:34:07 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:04:07 --> Total execution time: 0.1694
DEBUG - 2022-11-11 10:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:34:14 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:04:15 --> Total execution time: 0.1704
DEBUG - 2022-11-11 10:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:04:18 --> Total execution time: 0.1642
DEBUG - 2022-11-11 10:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:04:20 --> Total execution time: 0.1743
DEBUG - 2022-11-11 10:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:34:30 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:04:30 --> Total execution time: 0.1761
DEBUG - 2022-11-11 10:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:34:35 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:04:35 --> Total execution time: 0.1778
DEBUG - 2022-11-11 10:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:04:38 --> Total execution time: 0.1624
DEBUG - 2022-11-11 10:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:34:44 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:04:44 --> Total execution time: 0.1997
DEBUG - 2022-11-11 10:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:04:48 --> Total execution time: 0.1749
DEBUG - 2022-11-11 10:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:34:49 --> Total execution time: 0.1695
DEBUG - 2022-11-11 10:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:04:54 --> Total execution time: 0.4498
DEBUG - 2022-11-11 10:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:34:59 --> Total execution time: 0.2315
DEBUG - 2022-11-11 10:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:35:00 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:05:00 --> Total execution time: 0.1789
DEBUG - 2022-11-11 10:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:35:03 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:05:03 --> Total execution time: 0.2015
DEBUG - 2022-11-11 10:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:35:07 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:05:08 --> Total execution time: 0.4561
DEBUG - 2022-11-11 10:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:35:10 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:05:11 --> Total execution time: 0.1702
DEBUG - 2022-11-11 10:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:35:17 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:05:17 --> Total execution time: 0.1101
DEBUG - 2022-11-11 10:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:05:18 --> Total execution time: 0.1791
DEBUG - 2022-11-11 10:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:05:26 --> Total execution time: 0.1716
DEBUG - 2022-11-11 10:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:05:28 --> Total execution time: 0.1913
DEBUG - 2022-11-11 10:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:35:30 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:05:31 --> Total execution time: 0.1963
DEBUG - 2022-11-11 10:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:05:32 --> Total execution time: 0.1772
DEBUG - 2022-11-11 10:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:35:59 --> Total execution time: 0.1696
DEBUG - 2022-11-11 10:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:05:59 --> Total execution time: 0.1751
DEBUG - 2022-11-11 10:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:05:59 --> Total execution time: 0.1951
DEBUG - 2022-11-11 10:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:36:00 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:06:01 --> Total execution time: 0.2193
DEBUG - 2022-11-11 10:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:06:02 --> Total execution time: 0.3408
DEBUG - 2022-11-11 10:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:06:05 --> Total execution time: 0.2353
DEBUG - 2022-11-11 10:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:06:07 --> Total execution time: 0.2377
DEBUG - 2022-11-11 10:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:06:21 --> Total execution time: 0.1789
DEBUG - 2022-11-11 10:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:06:28 --> Total execution time: 0.1680
DEBUG - 2022-11-11 10:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:06:44 --> Total execution time: 0.1775
DEBUG - 2022-11-11 10:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:06:53 --> Total execution time: 0.1692
DEBUG - 2022-11-11 10:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:07:02 --> Total execution time: 0.2295
DEBUG - 2022-11-11 10:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:37:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 10:37:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 10:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:07:15 --> Total execution time: 0.1814
DEBUG - 2022-11-11 10:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:07:22 --> Total execution time: 0.1886
DEBUG - 2022-11-11 10:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:07:26 --> Total execution time: 0.2188
DEBUG - 2022-11-11 10:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:07:32 --> Total execution time: 0.1785
DEBUG - 2022-11-11 10:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:07:40 --> Total execution time: 0.4746
DEBUG - 2022-11-11 10:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:07:44 --> Total execution time: 0.1725
DEBUG - 2022-11-11 10:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:07:52 --> Total execution time: 0.2087
DEBUG - 2022-11-11 10:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:38:35 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:08:35 --> Total execution time: 0.4730
DEBUG - 2022-11-11 10:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:38:37 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:08:37 --> Total execution time: 0.1851
DEBUG - 2022-11-11 10:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:09:02 --> Total execution time: 0.1745
DEBUG - 2022-11-11 10:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:09:09 --> Total execution time: 0.1681
DEBUG - 2022-11-11 10:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:09:14 --> Total execution time: 0.2173
DEBUG - 2022-11-11 10:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:09:30 --> Total execution time: 0.5079
DEBUG - 2022-11-11 10:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:09:53 --> Total execution time: 0.1720
DEBUG - 2022-11-11 10:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:40:20 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:10:20 --> Total execution time: 0.4418
DEBUG - 2022-11-11 10:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:10:26 --> Total execution time: 0.1609
DEBUG - 2022-11-11 10:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:10:31 --> Total execution time: 0.1645
DEBUG - 2022-11-11 10:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:40:34 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:10:34 --> Total execution time: 0.4395
DEBUG - 2022-11-11 10:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:10:37 --> Total execution time: 0.1809
DEBUG - 2022-11-11 10:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:10:44 --> Total execution time: 0.1752
DEBUG - 2022-11-11 10:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:40:47 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:10:47 --> Total execution time: 0.1982
DEBUG - 2022-11-11 10:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:10:53 --> Total execution time: 0.1727
DEBUG - 2022-11-11 22:10:53 --> Total execution time: 0.2257
DEBUG - 2022-11-11 10:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:10:57 --> Total execution time: 0.1724
DEBUG - 2022-11-11 10:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:41:10 --> Total execution time: 0.1913
DEBUG - 2022-11-11 10:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:11:12 --> Total execution time: 0.1906
DEBUG - 2022-11-11 10:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:41:16 --> Total execution time: 0.2334
DEBUG - 2022-11-11 10:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:41:18 --> Total execution time: 0.1633
DEBUG - 2022-11-11 10:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:11:25 --> Total execution time: 0.2037
DEBUG - 2022-11-11 10:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:41:27 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:11:28 --> Total execution time: 0.1920
DEBUG - 2022-11-11 10:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:11:28 --> Total execution time: 0.4707
DEBUG - 2022-11-11 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:11:35 --> Total execution time: 0.1685
DEBUG - 2022-11-11 10:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:11:35 --> Total execution time: 0.1954
DEBUG - 2022-11-11 10:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:11:52 --> Total execution time: 0.1649
DEBUG - 2022-11-11 10:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:42:00 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:12:00 --> Total execution time: 0.2270
DEBUG - 2022-11-11 10:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:12:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-11 10:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:12:16 --> Total execution time: 0.1982
DEBUG - 2022-11-11 10:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:42:20 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:12:21 --> Total execution time: 0.1331
DEBUG - 2022-11-11 10:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:12:33 --> Total execution time: 0.1783
DEBUG - 2022-11-11 10:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:42:37 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:12:37 --> Total execution time: 0.1057
DEBUG - 2022-11-11 10:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:12:43 --> Total execution time: 0.4476
DEBUG - 2022-11-11 10:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:12:45 --> Total execution time: 0.2072
DEBUG - 2022-11-11 10:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:42:46 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:12:46 --> Total execution time: 0.2130
DEBUG - 2022-11-11 10:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:12:52 --> Total execution time: 0.1679
DEBUG - 2022-11-11 10:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:12:59 --> Total execution time: 0.1923
DEBUG - 2022-11-11 10:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:13:02 --> Total execution time: 0.1817
DEBUG - 2022-11-11 10:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:13:13 --> Total execution time: 0.1692
DEBUG - 2022-11-11 10:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:13:17 --> Total execution time: 0.1851
DEBUG - 2022-11-11 10:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:13:23 --> Total execution time: 0.1786
DEBUG - 2022-11-11 10:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:13:30 --> Total execution time: 0.1710
DEBUG - 2022-11-11 10:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:13:31 --> Total execution time: 0.4128
DEBUG - 2022-11-11 10:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:13:31 --> Total execution time: 0.1996
DEBUG - 2022-11-11 10:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:13:42 --> Total execution time: 0.4554
DEBUG - 2022-11-11 10:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:43:56 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:13:56 --> Total execution time: 0.1702
DEBUG - 2022-11-11 10:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:44:07 --> Total execution time: 0.1916
DEBUG - 2022-11-11 10:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:14:09 --> Total execution time: 0.1614
DEBUG - 2022-11-11 10:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:44:09 --> Total execution time: 0.1821
DEBUG - 2022-11-11 10:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:44:10 --> Total execution time: 0.1734
DEBUG - 2022-11-11 10:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:44:10 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:14:10 --> Total execution time: 0.1742
DEBUG - 2022-11-11 10:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:14:17 --> Total execution time: 0.1674
DEBUG - 2022-11-11 10:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:44:24 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:14:24 --> Total execution time: 0.1640
DEBUG - 2022-11-11 10:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:14:29 --> Total execution time: 0.2044
DEBUG - 2022-11-11 10:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:14:59 --> Total execution time: 0.1677
DEBUG - 2022-11-11 10:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:15:00 --> Total execution time: 0.1640
DEBUG - 2022-11-11 10:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:45:01 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:15:02 --> Total execution time: 0.6836
DEBUG - 2022-11-11 10:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:45:05 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:15:06 --> Total execution time: 0.1790
DEBUG - 2022-11-11 10:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:45:13 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:15:13 --> Total execution time: 0.1816
DEBUG - 2022-11-11 10:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:15:13 --> Total execution time: 0.1672
DEBUG - 2022-11-11 10:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:45:16 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:15:16 --> Total execution time: 0.2481
DEBUG - 2022-11-11 10:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:15:16 --> Total execution time: 0.2025
DEBUG - 2022-11-11 10:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:15:20 --> Total execution time: 0.2060
DEBUG - 2022-11-11 10:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:15:22 --> Total execution time: 0.1711
DEBUG - 2022-11-11 10:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:15:31 --> Total execution time: 0.1711
DEBUG - 2022-11-11 10:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:15:52 --> Total execution time: 0.2035
DEBUG - 2022-11-11 10:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:16:00 --> Total execution time: 0.1707
DEBUG - 2022-11-11 10:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:46:27 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:16:27 --> Total execution time: 0.4580
DEBUG - 2022-11-11 10:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:16:28 --> Total execution time: 0.1772
DEBUG - 2022-11-11 10:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:16:47 --> Total execution time: 0.1954
DEBUG - 2022-11-11 10:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:17:44 --> Total execution time: 0.5289
DEBUG - 2022-11-11 10:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:18:13 --> Total execution time: 0.1827
DEBUG - 2022-11-11 10:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:18:23 --> Total execution time: 0.1689
DEBUG - 2022-11-11 10:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:18:31 --> Total execution time: 0.1591
DEBUG - 2022-11-11 10:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:18:42 --> Total execution time: 0.2141
DEBUG - 2022-11-11 10:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:48:47 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:18:47 --> Total execution time: 0.1847
DEBUG - 2022-11-11 10:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:18:48 --> Total execution time: 0.1748
DEBUG - 2022-11-11 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:18:49 --> Total execution time: 0.2049
DEBUG - 2022-11-11 10:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:18:55 --> Total execution time: 0.1791
DEBUG - 2022-11-11 10:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:49:00 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:19:01 --> Total execution time: 0.1041
DEBUG - 2022-11-11 10:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:49:02 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:19:02 --> Total execution time: 0.1153
DEBUG - 2022-11-11 10:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:19:03 --> Total execution time: 0.1642
DEBUG - 2022-11-11 10:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:49:11 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:19:11 --> Total execution time: 0.1731
DEBUG - 2022-11-11 10:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:19:15 --> Total execution time: 0.2222
DEBUG - 2022-11-11 10:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:19:17 --> Total execution time: 0.2067
DEBUG - 2022-11-11 10:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:19:31 --> Total execution time: 0.1792
DEBUG - 2022-11-11 10:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:19:34 --> Total execution time: 0.2548
DEBUG - 2022-11-11 10:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:19:58 --> Total execution time: 0.1716
DEBUG - 2022-11-11 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:20:02 --> Total execution time: 0.2041
DEBUG - 2022-11-11 10:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:20:12 --> Total execution time: 0.1887
DEBUG - 2022-11-11 10:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 10:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:20:14 --> Total execution time: 0.1906
DEBUG - 2022-11-11 10:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:20:17 --> Total execution time: 0.1021
DEBUG - 2022-11-11 10:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:50:20 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:20:20 --> Total execution time: 0.1630
DEBUG - 2022-11-11 10:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:20:26 --> Total execution time: 0.1604
DEBUG - 2022-11-11 10:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:20:30 --> Total execution time: 0.1712
DEBUG - 2022-11-11 10:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:50:31 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:20:32 --> Total execution time: 0.1044
DEBUG - 2022-11-11 10:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:20:35 --> Total execution time: 0.1838
DEBUG - 2022-11-11 10:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:20:39 --> Total execution time: 0.1857
DEBUG - 2022-11-11 10:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:50:40 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:20:40 --> Total execution time: 0.1734
DEBUG - 2022-11-11 10:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:20:41 --> Total execution time: 0.1755
DEBUG - 2022-11-11 10:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:20:42 --> Total execution time: 0.2147
DEBUG - 2022-11-11 10:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:20:54 --> Total execution time: 0.2268
DEBUG - 2022-11-11 10:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:04 --> Total execution time: 0.2817
DEBUG - 2022-11-11 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:12 --> Total execution time: 0.1915
DEBUG - 2022-11-11 10:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:25 --> Total execution time: 0.1749
DEBUG - 2022-11-11 10:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:33 --> Total execution time: 0.1774
DEBUG - 2022-11-11 10:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:33 --> Total execution time: 0.1668
DEBUG - 2022-11-11 10:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:36 --> Total execution time: 0.1876
DEBUG - 2022-11-11 10:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:41 --> Total execution time: 0.2409
DEBUG - 2022-11-11 10:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:45 --> Total execution time: 0.1962
DEBUG - 2022-11-11 10:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:50 --> Total execution time: 0.2060
DEBUG - 2022-11-11 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:51 --> Total execution time: 0.1953
DEBUG - 2022-11-11 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:52 --> Total execution time: 0.2496
DEBUG - 2022-11-11 10:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:53 --> Total execution time: 0.1947
DEBUG - 2022-11-11 10:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:54 --> Total execution time: 0.1892
DEBUG - 2022-11-11 10:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:54 --> Total execution time: 0.1705
DEBUG - 2022-11-11 10:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:55 --> Total execution time: 0.1653
DEBUG - 2022-11-11 10:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:55 --> Total execution time: 0.2220
DEBUG - 2022-11-11 10:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:56 --> Total execution time: 0.3555
DEBUG - 2022-11-11 10:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:57 --> Total execution time: 0.1845
DEBUG - 2022-11-11 10:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:57 --> Total execution time: 0.1912
DEBUG - 2022-11-11 10:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:21:58 --> Total execution time: 0.2199
DEBUG - 2022-11-11 10:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:52:04 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:22:04 --> Total execution time: 0.1719
DEBUG - 2022-11-11 10:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:22:10 --> Total execution time: 0.1934
DEBUG - 2022-11-11 10:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:22:10 --> Total execution time: 0.1950
DEBUG - 2022-11-11 10:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:22:12 --> Total execution time: 0.1751
DEBUG - 2022-11-11 10:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:22:13 --> Total execution time: 0.1785
DEBUG - 2022-11-11 10:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:23:00 --> Total execution time: 0.1774
DEBUG - 2022-11-11 10:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:23:16 --> Total execution time: 0.1804
DEBUG - 2022-11-11 10:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:23:29 --> Total execution time: 0.1653
DEBUG - 2022-11-11 10:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:28:01 --> Total execution time: 1.1719
DEBUG - 2022-11-11 10:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:58:09 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:28:10 --> Total execution time: 0.4707
DEBUG - 2022-11-11 10:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:28:10 --> Total execution time: 0.1875
DEBUG - 2022-11-11 10:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:28:23 --> Total execution time: 0.1667
DEBUG - 2022-11-11 10:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:58:39 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:28:40 --> Total execution time: 0.1748
DEBUG - 2022-11-11 10:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:28:41 --> Total execution time: 0.1618
DEBUG - 2022-11-11 10:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:58:43 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:28:43 --> Total execution time: 0.1645
DEBUG - 2022-11-11 10:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:28:44 --> Total execution time: 0.2040
DEBUG - 2022-11-11 10:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:28:45 --> Total execution time: 0.1884
DEBUG - 2022-11-11 10:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:28:46 --> Total execution time: 0.1640
DEBUG - 2022-11-11 10:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:58:52 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:28:52 --> Total execution time: 0.4912
DEBUG - 2022-11-11 10:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:58:54 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:28:54 --> Total execution time: 0.1662
DEBUG - 2022-11-11 10:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:59:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 10:59:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 10:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:59:11 --> No URI present. Default controller set.
DEBUG - 2022-11-11 10:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:29:11 --> Total execution time: 0.1150
DEBUG - 2022-11-11 10:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:29:27 --> Total execution time: 0.1656
DEBUG - 2022-11-11 10:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 10:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 10:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:29:58 --> Total execution time: 0.4585
DEBUG - 2022-11-11 11:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:30:03 --> Total execution time: 0.1700
DEBUG - 2022-11-11 11:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:30:05 --> Total execution time: 0.2057
DEBUG - 2022-11-11 11:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:30:10 --> Total execution time: 0.2830
DEBUG - 2022-11-11 11:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:30:15 --> Total execution time: 0.1944
DEBUG - 2022-11-11 11:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:31:30 --> Total execution time: 0.4689
DEBUG - 2022-11-11 11:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:31:46 --> Total execution time: 0.1876
DEBUG - 2022-11-11 11:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:01:47 --> No URI present. Default controller set.
DEBUG - 2022-11-11 11:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:31:47 --> Total execution time: 0.1038
DEBUG - 2022-11-11 11:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:31:50 --> Total execution time: 0.1602
DEBUG - 2022-11-11 11:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:03 --> Total execution time: 0.1826
DEBUG - 2022-11-11 11:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:04 --> Total execution time: 0.1883
DEBUG - 2022-11-11 11:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:05 --> Total execution time: 0.1620
DEBUG - 2022-11-11 11:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:09 --> Total execution time: 0.1657
DEBUG - 2022-11-11 11:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:11 --> Total execution time: 0.1746
DEBUG - 2022-11-11 11:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:13 --> Total execution time: 0.2100
DEBUG - 2022-11-11 11:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:17 --> Total execution time: 0.1661
DEBUG - 2022-11-11 11:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:21 --> Total execution time: 0.1859
DEBUG - 2022-11-11 11:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:23 --> Total execution time: 0.1900
DEBUG - 2022-11-11 11:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:25 --> Total execution time: 0.1646
DEBUG - 2022-11-11 11:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:28 --> Total execution time: 0.1780
DEBUG - 2022-11-11 11:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:29 --> Total execution time: 0.1921
DEBUG - 2022-11-11 11:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:35 --> Total execution time: 0.1828
DEBUG - 2022-11-11 11:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:46 --> Total execution time: 0.1812
DEBUG - 2022-11-11 11:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:47 --> Total execution time: 0.1784
DEBUG - 2022-11-11 11:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:47 --> Total execution time: 0.4680
DEBUG - 2022-11-11 11:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:48 --> Total execution time: 0.1632
DEBUG - 2022-11-11 11:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:53 --> Total execution time: 0.2749
DEBUG - 2022-11-11 11:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:54 --> Total execution time: 0.1907
DEBUG - 2022-11-11 11:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:32:58 --> Total execution time: 0.1911
DEBUG - 2022-11-11 11:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:33:02 --> Total execution time: 0.1861
DEBUG - 2022-11-11 11:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:33:07 --> Total execution time: 0.1888
DEBUG - 2022-11-11 11:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:33:11 --> Total execution time: 0.1855
DEBUG - 2022-11-11 11:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:33:18 --> Total execution time: 0.1804
DEBUG - 2022-11-11 11:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:33:20 --> Total execution time: 0.1868
DEBUG - 2022-11-11 11:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:33:25 --> Total execution time: 0.1744
DEBUG - 2022-11-11 11:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:33:34 --> Total execution time: 0.1702
DEBUG - 2022-11-11 11:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:34:01 --> Total execution time: 0.2235
DEBUG - 2022-11-11 11:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:34:20 --> Total execution time: 0.1836
DEBUG - 2022-11-11 11:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:34:27 --> Total execution time: 0.1726
DEBUG - 2022-11-11 11:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:34:34 --> Total execution time: 0.1891
DEBUG - 2022-11-11 11:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:35:02 --> Total execution time: 0.2110
DEBUG - 2022-11-11 11:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:35:02 --> Total execution time: 0.1976
DEBUG - 2022-11-11 11:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:35:15 --> Total execution time: 0.1688
DEBUG - 2022-11-11 11:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:09:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 11:09:03 --> 404 Page Not Found: Summer-course-starts-from-june/index
DEBUG - 2022-11-11 11:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:09:04 --> No URI present. Default controller set.
DEBUG - 2022-11-11 11:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:39:04 --> Total execution time: 0.5502
DEBUG - 2022-11-11 11:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:39:19 --> Total execution time: 0.1799
DEBUG - 2022-11-11 11:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:39:41 --> Total execution time: 0.1641
DEBUG - 2022-11-11 11:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:40:59 --> Total execution time: 0.1921
DEBUG - 2022-11-11 11:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:11:52 --> No URI present. Default controller set.
DEBUG - 2022-11-11 11:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:41:52 --> Total execution time: 0.1162
DEBUG - 2022-11-11 11:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:11:55 --> No URI present. Default controller set.
DEBUG - 2022-11-11 11:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:41:56 --> Total execution time: 0.1479
DEBUG - 2022-11-11 11:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:42:11 --> Total execution time: 0.1803
DEBUG - 2022-11-11 11:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:42:17 --> Total execution time: 0.1062
DEBUG - 2022-11-11 11:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:42:30 --> Total execution time: 0.2484
DEBUG - 2022-11-11 11:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:42:32 --> Total execution time: 0.1934
DEBUG - 2022-11-11 11:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:42:44 --> Total execution time: 0.2859
DEBUG - 2022-11-11 11:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:43:24 --> Total execution time: 0.4812
DEBUG - 2022-11-11 11:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:43:25 --> Total execution time: 0.1733
DEBUG - 2022-11-11 11:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:43:25 --> Total execution time: 0.1749
DEBUG - 2022-11-11 11:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:43:27 --> Total execution time: 0.1863
DEBUG - 2022-11-11 11:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:13:34 --> No URI present. Default controller set.
DEBUG - 2022-11-11 11:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:43:34 --> Total execution time: 0.4463
DEBUG - 2022-11-11 11:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:43:37 --> Total execution time: 0.1715
DEBUG - 2022-11-11 11:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:43:42 --> Total execution time: 0.1947
DEBUG - 2022-11-11 11:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:43:47 --> Total execution time: 0.2096
DEBUG - 2022-11-11 11:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:43:51 --> Total execution time: 0.3136
DEBUG - 2022-11-11 11:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:43:55 --> Total execution time: 0.1790
DEBUG - 2022-11-11 11:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:02 --> Total execution time: 0.2109
DEBUG - 2022-11-11 11:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:09 --> Total execution time: 0.1708
DEBUG - 2022-11-11 11:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:12 --> Total execution time: 0.1799
DEBUG - 2022-11-11 11:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:14:15 --> Total execution time: 0.2074
DEBUG - 2022-11-11 11:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:18 --> Total execution time: 0.1742
DEBUG - 2022-11-11 11:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:20 --> Total execution time: 0.1665
DEBUG - 2022-11-11 11:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:14:25 --> Total execution time: 0.1759
DEBUG - 2022-11-11 11:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:14:29 --> Total execution time: 0.1677
DEBUG - 2022-11-11 11:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:30 --> Total execution time: 0.1781
DEBUG - 2022-11-11 11:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:35 --> Total execution time: 0.1749
DEBUG - 2022-11-11 11:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:39 --> Total execution time: 0.1734
DEBUG - 2022-11-11 11:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:14:41 --> Total execution time: 0.1605
DEBUG - 2022-11-11 11:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:14:46 --> Total execution time: 0.1739
DEBUG - 2022-11-11 11:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:14:47 --> Total execution time: 0.1616
DEBUG - 2022-11-11 11:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:14:49 --> Total execution time: 0.1720
DEBUG - 2022-11-11 11:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:45:35 --> Total execution time: 0.2677
DEBUG - 2022-11-11 11:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:46:15 --> Total execution time: 0.1801
DEBUG - 2022-11-11 11:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:46:19 --> Total execution time: 0.1693
DEBUG - 2022-11-11 11:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:46:35 --> Total execution time: 0.4534
DEBUG - 2022-11-11 11:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:46:49 --> Total execution time: 0.1938
DEBUG - 2022-11-11 11:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:46:50 --> Total execution time: 0.1710
DEBUG - 2022-11-11 11:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:46:53 --> Total execution time: 0.1865
DEBUG - 2022-11-11 11:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:47:00 --> Total execution time: 0.1851
DEBUG - 2022-11-11 11:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:47:09 --> Total execution time: 0.1667
DEBUG - 2022-11-11 11:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:47:40 --> Total execution time: 0.1714
DEBUG - 2022-11-11 11:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:47:42 --> Total execution time: 0.2411
DEBUG - 2022-11-11 11:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:47:44 --> Total execution time: 0.3032
DEBUG - 2022-11-11 11:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:47:46 --> Total execution time: 0.1733
DEBUG - 2022-11-11 11:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:47:54 --> Total execution time: 0.1675
DEBUG - 2022-11-11 11:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:47:57 --> Total execution time: 0.1715
DEBUG - 2022-11-11 11:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:48:11 --> Total execution time: 0.1836
DEBUG - 2022-11-11 11:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:19:35 --> No URI present. Default controller set.
DEBUG - 2022-11-11 11:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:49:35 --> Total execution time: 0.1456
DEBUG - 2022-11-11 11:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:20:04 --> UTF-8 Support Enabled
ERROR - 2022-11-11 11:20:04 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-11-11 11:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 11:20:04 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-11-11 11:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 11:20:21 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-11-11 11:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 11:20:21 --> 404 Page Not Found: Well-known/gpc.json
DEBUG - 2022-11-11 11:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 11:20:21 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-11-11 11:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 11:20:21 --> 404 Page Not Found: Well-known/security.txt
DEBUG - 2022-11-11 11:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 11:20:21 --> 404 Page Not Found: Well-known/resource-that-should-not-exist-whose-status-code-should-not-be-200
DEBUG - 2022-11-11 11:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 11:20:21 --> 404 Page Not Found: Well-known/change-password
DEBUG - 2022-11-11 11:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:50:27 --> Total execution time: 0.4944
DEBUG - 2022-11-11 11:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:50:28 --> Total execution time: 0.1896
DEBUG - 2022-11-11 11:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:50:31 --> Total execution time: 0.2212
DEBUG - 2022-11-11 11:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:50:36 --> Total execution time: 0.2167
DEBUG - 2022-11-11 11:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:50:47 --> Total execution time: 0.2055
DEBUG - 2022-11-11 11:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:20:55 --> No URI present. Default controller set.
DEBUG - 2022-11-11 11:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:50:55 --> Total execution time: 0.1070
DEBUG - 2022-11-11 11:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:21:21 --> No URI present. Default controller set.
DEBUG - 2022-11-11 11:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:21 --> Total execution time: 0.1427
DEBUG - 2022-11-11 11:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:52:41 --> Total execution time: 0.4513
DEBUG - 2022-11-11 11:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:22:49 --> Total execution time: 0.1639
DEBUG - 2022-11-11 11:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:52:52 --> Total execution time: 0.2005
DEBUG - 2022-11-11 11:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:52:55 --> Total execution time: 0.2017
DEBUG - 2022-11-11 11:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:53:00 --> Total execution time: 0.1729
DEBUG - 2022-11-11 11:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:53:03 --> Total execution time: 0.1674
DEBUG - 2022-11-11 11:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:53:07 --> Total execution time: 0.1679
DEBUG - 2022-11-11 11:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:53:11 --> Total execution time: 0.2083
DEBUG - 2022-11-11 11:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:53:24 --> Total execution time: 0.1836
DEBUG - 2022-11-11 11:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:53:53 --> Total execution time: 0.1965
DEBUG - 2022-11-11 11:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:54:00 --> Total execution time: 0.4862
DEBUG - 2022-11-11 11:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:54:05 --> Total execution time: 0.1668
DEBUG - 2022-11-11 11:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:54:07 --> Total execution time: 0.1818
DEBUG - 2022-11-11 11:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:54:11 --> Total execution time: 0.2188
DEBUG - 2022-11-11 11:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:54:16 --> Total execution time: 0.1758
DEBUG - 2022-11-11 11:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:54:21 --> Total execution time: 0.1816
DEBUG - 2022-11-11 11:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:54:23 --> Total execution time: 0.1643
DEBUG - 2022-11-11 11:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:54:36 --> Total execution time: 0.2055
DEBUG - 2022-11-11 11:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:55:01 --> Total execution time: 0.2337
DEBUG - 2022-11-11 11:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:55:06 --> Total execution time: 0.1675
DEBUG - 2022-11-11 11:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:55:09 --> Total execution time: 0.1767
DEBUG - 2022-11-11 11:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:55:19 --> Total execution time: 0.2445
DEBUG - 2022-11-11 11:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:55:34 --> Total execution time: 0.1906
DEBUG - 2022-11-11 11:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:55:45 --> Total execution time: 0.1727
DEBUG - 2022-11-11 22:55:45 --> Total execution time: 0.2551
DEBUG - 2022-11-11 11:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:55:54 --> Total execution time: 0.1609
DEBUG - 2022-11-11 11:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:56:08 --> Total execution time: 0.2721
DEBUG - 2022-11-11 11:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:56:35 --> Total execution time: 0.2010
DEBUG - 2022-11-11 11:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:56:46 --> Total execution time: 0.1954
DEBUG - 2022-11-11 11:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:56:46 --> Total execution time: 0.5495
DEBUG - 2022-11-11 11:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:26:53 --> No URI present. Default controller set.
DEBUG - 2022-11-11 11:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:56:54 --> Total execution time: 0.1111
DEBUG - 2022-11-11 11:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:57:02 --> Total execution time: 0.1770
DEBUG - 2022-11-11 11:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:57:08 --> Total execution time: 0.1646
DEBUG - 2022-11-11 11:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:57:10 --> Total execution time: 0.2415
DEBUG - 2022-11-11 11:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:57:11 --> Total execution time: 0.4878
DEBUG - 2022-11-11 11:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:57:23 --> Total execution time: 0.2161
DEBUG - 2022-11-11 11:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:57:24 --> Total execution time: 0.2434
DEBUG - 2022-11-11 11:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:58:31 --> Total execution time: 3.5379
DEBUG - 2022-11-11 11:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:58:38 --> Total execution time: 0.8059
DEBUG - 2022-11-11 11:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:00:08 --> Total execution time: 1.9635
DEBUG - 2022-11-11 11:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:00:13 --> Total execution time: 0.3003
DEBUG - 2022-11-11 11:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:00:47 --> Total execution time: 0.3055
DEBUG - 2022-11-11 11:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:07:08 --> Total execution time: 0.5032
DEBUG - 2022-11-11 11:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:07:13 --> Total execution time: 0.1882
DEBUG - 2022-11-11 11:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:07:14 --> Total execution time: 0.2150
DEBUG - 2022-11-11 11:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:07:21 --> Total execution time: 0.1871
DEBUG - 2022-11-11 11:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:37:39 --> No URI present. Default controller set.
DEBUG - 2022-11-11 11:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:07:39 --> Total execution time: 0.4586
DEBUG - 2022-11-11 11:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:07:42 --> Total execution time: 0.2209
DEBUG - 2022-11-11 11:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:07:46 --> Total execution time: 0.1734
DEBUG - 2022-11-11 11:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:07:46 --> Total execution time: 0.1681
DEBUG - 2022-11-11 11:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:07:52 --> Total execution time: 0.2088
DEBUG - 2022-11-11 11:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:07:59 --> Total execution time: 0.2063
DEBUG - 2022-11-11 11:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:08:12 --> Total execution time: 0.1602
DEBUG - 2022-11-11 11:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:42:11 --> No URI present. Default controller set.
DEBUG - 2022-11-11 11:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:12:11 --> Total execution time: 0.4477
DEBUG - 2022-11-11 11:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:14 --> Total execution time: 0.2157
DEBUG - 2022-11-11 11:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:30 --> Total execution time: 0.2201
DEBUG - 2022-11-11 11:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:42 --> Total execution time: 0.2228
DEBUG - 2022-11-11 11:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:43:54 --> Total execution time: 0.4528
DEBUG - 2022-11-11 11:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:43:58 --> No URI present. Default controller set.
DEBUG - 2022-11-11 11:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:59 --> Total execution time: 0.4846
DEBUG - 2022-11-11 11:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:14:22 --> Total execution time: 0.2308
DEBUG - 2022-11-11 11:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:14:57 --> Total execution time: 0.2135
DEBUG - 2022-11-11 11:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:15:20 --> Total execution time: 0.2927
DEBUG - 2022-11-11 11:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 11:46:05 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-11 11:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:46:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 11:46:07 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-11 11:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:46:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 11:46:15 --> 404 Page Not Found: Wp-content/wso.php
DEBUG - 2022-11-11 11:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:46:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 11:46:23 --> 404 Page Not Found: Wp-content/wso.php
DEBUG - 2022-11-11 11:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:16:27 --> Total execution time: 0.2489
DEBUG - 2022-11-11 11:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:16:32 --> Total execution time: 0.1768
DEBUG - 2022-11-11 11:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:16:38 --> Total execution time: 0.2502
DEBUG - 2022-11-11 11:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:16:39 --> Total execution time: 0.2632
DEBUG - 2022-11-11 11:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:16:40 --> Total execution time: 0.1697
DEBUG - 2022-11-11 11:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:16:40 --> Total execution time: 0.2724
DEBUG - 2022-11-11 11:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:16:41 --> Total execution time: 0.2538
DEBUG - 2022-11-11 11:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:16:41 --> Total execution time: 0.1746
DEBUG - 2022-11-11 11:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:16:47 --> Total execution time: 0.2332
DEBUG - 2022-11-11 11:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:16:57 --> Total execution time: 0.1657
DEBUG - 2022-11-11 11:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:17:01 --> Total execution time: 0.1902
DEBUG - 2022-11-11 11:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:17:23 --> Total execution time: 0.1744
DEBUG - 2022-11-11 11:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:17:32 --> Total execution time: 0.1668
DEBUG - 2022-11-11 11:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:00 --> Total execution time: 0.1864
DEBUG - 2022-11-11 11:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:41 --> Total execution time: 0.4704
DEBUG - 2022-11-11 11:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:48:43 --> No URI present. Default controller set.
DEBUG - 2022-11-11 11:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:44 --> Total execution time: 0.1867
DEBUG - 2022-11-11 11:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:19:07 --> Total execution time: 0.1880
DEBUG - 2022-11-11 11:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:49:26 --> No URI present. Default controller set.
DEBUG - 2022-11-11 11:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:19:26 --> Total execution time: 0.1286
DEBUG - 2022-11-11 11:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:20:07 --> Total execution time: 0.1707
DEBUG - 2022-11-11 11:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:20:59 --> Total execution time: 0.1999
DEBUG - 2022-11-11 11:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:51:37 --> No URI present. Default controller set.
DEBUG - 2022-11-11 11:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:21:37 --> Total execution time: 0.1153
DEBUG - 2022-11-11 11:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:21:48 --> Total execution time: 0.1649
DEBUG - 2022-11-11 11:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:21:53 --> Total execution time: 0.1742
DEBUG - 2022-11-11 11:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 11:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:22:03 --> Total execution time: 0.2027
DEBUG - 2022-11-11 11:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:22:13 --> Total execution time: 0.2180
DEBUG - 2022-11-11 11:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:22:33 --> Total execution time: 0.1869
DEBUG - 2022-11-11 11:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:22:37 --> Total execution time: 0.1932
DEBUG - 2022-11-11 11:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:22:44 --> Total execution time: 0.2246
DEBUG - 2022-11-11 11:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:54:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 11:54:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 11:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:55:03 --> No URI present. Default controller set.
DEBUG - 2022-11-11 11:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:25:03 --> Total execution time: 0.1205
DEBUG - 2022-11-11 11:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:25:03 --> Total execution time: 0.1245
DEBUG - 2022-11-11 11:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:25:04 --> Total execution time: 0.1386
DEBUG - 2022-11-11 11:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:26:35 --> Total execution time: 0.1643
DEBUG - 2022-11-11 11:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 11:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 11:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:29:24 --> Total execution time: 0.4558
DEBUG - 2022-11-11 12:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:30:02 --> Total execution time: 0.1460
DEBUG - 2022-11-11 12:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:03:24 --> No URI present. Default controller set.
DEBUG - 2022-11-11 12:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:33:24 --> Total execution time: 0.4626
DEBUG - 2022-11-11 12:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:03:45 --> No URI present. Default controller set.
DEBUG - 2022-11-11 12:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:33:45 --> Total execution time: 0.2740
DEBUG - 2022-11-11 12:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:07:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 12:07:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 12:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:40:34 --> Total execution time: 0.1733
DEBUG - 2022-11-11 12:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:13:22 --> No URI present. Default controller set.
DEBUG - 2022-11-11 12:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:43:23 --> Total execution time: 1.1844
DEBUG - 2022-11-11 12:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:43:40 --> Total execution time: 0.1718
DEBUG - 2022-11-11 12:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:43:48 --> Total execution time: 0.2197
DEBUG - 2022-11-11 12:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:44:03 --> Total execution time: 0.1871
DEBUG - 2022-11-11 12:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:44:14 --> Total execution time: 0.2405
DEBUG - 2022-11-11 12:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:15:56 --> No URI present. Default controller set.
DEBUG - 2022-11-11 12:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:45:56 --> Total execution time: 0.1224
DEBUG - 2022-11-11 12:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:23:46 --> No URI present. Default controller set.
DEBUG - 2022-11-11 12:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:53:46 --> Total execution time: 0.3588
DEBUG - 2022-11-11 12:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:25:28 --> No URI present. Default controller set.
DEBUG - 2022-11-11 12:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:55:28 --> Total execution time: 0.4575
DEBUG - 2022-11-11 12:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:58 --> Total execution time: 0.1830
DEBUG - 2022-11-11 12:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:41:56 --> No URI present. Default controller set.
DEBUG - 2022-11-11 12:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:42:30 --> No URI present. Default controller set.
DEBUG - 2022-11-11 12:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:47:19 --> No URI present. Default controller set.
DEBUG - 2022-11-11 12:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:59:38 --> No URI present. Default controller set.
DEBUG - 2022-11-11 12:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 12:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 12:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 12:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:00:13 --> No URI present. Default controller set.
DEBUG - 2022-11-11 13:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 13:01:00 --> 404 Page Not Found: Courses-v3/index
DEBUG - 2022-11-11 13:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:04:06 --> No URI present. Default controller set.
DEBUG - 2022-11-11 13:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:07:34 --> No URI present. Default controller set.
DEBUG - 2022-11-11 13:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:16:51 --> No URI present. Default controller set.
DEBUG - 2022-11-11 13:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:41:17 --> No URI present. Default controller set.
DEBUG - 2022-11-11 13:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 13:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 13:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 13:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:00:33 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:01:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 14:01:36 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-11-11 14:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:02:45 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:03:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 14:03:24 --> 404 Page Not Found: Refund/index
DEBUG - 2022-11-11 14:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:11:54 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:14:11 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:14:31 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:14:35 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:14:42 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:16:19 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:16:22 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:16:43 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:16:54 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:24 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:20:21 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:20:22 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:20:39 --> Total execution time: 0.2150
DEBUG - 2022-11-11 14:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:20:41 --> Total execution time: 0.1750
DEBUG - 2022-11-11 14:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:20:42 --> Total execution time: 0.1655
DEBUG - 2022-11-11 14:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:27:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 14:27:05 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-11-11 14:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:34:41 --> Total execution time: 0.8241
DEBUG - 2022-11-11 14:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:34:55 --> Total execution time: 0.2105
DEBUG - 2022-11-11 14:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:45:53 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:55:52 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 14:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 14:55:53 --> No URI present. Default controller set.
DEBUG - 2022-11-11 14:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 14:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:14:47 --> Total execution time: 0.5242
DEBUG - 2022-11-11 15:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:15:22 --> Total execution time: 0.1775
DEBUG - 2022-11-11 15:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:15:30 --> Total execution time: 0.1686
DEBUG - 2022-11-11 15:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:28:07 --> No URI present. Default controller set.
DEBUG - 2022-11-11 15:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 15:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 15:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 15:47:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 15:47:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:03:34 --> No URI present. Default controller set.
DEBUG - 2022-11-11 16:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 16:03:34 --> 404 Page Not Found: ALFA_DATA/alfacgiapi
ERROR - 2022-11-11 16:03:34 --> 404 Page Not Found: Wp-plainphp/index
DEBUG - 2022-11-11 16:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 16:03:34 --> 404 Page Not Found: Alfacgiapi/perl.alfa
DEBUG - 2022-11-11 16:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 16:03:34 --> 404 Page Not Found: Ewudmtasphp/index
DEBUG - 2022-11-11 16:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 16:03:34 --> 404 Page Not Found: Wp-plainphp/index
DEBUG - 2022-11-11 16:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 16:03:34 --> 404 Page Not Found: Kogugaxfphp/index
DEBUG - 2022-11-11 16:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:10:21 --> No URI present. Default controller set.
DEBUG - 2022-11-11 16:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:15:00 --> No URI present. Default controller set.
DEBUG - 2022-11-11 16:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:18:42 --> No URI present. Default controller set.
DEBUG - 2022-11-11 16:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:18:58 --> Total execution time: 0.1715
DEBUG - 2022-11-11 16:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:23:13 --> No URI present. Default controller set.
DEBUG - 2022-11-11 16:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:25:44 --> No URI present. Default controller set.
DEBUG - 2022-11-11 16:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:25:53 --> No URI present. Default controller set.
DEBUG - 2022-11-11 16:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:25:54 --> No URI present. Default controller set.
DEBUG - 2022-11-11 16:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:28:09 --> No URI present. Default controller set.
DEBUG - 2022-11-11 16:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:28:16 --> No URI present. Default controller set.
DEBUG - 2022-11-11 16:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:34:48 --> No URI present. Default controller set.
DEBUG - 2022-11-11 16:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:51:04 --> No URI present. Default controller set.
DEBUG - 2022-11-11 16:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 16:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 16:59:15 --> No URI present. Default controller set.
DEBUG - 2022-11-11 16:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 16:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 17:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:04:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 17:04:26 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-11-11 17:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 17:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:11:00 --> No URI present. Default controller set.
DEBUG - 2022-11-11 17:11:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 17:11:00 --> 404 Page Not Found: ALFA_DATA/alfacgiapi
DEBUG - 2022-11-11 17:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:11:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 17:11:00 --> 404 Page Not Found: Wp-plainphp/index
DEBUG - 2022-11-11 17:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:11:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 17:11:00 --> 404 Page Not Found: Alfacgiapi/perl.alfa
DEBUG - 2022-11-11 17:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:11:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 17:11:00 --> 404 Page Not Found: Ytnngleyphp/index
DEBUG - 2022-11-11 17:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:11:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 17:11:00 --> 404 Page Not Found: Wp-plainphp/index
DEBUG - 2022-11-11 17:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:11:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 17:11:01 --> 404 Page Not Found: Ukozmhzbphp/index
DEBUG - 2022-11-11 17:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 17:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 17:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:19:14 --> No URI present. Default controller set.
DEBUG - 2022-11-11 17:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 17:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 17:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 17:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 17:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:30:30 --> No URI present. Default controller set.
DEBUG - 2022-11-11 17:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 17:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:30:31 --> No URI present. Default controller set.
DEBUG - 2022-11-11 17:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 17:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:37:43 --> No URI present. Default controller set.
DEBUG - 2022-11-11 17:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 17:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 17:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 17:56:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 17:56:57 --> 404 Page Not Found: Courses-v3/index
DEBUG - 2022-11-11 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:11:18 --> No URI present. Default controller set.
DEBUG - 2022-11-11 18:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:11:31 --> No URI present. Default controller set.
DEBUG - 2022-11-11 18:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:11:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 18:11:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 18:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 18:12:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 18:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:12:05 --> No URI present. Default controller set.
DEBUG - 2022-11-11 18:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:18:01 --> No URI present. Default controller set.
DEBUG - 2022-11-11 18:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:25:32 --> No URI present. Default controller set.
DEBUG - 2022-11-11 18:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:32:34 --> No URI present. Default controller set.
DEBUG - 2022-11-11 18:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:41:31 --> No URI present. Default controller set.
DEBUG - 2022-11-11 18:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:42:01 --> No URI present. Default controller set.
DEBUG - 2022-11-11 18:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:42:40 --> No URI present. Default controller set.
DEBUG - 2022-11-11 18:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:43:41 --> No URI present. Default controller set.
DEBUG - 2022-11-11 18:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:44:02 --> Total execution time: 0.4447
DEBUG - 2022-11-11 18:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:44:07 --> Total execution time: 0.2625
DEBUG - 2022-11-11 18:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:44:08 --> Total execution time: 0.1845
DEBUG - 2022-11-11 18:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:45:50 --> Total execution time: 0.1756
DEBUG - 2022-11-11 18:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:45:54 --> Total execution time: 0.1709
DEBUG - 2022-11-11 18:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:45:54 --> Total execution time: 0.4023
DEBUG - 2022-11-11 18:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:46:07 --> Total execution time: 0.1725
DEBUG - 2022-11-11 18:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:46:12 --> Total execution time: 0.1700
DEBUG - 2022-11-11 18:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:46:12 --> Total execution time: 0.1734
DEBUG - 2022-11-11 18:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:24 --> Total execution time: 0.1757
DEBUG - 2022-11-11 18:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:28 --> Total execution time: 0.2071
DEBUG - 2022-11-11 18:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:29 --> Total execution time: 0.1667
DEBUG - 2022-11-11 18:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:50 --> Total execution time: 0.1619
DEBUG - 2022-11-11 18:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:54 --> Total execution time: 0.1729
DEBUG - 2022-11-11 18:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:48:54 --> Total execution time: 0.3614
DEBUG - 2022-11-11 18:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:58:18 --> No URI present. Default controller set.
DEBUG - 2022-11-11 18:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 18:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 18:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 18:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:03:03 --> No URI present. Default controller set.
DEBUG - 2022-11-11 19:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:03:52 --> No URI present. Default controller set.
DEBUG - 2022-11-11 19:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:04:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 19:04:40 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-11-11 19:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:04:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 19:04:42 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-11-11 19:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:04:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 19:04:43 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-11-11 19:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:09:23 --> No URI present. Default controller set.
DEBUG - 2022-11-11 19:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:10:11 --> No URI present. Default controller set.
DEBUG - 2022-11-11 19:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:10:33 --> No URI present. Default controller set.
DEBUG - 2022-11-11 19:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:18:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 19:18:27 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-11-11 19:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:19:18 --> No URI present. Default controller set.
DEBUG - 2022-11-11 19:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:19:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 19:19:35 --> 404 Page Not Found: Admin/index.php
DEBUG - 2022-11-11 19:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:19:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 19:19:36 --> 404 Page Not Found: Admin/index.php
DEBUG - 2022-11-11 19:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:19:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 19:19:38 --> 404 Page Not Found: Admin/index.php
DEBUG - 2022-11-11 19:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:31:10 --> No URI present. Default controller set.
DEBUG - 2022-11-11 19:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:31:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 19:31:47 --> 404 Page Not Found: Contact/index
DEBUG - 2022-11-11 19:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:31:47 --> No URI present. Default controller set.
DEBUG - 2022-11-11 19:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:32:30 --> No URI present. Default controller set.
DEBUG - 2022-11-11 19:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:32:51 --> Total execution time: 0.1835
DEBUG - 2022-11-11 19:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:32:53 --> Total execution time: 0.1941
DEBUG - 2022-11-11 19:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:32:53 --> Total execution time: 0.1708
DEBUG - 2022-11-11 19:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:33:12 --> No URI present. Default controller set.
DEBUG - 2022-11-11 19:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:33:43 --> Total execution time: 0.1686
DEBUG - 2022-11-11 19:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:33:46 --> Total execution time: 0.1740
DEBUG - 2022-11-11 19:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:33:46 --> Total execution time: 0.1816
DEBUG - 2022-11-11 19:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:33:54 --> Total execution time: 0.1686
DEBUG - 2022-11-11 19:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:33:56 --> Total execution time: 0.1665
DEBUG - 2022-11-11 19:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:33:56 --> Total execution time: 0.1705
DEBUG - 2022-11-11 19:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:34:32 --> No URI present. Default controller set.
DEBUG - 2022-11-11 19:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 19:34:38 --> 404 Page Not Found: Contact/index
DEBUG - 2022-11-11 19:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:34:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 19:34:57 --> 404 Page Not Found: Allsitemapxml/index
DEBUG - 2022-11-11 19:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 19:34:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 19:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:35:21 --> No URI present. Default controller set.
DEBUG - 2022-11-11 19:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:37:21 --> No URI present. Default controller set.
DEBUG - 2022-11-11 19:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 19:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 19:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 19:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:38:52 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:40:38 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:40:40 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:40:41 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:41:53 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:42:48 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:42:54 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:43:09 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:43:19 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:43:51 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:45:05 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:45:55 --> Total execution time: 0.1122
DEBUG - 2022-11-11 22:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:47:27 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:48:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 22:48:46 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-11 22:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:49:36 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:49:38 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:49:41 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:50:17 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:50:26 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:03 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:05 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:06 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:06 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:11 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:13 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:15 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:17 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:18 --> Total execution time: 0.1876
DEBUG - 2022-11-11 22:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:21 --> Total execution time: 0.1732
DEBUG - 2022-11-11 22:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:21 --> Total execution time: 0.1876
DEBUG - 2022-11-11 22:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 22:51:23 --> 404 Page Not Found: Summer-course-starts-from-june/index
DEBUG - 2022-11-11 22:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:24 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:29 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:38 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:42 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:51:44 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:52:02 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:52:05 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 22:52:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 22:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:55:43 --> No URI present. Default controller set.
DEBUG - 2022-11-11 22:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 22:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 22:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 22:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:00:43 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:01:13 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:04:55 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:06:28 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:06:34 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:06:46 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:10:23 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:10:34 --> Total execution time: 0.1632
DEBUG - 2022-11-11 23:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:10:38 --> Total execution time: 0.1763
DEBUG - 2022-11-11 23:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:10:38 --> Total execution time: 0.1666
DEBUG - 2022-11-11 23:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 23:11:16 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-11 23:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:28 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:12:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 23:12:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 23:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:03 --> Total execution time: 0.1743
DEBUG - 2022-11-11 23:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:05 --> Total execution time: 0.1740
DEBUG - 2022-11-11 23:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:05 --> Total execution time: 0.1747
DEBUG - 2022-11-11 23:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:06 --> Total execution time: 0.1669
DEBUG - 2022-11-11 23:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:08 --> Total execution time: 0.1740
DEBUG - 2022-11-11 23:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:08 --> Total execution time: 0.3937
DEBUG - 2022-11-11 23:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:13:13 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:14:28 --> Total execution time: 0.1760
DEBUG - 2022-11-11 23:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:14:30 --> Total execution time: 0.1743
DEBUG - 2022-11-11 23:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:14:30 --> Total execution time: 0.3932
DEBUG - 2022-11-11 23:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 23:14:36 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 23:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:14:36 --> Total execution time: 0.1676
DEBUG - 2022-11-11 23:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:14:56 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:15:02 --> Total execution time: 0.1933
DEBUG - 2022-11-11 23:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:15:04 --> Total execution time: 0.2021
DEBUG - 2022-11-11 23:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:15:05 --> Total execution time: 0.4436
DEBUG - 2022-11-11 23:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:15:50 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:19:04 --> Total execution time: 0.1815
DEBUG - 2022-11-11 23:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:19:45 --> Total execution time: 0.2010
DEBUG - 2022-11-11 23:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:19:53 --> Total execution time: 0.3123
DEBUG - 2022-11-11 23:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:19:54 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:19:54 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:22:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 23:22:30 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-11 23:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:25:10 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:30:41 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:33:50 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:21 --> Total execution time: 0.1712
DEBUG - 2022-11-11 23:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:23 --> Total execution time: 0.1815
DEBUG - 2022-11-11 23:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:32 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:33 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 23:34:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 23:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:47 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:34:51 --> Total execution time: 0.1758
DEBUG - 2022-11-11 23:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:38:35 --> Total execution time: 1.9266
DEBUG - 2022-11-11 23:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:38:43 --> Total execution time: 0.4274
DEBUG - 2022-11-11 23:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:41:07 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:44:15 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:44:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 23:44:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-11-11 23:44:15 --> Unable to connect to the database
ERROR - 2022-11-11 23:44:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-11-11 23:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:45:26 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:45:55 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:45:55 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:48:59 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:49:10 --> Total execution time: 0.1711
DEBUG - 2022-11-11 23:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:49:12 --> Total execution time: 0.2421
DEBUG - 2022-11-11 23:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:49:12 --> Total execution time: 0.1734
DEBUG - 2022-11-11 23:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:49:14 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:49:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 23:49:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 23:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 23:55:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-11 23:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:56:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-11 23:56:16 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-11 23:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:58:05 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:58:54 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:34 --> No URI present. Default controller set.
DEBUG - 2022-11-11 23:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-11 23:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-11 23:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-11 23:59:43 --> Encryption: Auto-configured driver 'openssl'.
