<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-03 00:00:57 --> Total execution time: 0.0934
DEBUG - 2022-07-03 00:01:02 --> Total execution time: 0.1820
DEBUG - 2022-07-03 00:01:17 --> Total execution time: 0.0513
DEBUG - 2022-07-03 00:01:29 --> Total execution time: 0.0555
DEBUG - 2022-07-03 00:02:31 --> Total execution time: 0.0471
DEBUG - 2022-07-03 00:12:34 --> Total execution time: 0.0505
DEBUG - 2022-07-03 00:16:39 --> Total execution time: 0.0404
DEBUG - 2022-07-03 00:16:41 --> Total execution time: 0.0404
DEBUG - 2022-07-03 00:16:51 --> Total execution time: 0.0524
DEBUG - 2022-07-03 00:16:54 --> Total execution time: 0.0521
DEBUG - 2022-07-03 00:16:57 --> Total execution time: 0.0847
DEBUG - 2022-07-03 00:17:06 --> Total execution time: 0.0457
DEBUG - 2022-07-03 00:17:31 --> Total execution time: 0.0517
DEBUG - 2022-07-03 00:23:32 --> Total execution time: 0.2012
DEBUG - 2022-07-03 00:24:13 --> Total execution time: 0.0357
DEBUG - 2022-07-03 00:24:17 --> Total execution time: 0.0527
DEBUG - 2022-07-03 00:24:22 --> Total execution time: 0.0469
DEBUG - 2022-07-03 00:27:12 --> Total execution time: 0.2081
DEBUG - 2022-07-03 00:28:59 --> Total execution time: 0.1150
DEBUG - 2022-07-03 00:30:03 --> Total execution time: 0.1393
DEBUG - 2022-07-03 00:43:17 --> Total execution time: 0.0555
DEBUG - 2022-07-03 00:43:30 --> Total execution time: 0.0663
DEBUG - 2022-07-03 00:46:47 --> Total execution time: 0.1054
DEBUG - 2022-07-03 00:55:28 --> Total execution time: 0.1969
DEBUG - 2022-07-03 00:55:32 --> Total execution time: 0.0764
DEBUG - 2022-07-03 00:55:36 --> Total execution time: 0.0952
DEBUG - 2022-07-03 00:55:49 --> Total execution time: 0.0451
DEBUG - 2022-07-03 00:56:08 --> Total execution time: 0.0499
DEBUG - 2022-07-03 00:56:56 --> Total execution time: 0.0327
DEBUG - 2022-07-03 00:58:09 --> Total execution time: 0.0368
DEBUG - 2022-07-03 01:25:30 --> Total execution time: 0.0577
DEBUG - 2022-07-03 01:26:11 --> Total execution time: 0.0315
DEBUG - 2022-07-03 01:30:04 --> Total execution time: 0.3550
DEBUG - 2022-07-03 02:00:23 --> Total execution time: 0.1663
DEBUG - 2022-07-03 02:00:24 --> Total execution time: 0.0462
DEBUG - 2022-07-03 02:08:28 --> Total execution time: 0.0499
DEBUG - 2022-07-03 02:08:42 --> Total execution time: 0.0781
DEBUG - 2022-07-03 02:08:49 --> Total execution time: 0.0720
DEBUG - 2022-07-03 02:09:01 --> Total execution time: 0.0615
DEBUG - 2022-07-03 02:09:12 --> Total execution time: 0.0546
DEBUG - 2022-07-03 02:11:08 --> Total execution time: 0.1729
DEBUG - 2022-07-03 02:11:17 --> Total execution time: 0.1037
DEBUG - 2022-07-03 02:11:29 --> Total execution time: 0.0916
DEBUG - 2022-07-03 02:11:33 --> Total execution time: 0.0608
DEBUG - 2022-07-03 02:16:18 --> Total execution time: 0.1328
DEBUG - 2022-07-03 02:30:03 --> Total execution time: 0.3961
DEBUG - 2022-07-03 03:16:17 --> Total execution time: 0.2212
DEBUG - 2022-07-03 03:30:04 --> Total execution time: 0.4495
DEBUG - 2022-07-03 03:33:56 --> Total execution time: 0.0960
DEBUG - 2022-07-03 03:33:58 --> Total execution time: 0.0341
DEBUG - 2022-07-03 03:39:16 --> Total execution time: 0.0761
DEBUG - 2022-07-03 03:39:18 --> Total execution time: 0.0334
DEBUG - 2022-07-03 03:41:33 --> Total execution time: 0.0445
DEBUG - 2022-07-03 03:41:36 --> Total execution time: 0.0364
DEBUG - 2022-07-03 03:41:49 --> Total execution time: 0.0751
DEBUG - 2022-07-03 03:41:56 --> Total execution time: 0.0649
DEBUG - 2022-07-03 03:41:59 --> Total execution time: 0.0657
DEBUG - 2022-07-03 03:42:14 --> Total execution time: 0.0464
DEBUG - 2022-07-03 04:30:03 --> Total execution time: 0.3431
DEBUG - 2022-07-03 04:39:04 --> Total execution time: 0.0551
DEBUG - 2022-07-03 04:48:29 --> Total execution time: 0.1850
DEBUG - 2022-07-03 04:48:29 --> Total execution time: 0.0354
DEBUG - 2022-07-03 05:30:03 --> Total execution time: 0.3397
DEBUG - 2022-07-03 05:31:57 --> Total execution time: 0.0539
DEBUG - 2022-07-03 05:32:10 --> Total execution time: 0.0944
DEBUG - 2022-07-03 05:32:14 --> Total execution time: 0.0847
DEBUG - 2022-07-03 05:32:22 --> Total execution time: 0.0451
DEBUG - 2022-07-03 05:32:29 --> Total execution time: 0.0483
DEBUG - 2022-07-03 05:32:33 --> Total execution time: 0.0491
DEBUG - 2022-07-03 05:32:34 --> Total execution time: 0.0476
DEBUG - 2022-07-03 05:32:35 --> Total execution time: 0.0463
DEBUG - 2022-07-03 05:32:36 --> Total execution time: 0.0477
DEBUG - 2022-07-03 05:43:17 --> Total execution time: 0.2276
DEBUG - 2022-07-03 05:43:25 --> Total execution time: 0.0570
DEBUG - 2022-07-03 05:43:34 --> Total execution time: 0.0501
DEBUG - 2022-07-03 05:43:47 --> Total execution time: 0.0349
DEBUG - 2022-07-03 05:52:52 --> Total execution time: 0.1154
DEBUG - 2022-07-03 05:52:59 --> Total execution time: 0.0491
DEBUG - 2022-07-03 05:53:11 --> Total execution time: 0.0349
DEBUG - 2022-07-03 05:53:12 --> Total execution time: 0.0604
DEBUG - 2022-07-03 05:53:13 --> Total execution time: 0.0505
DEBUG - 2022-07-03 05:53:44 --> Total execution time: 0.0636
DEBUG - 2022-07-03 05:54:36 --> Total execution time: 0.0317
DEBUG - 2022-07-03 05:54:38 --> Total execution time: 0.0617
DEBUG - 2022-07-03 05:54:43 --> Total execution time: 0.0621
DEBUG - 2022-07-03 05:54:46 --> Total execution time: 0.0501
DEBUG - 2022-07-03 05:54:52 --> Total execution time: 0.0453
DEBUG - 2022-07-03 05:54:55 --> Total execution time: 0.0664
DEBUG - 2022-07-03 05:54:59 --> Total execution time: 0.0490
DEBUG - 2022-07-03 05:55:05 --> Total execution time: 0.0490
DEBUG - 2022-07-03 05:55:07 --> Total execution time: 0.0668
DEBUG - 2022-07-03 05:55:11 --> Total execution time: 0.0549
DEBUG - 2022-07-03 05:55:19 --> Total execution time: 0.0538
DEBUG - 2022-07-03 05:55:35 --> Total execution time: 0.0463
DEBUG - 2022-07-03 05:55:58 --> Total execution time: 0.0459
DEBUG - 2022-07-03 05:57:00 --> Total execution time: 0.0994
DEBUG - 2022-07-03 05:57:58 --> Total execution time: 0.0474
DEBUG - 2022-07-03 06:05:48 --> Total execution time: 0.1021
DEBUG - 2022-07-03 06:07:38 --> Total execution time: 0.0368
DEBUG - 2022-07-03 06:08:52 --> Total execution time: 0.0509
DEBUG - 2022-07-03 06:08:54 --> Total execution time: 0.0486
DEBUG - 2022-07-03 06:14:04 --> Total execution time: 0.1600
DEBUG - 2022-07-03 06:14:06 --> Total execution time: 0.0335
DEBUG - 2022-07-03 06:14:40 --> Total execution time: 0.0392
DEBUG - 2022-07-03 06:14:46 --> Total execution time: 0.0340
DEBUG - 2022-07-03 06:15:12 --> Total execution time: 0.0553
DEBUG - 2022-07-03 06:22:16 --> Total execution time: 0.1012
DEBUG - 2022-07-03 06:30:02 --> Total execution time: 0.1660
DEBUG - 2022-07-03 06:51:39 --> Total execution time: 0.0958
DEBUG - 2022-07-03 06:56:49 --> Total execution time: 0.0850
DEBUG - 2022-07-03 07:00:26 --> Total execution time: 0.0554
DEBUG - 2022-07-03 07:00:40 --> Total execution time: 0.0493
DEBUG - 2022-07-03 07:01:35 --> Total execution time: 0.0480
DEBUG - 2022-07-03 07:02:01 --> Total execution time: 0.0678
DEBUG - 2022-07-03 07:06:12 --> Total execution time: 0.0373
DEBUG - 2022-07-03 07:06:13 --> Total execution time: 0.0330
DEBUG - 2022-07-03 07:06:23 --> Total execution time: 0.0339
DEBUG - 2022-07-03 07:06:36 --> Total execution time: 0.0470
DEBUG - 2022-07-03 07:07:41 --> Total execution time: 0.0559
DEBUG - 2022-07-03 07:08:18 --> Total execution time: 0.0607
DEBUG - 2022-07-03 07:08:22 --> Total execution time: 0.0475
DEBUG - 2022-07-03 07:08:22 --> Total execution time: 0.0461
DEBUG - 2022-07-03 07:09:03 --> Total execution time: 0.1466
DEBUG - 2022-07-03 07:17:53 --> Total execution time: 0.1857
DEBUG - 2022-07-03 07:17:55 --> Total execution time: 0.0502
DEBUG - 2022-07-03 07:18:03 --> Total execution time: 0.0811
DEBUG - 2022-07-03 07:18:07 --> Total execution time: 0.1173
DEBUG - 2022-07-03 07:18:23 --> Total execution time: 0.0525
DEBUG - 2022-07-03 07:18:28 --> Total execution time: 0.0844
DEBUG - 2022-07-03 07:18:47 --> Total execution time: 0.0565
DEBUG - 2022-07-03 07:19:06 --> Total execution time: 0.0508
DEBUG - 2022-07-03 07:19:12 --> Total execution time: 0.0647
DEBUG - 2022-07-03 07:19:17 --> Total execution time: 0.0506
DEBUG - 2022-07-03 07:19:28 --> Total execution time: 0.0457
DEBUG - 2022-07-03 07:19:28 --> Total execution time: 0.0917
DEBUG - 2022-07-03 07:19:29 --> Total execution time: 0.1279
DEBUG - 2022-07-03 07:19:43 --> Total execution time: 0.0799
DEBUG - 2022-07-03 07:20:06 --> Total execution time: 0.0524
DEBUG - 2022-07-03 07:20:21 --> Total execution time: 0.0590
DEBUG - 2022-07-03 07:20:22 --> Total execution time: 0.0461
DEBUG - 2022-07-03 07:20:30 --> Total execution time: 0.0562
DEBUG - 2022-07-03 07:20:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 07:20:31 --> Total execution time: 0.0472
DEBUG - 2022-07-03 07:20:35 --> Total execution time: 0.0503
DEBUG - 2022-07-03 07:20:43 --> Total execution time: 0.0527
DEBUG - 2022-07-03 07:20:47 --> Total execution time: 0.0612
DEBUG - 2022-07-03 07:20:53 --> Total execution time: 0.0541
DEBUG - 2022-07-03 07:21:00 --> Total execution time: 0.0466
DEBUG - 2022-07-03 07:21:11 --> Total execution time: 0.0479
DEBUG - 2022-07-03 07:21:15 --> Total execution time: 0.0452
DEBUG - 2022-07-03 07:21:36 --> Total execution time: 0.0484
DEBUG - 2022-07-03 07:21:46 --> Total execution time: 0.0824
DEBUG - 2022-07-03 07:21:47 --> Total execution time: 0.0569
DEBUG - 2022-07-03 07:21:58 --> Total execution time: 0.0548
DEBUG - 2022-07-03 07:22:04 --> Total execution time: 0.0351
DEBUG - 2022-07-03 07:22:07 --> Total execution time: 0.0305
DEBUG - 2022-07-03 07:22:10 --> Total execution time: 0.0372
DEBUG - 2022-07-03 07:22:11 --> Total execution time: 0.0302
DEBUG - 2022-07-03 07:22:11 --> Total execution time: 0.0364
DEBUG - 2022-07-03 07:22:26 --> Total execution time: 0.0605
DEBUG - 2022-07-03 07:22:28 --> Total execution time: 0.0332
DEBUG - 2022-07-03 07:22:35 --> Total execution time: 0.1298
DEBUG - 2022-07-03 07:22:37 --> Total execution time: 0.0320
DEBUG - 2022-07-03 07:23:20 --> Total execution time: 0.0478
DEBUG - 2022-07-03 07:23:27 --> Total execution time: 0.0462
DEBUG - 2022-07-03 07:23:27 --> Total execution time: 0.0604
DEBUG - 2022-07-03 07:23:28 --> Total execution time: 0.0457
DEBUG - 2022-07-03 07:23:29 --> Total execution time: 0.0473
DEBUG - 2022-07-03 07:23:29 --> Total execution time: 0.0498
DEBUG - 2022-07-03 07:23:30 --> Total execution time: 0.0563
DEBUG - 2022-07-03 07:23:30 --> Total execution time: 0.0497
DEBUG - 2022-07-03 07:23:31 --> Total execution time: 0.0456
DEBUG - 2022-07-03 07:23:31 --> Total execution time: 0.0451
DEBUG - 2022-07-03 07:23:32 --> Total execution time: 0.0455
DEBUG - 2022-07-03 07:23:32 --> Total execution time: 0.0686
DEBUG - 2022-07-03 07:23:33 --> Total execution time: 0.0597
DEBUG - 2022-07-03 07:23:33 --> Total execution time: 0.0637
DEBUG - 2022-07-03 07:23:34 --> Total execution time: 0.0725
DEBUG - 2022-07-03 07:23:34 --> Total execution time: 0.0479
DEBUG - 2022-07-03 07:23:35 --> Total execution time: 0.0502
DEBUG - 2022-07-03 07:23:35 --> Total execution time: 0.0455
DEBUG - 2022-07-03 07:23:36 --> Total execution time: 0.0455
DEBUG - 2022-07-03 07:23:40 --> Total execution time: 0.0509
DEBUG - 2022-07-03 07:23:47 --> Total execution time: 0.0538
DEBUG - 2022-07-03 07:23:50 --> Total execution time: 0.0253
DEBUG - 2022-07-03 07:24:01 --> Total execution time: 0.0696
DEBUG - 2022-07-03 07:24:03 --> Total execution time: 0.0316
DEBUG - 2022-07-03 07:24:15 --> Total execution time: 0.0523
DEBUG - 2022-07-03 07:24:17 --> Total execution time: 0.0315
DEBUG - 2022-07-03 07:25:08 --> Total execution time: 0.0529
DEBUG - 2022-07-03 07:25:10 --> Total execution time: 0.0258
DEBUG - 2022-07-03 07:25:37 --> Total execution time: 0.0417
DEBUG - 2022-07-03 07:25:39 --> Total execution time: 0.0671
DEBUG - 2022-07-03 07:25:41 --> Total execution time: 0.0324
DEBUG - 2022-07-03 07:26:07 --> Total execution time: 0.0625
DEBUG - 2022-07-03 07:30:04 --> Total execution time: 0.1208
DEBUG - 2022-07-03 07:36:34 --> Total execution time: 0.2608
DEBUG - 2022-07-03 07:38:05 --> Total execution time: 0.0943
DEBUG - 2022-07-03 07:38:16 --> Total execution time: 0.0779
DEBUG - 2022-07-03 07:39:34 --> Total execution time: 0.0989
DEBUG - 2022-07-03 07:39:35 --> Total execution time: 0.0874
DEBUG - 2022-07-03 07:39:50 --> Total execution time: 0.0832
DEBUG - 2022-07-03 07:39:53 --> Total execution time: 0.0644
DEBUG - 2022-07-03 07:39:54 --> Total execution time: 0.0583
DEBUG - 2022-07-03 07:39:55 --> Total execution time: 0.0685
DEBUG - 2022-07-03 07:39:56 --> Total execution time: 0.0543
DEBUG - 2022-07-03 07:40:00 --> Total execution time: 0.0613
DEBUG - 2022-07-03 07:40:11 --> Total execution time: 0.0511
DEBUG - 2022-07-03 07:40:16 --> Total execution time: 0.0667
DEBUG - 2022-07-03 07:40:21 --> Total execution time: 0.0531
DEBUG - 2022-07-03 07:40:25 --> Total execution time: 0.0491
DEBUG - 2022-07-03 07:40:28 --> Total execution time: 0.0486
DEBUG - 2022-07-03 07:40:37 --> Total execution time: 0.0400
DEBUG - 2022-07-03 07:40:38 --> Total execution time: 0.0416
DEBUG - 2022-07-03 07:40:39 --> Total execution time: 0.0532
DEBUG - 2022-07-03 07:40:41 --> Total execution time: 0.0534
DEBUG - 2022-07-03 07:40:46 --> Total execution time: 0.0685
DEBUG - 2022-07-03 07:40:48 --> Total execution time: 0.0828
DEBUG - 2022-07-03 07:41:17 --> Total execution time: 0.0553
DEBUG - 2022-07-03 07:41:22 --> Total execution time: 0.0685
DEBUG - 2022-07-03 07:41:29 --> Total execution time: 0.0785
DEBUG - 2022-07-03 07:42:10 --> Total execution time: 0.0360
DEBUG - 2022-07-03 07:42:15 --> Total execution time: 0.0502
DEBUG - 2022-07-03 07:42:28 --> Total execution time: 0.0508
DEBUG - 2022-07-03 07:42:35 --> Total execution time: 0.0504
DEBUG - 2022-07-03 07:43:03 --> Total execution time: 0.1287
DEBUG - 2022-07-03 07:43:13 --> Total execution time: 0.0450
DEBUG - 2022-07-03 07:43:18 --> Total execution time: 0.0701
DEBUG - 2022-07-03 07:43:32 --> Total execution time: 0.0671
DEBUG - 2022-07-03 07:44:19 --> Total execution time: 0.0531
DEBUG - 2022-07-03 07:44:53 --> Total execution time: 0.0960
DEBUG - 2022-07-03 07:45:19 --> Total execution time: 0.0444
DEBUG - 2022-07-03 07:45:36 --> Total execution time: 0.0704
DEBUG - 2022-07-03 07:45:41 --> Total execution time: 0.0503
DEBUG - 2022-07-03 07:46:03 --> Total execution time: 0.0580
DEBUG - 2022-07-03 07:46:11 --> Total execution time: 0.0516
DEBUG - 2022-07-03 07:46:13 --> Total execution time: 0.0522
DEBUG - 2022-07-03 07:46:17 --> Total execution time: 0.0975
DEBUG - 2022-07-03 07:46:21 --> Total execution time: 0.0591
DEBUG - 2022-07-03 07:46:23 --> Total execution time: 0.0648
DEBUG - 2022-07-03 07:46:25 --> Total execution time: 0.0719
DEBUG - 2022-07-03 07:46:27 --> Total execution time: 0.0655
DEBUG - 2022-07-03 07:46:27 --> Total execution time: 0.0548
DEBUG - 2022-07-03 07:46:28 --> Total execution time: 0.1228
DEBUG - 2022-07-03 07:46:35 --> Total execution time: 0.0636
DEBUG - 2022-07-03 07:46:42 --> Total execution time: 0.0493
DEBUG - 2022-07-03 07:46:45 --> Total execution time: 0.0397
DEBUG - 2022-07-03 07:47:02 --> Total execution time: 0.0518
DEBUG - 2022-07-03 07:47:11 --> Total execution time: 0.0501
DEBUG - 2022-07-03 07:47:21 --> Total execution time: 0.0718
DEBUG - 2022-07-03 07:47:33 --> Total execution time: 0.0786
DEBUG - 2022-07-03 07:47:42 --> Total execution time: 0.0505
DEBUG - 2022-07-03 07:48:01 --> Total execution time: 0.1026
DEBUG - 2022-07-03 07:48:02 --> Total execution time: 0.0697
DEBUG - 2022-07-03 07:48:15 --> Total execution time: 0.0585
DEBUG - 2022-07-03 07:48:15 --> Total execution time: 0.0485
DEBUG - 2022-07-03 07:48:21 --> Total execution time: 0.1207
DEBUG - 2022-07-03 07:48:25 --> Total execution time: 0.0658
DEBUG - 2022-07-03 07:48:25 --> Total execution time: 0.0495
DEBUG - 2022-07-03 07:48:26 --> Total execution time: 0.0564
DEBUG - 2022-07-03 07:48:41 --> Total execution time: 0.0516
DEBUG - 2022-07-03 07:49:04 --> Total execution time: 1.4954
DEBUG - 2022-07-03 07:49:33 --> Total execution time: 0.0478
DEBUG - 2022-07-03 07:56:28 --> Total execution time: 0.0911
DEBUG - 2022-07-03 08:11:35 --> Total execution time: 0.1284
DEBUG - 2022-07-03 08:21:40 --> Total execution time: 0.0514
DEBUG - 2022-07-03 08:22:45 --> Total execution time: 0.0472
DEBUG - 2022-07-03 08:30:03 --> Total execution time: 0.1217
DEBUG - 2022-07-03 08:34:36 --> Total execution time: 0.0929
DEBUG - 2022-07-03 08:34:41 --> Total execution time: 0.0436
DEBUG - 2022-07-03 08:34:45 --> Total execution time: 0.0468
DEBUG - 2022-07-03 08:41:58 --> Total execution time: 0.0880
DEBUG - 2022-07-03 08:42:03 --> Total execution time: 0.0500
DEBUG - 2022-07-03 08:45:02 --> Total execution time: 0.0606
DEBUG - 2022-07-03 08:45:14 --> Total execution time: 0.0335
DEBUG - 2022-07-03 08:45:50 --> Total execution time: 0.0495
DEBUG - 2022-07-03 08:46:34 --> Total execution time: 0.0482
DEBUG - 2022-07-03 08:49:11 --> Total execution time: 0.0844
DEBUG - 2022-07-03 08:49:13 --> Total execution time: 0.0346
DEBUG - 2022-07-03 08:51:46 --> Total execution time: 0.1047
DEBUG - 2022-07-03 08:51:54 --> Total execution time: 0.0371
DEBUG - 2022-07-03 08:52:34 --> Total execution time: 0.0515
DEBUG - 2022-07-03 08:52:36 --> Total execution time: 0.0515
DEBUG - 2022-07-03 08:52:51 --> Total execution time: 0.0565
DEBUG - 2022-07-03 08:53:07 --> Total execution time: 0.0511
DEBUG - 2022-07-03 09:01:31 --> Total execution time: 0.0897
DEBUG - 2022-07-03 09:01:50 --> Total execution time: 0.1135
DEBUG - 2022-07-03 09:01:53 --> Total execution time: 0.0511
DEBUG - 2022-07-03 09:01:54 --> Total execution time: 0.0515
DEBUG - 2022-07-03 09:01:56 --> Total execution time: 0.0584
DEBUG - 2022-07-03 09:02:40 --> Total execution time: 0.0516
DEBUG - 2022-07-03 09:04:50 --> Total execution time: 0.0347
DEBUG - 2022-07-03 09:05:01 --> Total execution time: 0.0898
DEBUG - 2022-07-03 09:05:19 --> Total execution time: 0.0784
DEBUG - 2022-07-03 09:05:39 --> Total execution time: 0.0607
DEBUG - 2022-07-03 09:05:47 --> Total execution time: 0.0540
DEBUG - 2022-07-03 09:05:49 --> Total execution time: 0.0494
DEBUG - 2022-07-03 09:05:51 --> Total execution time: 0.0538
DEBUG - 2022-07-03 09:05:58 --> Total execution time: 0.0455
DEBUG - 2022-07-03 09:06:13 --> Total execution time: 0.0401
DEBUG - 2022-07-03 09:07:19 --> Total execution time: 0.1130
DEBUG - 2022-07-03 09:07:59 --> Total execution time: 0.0548
DEBUG - 2022-07-03 09:08:31 --> Total execution time: 0.0463
DEBUG - 2022-07-03 09:08:44 --> Total execution time: 0.0475
DEBUG - 2022-07-03 09:09:03 --> Total execution time: 0.0645
DEBUG - 2022-07-03 09:09:58 --> Total execution time: 0.0519
DEBUG - 2022-07-03 09:10:55 --> Total execution time: 0.0519
DEBUG - 2022-07-03 09:11:37 --> Total execution time: 0.0593
DEBUG - 2022-07-03 09:12:26 --> Total execution time: 0.1391
DEBUG - 2022-07-03 09:12:28 --> Total execution time: 0.1134
DEBUG - 2022-07-03 09:12:33 --> Total execution time: 0.0508
DEBUG - 2022-07-03 09:12:38 --> Total execution time: 0.0471
DEBUG - 2022-07-03 09:12:45 --> Total execution time: 0.0375
DEBUG - 2022-07-03 09:12:49 --> Total execution time: 0.0533
DEBUG - 2022-07-03 09:12:51 --> Total execution time: 0.0512
DEBUG - 2022-07-03 09:12:58 --> Total execution time: 0.0498
DEBUG - 2022-07-03 09:13:13 --> Total execution time: 0.0493
DEBUG - 2022-07-03 09:13:13 --> Total execution time: 0.0520
DEBUG - 2022-07-03 09:13:15 --> Total execution time: 0.0507
DEBUG - 2022-07-03 09:13:17 --> Total execution time: 0.0666
DEBUG - 2022-07-03 09:13:18 --> Total execution time: 0.0504
DEBUG - 2022-07-03 09:13:23 --> Total execution time: 0.0833
DEBUG - 2022-07-03 09:13:36 --> Total execution time: 0.0524
DEBUG - 2022-07-03 09:13:45 --> Total execution time: 0.0575
DEBUG - 2022-07-03 09:13:58 --> Total execution time: 0.0505
DEBUG - 2022-07-03 09:14:22 --> Total execution time: 0.0604
DEBUG - 2022-07-03 09:14:23 --> Total execution time: 0.0514
DEBUG - 2022-07-03 09:14:38 --> Total execution time: 0.0503
DEBUG - 2022-07-03 09:15:01 --> Total execution time: 0.0681
DEBUG - 2022-07-03 09:15:22 --> Total execution time: 0.0388
DEBUG - 2022-07-03 09:15:33 --> Total execution time: 0.0516
DEBUG - 2022-07-03 09:15:33 --> Total execution time: 0.0552
DEBUG - 2022-07-03 09:15:40 --> Total execution time: 0.0488
DEBUG - 2022-07-03 09:16:16 --> Total execution time: 0.0748
DEBUG - 2022-07-03 09:16:40 --> Total execution time: 0.0355
DEBUG - 2022-07-03 09:16:40 --> Total execution time: 0.0556
DEBUG - 2022-07-03 09:16:58 --> Total execution time: 1.5373
DEBUG - 2022-07-03 09:17:03 --> Total execution time: 0.0635
DEBUG - 2022-07-03 09:17:14 --> Total execution time: 0.0494
DEBUG - 2022-07-03 09:17:19 --> Total execution time: 0.0604
DEBUG - 2022-07-03 09:17:23 --> Total execution time: 0.0498
DEBUG - 2022-07-03 09:17:39 --> Total execution time: 0.0508
DEBUG - 2022-07-03 09:18:18 --> Total execution time: 0.0492
DEBUG - 2022-07-03 09:20:35 --> Total execution time: 0.1161
DEBUG - 2022-07-03 09:21:08 --> Total execution time: 0.1262
DEBUG - 2022-07-03 09:21:11 --> Total execution time: 0.0571
DEBUG - 2022-07-03 09:21:16 --> Total execution time: 0.0621
DEBUG - 2022-07-03 09:22:02 --> Total execution time: 0.1617
DEBUG - 2022-07-03 09:22:03 --> Total execution time: 0.0471
DEBUG - 2022-07-03 09:23:37 --> Total execution time: 0.0758
DEBUG - 2022-07-03 09:24:30 --> Total execution time: 0.0319
DEBUG - 2022-07-03 09:28:31 --> Total execution time: 0.0884
DEBUG - 2022-07-03 09:28:32 --> Total execution time: 0.0402
DEBUG - 2022-07-03 09:30:02 --> Total execution time: 0.0787
DEBUG - 2022-07-03 09:31:11 --> Total execution time: 0.0385
DEBUG - 2022-07-03 09:31:16 --> Total execution time: 0.0465
DEBUG - 2022-07-03 09:31:19 --> Total execution time: 0.0546
DEBUG - 2022-07-03 09:31:21 --> Total execution time: 0.0594
DEBUG - 2022-07-03 09:31:26 --> Total execution time: 0.0538
DEBUG - 2022-07-03 09:31:29 --> Total execution time: 0.0468
DEBUG - 2022-07-03 09:31:44 --> Total execution time: 0.0869
DEBUG - 2022-07-03 09:32:04 --> Total execution time: 0.1037
DEBUG - 2022-07-03 09:32:07 --> Total execution time: 0.0550
DEBUG - 2022-07-03 09:32:11 --> Total execution time: 0.0874
DEBUG - 2022-07-03 09:32:23 --> Total execution time: 0.0646
DEBUG - 2022-07-03 09:32:31 --> Total execution time: 0.0569
DEBUG - 2022-07-03 09:32:34 --> Total execution time: 0.0561
DEBUG - 2022-07-03 09:32:37 --> Total execution time: 0.0603
DEBUG - 2022-07-03 09:32:41 --> Total execution time: 0.0566
DEBUG - 2022-07-03 09:32:43 --> Total execution time: 0.0563
DEBUG - 2022-07-03 09:32:47 --> Total execution time: 0.0542
DEBUG - 2022-07-03 09:32:49 --> Total execution time: 0.0929
DEBUG - 2022-07-03 09:32:52 --> Total execution time: 0.0551
DEBUG - 2022-07-03 09:32:55 --> Total execution time: 0.0539
DEBUG - 2022-07-03 09:32:57 --> Total execution time: 0.0517
DEBUG - 2022-07-03 09:34:47 --> Total execution time: 0.1447
DEBUG - 2022-07-03 09:43:01 --> Total execution time: 0.1680
DEBUG - 2022-07-03 09:43:10 --> Total execution time: 1.5059
DEBUG - 2022-07-03 09:43:56 --> Total execution time: 0.0489
DEBUG - 2022-07-03 09:45:55 --> Total execution time: 0.0348
DEBUG - 2022-07-03 09:46:02 --> Total execution time: 0.0408
DEBUG - 2022-07-03 09:46:16 --> Total execution time: 0.0308
DEBUG - 2022-07-03 09:46:21 --> Total execution time: 0.0424
DEBUG - 2022-07-03 09:48:28 --> Total execution time: 0.0919
DEBUG - 2022-07-03 09:48:28 --> Total execution time: 0.0332
DEBUG - 2022-07-03 09:48:43 --> Total execution time: 0.0695
DEBUG - 2022-07-03 09:48:58 --> Total execution time: 0.0860
DEBUG - 2022-07-03 09:49:06 --> Total execution time: 0.0667
DEBUG - 2022-07-03 09:49:14 --> Total execution time: 0.0489
DEBUG - 2022-07-03 09:52:17 --> Total execution time: 0.1267
DEBUG - 2022-07-03 09:52:19 --> Total execution time: 0.0433
DEBUG - 2022-07-03 09:52:48 --> Total execution time: 0.0491
DEBUG - 2022-07-03 09:52:54 --> Total execution time: 0.0643
DEBUG - 2022-07-03 09:52:59 --> Total execution time: 0.0554
DEBUG - 2022-07-03 09:53:10 --> Total execution time: 0.0563
DEBUG - 2022-07-03 09:53:22 --> Total execution time: 0.0488
DEBUG - 2022-07-03 09:53:26 --> Total execution time: 0.0717
DEBUG - 2022-07-03 09:56:54 --> Total execution time: 0.1288
DEBUG - 2022-07-03 09:58:15 --> Total execution time: 0.0461
DEBUG - 2022-07-03 10:00:13 --> Total execution time: 0.0399
DEBUG - 2022-07-03 10:00:13 --> Total execution time: 0.0445
DEBUG - 2022-07-03 10:00:25 --> Total execution time: 0.0357
DEBUG - 2022-07-03 10:00:34 --> Total execution time: 0.0490
DEBUG - 2022-07-03 10:00:40 --> Total execution time: 0.0679
DEBUG - 2022-07-03 10:00:43 --> Total execution time: 0.0498
DEBUG - 2022-07-03 10:00:49 --> Total execution time: 0.0597
DEBUG - 2022-07-03 10:00:55 --> Total execution time: 0.0778
DEBUG - 2022-07-03 10:01:15 --> Total execution time: 0.0690
DEBUG - 2022-07-03 10:01:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 10:01:38 --> Total execution time: 0.0524
DEBUG - 2022-07-03 10:01:44 --> Total execution time: 0.0491
DEBUG - 2022-07-03 10:01:47 --> Total execution time: 0.0654
DEBUG - 2022-07-03 10:01:54 --> Total execution time: 0.0457
DEBUG - 2022-07-03 10:01:54 --> Total execution time: 0.0721
DEBUG - 2022-07-03 10:02:01 --> Total execution time: 0.0954
DEBUG - 2022-07-03 10:02:08 --> Total execution time: 0.0312
DEBUG - 2022-07-03 10:02:20 --> Total execution time: 0.0503
DEBUG - 2022-07-03 10:02:23 --> Total execution time: 0.0600
DEBUG - 2022-07-03 10:02:31 --> Total execution time: 0.0541
DEBUG - 2022-07-03 10:02:34 --> Total execution time: 0.0711
DEBUG - 2022-07-03 10:02:36 --> Total execution time: 0.0589
DEBUG - 2022-07-03 10:02:58 --> Total execution time: 0.0556
DEBUG - 2022-07-03 10:03:01 --> Total execution time: 0.0568
DEBUG - 2022-07-03 10:13:57 --> Total execution time: 0.1784
DEBUG - 2022-07-03 10:14:48 --> Total execution time: 0.0822
DEBUG - 2022-07-03 10:16:24 --> Total execution time: 0.1207
DEBUG - 2022-07-03 10:16:34 --> Total execution time: 0.0328
DEBUG - 2022-07-03 10:16:47 --> Total execution time: 0.0768
DEBUG - 2022-07-03 10:16:53 --> Total execution time: 0.0812
DEBUG - 2022-07-03 10:17:22 --> Total execution time: 0.0878
DEBUG - 2022-07-03 10:25:15 --> Total execution time: 0.0539
DEBUG - 2022-07-03 10:25:25 --> Total execution time: 0.0633
DEBUG - 2022-07-03 10:25:29 --> Total execution time: 0.0703
DEBUG - 2022-07-03 10:25:34 --> Total execution time: 0.1030
DEBUG - 2022-07-03 10:25:46 --> Total execution time: 0.0595
DEBUG - 2022-07-03 10:26:07 --> Total execution time: 0.0350
DEBUG - 2022-07-03 10:26:22 --> Total execution time: 0.0346
DEBUG - 2022-07-03 10:26:29 --> Total execution time: 0.0454
DEBUG - 2022-07-03 10:26:39 --> Total execution time: 0.0845
DEBUG - 2022-07-03 10:26:46 --> Total execution time: 0.0447
DEBUG - 2022-07-03 10:27:08 --> Total execution time: 0.0559
DEBUG - 2022-07-03 10:27:29 --> Total execution time: 0.0571
DEBUG - 2022-07-03 10:27:32 --> Total execution time: 0.1285
DEBUG - 2022-07-03 10:27:34 --> Total execution time: 0.0526
DEBUG - 2022-07-03 10:27:36 --> Total execution time: 0.0679
DEBUG - 2022-07-03 10:27:40 --> Total execution time: 0.0558
DEBUG - 2022-07-03 10:27:47 --> Total execution time: 0.0576
DEBUG - 2022-07-03 10:27:50 --> Total execution time: 0.0460
DEBUG - 2022-07-03 10:27:58 --> Total execution time: 0.0462
DEBUG - 2022-07-03 10:28:49 --> Total execution time: 1.4903
DEBUG - 2022-07-03 10:29:16 --> Total execution time: 0.0481
DEBUG - 2022-07-03 10:29:50 --> Total execution time: 0.0524
DEBUG - 2022-07-03 00:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:00:00 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:30:00 --> Total execution time: 0.0480
DEBUG - 2022-07-03 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:30:02 --> Total execution time: 0.0616
DEBUG - 2022-07-03 00:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:30:07 --> Total execution time: 1.7108
DEBUG - 2022-07-03 00:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:00:16 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:30:17 --> Total execution time: 0.0512
DEBUG - 2022-07-03 00:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:30:17 --> Total execution time: 0.0378
DEBUG - 2022-07-03 00:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:00:45 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:30:45 --> Total execution time: 0.0622
DEBUG - 2022-07-03 00:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:00:55 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:30:55 --> Total execution time: 0.0482
DEBUG - 2022-07-03 00:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:31:02 --> Total execution time: 0.0480
DEBUG - 2022-07-03 00:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:31:42 --> Total execution time: 0.0581
DEBUG - 2022-07-03 00:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:31:50 --> Total execution time: 0.0512
DEBUG - 2022-07-03 00:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:31:56 --> Total execution time: 0.0484
DEBUG - 2022-07-03 00:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:33:52 --> Total execution time: 0.0579
DEBUG - 2022-07-03 00:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:34:33 --> Total execution time: 0.0346
DEBUG - 2022-07-03 00:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:35:39 --> Total execution time: 0.0526
DEBUG - 2022-07-03 00:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:05:45 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:35:45 --> Total execution time: 0.0347
DEBUG - 2022-07-03 00:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:11:16 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:41:16 --> Total execution time: 0.1123
DEBUG - 2022-07-03 00:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:41:16 --> Total execution time: 0.0499
DEBUG - 2022-07-03 00:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:11:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:41:53 --> Total execution time: 0.1135
DEBUG - 2022-07-03 00:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:42:28 --> Total execution time: 0.0543
DEBUG - 2022-07-03 00:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:12:59 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:42:59 --> Total execution time: 0.0707
DEBUG - 2022-07-03 00:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:43:02 --> Total execution time: 0.0565
DEBUG - 2022-07-03 00:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:13:45 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:43:45 --> Total execution time: 0.0479
DEBUG - 2022-07-03 00:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:43:48 --> Total execution time: 0.0403
DEBUG - 2022-07-03 00:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:43:55 --> Total execution time: 0.0524
DEBUG - 2022-07-03 00:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:44:26 --> Total execution time: 0.0471
DEBUG - 2022-07-03 00:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:45:02 --> Total execution time: 0.0668
DEBUG - 2022-07-03 00:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:45:10 --> Total execution time: 0.0547
DEBUG - 2022-07-03 00:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:45:19 --> Total execution time: 0.0750
DEBUG - 2022-07-03 00:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:45:24 --> Total execution time: 0.0656
DEBUG - 2022-07-03 00:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:45:24 --> Total execution time: 0.0526
DEBUG - 2022-07-03 00:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:45:29 --> Total execution time: 0.0577
DEBUG - 2022-07-03 00:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:45:32 --> Total execution time: 0.0545
DEBUG - 2022-07-03 00:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:45:37 --> Total execution time: 0.0525
DEBUG - 2022-07-03 00:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:45:37 --> Total execution time: 0.0607
DEBUG - 2022-07-03 00:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:45:41 --> Total execution time: 0.0616
DEBUG - 2022-07-03 00:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:46:18 --> Total execution time: 0.1365
DEBUG - 2022-07-03 00:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:46:24 --> Total execution time: 0.0549
DEBUG - 2022-07-03 00:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:46:40 --> Total execution time: 0.0641
DEBUG - 2022-07-03 00:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:16:46 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:46:46 --> Total execution time: 0.0577
DEBUG - 2022-07-03 00:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:46:51 --> Total execution time: 0.0477
DEBUG - 2022-07-03 00:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:17:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 00:17:22 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-03 00:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:49:38 --> Total execution time: 0.1110
DEBUG - 2022-07-03 00:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:24:35 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:54:35 --> Total execution time: 0.0882
DEBUG - 2022-07-03 00:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:27:00 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:57:00 --> Total execution time: 0.1859
DEBUG - 2022-07-03 00:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:57:05 --> Total execution time: 0.0483
DEBUG - 2022-07-03 00:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:57:14 --> Total execution time: 0.0639
DEBUG - 2022-07-03 00:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:57:18 --> Total execution time: 0.0835
DEBUG - 2022-07-03 00:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:27:21 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:57:21 --> Total execution time: 0.0543
DEBUG - 2022-07-03 00:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:27:38 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:57:38 --> Total execution time: 0.0585
DEBUG - 2022-07-03 00:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:28:22 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:58:22 --> Total execution time: 0.0483
DEBUG - 2022-07-03 00:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:28:23 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:58:23 --> Total execution time: 0.0707
DEBUG - 2022-07-03 00:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 00:28:33 --> 404 Page Not Found: Lessons/how-to-set-product-price
DEBUG - 2022-07-03 00:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:32:29 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:02:29 --> Total execution time: 0.0421
DEBUG - 2022-07-03 00:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:02:45 --> Total execution time: 0.1685
DEBUG - 2022-07-03 00:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:02:49 --> Total execution time: 0.0595
DEBUG - 2022-07-03 00:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:02:56 --> Total execution time: 0.0662
DEBUG - 2022-07-03 00:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:32:58 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:02:58 --> Total execution time: 0.0327
DEBUG - 2022-07-03 00:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:03:39 --> Total execution time: 0.0342
DEBUG - 2022-07-03 00:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:03:43 --> Total execution time: 0.0494
DEBUG - 2022-07-03 00:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:33:55 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:03:55 --> Total execution time: 0.0432
DEBUG - 2022-07-03 00:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:04:34 --> Total execution time: 0.0362
DEBUG - 2022-07-03 00:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:04:47 --> Total execution time: 0.0334
DEBUG - 2022-07-03 00:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:04:47 --> Total execution time: 0.0273
DEBUG - 2022-07-03 00:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:04:54 --> Total execution time: 0.0710
DEBUG - 2022-07-03 00:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:05:14 --> Total execution time: 0.0898
DEBUG - 2022-07-03 00:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:35:17 --> Total execution time: 0.0717
DEBUG - 2022-07-03 00:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:35:19 --> Total execution time: 0.0506
DEBUG - 2022-07-03 00:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:35:19 --> Total execution time: 0.1048
DEBUG - 2022-07-03 00:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:35:28 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:05:28 --> Total execution time: 0.0465
DEBUG - 2022-07-03 00:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:35:46 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:05:46 --> Total execution time: 0.0357
DEBUG - 2022-07-03 11:05:47 --> Total execution time: 1.5703
DEBUG - 2022-07-03 00:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:35:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 00:35:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 00:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:36:13 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:06:13 --> Total execution time: 0.0349
DEBUG - 2022-07-03 00:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:36:39 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:06:39 --> Total execution time: 0.0337
DEBUG - 2022-07-03 00:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:06:42 --> Total execution time: 1.5077
DEBUG - 2022-07-03 00:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:37:05 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:07:05 --> Total execution time: 0.0613
DEBUG - 2022-07-03 00:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:37:18 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:07:18 --> Total execution time: 0.0746
DEBUG - 2022-07-03 00:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:37:41 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:07:41 --> Total execution time: 0.0617
DEBUG - 2022-07-03 00:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:37:49 --> Total execution time: 0.0507
DEBUG - 2022-07-03 00:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:37:50 --> Total execution time: 0.0516
DEBUG - 2022-07-03 00:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:37:50 --> Total execution time: 0.0787
DEBUG - 2022-07-03 00:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:38:20 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:08:20 --> Total execution time: 0.0308
DEBUG - 2022-07-03 00:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:08:26 --> Total execution time: 0.0277
DEBUG - 2022-07-03 00:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:08:35 --> Total execution time: 0.0567
DEBUG - 2022-07-03 00:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:08:40 --> Total execution time: 0.0694
DEBUG - 2022-07-03 00:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:08:45 --> Total execution time: 0.0528
DEBUG - 2022-07-03 00:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:08:52 --> Total execution time: 0.0633
DEBUG - 2022-07-03 00:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:08:52 --> Total execution time: 0.0462
DEBUG - 2022-07-03 00:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:08:59 --> Total execution time: 0.0663
DEBUG - 2022-07-03 00:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:09:03 --> Total execution time: 0.1401
DEBUG - 2022-07-03 00:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:09:04 --> Total execution time: 0.0663
DEBUG - 2022-07-03 00:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:09:04 --> Total execution time: 0.0622
DEBUG - 2022-07-03 00:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:09:08 --> Total execution time: 0.0554
DEBUG - 2022-07-03 00:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:39:09 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:09:09 --> Total execution time: 0.0794
DEBUG - 2022-07-03 00:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:09:33 --> Total execution time: 0.2205
DEBUG - 2022-07-03 00:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:10:20 --> Total execution time: 0.0660
DEBUG - 2022-07-03 00:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:41:42 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:11:42 --> Total execution time: 0.0533
DEBUG - 2022-07-03 00:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:11:47 --> Total execution time: 0.0313
DEBUG - 2022-07-03 00:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:11:48 --> Total execution time: 0.0329
DEBUG - 2022-07-03 00:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:42:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 00:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:12:11 --> Total execution time: 1.4882
DEBUG - 2022-07-03 00:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:42:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 00:42:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 00:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:12:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 00:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:12:45 --> Total execution time: 0.0562
DEBUG - 2022-07-03 00:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:12:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 11:12:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 11:12:48 --> Total execution time: 0.1972
DEBUG - 2022-07-03 00:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:43:08 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:13:08 --> Total execution time: 0.0500
DEBUG - 2022-07-03 00:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:43:59 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:13:59 --> Total execution time: 0.0538
DEBUG - 2022-07-03 00:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:44:02 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:14:02 --> Total execution time: 0.0525
DEBUG - 2022-07-03 00:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:44:05 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:14:05 --> Total execution time: 0.0546
DEBUG - 2022-07-03 00:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:14:20 --> Total execution time: 0.0542
DEBUG - 2022-07-03 00:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:14:41 --> Total execution time: 0.0510
DEBUG - 2022-07-03 00:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:14:54 --> Total execution time: 0.0616
DEBUG - 2022-07-03 00:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:15:07 --> Total execution time: 0.0785
DEBUG - 2022-07-03 00:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:15:37 --> Total execution time: 0.0584
DEBUG - 2022-07-03 00:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:15:43 --> Total execution time: 0.0525
DEBUG - 2022-07-03 00:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:15:47 --> Total execution time: 0.0659
DEBUG - 2022-07-03 00:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 00:45:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 00:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:45:54 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:15:54 --> Total execution time: 0.1385
DEBUG - 2022-07-03 00:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:16:09 --> Total execution time: 0.0532
DEBUG - 2022-07-03 00:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:16:12 --> Total execution time: 0.0544
DEBUG - 2022-07-03 00:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:16:41 --> Total execution time: 0.0693
DEBUG - 2022-07-03 00:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:46:48 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:16:48 --> Total execution time: 0.1222
DEBUG - 2022-07-03 00:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:16:48 --> Total execution time: 0.0516
DEBUG - 2022-07-03 00:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:16:55 --> Total execution time: 0.0613
DEBUG - 2022-07-03 00:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:47:03 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:17:03 --> Total execution time: 0.0378
DEBUG - 2022-07-03 00:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:47:37 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:17:37 --> Total execution time: 0.0447
DEBUG - 2022-07-03 00:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:20:01 --> Total execution time: 0.2164
DEBUG - 2022-07-03 00:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:20:14 --> Total execution time: 0.0668
DEBUG - 2022-07-03 00:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:51:48 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:21:48 --> Total execution time: 0.0392
DEBUG - 2022-07-03 00:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:21:50 --> Total execution time: 0.0547
DEBUG - 2022-07-03 00:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:21:56 --> Total execution time: 0.0552
DEBUG - 2022-07-03 00:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:22:03 --> Total execution time: 0.0532
DEBUG - 2022-07-03 00:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:22:11 --> Total execution time: 0.0792
DEBUG - 2022-07-03 00:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:22:15 --> Total execution time: 0.0757
DEBUG - 2022-07-03 00:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:52:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 00:52:18 --> 404 Page Not Found: Lp-profile/index
DEBUG - 2022-07-03 00:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:22:57 --> Total execution time: 0.1527
DEBUG - 2022-07-03 00:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:23:39 --> Total execution time: 0.1377
DEBUG - 2022-07-03 00:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:54:06 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:24:06 --> Total execution time: 0.0463
DEBUG - 2022-07-03 00:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:54:28 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:24:28 --> Total execution time: 0.0366
DEBUG - 2022-07-03 00:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:54:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:24:53 --> Total execution time: 0.0351
DEBUG - 2022-07-03 00:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:25:55 --> Total execution time: 0.0410
DEBUG - 2022-07-03 00:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:26:35 --> Total execution time: 0.0667
DEBUG - 2022-07-03 00:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:27:10 --> Total execution time: 0.0683
DEBUG - 2022-07-03 00:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:27:17 --> Total execution time: 0.0599
DEBUG - 2022-07-03 00:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 00:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:28:09 --> Total execution time: 0.0606
DEBUG - 2022-07-03 00:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:59:33 --> No URI present. Default controller set.
DEBUG - 2022-07-03 00:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:29:33 --> Total execution time: 0.0363
DEBUG - 2022-07-03 00:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 00:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 00:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:29:58 --> Total execution time: 0.0318
DEBUG - 2022-07-03 01:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:30:01 --> Total execution time: 0.0487
DEBUG - 2022-07-03 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:30:02 --> Total execution time: 0.0551
DEBUG - 2022-07-03 01:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:00:08 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:30:08 --> Total execution time: 0.0768
DEBUG - 2022-07-03 01:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:30:11 --> Total execution time: 0.0491
DEBUG - 2022-07-03 01:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:30:26 --> Total execution time: 0.0755
DEBUG - 2022-07-03 01:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:30:30 --> Total execution time: 0.0995
DEBUG - 2022-07-03 01:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:01:18 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:31:18 --> Total execution time: 0.0351
DEBUG - 2022-07-03 01:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:31:22 --> Total execution time: 0.0794
DEBUG - 2022-07-03 01:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:31:23 --> Total execution time: 0.0644
DEBUG - 2022-07-03 01:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:01:38 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:31:38 --> Total execution time: 0.0472
DEBUG - 2022-07-03 01:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:01:39 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:31:39 --> Total execution time: 0.0275
DEBUG - 2022-07-03 01:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:32:38 --> Total execution time: 0.0816
DEBUG - 2022-07-03 01:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:33:44 --> Total execution time: 0.0540
DEBUG - 2022-07-03 01:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:33:50 --> Total execution time: 0.0461
DEBUG - 2022-07-03 01:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:34:08 --> Total execution time: 0.1393
DEBUG - 2022-07-03 01:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:34:24 --> Total execution time: 0.0557
DEBUG - 2022-07-03 01:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:34:43 --> Total execution time: 0.0466
DEBUG - 2022-07-03 01:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:05:46 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:35:46 --> Total execution time: 0.1394
DEBUG - 2022-07-03 01:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:05:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 01:05:54 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-03 01:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:36:14 --> Total execution time: 0.0539
DEBUG - 2022-07-03 01:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:36:18 --> Total execution time: 0.0700
DEBUG - 2022-07-03 01:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:36:40 --> Total execution time: 0.1630
DEBUG - 2022-07-03 01:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:36:48 --> Total execution time: 0.0745
DEBUG - 2022-07-03 01:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:07:51 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:37:51 --> Total execution time: 0.0454
DEBUG - 2022-07-03 01:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:08:27 --> Total execution time: 0.0353
DEBUG - 2022-07-03 01:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:39:35 --> Total execution time: 0.0454
DEBUG - 2022-07-03 01:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:39:42 --> Total execution time: 0.0901
DEBUG - 2022-07-03 01:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:39:50 --> Total execution time: 0.0716
DEBUG - 2022-07-03 01:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:40:20 --> Total execution time: 0.1188
DEBUG - 2022-07-03 01:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:40:26 --> Total execution time: 0.0539
DEBUG - 2022-07-03 01:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:10:49 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:40:49 --> Total execution time: 0.0372
DEBUG - 2022-07-03 01:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:41:07 --> Total execution time: 0.0616
DEBUG - 2022-07-03 01:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:11:10 --> Total execution time: 0.0508
DEBUG - 2022-07-03 01:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:11:11 --> Total execution time: 0.0536
DEBUG - 2022-07-03 01:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:11:11 --> Total execution time: 0.0697
DEBUG - 2022-07-03 01:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:11:12 --> Total execution time: 0.0479
DEBUG - 2022-07-03 01:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:11:31 --> Total execution time: 0.0581
DEBUG - 2022-07-03 01:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:11:50 --> Total execution time: 0.0453
DEBUG - 2022-07-03 01:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:11:52 --> Total execution time: 0.0540
DEBUG - 2022-07-03 01:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:11:54 --> Total execution time: 0.0511
DEBUG - 2022-07-03 01:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:41:56 --> Total execution time: 0.0868
DEBUG - 2022-07-03 01:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:12:25 --> Total execution time: 0.0658
DEBUG - 2022-07-03 01:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:42:25 --> Total execution time: 0.0682
DEBUG - 2022-07-03 01:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:42:32 --> Total execution time: 0.0620
DEBUG - 2022-07-03 01:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:42:49 --> Total execution time: 0.0526
DEBUG - 2022-07-03 01:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:43:08 --> Total execution time: 0.0550
DEBUG - 2022-07-03 01:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:43:14 --> Total execution time: 0.0520
DEBUG - 2022-07-03 01:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:43:37 --> Total execution time: 0.0770
DEBUG - 2022-07-03 01:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:43:38 --> Total execution time: 0.1497
DEBUG - 2022-07-03 01:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:13:46 --> Total execution time: 0.0521
DEBUG - 2022-07-03 01:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:43:48 --> Total execution time: 0.0829
DEBUG - 2022-07-03 01:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:43:50 --> Total execution time: 0.1046
DEBUG - 2022-07-03 01:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:44:12 --> Total execution time: 0.0768
DEBUG - 2022-07-03 01:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:44:27 --> Total execution time: 0.0546
DEBUG - 2022-07-03 01:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:44:31 --> Total execution time: 0.0727
DEBUG - 2022-07-03 01:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:44:56 --> Total execution time: 0.0487
DEBUG - 2022-07-03 01:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:45:09 --> Total execution time: 0.0619
DEBUG - 2022-07-03 01:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:45:10 --> Total execution time: 0.0561
DEBUG - 2022-07-03 01:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:45:17 --> Total execution time: 0.0514
DEBUG - 2022-07-03 01:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:45:20 --> Total execution time: 0.0403
DEBUG - 2022-07-03 01:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:45:22 --> Total execution time: 0.1240
DEBUG - 2022-07-03 01:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:45:28 --> Total execution time: 0.0472
DEBUG - 2022-07-03 01:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:45:39 --> Total execution time: 0.0558
DEBUG - 2022-07-03 01:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:45:47 --> Total execution time: 0.0683
DEBUG - 2022-07-03 01:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:45:53 --> Total execution time: 0.0842
DEBUG - 2022-07-03 01:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:46:06 --> Total execution time: 0.0579
DEBUG - 2022-07-03 01:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:46:12 --> Total execution time: 0.0478
DEBUG - 2022-07-03 01:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:46:58 --> Total execution time: 0.0511
DEBUG - 2022-07-03 01:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:17:28 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:47:28 --> Total execution time: 0.0389
DEBUG - 2022-07-03 01:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:17:32 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:47:32 --> Total execution time: 0.0411
DEBUG - 2022-07-03 01:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:18:06 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:48:06 --> Total execution time: 0.0415
DEBUG - 2022-07-03 01:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:48:22 --> Total execution time: 0.0578
DEBUG - 2022-07-03 01:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:48:27 --> Total execution time: 0.1541
DEBUG - 2022-07-03 01:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:48:34 --> Total execution time: 0.1414
DEBUG - 2022-07-03 01:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:48:47 --> Total execution time: 0.0753
DEBUG - 2022-07-03 01:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:50:04 --> Total execution time: 0.0561
DEBUG - 2022-07-03 01:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:50:34 --> Total execution time: 0.1280
DEBUG - 2022-07-03 01:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:50:39 --> Total execution time: 0.0550
DEBUG - 2022-07-03 01:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:50:40 --> Total execution time: 0.0465
DEBUG - 2022-07-03 01:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:52:20 --> Total execution time: 0.0444
DEBUG - 2022-07-03 01:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:52:31 --> Total execution time: 0.0578
DEBUG - 2022-07-03 01:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:52:44 --> Total execution time: 0.0777
DEBUG - 2022-07-03 01:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:22:54 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:52:54 --> Total execution time: 0.0396
DEBUG - 2022-07-03 01:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:52:57 --> Total execution time: 0.0684
DEBUG - 2022-07-03 01:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:53:03 --> Total execution time: 0.0517
DEBUG - 2022-07-03 01:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:23:05 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:53:05 --> Total execution time: 0.1226
DEBUG - 2022-07-03 01:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:53:13 --> Total execution time: 0.0696
DEBUG - 2022-07-03 01:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:53:17 --> Total execution time: 0.0859
DEBUG - 2022-07-03 01:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:53:24 --> Total execution time: 1.5515
DEBUG - 2022-07-03 01:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:53:44 --> Total execution time: 0.0722
DEBUG - 2022-07-03 01:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:53:55 --> Total execution time: 0.1299
DEBUG - 2022-07-03 01:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:53:56 --> Total execution time: 0.0439
DEBUG - 2022-07-03 01:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:54:00 --> Total execution time: 0.0696
DEBUG - 2022-07-03 01:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:54:04 --> Total execution time: 0.0535
DEBUG - 2022-07-03 01:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:54:04 --> Total execution time: 0.0535
DEBUG - 2022-07-03 01:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:54:07 --> Total execution time: 0.0518
DEBUG - 2022-07-03 01:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 01:24:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 01:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:54:24 --> Total execution time: 0.0463
DEBUG - 2022-07-03 01:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:25:20 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:55:20 --> Total execution time: 0.0855
DEBUG - 2022-07-03 01:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:55:20 --> Total execution time: 0.1762
DEBUG - 2022-07-03 01:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:55:34 --> Total execution time: 1.4869
DEBUG - 2022-07-03 01:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:25:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 01:25:37 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 01:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:25:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:55:53 --> Total execution time: 0.0509
DEBUG - 2022-07-03 01:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:25:56 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:55:56 --> Total execution time: 0.0526
DEBUG - 2022-07-03 01:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:26:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 01:26:09 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-03 01:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:56:35 --> Total execution time: 0.0693
DEBUG - 2022-07-03 01:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:28:24 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:58:24 --> Total execution time: 0.1246
DEBUG - 2022-07-03 01:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:58:33 --> Total execution time: 0.0701
DEBUG - 2022-07-03 01:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:58:33 --> Total execution time: 0.0585
DEBUG - 2022-07-03 01:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:28:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 01:28:34 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 01:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:58:52 --> Total execution time: 0.0776
DEBUG - 2022-07-03 01:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:58:54 --> Total execution time: 0.0514
DEBUG - 2022-07-03 01:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:58:54 --> Total execution time: 0.0637
DEBUG - 2022-07-03 01:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:58:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 01:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:58:56 --> Total execution time: 0.0558
DEBUG - 2022-07-03 01:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:59:01 --> Total execution time: 0.0720
DEBUG - 2022-07-03 01:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:59:05 --> Total execution time: 0.0560
DEBUG - 2022-07-03 01:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:59:17 --> Total execution time: 0.0605
DEBUG - 2022-07-03 01:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:30:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 01:30:36 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-03 01:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:02:58 --> Total execution time: 0.1964
DEBUG - 2022-07-03 01:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:04:10 --> Total execution time: 0.0419
DEBUG - 2022-07-03 01:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:05:22 --> Total execution time: 0.0632
DEBUG - 2022-07-03 01:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:36:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 01:36:06 --> 404 Page Not Found: Modulessphp/index
DEBUG - 2022-07-03 01:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:36:30 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:06:30 --> Total execution time: 0.0470
DEBUG - 2022-07-03 01:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:06:36 --> Total execution time: 0.0414
DEBUG - 2022-07-03 01:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:07:23 --> Total execution time: 0.0662
DEBUG - 2022-07-03 01:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:37:59 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:07:59 --> Total execution time: 0.0433
DEBUG - 2022-07-03 01:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:08:04 --> Total execution time: 0.0365
DEBUG - 2022-07-03 01:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:38:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 01:38:36 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-03 01:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 01:38:39 --> 404 Page Not Found: My-account/index
DEBUG - 2022-07-03 01:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:08:50 --> Total execution time: 0.0478
DEBUG - 2022-07-03 01:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 01:39:07 --> 404 Page Not Found: Wp-content/index
DEBUG - 2022-07-03 01:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:09:11 --> Total execution time: 0.0664
DEBUG - 2022-07-03 01:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:09:32 --> Total execution time: 0.0465
DEBUG - 2022-07-03 01:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:09:52 --> Total execution time: 0.0561
DEBUG - 2022-07-03 01:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:10:07 --> Total execution time: 0.2065
DEBUG - 2022-07-03 01:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:40:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:10:11 --> Total execution time: 0.0559
DEBUG - 2022-07-03 01:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:10:15 --> Total execution time: 0.0570
DEBUG - 2022-07-03 01:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:10:26 --> Total execution time: 0.0635
DEBUG - 2022-07-03 01:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:10:27 --> Total execution time: 0.0547
DEBUG - 2022-07-03 01:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:10:38 --> Total execution time: 0.0916
DEBUG - 2022-07-03 01:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:10:45 --> Total execution time: 0.1079
DEBUG - 2022-07-03 01:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:10:52 --> Total execution time: 0.0463
DEBUG - 2022-07-03 01:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:10:58 --> Total execution time: 0.0629
DEBUG - 2022-07-03 01:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:11:08 --> Total execution time: 0.0630
DEBUG - 2022-07-03 01:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:11:10 --> Total execution time: 0.0569
DEBUG - 2022-07-03 01:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:11:26 --> Total execution time: 0.0540
DEBUG - 2022-07-03 01:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:11:51 --> Total execution time: 0.0486
DEBUG - 2022-07-03 01:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:12:05 --> Total execution time: 0.0459
DEBUG - 2022-07-03 01:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:12:15 --> Total execution time: 0.0455
DEBUG - 2022-07-03 01:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:12:23 --> Total execution time: 0.0530
DEBUG - 2022-07-03 01:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:12:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 01:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:12:24 --> Total execution time: 0.0488
DEBUG - 2022-07-03 01:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:43:37 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:13:37 --> Total execution time: 0.0381
DEBUG - 2022-07-03 01:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:13:38 --> Total execution time: 0.0542
DEBUG - 2022-07-03 01:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:13:40 --> Total execution time: 0.0844
DEBUG - 2022-07-03 01:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:43:54 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:13:54 --> Total execution time: 0.0366
DEBUG - 2022-07-03 01:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:44:30 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:14:30 --> Total execution time: 0.0473
DEBUG - 2022-07-03 01:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:44:43 --> Total execution time: 0.0559
DEBUG - 2022-07-03 01:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:45:00 --> Total execution time: 0.0529
DEBUG - 2022-07-03 01:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:05 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:15:05 --> Total execution time: 0.0399
DEBUG - 2022-07-03 01:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:45:10 --> Total execution time: 0.0660
DEBUG - 2022-07-03 01:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:45:14 --> Total execution time: 0.0507
DEBUG - 2022-07-03 01:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:15:15 --> Total execution time: 0.1485
DEBUG - 2022-07-03 01:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:45:16 --> Total execution time: 0.0706
DEBUG - 2022-07-03 01:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:45:17 --> Total execution time: 0.0600
DEBUG - 2022-07-03 01:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:45:17 --> Total execution time: 0.0801
DEBUG - 2022-07-03 01:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:15:33 --> Total execution time: 0.0364
DEBUG - 2022-07-03 01:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:15:33 --> Total execution time: 0.0513
DEBUG - 2022-07-03 01:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:15:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 01:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:15:35 --> Total execution time: 0.0722
DEBUG - 2022-07-03 01:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:45:46 --> Total execution time: 0.0482
DEBUG - 2022-07-03 01:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:45:47 --> Total execution time: 0.0502
DEBUG - 2022-07-03 01:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:45:48 --> Total execution time: 0.0861
DEBUG - 2022-07-03 01:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:46:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 01:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:16:15 --> Total execution time: 1.5306
DEBUG - 2022-07-03 01:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:46:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 01:46:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 01:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:16:39 --> Total execution time: 0.0523
DEBUG - 2022-07-03 01:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:16:45 --> Total execution time: 0.0461
DEBUG - 2022-07-03 01:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:17:18 --> Total execution time: 0.0453
DEBUG - 2022-07-03 01:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:17:32 --> Total execution time: 0.0515
DEBUG - 2022-07-03 01:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:17:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 01:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:17:33 --> Total execution time: 0.0495
DEBUG - 2022-07-03 01:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:17:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 12:17:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 12:17:35 --> Total execution time: 0.1917
DEBUG - 2022-07-03 01:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:17:37 --> Total execution time: 0.0508
DEBUG - 2022-07-03 01:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:17:46 --> Total execution time: 0.0506
DEBUG - 2022-07-03 01:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:17:47 --> Total execution time: 0.0394
DEBUG - 2022-07-03 01:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:17:54 --> Total execution time: 0.0534
DEBUG - 2022-07-03 01:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:18:01 --> Total execution time: 0.0961
DEBUG - 2022-07-03 01:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:18:06 --> Total execution time: 0.0456
DEBUG - 2022-07-03 01:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:18:08 --> Total execution time: 0.0481
DEBUG - 2022-07-03 01:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:18:10 --> Total execution time: 0.0503
DEBUG - 2022-07-03 01:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:18:13 --> Total execution time: 0.0467
DEBUG - 2022-07-03 01:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:18:18 --> Total execution time: 0.0695
DEBUG - 2022-07-03 01:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:18:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 01:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:18:19 --> Total execution time: 0.0416
DEBUG - 2022-07-03 01:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:18:29 --> Total execution time: 0.0484
DEBUG - 2022-07-03 01:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:41 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:18:41 --> Total execution time: 0.0357
DEBUG - 2022-07-03 01:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:18:42 --> Total execution time: 0.1195
DEBUG - 2022-07-03 01:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:18:48 --> Total execution time: 0.0653
DEBUG - 2022-07-03 01:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:19:06 --> Total execution time: 0.0513
DEBUG - 2022-07-03 01:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:19:27 --> Total execution time: 0.0607
DEBUG - 2022-07-03 01:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:19:35 --> Total execution time: 0.0543
DEBUG - 2022-07-03 01:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:19:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 01:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:19:36 --> Total execution time: 0.0656
DEBUG - 2022-07-03 01:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:19:47 --> Total execution time: 0.0483
DEBUG - 2022-07-03 01:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:19:52 --> Total execution time: 0.0522
DEBUG - 2022-07-03 01:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:19:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 01:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:19:53 --> Total execution time: 0.0730
DEBUG - 2022-07-03 01:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:20:10 --> Total execution time: 0.0526
DEBUG - 2022-07-03 01:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:20:23 --> Total execution time: 0.1012
DEBUG - 2022-07-03 01:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:20:52 --> Total execution time: 0.1303
DEBUG - 2022-07-03 01:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:50:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:20:53 --> Total execution time: 0.0340
DEBUG - 2022-07-03 01:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:50:54 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:20:54 --> Total execution time: 0.0371
DEBUG - 2022-07-03 01:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:50:54 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:20:54 --> Total execution time: 0.0414
DEBUG - 2022-07-03 01:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:51:00 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:21:00 --> Total execution time: 0.0519
DEBUG - 2022-07-03 01:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:21:03 --> Total execution time: 0.0328
DEBUG - 2022-07-03 01:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:21:14 --> Total execution time: 0.0314
DEBUG - 2022-07-03 01:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:21:26 --> Total execution time: 0.0465
DEBUG - 2022-07-03 01:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:21:28 --> Total execution time: 0.0512
DEBUG - 2022-07-03 01:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:21:36 --> Total execution time: 0.0503
DEBUG - 2022-07-03 01:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:21:49 --> Total execution time: 0.0516
DEBUG - 2022-07-03 01:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:21:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 01:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:21:50 --> Total execution time: 0.0473
DEBUG - 2022-07-03 01:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:22:14 --> Total execution time: 0.0471
DEBUG - 2022-07-03 01:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:22:21 --> Total execution time: 0.0488
DEBUG - 2022-07-03 01:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:52:25 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:22:25 --> Total execution time: 0.0466
DEBUG - 2022-07-03 01:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:22:31 --> Total execution time: 0.0528
DEBUG - 2022-07-03 01:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:22:52 --> Total execution time: 0.0316
DEBUG - 2022-07-03 01:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:52:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 01:52:59 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-03 01:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:23:10 --> Total execution time: 0.0452
DEBUG - 2022-07-03 01:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:23:25 --> Total execution time: 0.0463
DEBUG - 2022-07-03 01:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:23:43 --> Total execution time: 0.0444
DEBUG - 2022-07-03 01:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:23:58 --> Total execution time: 0.0476
DEBUG - 2022-07-03 01:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:24:09 --> Total execution time: 0.0457
DEBUG - 2022-07-03 01:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:24:19 --> Total execution time: 0.1266
DEBUG - 2022-07-03 01:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:24:50 --> Total execution time: 0.0881
DEBUG - 2022-07-03 01:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:25:03 --> Total execution time: 0.0465
DEBUG - 2022-07-03 01:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:25:24 --> Total execution time: 0.0482
DEBUG - 2022-07-03 01:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:55:29 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:25:29 --> Total execution time: 0.0353
DEBUG - 2022-07-03 01:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:25:30 --> Total execution time: 0.0794
DEBUG - 2022-07-03 01:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:25:39 --> Total execution time: 0.0724
DEBUG - 2022-07-03 01:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:25:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 01:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:25:40 --> Total execution time: 0.0711
DEBUG - 2022-07-03 01:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:55:59 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:25:59 --> Total execution time: 0.0341
DEBUG - 2022-07-03 01:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:26:03 --> Total execution time: 0.0345
DEBUG - 2022-07-03 01:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:26:11 --> Total execution time: 0.0504
DEBUG - 2022-07-03 01:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:26:16 --> Total execution time: 0.0498
DEBUG - 2022-07-03 01:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:26:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 01:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:26:17 --> Total execution time: 0.0454
DEBUG - 2022-07-03 01:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:28:04 --> Total execution time: 0.1147
DEBUG - 2022-07-03 01:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:58:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 01:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:28:11 --> Total execution time: 0.0494
DEBUG - 2022-07-03 01:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:28:14 --> Total execution time: 0.0581
DEBUG - 2022-07-03 01:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:28:19 --> Total execution time: 0.0515
DEBUG - 2022-07-03 01:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:28:51 --> Total execution time: 0.0542
DEBUG - 2022-07-03 01:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:29:14 --> Total execution time: 0.0399
DEBUG - 2022-07-03 01:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:29:30 --> Total execution time: 0.1497
DEBUG - 2022-07-03 01:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:29:34 --> Total execution time: 0.0517
DEBUG - 2022-07-03 01:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:29:46 --> Total execution time: 0.1210
DEBUG - 2022-07-03 01:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 01:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 01:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 01:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:29:56 --> Total execution time: 0.0729
DEBUG - 2022-07-03 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:30:03 --> Total execution time: 0.0967
DEBUG - 2022-07-03 02:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:30:08 --> Total execution time: 0.1066
DEBUG - 2022-07-03 02:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:30:27 --> Total execution time: 0.0503
DEBUG - 2022-07-03 02:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:30:44 --> Total execution time: 0.0444
DEBUG - 2022-07-03 02:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:00:55 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:30:55 --> Total execution time: 0.0357
DEBUG - 2022-07-03 02:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:31:01 --> Total execution time: 0.1735
DEBUG - 2022-07-03 02:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:31:02 --> Total execution time: 0.0525
DEBUG - 2022-07-03 02:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:31:19 --> Total execution time: 0.1235
DEBUG - 2022-07-03 02:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:01:35 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:31:35 --> Total execution time: 0.1167
DEBUG - 2022-07-03 02:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:31:40 --> Total execution time: 0.1181
DEBUG - 2022-07-03 02:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:32:06 --> Total execution time: 0.0463
DEBUG - 2022-07-03 02:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:02:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:32:11 --> Total execution time: 0.0429
DEBUG - 2022-07-03 02:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:32:20 --> Total execution time: 0.0675
DEBUG - 2022-07-03 02:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:32:20 --> Total execution time: 0.0806
DEBUG - 2022-07-03 02:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:32:36 --> Total execution time: 0.0455
DEBUG - 2022-07-03 02:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:32:49 --> Total execution time: 0.0496
DEBUG - 2022-07-03 02:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:32:53 --> Total execution time: 0.0570
DEBUG - 2022-07-03 02:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:03:47 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:33:47 --> Total execution time: 0.0515
DEBUG - 2022-07-03 02:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:04:15 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:34:16 --> Total execution time: 0.0338
DEBUG - 2022-07-03 02:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:34:18 --> Total execution time: 0.1165
DEBUG - 2022-07-03 02:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:34:18 --> Total execution time: 0.0507
DEBUG - 2022-07-03 02:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:04:20 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:34:20 --> Total execution time: 0.0686
DEBUG - 2022-07-03 02:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:34:20 --> Total execution time: 0.1185
DEBUG - 2022-07-03 02:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:04:23 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:34:23 --> Total execution time: 0.0278
DEBUG - 2022-07-03 02:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:34:28 --> Total execution time: 0.0324
DEBUG - 2022-07-03 02:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:34:28 --> Total execution time: 0.0479
DEBUG - 2022-07-03 02:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:04:37 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:34:37 --> Total execution time: 0.0483
DEBUG - 2022-07-03 02:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:34:37 --> Total execution time: 0.0346
DEBUG - 2022-07-03 02:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:34:44 --> Total execution time: 0.0461
DEBUG - 2022-07-03 02:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:35:06 --> Total execution time: 0.0484
DEBUG - 2022-07-03 02:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:35:15 --> Total execution time: 0.0562
DEBUG - 2022-07-03 02:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:35:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 02:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:35:22 --> Total execution time: 0.0533
DEBUG - 2022-07-03 02:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:35:25 --> Total execution time: 0.0514
DEBUG - 2022-07-03 02:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:35:59 --> Total execution time: 0.0478
DEBUG - 2022-07-03 02:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:36:15 --> Total execution time: 0.0569
DEBUG - 2022-07-03 02:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:36:41 --> Total execution time: 0.0462
DEBUG - 2022-07-03 02:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:36:48 --> Total execution time: 0.0665
DEBUG - 2022-07-03 02:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:36:54 --> Total execution time: 0.0847
DEBUG - 2022-07-03 02:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:37:10 --> Total execution time: 0.1074
DEBUG - 2022-07-03 02:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:37:19 --> Total execution time: 0.0463
DEBUG - 2022-07-03 02:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:37:38 --> Total execution time: 0.0606
DEBUG - 2022-07-03 02:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:37:45 --> Total execution time: 0.0423
DEBUG - 2022-07-03 02:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:38:01 --> Total execution time: 0.0755
DEBUG - 2022-07-03 02:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:38:29 --> Total execution time: 0.0507
DEBUG - 2022-07-03 02:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:38:43 --> Total execution time: 0.0500
DEBUG - 2022-07-03 02:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:39:05 --> Total execution time: 0.0519
DEBUG - 2022-07-03 02:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:39:29 --> Total execution time: 0.1177
DEBUG - 2022-07-03 02:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:39:46 --> Total execution time: 0.1244
DEBUG - 2022-07-03 02:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:40:13 --> Total execution time: 0.0593
DEBUG - 2022-07-03 02:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:10:32 --> Total execution time: 0.0464
DEBUG - 2022-07-03 02:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:10:58 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:40:58 --> Total execution time: 0.0448
DEBUG - 2022-07-03 02:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:10:58 --> Total execution time: 0.0463
DEBUG - 2022-07-03 02:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:41:02 --> Total execution time: 0.0375
DEBUG - 2022-07-03 02:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:11:12 --> Total execution time: 0.0506
DEBUG - 2022-07-03 02:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:41:12 --> Total execution time: 0.0492
DEBUG - 2022-07-03 02:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:11:22 --> Total execution time: 0.0508
DEBUG - 2022-07-03 02:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:11:46 --> Total execution time: 0.0534
DEBUG - 2022-07-03 02:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:11:50 --> Total execution time: 0.0474
DEBUG - 2022-07-03 02:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:11:54 --> Total execution time: 0.0515
DEBUG - 2022-07-03 02:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:11:58 --> Total execution time: 0.0715
DEBUG - 2022-07-03 02:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:12:04 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:42:04 --> Total execution time: 0.0756
DEBUG - 2022-07-03 02:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:42:19 --> Total execution time: 0.1156
DEBUG - 2022-07-03 02:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:42:25 --> Total execution time: 0.0533
DEBUG - 2022-07-03 02:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:42:46 --> Total execution time: 0.0921
DEBUG - 2022-07-03 02:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:42:59 --> Total execution time: 0.0768
DEBUG - 2022-07-03 02:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:43:13 --> Total execution time: 0.0908
DEBUG - 2022-07-03 02:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:13:52 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:43:52 --> Total execution time: 0.0504
DEBUG - 2022-07-03 02:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:44:05 --> Total execution time: 0.0399
DEBUG - 2022-07-03 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:44:45 --> Total execution time: 0.1213
DEBUG - 2022-07-03 02:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:14:51 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:44:51 --> Total execution time: 0.1148
DEBUG - 2022-07-03 02:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:44:59 --> Total execution time: 0.0394
DEBUG - 2022-07-03 02:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:45:10 --> Total execution time: 0.0522
DEBUG - 2022-07-03 02:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:15:18 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:45:18 --> Total execution time: 0.0444
DEBUG - 2022-07-03 02:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:45:25 --> Total execution time: 0.1065
DEBUG - 2022-07-03 02:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:15:31 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:45:31 --> Total execution time: 0.0494
DEBUG - 2022-07-03 02:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:45:32 --> Total execution time: 0.0539
DEBUG - 2022-07-03 02:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:45:44 --> Total execution time: 0.0742
DEBUG - 2022-07-03 02:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:16:24 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:46:24 --> Total execution time: 0.0713
DEBUG - 2022-07-03 02:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:16:26 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:46:26 --> Total execution time: 0.0555
DEBUG - 2022-07-03 02:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:46:34 --> Total execution time: 0.0540
DEBUG - 2022-07-03 02:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:47:13 --> Total execution time: 0.0636
DEBUG - 2022-07-03 02:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:47:27 --> Total execution time: 0.0666
DEBUG - 2022-07-03 02:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:47:43 --> Total execution time: 0.0494
DEBUG - 2022-07-03 02:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:47:48 --> Total execution time: 0.0538
DEBUG - 2022-07-03 02:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:48:06 --> Total execution time: 0.1029
DEBUG - 2022-07-03 02:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:48:32 --> Total execution time: 0.0576
DEBUG - 2022-07-03 02:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:48:37 --> Total execution time: 0.0570
DEBUG - 2022-07-03 02:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:18:45 --> Total execution time: 0.0523
DEBUG - 2022-07-03 02:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:18:46 --> Total execution time: 0.0819
DEBUG - 2022-07-03 02:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:18:50 --> Total execution time: 0.0981
DEBUG - 2022-07-03 02:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:18:54 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:48:54 --> Total execution time: 0.0634
DEBUG - 2022-07-03 02:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:18:56 --> Total execution time: 0.0617
DEBUG - 2022-07-03 02:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:19:03 --> Total execution time: 0.0451
DEBUG - 2022-07-03 02:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:19:07 --> Total execution time: 0.0463
DEBUG - 2022-07-03 02:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:19:11 --> Total execution time: 0.0423
DEBUG - 2022-07-03 02:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:19:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:49:11 --> Total execution time: 0.0340
DEBUG - 2022-07-03 02:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:49:14 --> Total execution time: 0.0558
DEBUG - 2022-07-03 02:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:49:22 --> Total execution time: 0.0425
DEBUG - 2022-07-03 02:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:49:36 --> Total execution time: 0.0757
DEBUG - 2022-07-03 02:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:49:55 --> Total execution time: 0.0611
DEBUG - 2022-07-03 02:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:20:37 --> Total execution time: 0.0516
DEBUG - 2022-07-03 02:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:20:44 --> Total execution time: 0.0659
DEBUG - 2022-07-03 02:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:51:17 --> Total execution time: 0.0675
DEBUG - 2022-07-03 02:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:22:01 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:52:01 --> Total execution time: 0.1299
DEBUG - 2022-07-03 02:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:22:11 --> Total execution time: 0.1005
DEBUG - 2022-07-03 02:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:22:16 --> Total execution time: 0.0741
DEBUG - 2022-07-03 02:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:52:39 --> Total execution time: 0.0625
DEBUG - 2022-07-03 02:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:52:49 --> Total execution time: 0.0898
DEBUG - 2022-07-03 02:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:22:57 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:52:57 --> Total execution time: 0.0281
DEBUG - 2022-07-03 02:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:53:00 --> Total execution time: 0.0423
DEBUG - 2022-07-03 02:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:53:20 --> Total execution time: 0.0722
DEBUG - 2022-07-03 02:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:23:39 --> Total execution time: 0.0473
DEBUG - 2022-07-03 02:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:23:43 --> Total execution time: 0.0840
DEBUG - 2022-07-03 02:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:54:05 --> Total execution time: 0.0713
DEBUG - 2022-07-03 02:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:55:02 --> Total execution time: 0.0864
DEBUG - 2022-07-03 02:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:55:03 --> Total execution time: 0.0820
DEBUG - 2022-07-03 02:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:25:15 --> Total execution time: 0.0529
DEBUG - 2022-07-03 02:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:55:16 --> Total execution time: 0.0675
DEBUG - 2022-07-03 02:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:55:18 --> Total execution time: 0.0503
DEBUG - 2022-07-03 02:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:25:19 --> Total execution time: 0.0711
DEBUG - 2022-07-03 02:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:55:44 --> Total execution time: 0.0631
DEBUG - 2022-07-03 02:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:55:56 --> Total execution time: 0.0500
DEBUG - 2022-07-03 02:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:56:02 --> Total execution time: 0.0954
DEBUG - 2022-07-03 02:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:56:07 --> Total execution time: 0.0492
DEBUG - 2022-07-03 02:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:56:27 --> Total execution time: 0.1406
DEBUG - 2022-07-03 02:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:26:36 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:56:36 --> Total execution time: 0.1133
DEBUG - 2022-07-03 02:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:56:41 --> Total execution time: 0.0978
DEBUG - 2022-07-03 02:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:57:00 --> Total execution time: 0.0620
DEBUG - 2022-07-03 02:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:57:13 --> Total execution time: 0.0557
DEBUG - 2022-07-03 02:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:57:44 --> Total execution time: 0.0486
DEBUG - 2022-07-03 02:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 02:29:27 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-03 02:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 02:29:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 02:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:29:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 02:29:29 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-03 02:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:59:36 --> Total execution time: 0.0486
DEBUG - 2022-07-03 02:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:59:38 --> Total execution time: 0.1235
DEBUG - 2022-07-03 02:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:59:45 --> Total execution time: 0.0501
DEBUG - 2022-07-03 02:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:29:46 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:59:46 --> Total execution time: 0.0493
DEBUG - 2022-07-03 02:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:59:51 --> Total execution time: 0.0587
DEBUG - 2022-07-03 02:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:59:55 --> Total execution time: 0.0577
DEBUG - 2022-07-03 02:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:59:57 --> Total execution time: 0.0525
DEBUG - 2022-07-03 02:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:59:58 --> Total execution time: 0.0564
DEBUG - 2022-07-03 02:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:00:09 --> Total execution time: 0.0495
DEBUG - 2022-07-03 02:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:00:11 --> Total execution time: 0.0468
DEBUG - 2022-07-03 02:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:00:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 02:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:00:21 --> Total execution time: 0.0591
DEBUG - 2022-07-03 02:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:00:22 --> Total execution time: 0.1504
DEBUG - 2022-07-03 02:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:00:38 --> Total execution time: 0.0547
DEBUG - 2022-07-03 02:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:00:46 --> Total execution time: 0.0545
DEBUG - 2022-07-03 02:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:00:47 --> Total execution time: 0.0533
DEBUG - 2022-07-03 02:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:00:51 --> Total execution time: 0.0536
DEBUG - 2022-07-03 02:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:31:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 02:31:04 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-03 02:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:31:08 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:01:08 --> Total execution time: 0.0735
DEBUG - 2022-07-03 02:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:31:10 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:01:10 --> Total execution time: 0.0482
DEBUG - 2022-07-03 02:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:31:16 --> Total execution time: 0.0552
DEBUG - 2022-07-03 02:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:01:19 --> Total execution time: 0.0489
DEBUG - 2022-07-03 02:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:01:19 --> Total execution time: 0.0556
DEBUG - 2022-07-03 02:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:01:21 --> Total execution time: 0.0447
DEBUG - 2022-07-03 02:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:01:30 --> Total execution time: 0.0494
DEBUG - 2022-07-03 02:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:01:32 --> Total execution time: 0.1445
DEBUG - 2022-07-03 02:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:01:33 --> Total execution time: 0.0673
DEBUG - 2022-07-03 02:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:01:34 --> Total execution time: 0.1284
DEBUG - 2022-07-03 02:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:01:40 --> Total execution time: 0.0519
DEBUG - 2022-07-03 02:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:01:48 --> Total execution time: 0.0509
DEBUG - 2022-07-03 02:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:01:56 --> Total execution time: 0.0505
DEBUG - 2022-07-03 02:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:02:12 --> Total execution time: 0.0592
DEBUG - 2022-07-03 02:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:02:15 --> Total execution time: 0.0583
DEBUG - 2022-07-03 02:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:32:17 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:02:17 --> Total execution time: 0.1581
DEBUG - 2022-07-03 02:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:32:53 --> Total execution time: 0.0501
DEBUG - 2022-07-03 02:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:32:57 --> Total execution time: 0.0718
DEBUG - 2022-07-03 02:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:03:10 --> Total execution time: 0.0753
DEBUG - 2022-07-03 02:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:03:25 --> Total execution time: 0.0735
DEBUG - 2022-07-03 02:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:03:33 --> Total execution time: 0.0531
DEBUG - 2022-07-03 02:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:03:38 --> Total execution time: 0.0515
DEBUG - 2022-07-03 02:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:03:44 --> Total execution time: 0.0741
DEBUG - 2022-07-03 02:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:03:59 --> Total execution time: 0.0663
DEBUG - 2022-07-03 02:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:34:42 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:04:42 --> Total execution time: 0.0582
DEBUG - 2022-07-03 02:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:04:53 --> Total execution time: 0.0494
DEBUG - 2022-07-03 02:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:05:10 --> Total execution time: 0.0704
DEBUG - 2022-07-03 02:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:05:39 --> Total execution time: 0.0521
DEBUG - 2022-07-03 02:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:05:44 --> Total execution time: 0.0675
DEBUG - 2022-07-03 02:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:05:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 02:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:05:45 --> Total execution time: 0.0510
DEBUG - 2022-07-03 02:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:36:22 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:06:22 --> Total execution time: 0.0440
DEBUG - 2022-07-03 02:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:06:26 --> Total execution time: 0.0321
DEBUG - 2022-07-03 02:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:06:31 --> Total execution time: 0.0578
DEBUG - 2022-07-03 02:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:06:34 --> Total execution time: 0.0712
DEBUG - 2022-07-03 02:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:06:47 --> Total execution time: 0.0860
DEBUG - 2022-07-03 02:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:07:01 --> Total execution time: 0.1676
DEBUG - 2022-07-03 02:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:37:15 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:07:16 --> Total execution time: 0.0354
DEBUG - 2022-07-03 02:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:37:43 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:07:43 --> Total execution time: 0.1139
DEBUG - 2022-07-03 02:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:07:50 --> Total execution time: 0.0323
DEBUG - 2022-07-03 02:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:08:12 --> Total execution time: 0.0501
DEBUG - 2022-07-03 02:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:08:21 --> Total execution time: 0.0614
DEBUG - 2022-07-03 02:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:08:30 --> Total execution time: 0.0602
DEBUG - 2022-07-03 02:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:38:33 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:08:33 --> Total execution time: 0.0536
DEBUG - 2022-07-03 02:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:38:54 --> Total execution time: 0.0490
DEBUG - 2022-07-03 02:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:38:55 --> Total execution time: 0.0508
DEBUG - 2022-07-03 02:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:38:55 --> Total execution time: 0.0989
DEBUG - 2022-07-03 02:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:39:55 --> Total execution time: 0.1256
DEBUG - 2022-07-03 02:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:39:57 --> Total execution time: 0.0564
DEBUG - 2022-07-03 02:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:39:57 --> Total execution time: 0.0997
DEBUG - 2022-07-03 02:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:10:03 --> Total execution time: 0.0509
DEBUG - 2022-07-03 02:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:40:05 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:10:05 --> Total execution time: 0.0335
DEBUG - 2022-07-03 02:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:10:17 --> Total execution time: 0.0632
DEBUG - 2022-07-03 02:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:10:28 --> Total execution time: 0.1673
DEBUG - 2022-07-03 02:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:10:50 --> Total execution time: 0.0568
DEBUG - 2022-07-03 02:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:10:50 --> Total execution time: 0.1626
DEBUG - 2022-07-03 02:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:10:53 --> Total execution time: 0.0708
DEBUG - 2022-07-03 02:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:10:57 --> Total execution time: 0.1055
DEBUG - 2022-07-03 02:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:10:58 --> Total execution time: 0.0703
DEBUG - 2022-07-03 02:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:11:07 --> Total execution time: 0.0659
DEBUG - 2022-07-03 02:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:11:34 --> Total execution time: 0.0603
DEBUG - 2022-07-03 02:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:11:38 --> Total execution time: 0.0598
DEBUG - 2022-07-03 02:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:11:39 --> Total execution time: 0.0722
DEBUG - 2022-07-03 02:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:11:40 --> Total execution time: 0.0673
DEBUG - 2022-07-03 02:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:11:40 --> Total execution time: 0.0836
DEBUG - 2022-07-03 02:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:11:40 --> Total execution time: 0.0932
DEBUG - 2022-07-03 02:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:11:41 --> Total execution time: 0.0678
DEBUG - 2022-07-03 02:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:11:57 --> Total execution time: 0.0680
DEBUG - 2022-07-03 02:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:12:03 --> Total execution time: 0.0974
DEBUG - 2022-07-03 02:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:12:06 --> Total execution time: 0.0471
DEBUG - 2022-07-03 02:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:12:11 --> Total execution time: 0.0508
DEBUG - 2022-07-03 02:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:42:12 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:12:12 --> Total execution time: 0.0390
DEBUG - 2022-07-03 02:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:12:20 --> Total execution time: 0.0629
DEBUG - 2022-07-03 02:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:12:25 --> Total execution time: 0.0647
DEBUG - 2022-07-03 02:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:12:34 --> Total execution time: 0.0533
DEBUG - 2022-07-03 02:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:12:50 --> Total execution time: 0.0596
DEBUG - 2022-07-03 02:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:15:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 02:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:15:41 --> Total execution time: 0.0584
DEBUG - 2022-07-03 02:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:15:52 --> Total execution time: 0.1473
DEBUG - 2022-07-03 02:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:16:01 --> Total execution time: 0.0570
DEBUG - 2022-07-03 02:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:16:05 --> Total execution time: 0.0721
DEBUG - 2022-07-03 02:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:16:13 --> Total execution time: 0.0611
DEBUG - 2022-07-03 02:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:16:16 --> Total execution time: 0.0721
DEBUG - 2022-07-03 02:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:16:24 --> Total execution time: 0.0542
DEBUG - 2022-07-03 02:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:47:27 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:17:27 --> Total execution time: 0.0553
DEBUG - 2022-07-03 02:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 02:47:28 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-03 02:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:18:45 --> Total execution time: 0.1276
DEBUG - 2022-07-03 02:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:18:48 --> Total execution time: 0.0722
DEBUG - 2022-07-03 02:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:18:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 02:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:18:49 --> Total execution time: 0.0554
DEBUG - 2022-07-03 02:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:48:52 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:18:52 --> Total execution time: 0.0500
DEBUG - 2022-07-03 02:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:19:09 --> Total execution time: 0.0476
DEBUG - 2022-07-03 02:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:19:14 --> Total execution time: 1.5303
DEBUG - 2022-07-03 02:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:49:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 02:49:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:19:20 --> Total execution time: 0.0721
DEBUG - 2022-07-03 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:49:26 --> No URI present. Default controller set.
DEBUG - 2022-07-03 02:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:19:26 --> Total execution time: 0.0516
DEBUG - 2022-07-03 02:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:19:39 --> Total execution time: 0.0660
DEBUG - 2022-07-03 02:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:19:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 02:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:19:40 --> Total execution time: 0.0465
DEBUG - 2022-07-03 02:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:19:59 --> Total execution time: 0.0528
DEBUG - 2022-07-03 02:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:20:08 --> Total execution time: 0.0812
DEBUG - 2022-07-03 02:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:20:17 --> Total execution time: 0.0467
DEBUG - 2022-07-03 02:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:20:18 --> Total execution time: 0.0782
DEBUG - 2022-07-03 02:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:20:19 --> Total execution time: 0.0495
DEBUG - 2022-07-03 02:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:20:20 --> Total execution time: 0.0526
DEBUG - 2022-07-03 02:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:20:27 --> Total execution time: 0.0517
DEBUG - 2022-07-03 02:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:20:34 --> Total execution time: 0.0522
DEBUG - 2022-07-03 02:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:50:44 --> Total execution time: 0.0475
DEBUG - 2022-07-03 02:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:50:45 --> Total execution time: 0.0675
DEBUG - 2022-07-03 02:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:50:45 --> Total execution time: 0.0991
DEBUG - 2022-07-03 02:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:20:53 --> Total execution time: 0.0648
DEBUG - 2022-07-03 02:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:20:58 --> Total execution time: 0.0569
DEBUG - 2022-07-03 02:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 02:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:21:15 --> Total execution time: 0.0478
DEBUG - 2022-07-03 02:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 02:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 02:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:24:21 --> Total execution time: 0.2042
DEBUG - 2022-07-03 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:30:02 --> Total execution time: 0.2306
DEBUG - 2022-07-03 03:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:00:14 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:30:14 --> Total execution time: 0.0466
DEBUG - 2022-07-03 03:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:00:14 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:30:14 --> Total execution time: 0.0422
DEBUG - 2022-07-03 03:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:30:24 --> Total execution time: 0.0291
DEBUG - 2022-07-03 03:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:30:31 --> Total execution time: 0.0525
DEBUG - 2022-07-03 03:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:01:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 03:01:36 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-03 03:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:03:48 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:33:48 --> Total execution time: 0.1657
DEBUG - 2022-07-03 03:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:03:50 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:33:50 --> Total execution time: 0.0502
DEBUG - 2022-07-03 03:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:33:52 --> Total execution time: 0.0602
DEBUG - 2022-07-03 03:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:33:57 --> Total execution time: 0.1034
DEBUG - 2022-07-03 03:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 03:04:04 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 03:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 03:04:08 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-03 03:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:34:52 --> Total execution time: 0.0315
DEBUG - 2022-07-03 03:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:05:11 --> Total execution time: 0.0330
DEBUG - 2022-07-03 03:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:05:28 --> Total execution time: 0.0399
DEBUG - 2022-07-03 03:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:05:44 --> Total execution time: 0.0395
DEBUG - 2022-07-03 03:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:06:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 03:06:02 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-03 03:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:06:05 --> Total execution time: 0.0469
DEBUG - 2022-07-03 03:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:06:26 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:36:26 --> Total execution time: 0.0690
DEBUG - 2022-07-03 03:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:06:32 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:36:32 --> Total execution time: 0.0473
DEBUG - 2022-07-03 03:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:37:17 --> Total execution time: 0.0469
DEBUG - 2022-07-03 03:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:38:02 --> Total execution time: 0.0510
DEBUG - 2022-07-03 03:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:38:20 --> Total execution time: 0.0481
DEBUG - 2022-07-03 03:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:38:24 --> Total execution time: 0.0495
DEBUG - 2022-07-03 03:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:38:34 --> Total execution time: 0.0663
DEBUG - 2022-07-03 03:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:38:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 03:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:38:36 --> Total execution time: 0.0551
DEBUG - 2022-07-03 03:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:39:48 --> Total execution time: 0.0322
DEBUG - 2022-07-03 03:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:10:02 --> Total execution time: 0.0459
DEBUG - 2022-07-03 03:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:40:09 --> Total execution time: 0.0468
DEBUG - 2022-07-03 03:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:40:09 --> Total execution time: 0.0528
DEBUG - 2022-07-03 03:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:40:16 --> Total execution time: 0.0800
DEBUG - 2022-07-03 03:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:40:17 --> Total execution time: 0.1225
DEBUG - 2022-07-03 03:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:40:19 --> Total execution time: 0.1214
DEBUG - 2022-07-03 03:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:10:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 03:10:25 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 03:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:40:25 --> Total execution time: 0.0664
DEBUG - 2022-07-03 03:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:40:25 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 03:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:40:26 --> Total execution time: 0.0487
DEBUG - 2022-07-03 03:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 03:10:26 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 03:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:10:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 03:10:29 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 03:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:40:35 --> Total execution time: 0.0710
DEBUG - 2022-07-03 03:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:40:40 --> Total execution time: 0.0800
DEBUG - 2022-07-03 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:11:22 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:41:22 --> Total execution time: 0.0507
DEBUG - 2022-07-03 03:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:41:30 --> Total execution time: 0.0412
DEBUG - 2022-07-03 03:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:41:42 --> Total execution time: 0.0485
DEBUG - 2022-07-03 03:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:41:43 --> Total execution time: 0.1811
DEBUG - 2022-07-03 03:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:41:45 --> Total execution time: 0.0456
DEBUG - 2022-07-03 03:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:41:59 --> Total execution time: 0.0544
DEBUG - 2022-07-03 03:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:42:04 --> Total execution time: 0.0529
DEBUG - 2022-07-03 03:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:42:25 --> Total execution time: 0.0493
DEBUG - 2022-07-03 03:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:42:38 --> Total execution time: 0.0542
DEBUG - 2022-07-03 03:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:42:42 --> Total execution time: 0.0831
DEBUG - 2022-07-03 03:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:42:50 --> Total execution time: 0.0595
DEBUG - 2022-07-03 03:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:42:55 --> Total execution time: 0.0934
DEBUG - 2022-07-03 03:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:43:05 --> Total execution time: 0.0637
DEBUG - 2022-07-03 03:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:13:17 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:43:17 --> Total execution time: 0.0401
DEBUG - 2022-07-03 03:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:13:18 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:43:18 --> Total execution time: 0.0470
DEBUG - 2022-07-03 03:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:43:22 --> Total execution time: 0.0310
DEBUG - 2022-07-03 03:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:43:37 --> Total execution time: 0.0681
DEBUG - 2022-07-03 03:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:13:40 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:43:40 --> Total execution time: 0.0437
DEBUG - 2022-07-03 03:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:43:41 --> Total execution time: 0.0699
DEBUG - 2022-07-03 03:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:43:42 --> Total execution time: 0.0493
DEBUG - 2022-07-03 03:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:43:43 --> Total execution time: 0.0662
DEBUG - 2022-07-03 03:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:44:09 --> Total execution time: 0.0514
DEBUG - 2022-07-03 03:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:44:11 --> Total execution time: 0.0501
DEBUG - 2022-07-03 03:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:44:22 --> Total execution time: 0.0656
DEBUG - 2022-07-03 03:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:44:35 --> Total execution time: 0.0740
DEBUG - 2022-07-03 03:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:44:45 --> Total execution time: 0.0542
DEBUG - 2022-07-03 03:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:44:46 --> Total execution time: 0.0463
DEBUG - 2022-07-03 03:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:44:49 --> Total execution time: 0.0572
DEBUG - 2022-07-03 03:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:15:17 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:45:17 --> Total execution time: 0.0560
DEBUG - 2022-07-03 03:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:45:32 --> Total execution time: 0.1668
DEBUG - 2022-07-03 03:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:45:37 --> Total execution time: 0.0485
DEBUG - 2022-07-03 03:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:45:44 --> Total execution time: 0.0522
DEBUG - 2022-07-03 03:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:45:54 --> Total execution time: 0.0537
DEBUG - 2022-07-03 03:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:45:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 03:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:45:55 --> Total execution time: 0.0841
DEBUG - 2022-07-03 03:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:46:28 --> Total execution time: 0.0482
DEBUG - 2022-07-03 03:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:16:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 03:16:38 --> 404 Page Not Found: My-account/index
DEBUG - 2022-07-03 03:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:16:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 03:16:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 03:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:46:41 --> Total execution time: 0.0537
DEBUG - 2022-07-03 03:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:16:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 03:16:43 --> 404 Page Not Found: My-account/index
DEBUG - 2022-07-03 03:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:46:44 --> Total execution time: 0.0731
DEBUG - 2022-07-03 03:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:16:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 03:16:49 --> 404 Page Not Found: My-account/index
DEBUG - 2022-07-03 03:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:46:52 --> Total execution time: 0.0517
DEBUG - 2022-07-03 03:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:46:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 03:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:46:53 --> Total execution time: 0.0611
DEBUG - 2022-07-03 03:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:47:29 --> Total execution time: 0.0564
DEBUG - 2022-07-03 03:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:17:33 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:47:33 --> Total execution time: 0.0627
DEBUG - 2022-07-03 03:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:47:33 --> Total execution time: 0.0627
DEBUG - 2022-07-03 03:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:48:29 --> Total execution time: 0.1171
DEBUG - 2022-07-03 03:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:48:48 --> Total execution time: 0.1334
DEBUG - 2022-07-03 03:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:48:52 --> Total execution time: 0.0626
DEBUG - 2022-07-03 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:49:00 --> Total execution time: 0.0425
DEBUG - 2022-07-03 03:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:49:21 --> Total execution time: 0.0565
DEBUG - 2022-07-03 03:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:49:23 --> Total execution time: 0.0592
DEBUG - 2022-07-03 03:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:49:26 --> Total execution time: 0.0526
DEBUG - 2022-07-03 03:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:51:41 --> Total execution time: 0.2051
DEBUG - 2022-07-03 03:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:51:42 --> Total execution time: 0.0734
DEBUG - 2022-07-03 03:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:51:49 --> Total execution time: 0.0696
DEBUG - 2022-07-03 03:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:51:52 --> Total execution time: 0.0923
DEBUG - 2022-07-03 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:52:49 --> Total execution time: 0.0563
DEBUG - 2022-07-03 03:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:52:52 --> Total execution time: 0.0461
DEBUG - 2022-07-03 03:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:53:10 --> Total execution time: 0.0539
DEBUG - 2022-07-03 03:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:53:21 --> Total execution time: 0.0731
DEBUG - 2022-07-03 03:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:53:51 --> Total execution time: 0.0683
DEBUG - 2022-07-03 03:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:54:07 --> Total execution time: 0.0889
DEBUG - 2022-07-03 03:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:54:35 --> Total execution time: 0.0558
DEBUG - 2022-07-03 03:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:54:43 --> Total execution time: 0.0976
DEBUG - 2022-07-03 03:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:55:37 --> Total execution time: 0.1003
DEBUG - 2022-07-03 03:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:55:52 --> Total execution time: 0.0545
DEBUG - 2022-07-03 03:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:55:53 --> Total execution time: 0.0358
DEBUG - 2022-07-03 03:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:55:55 --> Total execution time: 0.0505
DEBUG - 2022-07-03 03:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:55:57 --> Total execution time: 0.0663
DEBUG - 2022-07-03 03:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:56:12 --> Total execution time: 0.0623
DEBUG - 2022-07-03 03:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:56:49 --> Total execution time: 0.0635
DEBUG - 2022-07-03 03:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:57:18 --> Total execution time: 0.0977
DEBUG - 2022-07-03 03:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:57:47 --> Total execution time: 0.0672
DEBUG - 2022-07-03 03:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:57:53 --> Total execution time: 0.1195
DEBUG - 2022-07-03 03:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:57:56 --> Total execution time: 0.0531
DEBUG - 2022-07-03 03:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:57:58 --> Total execution time: 0.0510
DEBUG - 2022-07-03 03:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:58:01 --> Total execution time: 0.0651
DEBUG - 2022-07-03 03:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:58:05 --> Total execution time: 0.0943
DEBUG - 2022-07-03 03:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:58:13 --> Total execution time: 0.0256
DEBUG - 2022-07-03 03:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:58:22 --> Total execution time: 0.0469
DEBUG - 2022-07-03 03:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:58:25 --> Total execution time: 0.0685
DEBUG - 2022-07-03 03:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:28:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 03:28:34 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-03 03:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:58:55 --> Total execution time: 0.1012
DEBUG - 2022-07-03 03:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:00:06 --> Total execution time: 0.0707
DEBUG - 2022-07-03 03:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:00:07 --> Total execution time: 0.0497
DEBUG - 2022-07-03 03:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:00:10 --> Total execution time: 0.0794
DEBUG - 2022-07-03 03:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:00:41 --> Total execution time: 0.0693
DEBUG - 2022-07-03 03:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:00:53 --> Total execution time: 0.0776
DEBUG - 2022-07-03 03:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:00:59 --> Total execution time: 0.0529
DEBUG - 2022-07-03 03:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:01:01 --> Total execution time: 0.0492
DEBUG - 2022-07-03 03:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:31:05 --> Total execution time: 0.0503
DEBUG - 2022-07-03 03:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:01:10 --> Total execution time: 0.0493
DEBUG - 2022-07-03 03:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:01:31 --> Total execution time: 0.0529
DEBUG - 2022-07-03 03:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:01:40 --> Total execution time: 0.0518
DEBUG - 2022-07-03 03:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:01:55 --> Total execution time: 0.0544
DEBUG - 2022-07-03 03:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:02:09 --> Total execution time: 0.0570
DEBUG - 2022-07-03 03:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:02:22 --> Total execution time: 0.1199
DEBUG - 2022-07-03 03:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:33:21 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:03:21 --> Total execution time: 0.0382
DEBUG - 2022-07-03 03:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:03:58 --> Total execution time: 0.0322
DEBUG - 2022-07-03 03:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:05:40 --> Total execution time: 0.0737
DEBUG - 2022-07-03 03:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:06:10 --> Total execution time: 0.0629
DEBUG - 2022-07-03 03:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:06:15 --> Total execution time: 0.0650
DEBUG - 2022-07-03 03:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:06:31 --> Total execution time: 0.0653
DEBUG - 2022-07-03 03:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:06:32 --> Total execution time: 0.0498
DEBUG - 2022-07-03 03:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:06:34 --> Total execution time: 0.0507
DEBUG - 2022-07-03 03:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:36:35 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:06:35 --> Total execution time: 0.0490
DEBUG - 2022-07-03 03:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:38:28 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:08:28 --> Total execution time: 0.1151
DEBUG - 2022-07-03 03:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:08:28 --> Total execution time: 0.1506
DEBUG - 2022-07-03 03:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:08:44 --> Total execution time: 0.1302
DEBUG - 2022-07-03 03:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:08:50 --> Total execution time: 0.0676
DEBUG - 2022-07-03 03:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:09:18 --> Total execution time: 0.0846
DEBUG - 2022-07-03 03:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:09:25 --> Total execution time: 0.0712
DEBUG - 2022-07-03 03:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:09:32 --> Total execution time: 0.0610
DEBUG - 2022-07-03 03:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:09:40 --> Total execution time: 0.0496
DEBUG - 2022-07-03 03:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:09:43 --> Total execution time: 0.1717
DEBUG - 2022-07-03 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:09:50 --> Total execution time: 0.0686
DEBUG - 2022-07-03 03:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:09:51 --> Total execution time: 0.0894
DEBUG - 2022-07-03 03:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:09:55 --> Total execution time: 0.1013
DEBUG - 2022-07-03 03:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:10:28 --> Total execution time: 0.0793
DEBUG - 2022-07-03 03:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:41:04 --> Total execution time: 0.0546
DEBUG - 2022-07-03 03:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:41:06 --> Total execution time: 0.1111
DEBUG - 2022-07-03 03:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:11:14 --> Total execution time: 0.0553
DEBUG - 2022-07-03 03:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:11:43 --> Total execution time: 0.1128
DEBUG - 2022-07-03 03:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:42:20 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:12:20 --> Total execution time: 0.0444
DEBUG - 2022-07-03 03:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:12:27 --> Total execution time: 0.0640
DEBUG - 2022-07-03 03:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:12:33 --> Total execution time: 0.0506
DEBUG - 2022-07-03 03:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:12:45 --> Total execution time: 0.0619
DEBUG - 2022-07-03 03:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:12:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 03:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:12:46 --> Total execution time: 0.0474
DEBUG - 2022-07-03 03:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:12:56 --> Total execution time: 0.0628
DEBUG - 2022-07-03 03:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:13:15 --> Total execution time: 0.0458
DEBUG - 2022-07-03 03:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:13:17 --> Total execution time: 0.0606
DEBUG - 2022-07-03 03:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:13:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 03:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:13:18 --> Total execution time: 0.0465
DEBUG - 2022-07-03 03:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:13:46 --> Total execution time: 0.0506
DEBUG - 2022-07-03 03:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:13:49 --> Total execution time: 0.0501
DEBUG - 2022-07-03 03:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:13:52 --> Total execution time: 0.0638
DEBUG - 2022-07-03 03:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:14:00 --> Total execution time: 0.0597
DEBUG - 2022-07-03 03:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:14:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 03:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:14:01 --> Total execution time: 0.0467
DEBUG - 2022-07-03 03:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:18:01 --> Total execution time: 0.2014
DEBUG - 2022-07-03 03:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:18:05 --> Total execution time: 0.0474
DEBUG - 2022-07-03 03:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:18:08 --> Total execution time: 0.0509
DEBUG - 2022-07-03 03:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:18:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 03:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:18:09 --> Total execution time: 0.0405
DEBUG - 2022-07-03 03:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:48:27 --> Total execution time: 0.0607
DEBUG - 2022-07-03 03:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:48:30 --> Total execution time: 0.0509
DEBUG - 2022-07-03 03:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:48:41 --> Total execution time: 0.0729
DEBUG - 2022-07-03 03:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:02 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:19:02 --> Total execution time: 0.0353
DEBUG - 2022-07-03 03:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:19:10 --> Total execution time: 0.0526
DEBUG - 2022-07-03 03:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:19:16 --> Total execution time: 0.0631
DEBUG - 2022-07-03 03:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:19:18 --> Total execution time: 0.0423
DEBUG - 2022-07-03 03:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:19:23 --> Total execution time: 0.0510
DEBUG - 2022-07-03 03:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:19:24 --> Total execution time: 0.0531
DEBUG - 2022-07-03 03:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:19:28 --> Total execution time: 0.0899
DEBUG - 2022-07-03 03:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:19:33 --> Total execution time: 0.0452
DEBUG - 2022-07-03 03:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:19:38 --> Total execution time: 0.0458
DEBUG - 2022-07-03 03:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:19:41 --> Total execution time: 0.0510
DEBUG - 2022-07-03 03:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:19:45 --> Total execution time: 0.0568
DEBUG - 2022-07-03 03:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:19:59 --> Total execution time: 0.0545
DEBUG - 2022-07-03 03:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:20:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 03:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:20:00 --> Total execution time: 0.0457
DEBUG - 2022-07-03 03:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:20:03 --> Total execution time: 0.0461
DEBUG - 2022-07-03 03:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:20:06 --> Total execution time: 0.0511
DEBUG - 2022-07-03 03:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:20:12 --> Total execution time: 0.0515
DEBUG - 2022-07-03 03:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:20:18 --> Total execution time: 0.0555
DEBUG - 2022-07-03 03:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:20:21 --> Total execution time: 0.0601
DEBUG - 2022-07-03 03:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:20:35 --> Total execution time: 0.0591
DEBUG - 2022-07-03 03:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:22:43 --> Total execution time: 0.1388
DEBUG - 2022-07-03 03:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:52:50 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:22:50 --> Total execution time: 0.0373
DEBUG - 2022-07-03 03:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:52:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:22:54 --> Total execution time: 0.0341
DEBUG - 2022-07-03 03:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:55:50 --> No URI present. Default controller set.
DEBUG - 2022-07-03 03:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:25:50 --> Total execution time: 0.1118
DEBUG - 2022-07-03 03:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:56:07 --> Total execution time: 0.0573
DEBUG - 2022-07-03 03:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:56:09 --> Total execution time: 0.0481
DEBUG - 2022-07-03 03:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:56:09 --> Total execution time: 0.0948
DEBUG - 2022-07-03 03:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:26:26 --> Total execution time: 0.0477
DEBUG - 2022-07-03 03:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:26:33 --> Total execution time: 0.0547
DEBUG - 2022-07-03 03:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:26:38 --> Total execution time: 0.0559
DEBUG - 2022-07-03 03:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:26:45 --> Total execution time: 0.0707
DEBUG - 2022-07-03 03:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:26:49 --> Total execution time: 0.0522
DEBUG - 2022-07-03 03:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:26:52 --> Total execution time: 0.0567
DEBUG - 2022-07-03 03:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:27:01 --> Total execution time: 0.0897
DEBUG - 2022-07-03 03:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:27:14 --> Total execution time: 0.0527
DEBUG - 2022-07-03 03:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:27:18 --> Total execution time: 0.0508
DEBUG - 2022-07-03 03:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:58:04 --> Total execution time: 0.0438
DEBUG - 2022-07-03 03:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:58:05 --> Total execution time: 0.0639
DEBUG - 2022-07-03 03:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:58:05 --> Total execution time: 0.1158
DEBUG - 2022-07-03 03:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:59:02 --> Total execution time: 0.0465
DEBUG - 2022-07-03 03:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:59:04 --> Total execution time: 0.0681
DEBUG - 2022-07-03 03:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:59:04 --> Total execution time: 0.1157
DEBUG - 2022-07-03 03:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:29:31 --> Total execution time: 0.0596
DEBUG - 2022-07-03 03:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 03:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 03:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 03:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:29:47 --> Total execution time: 0.0728
DEBUG - 2022-07-03 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:30:02 --> Total execution time: 0.0521
DEBUG - 2022-07-03 04:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:30:14 --> Total execution time: 0.0591
DEBUG - 2022-07-03 04:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:30:37 --> Total execution time: 0.0550
DEBUG - 2022-07-03 04:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:30:54 --> Total execution time: 0.0511
DEBUG - 2022-07-03 04:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:30:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 04:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:30:55 --> Total execution time: 0.0588
DEBUG - 2022-07-03 04:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:31:28 --> Total execution time: 0.1479
DEBUG - 2022-07-03 04:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:03:06 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:33:06 --> Total execution time: 0.0338
DEBUG - 2022-07-03 04:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:03:06 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:33:06 --> Total execution time: 0.0285
DEBUG - 2022-07-03 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:33:23 --> Total execution time: 0.0308
DEBUG - 2022-07-03 04:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:33:51 --> Total execution time: 0.0518
DEBUG - 2022-07-03 04:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:33:59 --> Total execution time: 0.2267
DEBUG - 2022-07-03 04:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:34:13 --> Total execution time: 0.0531
DEBUG - 2022-07-03 04:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:04:25 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:34:25 --> Total execution time: 0.0356
DEBUG - 2022-07-03 04:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:34:35 --> Total execution time: 0.0463
DEBUG - 2022-07-03 04:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:04:36 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:34:36 --> Total execution time: 0.0655
DEBUG - 2022-07-03 04:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:34:43 --> Total execution time: 0.0603
DEBUG - 2022-07-03 04:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:34:50 --> Total execution time: 0.0649
DEBUG - 2022-07-03 04:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:34:51 --> Total execution time: 0.0459
DEBUG - 2022-07-03 04:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:04:57 --> Total execution time: 0.0618
DEBUG - 2022-07-03 04:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:05:08 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:35:08 --> Total execution time: 0.0355
DEBUG - 2022-07-03 04:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:05:09 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:35:09 --> Total execution time: 0.0524
DEBUG - 2022-07-03 04:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:05:11 --> Total execution time: 0.0528
DEBUG - 2022-07-03 04:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:05:11 --> Total execution time: 0.1176
DEBUG - 2022-07-03 04:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:35:12 --> Total execution time: 0.0466
DEBUG - 2022-07-03 04:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:35:12 --> Total execution time: 0.0515
DEBUG - 2022-07-03 04:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:35:16 --> Total execution time: 0.0477
DEBUG - 2022-07-03 04:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:35:21 --> Total execution time: 0.0809
DEBUG - 2022-07-03 04:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:35:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 04:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:35:22 --> Total execution time: 0.0482
DEBUG - 2022-07-03 04:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:05:24 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:35:24 --> Total execution time: 0.0526
DEBUG - 2022-07-03 04:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:35:32 --> Total execution time: 0.0552
DEBUG - 2022-07-03 04:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:06:17 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:36:17 --> Total execution time: 0.0427
DEBUG - 2022-07-03 04:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:36:20 --> Total execution time: 0.0691
DEBUG - 2022-07-03 04:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:06:27 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:36:27 --> Total execution time: 0.0543
DEBUG - 2022-07-03 04:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:06:34 --> Total execution time: 0.0729
DEBUG - 2022-07-03 04:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:06:36 --> Total execution time: 0.0549
DEBUG - 2022-07-03 04:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:06:36 --> Total execution time: 0.1112
DEBUG - 2022-07-03 04:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:06:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 04:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:36:40 --> Total execution time: 1.4915
DEBUG - 2022-07-03 04:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:06:47 --> Total execution time: 0.0523
DEBUG - 2022-07-03 04:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:06:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 04:06:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 04:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:07:06 --> Total execution time: 0.0450
DEBUG - 2022-07-03 04:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:07:21 --> Total execution time: 0.0595
DEBUG - 2022-07-03 04:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:07:21 --> Total execution time: 0.1552
DEBUG - 2022-07-03 04:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:07:34 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:37:34 --> Total execution time: 0.0484
DEBUG - 2022-07-03 04:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:07:48 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:37:48 --> Total execution time: 0.0509
DEBUG - 2022-07-03 04:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:37:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 04:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:37:56 --> Total execution time: 0.0703
DEBUG - 2022-07-03 04:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:37:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 14:37:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 14:37:58 --> Total execution time: 0.1998
DEBUG - 2022-07-03 04:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:38:14 --> Total execution time: 0.0656
DEBUG - 2022-07-03 04:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:38:14 --> Total execution time: 0.0584
DEBUG - 2022-07-03 04:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:38:31 --> Total execution time: 0.0444
DEBUG - 2022-07-03 04:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:38:32 --> Total execution time: 0.0450
DEBUG - 2022-07-03 04:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:38:54 --> Total execution time: 0.0455
DEBUG - 2022-07-03 04:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:38:55 --> Total execution time: 0.0436
DEBUG - 2022-07-03 04:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:09:03 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:39:03 --> Total execution time: 0.0467
DEBUG - 2022-07-03 04:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:39:12 --> Total execution time: 0.0494
DEBUG - 2022-07-03 04:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:39:17 --> Total execution time: 0.0508
DEBUG - 2022-07-03 04:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:39:20 --> Total execution time: 0.0567
DEBUG - 2022-07-03 04:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:09:21 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:39:21 --> Total execution time: 0.1208
DEBUG - 2022-07-03 04:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:39:32 --> Total execution time: 0.0601
DEBUG - 2022-07-03 04:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:39:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 04:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:39:33 --> Total execution time: 0.0471
DEBUG - 2022-07-03 04:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:39:45 --> Total execution time: 0.0576
DEBUG - 2022-07-03 04:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:09:46 --> Total execution time: 0.0518
DEBUG - 2022-07-03 04:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:09:47 --> Total execution time: 0.0560
DEBUG - 2022-07-03 04:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:09:47 --> Total execution time: 0.1047
DEBUG - 2022-07-03 04:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:39:57 --> Total execution time: 0.0617
DEBUG - 2022-07-03 04:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:40:12 --> Total execution time: 0.0730
DEBUG - 2022-07-03 04:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:10:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 04:10:19 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-03 04:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:11:17 --> Total execution time: 0.0459
DEBUG - 2022-07-03 04:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:11:18 --> Total execution time: 0.0566
DEBUG - 2022-07-03 04:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:11:18 --> Total execution time: 0.1052
DEBUG - 2022-07-03 04:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:11:55 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:41:55 --> Total execution time: 0.0712
DEBUG - 2022-07-03 04:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:12:02 --> Total execution time: 0.0551
DEBUG - 2022-07-03 04:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:12:03 --> Total execution time: 0.0481
DEBUG - 2022-07-03 04:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:12:03 --> Total execution time: 0.0932
DEBUG - 2022-07-03 04:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:12:57 --> Total execution time: 0.0503
DEBUG - 2022-07-03 04:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:12:58 --> Total execution time: 0.0512
DEBUG - 2022-07-03 04:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:12:58 --> Total execution time: 0.0814
DEBUG - 2022-07-03 04:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:43:09 --> Total execution time: 0.0585
DEBUG - 2022-07-03 04:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:43:31 --> Total execution time: 0.0468
DEBUG - 2022-07-03 04:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:43:42 --> Total execution time: 0.0506
DEBUG - 2022-07-03 04:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:44:21 --> Total execution time: 0.1241
DEBUG - 2022-07-03 04:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:44:28 --> Total execution time: 0.0482
DEBUG - 2022-07-03 04:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:44:39 --> Total execution time: 0.0546
DEBUG - 2022-07-03 04:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:44:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 04:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:44:40 --> Total execution time: 0.0477
DEBUG - 2022-07-03 04:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:44:46 --> Total execution time: 0.0576
DEBUG - 2022-07-03 04:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:44:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 04:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:44:47 --> Total execution time: 0.0488
DEBUG - 2022-07-03 04:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:44:58 --> Total execution time: 0.0723
DEBUG - 2022-07-03 04:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:45:03 --> Total execution time: 0.0544
DEBUG - 2022-07-03 04:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:45:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 04:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:45:04 --> Total execution time: 0.0492
DEBUG - 2022-07-03 04:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:45:45 --> Total execution time: 0.1183
DEBUG - 2022-07-03 04:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:46:59 --> Total execution time: 0.0566
DEBUG - 2022-07-03 04:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:47:02 --> Total execution time: 0.0594
DEBUG - 2022-07-03 04:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:47:04 --> Total execution time: 0.0567
DEBUG - 2022-07-03 04:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 04:17:14 --> 404 Page Not Found: Wp-admin/edit.php
DEBUG - 2022-07-03 04:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 04:17:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 04:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:47:15 --> Total execution time: 0.0781
DEBUG - 2022-07-03 04:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 04:17:17 --> 404 Page Not Found: Wp-admin/edit.php
DEBUG - 2022-07-03 04:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:47:23 --> Total execution time: 0.0749
DEBUG - 2022-07-03 04:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:17:27 --> Total execution time: 0.0525
DEBUG - 2022-07-03 04:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:47:31 --> Total execution time: 0.0517
DEBUG - 2022-07-03 04:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:47:34 --> Total execution time: 0.0766
DEBUG - 2022-07-03 04:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:47:35 --> Total execution time: 0.0816
DEBUG - 2022-07-03 04:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:47:37 --> Total execution time: 0.0670
DEBUG - 2022-07-03 04:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:47:41 --> Total execution time: 0.0731
DEBUG - 2022-07-03 04:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:47:43 --> Total execution time: 0.0928
DEBUG - 2022-07-03 04:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:47:48 --> Total execution time: 0.0815
DEBUG - 2022-07-03 04:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:47:55 --> Total execution time: 0.0483
DEBUG - 2022-07-03 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:47:58 --> Total execution time: 0.0480
DEBUG - 2022-07-03 04:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:48:03 --> Total execution time: 0.0719
DEBUG - 2022-07-03 04:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:18:10 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:48:10 --> Total execution time: 0.0575
DEBUG - 2022-07-03 04:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:51:18 --> Total execution time: 0.1021
DEBUG - 2022-07-03 04:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:51:19 --> Total execution time: 0.0516
DEBUG - 2022-07-03 04:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:51:26 --> Total execution time: 0.0545
DEBUG - 2022-07-03 04:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:51:29 --> Total execution time: 0.0626
DEBUG - 2022-07-03 04:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:51:32 --> Total execution time: 0.0563
DEBUG - 2022-07-03 04:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:53:13 --> Total execution time: 1.5367
DEBUG - 2022-07-03 04:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:53:13 --> Total execution time: 0.0482
DEBUG - 2022-07-03 04:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 04:23:25 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 04:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:23:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:53:53 --> Total execution time: 0.0520
DEBUG - 2022-07-03 04:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:53:56 --> Total execution time: 0.0573
DEBUG - 2022-07-03 04:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:54:03 --> Total execution time: 0.0805
DEBUG - 2022-07-03 04:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:54:06 --> Total execution time: 0.0604
DEBUG - 2022-07-03 04:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:54:09 --> Total execution time: 0.1145
DEBUG - 2022-07-03 04:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:54:12 --> Total execution time: 0.1252
DEBUG - 2022-07-03 04:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:54:17 --> Total execution time: 0.0477
DEBUG - 2022-07-03 04:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:54:17 --> Total execution time: 0.0461
DEBUG - 2022-07-03 04:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:54:21 --> Total execution time: 0.0628
DEBUG - 2022-07-03 04:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:54:28 --> Total execution time: 0.0624
DEBUG - 2022-07-03 04:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:54:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 04:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:54:29 --> Total execution time: 0.0546
DEBUG - 2022-07-03 04:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:54:54 --> Total execution time: 0.0497
DEBUG - 2022-07-03 04:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:54:56 --> Total execution time: 0.0613
DEBUG - 2022-07-03 04:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:55:06 --> Total execution time: 0.0819
DEBUG - 2022-07-03 04:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:55:14 --> Total execution time: 0.0541
DEBUG - 2022-07-03 04:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:55:23 --> Total execution time: 0.0524
DEBUG - 2022-07-03 04:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:55:37 --> Total execution time: 0.0507
DEBUG - 2022-07-03 04:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:55:58 --> Total execution time: 0.0482
DEBUG - 2022-07-03 04:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:56:24 --> Total execution time: 0.0473
DEBUG - 2022-07-03 04:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:26:35 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:56:35 --> Total execution time: 0.0516
DEBUG - 2022-07-03 04:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:26:44 --> Total execution time: 0.0540
DEBUG - 2022-07-03 04:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:26:45 --> Total execution time: 0.0546
DEBUG - 2022-07-03 04:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:26:45 --> Total execution time: 0.1084
DEBUG - 2022-07-03 04:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:27:39 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:57:39 --> Total execution time: 0.1371
DEBUG - 2022-07-03 04:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:57:42 --> Total execution time: 0.0582
DEBUG - 2022-07-03 04:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:57:52 --> Total execution time: 0.0487
DEBUG - 2022-07-03 04:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:58:04 --> Total execution time: 0.0659
DEBUG - 2022-07-03 04:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:58:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 04:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:58:05 --> Total execution time: 0.0494
DEBUG - 2022-07-03 04:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:58:31 --> Total execution time: 0.0553
DEBUG - 2022-07-03 04:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:58:48 --> Total execution time: 0.0501
DEBUG - 2022-07-03 04:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:59:02 --> Total execution time: 0.0575
DEBUG - 2022-07-03 04:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:59:08 --> Total execution time: 0.0460
DEBUG - 2022-07-03 04:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:29:12 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:59:12 --> Total execution time: 0.0366
DEBUG - 2022-07-03 04:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:29:12 --> Total execution time: 0.0546
DEBUG - 2022-07-03 04:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:59:32 --> Total execution time: 0.1155
DEBUG - 2022-07-03 04:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:29:37 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:59:37 --> Total execution time: 0.0507
DEBUG - 2022-07-03 04:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:59:49 --> Total execution time: 0.0518
DEBUG - 2022-07-03 04:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:30:20 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:00:20 --> Total execution time: 0.0614
DEBUG - 2022-07-03 04:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:32:02 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:02:02 --> Total execution time: 0.1189
DEBUG - 2022-07-03 04:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:02:05 --> Total execution time: 0.0405
DEBUG - 2022-07-03 04:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:02:11 --> Total execution time: 0.0447
DEBUG - 2022-07-03 04:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:02:19 --> Total execution time: 0.0706
DEBUG - 2022-07-03 04:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:02:25 --> Total execution time: 0.0734
DEBUG - 2022-07-03 04:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:03:25 --> Total execution time: 0.0505
DEBUG - 2022-07-03 04:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:35:02 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:05:02 --> Total execution time: 0.0347
DEBUG - 2022-07-03 04:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:05:09 --> Total execution time: 0.0506
DEBUG - 2022-07-03 04:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:05:14 --> Total execution time: 0.0503
DEBUG - 2022-07-03 04:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:05:20 --> Total execution time: 0.0534
DEBUG - 2022-07-03 04:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:05:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 04:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:05:21 --> Total execution time: 0.0478
DEBUG - 2022-07-03 04:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:06:11 --> Total execution time: 0.1297
DEBUG - 2022-07-03 04:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:06:57 --> Total execution time: 0.1240
DEBUG - 2022-07-03 04:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:36:59 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:06:59 --> Total execution time: 0.0394
DEBUG - 2022-07-03 04:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:37:01 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:07:01 --> Total execution time: 0.0430
DEBUG - 2022-07-03 04:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:07:05 --> Total execution time: 0.0472
DEBUG - 2022-07-03 04:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:07:08 --> Total execution time: 0.0471
DEBUG - 2022-07-03 04:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:07:13 --> Total execution time: 0.0519
DEBUG - 2022-07-03 04:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:07:13 --> Total execution time: 0.1345
DEBUG - 2022-07-03 04:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:37:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 04:37:22 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-03 04:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:07:41 --> Total execution time: 0.0551
DEBUG - 2022-07-03 04:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:08:00 --> Total execution time: 0.0459
DEBUG - 2022-07-03 04:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:08:08 --> Total execution time: 0.0607
DEBUG - 2022-07-03 04:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:08:08 --> Total execution time: 0.0661
DEBUG - 2022-07-03 04:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:09:32 --> Total execution time: 0.0626
DEBUG - 2022-07-03 04:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:39:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 04:39:45 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 04:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:40:19 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:10:19 --> Total execution time: 0.0345
DEBUG - 2022-07-03 04:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:40:23 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:10:23 --> Total execution time: 0.0496
DEBUG - 2022-07-03 04:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:10:45 --> Total execution time: 0.0461
DEBUG - 2022-07-03 04:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:41:08 --> Total execution time: 0.0338
DEBUG - 2022-07-03 04:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:41:09 --> Total execution time: 0.0494
DEBUG - 2022-07-03 04:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:41:09 --> Total execution time: 0.1144
DEBUG - 2022-07-03 04:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:41:28 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:11:28 --> Total execution time: 0.0502
DEBUG - 2022-07-03 04:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:41:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 04:41:43 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-03 04:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:41:56 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:11:56 --> Total execution time: 0.0532
DEBUG - 2022-07-03 04:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:12:01 --> Total execution time: 0.0560
DEBUG - 2022-07-03 04:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:12:09 --> Total execution time: 0.0468
DEBUG - 2022-07-03 04:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:42:15 --> Total execution time: 0.0478
DEBUG - 2022-07-03 04:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:42:16 --> Total execution time: 0.0527
DEBUG - 2022-07-03 04:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:42:16 --> Total execution time: 0.0819
DEBUG - 2022-07-03 04:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:42:26 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:12:26 --> Total execution time: 0.0501
DEBUG - 2022-07-03 04:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:42:33 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:12:33 --> Total execution time: 0.0491
DEBUG - 2022-07-03 04:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:42:34 --> Total execution time: 0.0612
DEBUG - 2022-07-03 04:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:42:35 --> Total execution time: 0.0525
DEBUG - 2022-07-03 04:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:42:36 --> Total execution time: 0.0628
DEBUG - 2022-07-03 04:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:12:54 --> Total execution time: 0.0570
DEBUG - 2022-07-03 04:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:43:50 --> Total execution time: 0.0477
DEBUG - 2022-07-03 04:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:43:52 --> Total execution time: 0.0653
DEBUG - 2022-07-03 04:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:43:52 --> Total execution time: 0.0986
DEBUG - 2022-07-03 04:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:44:26 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:14:26 --> Total execution time: 0.0892
DEBUG - 2022-07-03 04:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:14:28 --> Total execution time: 0.1118
DEBUG - 2022-07-03 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:14:38 --> Total execution time: 0.0566
DEBUG - 2022-07-03 04:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:14:38 --> Total execution time: 0.0468
DEBUG - 2022-07-03 04:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:44:46 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:14:46 --> Total execution time: 0.0515
DEBUG - 2022-07-03 04:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:14:50 --> Total execution time: 0.0650
DEBUG - 2022-07-03 04:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:44:56 --> Total execution time: 0.0484
DEBUG - 2022-07-03 04:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:44:57 --> Total execution time: 0.0483
DEBUG - 2022-07-03 04:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:44:57 --> Total execution time: 0.1110
DEBUG - 2022-07-03 04:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:14:58 --> Total execution time: 0.0644
DEBUG - 2022-07-03 04:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:15:11 --> Total execution time: 0.0579
DEBUG - 2022-07-03 04:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:45:19 --> Total execution time: 0.0516
DEBUG - 2022-07-03 04:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:45:20 --> Total execution time: 0.0519
DEBUG - 2022-07-03 04:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:45:20 --> Total execution time: 0.1065
DEBUG - 2022-07-03 04:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:45:28 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:15:28 --> Total execution time: 0.1301
DEBUG - 2022-07-03 04:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:45:29 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:15:29 --> Total execution time: 0.0485
DEBUG - 2022-07-03 04:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:15:31 --> Total execution time: 0.0427
DEBUG - 2022-07-03 04:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:46:30 --> Total execution time: 0.0609
DEBUG - 2022-07-03 04:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:46:31 --> Total execution time: 0.0559
DEBUG - 2022-07-03 04:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:46:31 --> Total execution time: 0.1206
DEBUG - 2022-07-03 04:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:46:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:16:53 --> Total execution time: 0.0345
DEBUG - 2022-07-03 04:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:47:03 --> Total execution time: 0.1104
DEBUG - 2022-07-03 04:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:47:05 --> Total execution time: 0.0403
DEBUG - 2022-07-03 04:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:47:05 --> Total execution time: 0.1027
DEBUG - 2022-07-03 04:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:17:11 --> Total execution time: 0.0439
DEBUG - 2022-07-03 04:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:17:29 --> Total execution time: 0.1616
DEBUG - 2022-07-03 04:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:17:32 --> Total execution time: 0.0569
DEBUG - 2022-07-03 04:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:17:33 --> Total execution time: 0.0613
DEBUG - 2022-07-03 04:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:17:41 --> Total execution time: 0.0599
DEBUG - 2022-07-03 04:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:18:17 --> Total execution time: 0.0535
DEBUG - 2022-07-03 04:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:18:19 --> Total execution time: 0.0673
DEBUG - 2022-07-03 04:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:18:19 --> Total execution time: 0.0625
DEBUG - 2022-07-03 04:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:18:22 --> Total execution time: 0.0457
DEBUG - 2022-07-03 04:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:18:22 --> Total execution time: 0.0459
DEBUG - 2022-07-03 04:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:48:33 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:18:33 --> Total execution time: 0.0758
DEBUG - 2022-07-03 04:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:18:45 --> Total execution time: 0.0497
DEBUG - 2022-07-03 04:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:18:48 --> Total execution time: 0.1224
DEBUG - 2022-07-03 04:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:18:57 --> Total execution time: 0.0501
DEBUG - 2022-07-03 04:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:19:33 --> Total execution time: 0.0513
DEBUG - 2022-07-03 04:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:19:50 --> Total execution time: 0.0477
DEBUG - 2022-07-03 04:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:50:15 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:20:15 --> Total execution time: 0.0355
DEBUG - 2022-07-03 04:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:20:23 --> Total execution time: 0.0679
DEBUG - 2022-07-03 04:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:20:25 --> Total execution time: 0.0563
DEBUG - 2022-07-03 04:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:20:35 --> Total execution time: 0.0633
DEBUG - 2022-07-03 04:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:20:42 --> Total execution time: 0.0560
DEBUG - 2022-07-03 04:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:50:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 04:50:48 --> 404 Page Not Found: Event/lesley-2030-help-shape-our-future
DEBUG - 2022-07-03 04:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:20:54 --> Total execution time: 0.0549
DEBUG - 2022-07-03 04:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:20:56 --> Total execution time: 0.0723
DEBUG - 2022-07-03 04:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:20:58 --> Total execution time: 0.0944
DEBUG - 2022-07-03 04:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:51:09 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:21:09 --> Total execution time: 0.0381
DEBUG - 2022-07-03 04:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:52:16 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:22:16 --> Total execution time: 0.0517
DEBUG - 2022-07-03 04:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:22:37 --> Total execution time: 0.0558
DEBUG - 2022-07-03 04:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:22:42 --> Total execution time: 0.0719
DEBUG - 2022-07-03 04:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:52:49 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:22:49 --> Total execution time: 0.0355
DEBUG - 2022-07-03 04:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:22:53 --> Total execution time: 0.0758
DEBUG - 2022-07-03 04:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:04 --> Total execution time: 0.0723
DEBUG - 2022-07-03 04:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:08 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:08 --> Total execution time: 0.1315
DEBUG - 2022-07-03 04:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:11 --> Total execution time: 0.0703
DEBUG - 2022-07-03 04:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:12 --> Total execution time: 0.0544
DEBUG - 2022-07-03 04:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:12 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:12 --> Total execution time: 0.0559
DEBUG - 2022-07-03 04:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:12 --> Total execution time: 0.1699
DEBUG - 2022-07-03 04:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:21 --> Total execution time: 0.0605
DEBUG - 2022-07-03 04:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:24 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:24 --> Total execution time: 0.0344
DEBUG - 2022-07-03 04:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:26 --> Total execution time: 0.0942
DEBUG - 2022-07-03 04:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:28 --> Total execution time: 0.0513
DEBUG - 2022-07-03 04:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:29 --> Total execution time: 0.1266
DEBUG - 2022-07-03 04:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:30 --> Total execution time: 0.0514
DEBUG - 2022-07-03 04:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:31 --> Total execution time: 0.0532
DEBUG - 2022-07-03 04:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:32 --> Total execution time: 0.0546
DEBUG - 2022-07-03 04:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:37 --> Total execution time: 0.0822
DEBUG - 2022-07-03 04:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:38 --> Total execution time: 0.0566
DEBUG - 2022-07-03 04:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:40 --> Total execution time: 0.0711
DEBUG - 2022-07-03 04:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:47 --> Total execution time: 0.0485
DEBUG - 2022-07-03 04:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:53:49 --> Total execution time: 0.0474
DEBUG - 2022-07-03 04:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:53:50 --> Total execution time: 0.0534
DEBUG - 2022-07-03 04:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:53:50 --> Total execution time: 0.0858
DEBUG - 2022-07-03 04:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:51 --> Total execution time: 0.0492
DEBUG - 2022-07-03 04:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:51 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:51 --> Total execution time: 0.0337
DEBUG - 2022-07-03 04:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:53 --> Total execution time: 0.0488
DEBUG - 2022-07-03 04:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:53 --> Total execution time: 0.0505
DEBUG - 2022-07-03 04:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:23:59 --> Total execution time: 0.0586
DEBUG - 2022-07-03 04:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:24:05 --> Total execution time: 0.1191
DEBUG - 2022-07-03 04:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:24:08 --> Total execution time: 0.0686
DEBUG - 2022-07-03 04:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:25:07 --> Total execution time: 0.0579
DEBUG - 2022-07-03 04:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:55:25 --> Total execution time: 0.0600
DEBUG - 2022-07-03 04:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:55:26 --> Total execution time: 0.0592
DEBUG - 2022-07-03 04:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:55:26 --> Total execution time: 0.1161
DEBUG - 2022-07-03 04:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:55:40 --> No URI present. Default controller set.
DEBUG - 2022-07-03 04:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 04:55:40 --> Total execution time: 0.0579
DEBUG - 2022-07-03 04:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:25:40 --> Total execution time: 0.0878
DEBUG - 2022-07-03 04:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:29:17 --> Total execution time: 0.1475
DEBUG - 2022-07-03 04:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:29:31 --> Total execution time: 0.1433
DEBUG - 2022-07-03 04:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:29:36 --> Total execution time: 0.0689
DEBUG - 2022-07-03 04:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 04:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 04:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:29:44 --> Total execution time: 0.0478
DEBUG - 2022-07-03 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:30:02 --> Total execution time: 0.0665
DEBUG - 2022-07-03 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:30:02 --> Total execution time: 0.1533
DEBUG - 2022-07-03 05:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:02:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:32:11 --> Total execution time: 0.0848
DEBUG - 2022-07-03 05:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:33:56 --> Total execution time: 0.0500
DEBUG - 2022-07-03 05:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:04:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 05:04:30 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-03 05:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:35:13 --> Total execution time: 0.0611
DEBUG - 2022-07-03 05:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:35:32 --> Total execution time: 0.1259
DEBUG - 2022-07-03 05:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:07:01 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:37:01 --> Total execution time: 0.0408
DEBUG - 2022-07-03 05:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:37:04 --> Total execution time: 0.0395
DEBUG - 2022-07-03 05:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:37:11 --> Total execution time: 0.0528
DEBUG - 2022-07-03 05:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:37:15 --> Total execution time: 0.0643
DEBUG - 2022-07-03 05:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:37:20 --> Total execution time: 0.0584
DEBUG - 2022-07-03 05:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:37:27 --> Total execution time: 0.0487
DEBUG - 2022-07-03 05:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:37:47 --> Total execution time: 0.0760
DEBUG - 2022-07-03 05:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:08:12 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:38:12 --> Total execution time: 0.1215
DEBUG - 2022-07-03 05:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:08:12 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:38:12 --> Total execution time: 0.0645
DEBUG - 2022-07-03 05:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:38:26 --> Total execution time: 0.0356
DEBUG - 2022-07-03 05:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:12:13 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:42:13 --> Total execution time: 0.1867
DEBUG - 2022-07-03 05:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:12:34 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:42:35 --> Total execution time: 0.0476
DEBUG - 2022-07-03 05:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:14:49 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:44:49 --> Total execution time: 0.0921
DEBUG - 2022-07-03 05:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:48:51 --> Total execution time: 0.1755
DEBUG - 2022-07-03 05:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:19:29 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:49:29 --> Total execution time: 0.0348
DEBUG - 2022-07-03 05:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:49:43 --> Total execution time: 0.0382
DEBUG - 2022-07-03 05:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:49:56 --> Total execution time: 0.0677
DEBUG - 2022-07-03 05:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:50:08 --> Total execution time: 0.0568
DEBUG - 2022-07-03 05:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:50:11 --> Total execution time: 0.0776
DEBUG - 2022-07-03 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:50:21 --> Total execution time: 0.0464
DEBUG - 2022-07-03 05:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:51:43 --> Total execution time: 0.0634
DEBUG - 2022-07-03 05:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:52:56 --> Total execution time: 0.1924
DEBUG - 2022-07-03 05:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:27:20 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:57:20 --> Total execution time: 0.1887
DEBUG - 2022-07-03 05:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:57:23 --> Total execution time: 0.0482
DEBUG - 2022-07-03 05:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:27:30 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:57:30 --> Total execution time: 0.0578
DEBUG - 2022-07-03 05:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:27:32 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:57:33 --> Total execution time: 0.0589
DEBUG - 2022-07-03 05:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:27:33 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:57:33 --> Total execution time: 0.0378
DEBUG - 2022-07-03 05:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:57:36 --> Total execution time: 0.0473
DEBUG - 2022-07-03 05:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:57:42 --> Total execution time: 0.0540
DEBUG - 2022-07-03 05:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:27:43 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:57:43 --> Total execution time: 0.0560
DEBUG - 2022-07-03 05:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:57:47 --> Total execution time: 0.0768
DEBUG - 2022-07-03 05:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:27:52 --> Total execution time: 0.0510
DEBUG - 2022-07-03 05:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:27:54 --> Total execution time: 0.0647
DEBUG - 2022-07-03 05:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:27:54 --> Total execution time: 0.1146
DEBUG - 2022-07-03 05:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:27:58 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:57:58 --> Total execution time: 0.0470
DEBUG - 2022-07-03 05:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:58:02 --> Total execution time: 0.0470
DEBUG - 2022-07-03 05:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:07 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:58:07 --> Total execution time: 0.0514
DEBUG - 2022-07-03 05:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:58:11 --> Total execution time: 0.0474
DEBUG - 2022-07-03 05:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:58:11 --> Total execution time: 0.0509
DEBUG - 2022-07-03 05:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:58:13 --> Total execution time: 0.0480
DEBUG - 2022-07-03 05:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:13 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:58:13 --> Total execution time: 0.0506
DEBUG - 2022-07-03 05:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:13 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:58:13 --> Total execution time: 0.0494
DEBUG - 2022-07-03 05:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:58:14 --> Total execution time: 0.0465
DEBUG - 2022-07-03 05:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:58:14 --> Total execution time: 0.0527
DEBUG - 2022-07-03 05:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:14 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:58:14 --> Total execution time: 0.0566
DEBUG - 2022-07-03 05:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:58:15 --> Total execution time: 0.0454
DEBUG - 2022-07-03 05:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:15 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:58:15 --> Total execution time: 0.0598
DEBUG - 2022-07-03 05:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:58:16 --> Total execution time: 0.0485
DEBUG - 2022-07-03 05:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:25 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:58:25 --> Total execution time: 0.0460
DEBUG - 2022-07-03 05:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:28:41 --> Total execution time: 0.0571
DEBUG - 2022-07-03 05:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:28:44 --> Total execution time: 0.0495
DEBUG - 2022-07-03 05:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:28:44 --> Total execution time: 0.1074
DEBUG - 2022-07-03 05:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:29:20 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:59:20 --> Total execution time: 0.0571
DEBUG - 2022-07-03 05:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:29:35 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:59:35 --> Total execution time: 0.0480
DEBUG - 2022-07-03 05:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:29:50 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:59:50 --> Total execution time: 0.0495
DEBUG - 2022-07-03 05:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:30:02 --> Total execution time: 0.0646
DEBUG - 2022-07-03 05:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:30:03 --> Total execution time: 0.0585
DEBUG - 2022-07-03 05:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:30:03 --> Total execution time: 0.1078
DEBUG - 2022-07-03 05:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:30:52 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:00:52 --> Total execution time: 0.0533
DEBUG - 2022-07-03 05:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:31:02 --> Total execution time: 0.0499
DEBUG - 2022-07-03 05:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:31:06 --> Total execution time: 0.0505
DEBUG - 2022-07-03 05:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:31:06 --> Total execution time: 0.1140
DEBUG - 2022-07-03 05:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:32:00 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:02:00 --> Total execution time: 0.1297
DEBUG - 2022-07-03 05:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:32:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 05:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:02:44 --> Total execution time: 1.5327
DEBUG - 2022-07-03 05:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:32:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 05:32:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 05:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:03:09 --> Total execution time: 0.0556
DEBUG - 2022-07-03 05:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:03:25 --> Total execution time: 0.0526
DEBUG - 2022-07-03 05:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:03:29 --> Total execution time: 0.0635
DEBUG - 2022-07-03 05:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:03:31 --> Total execution time: 0.0502
DEBUG - 2022-07-03 05:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:33:32 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:03:32 --> Total execution time: 0.0535
DEBUG - 2022-07-03 05:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:33:49 --> Total execution time: 0.1233
DEBUG - 2022-07-03 05:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:33:50 --> Total execution time: 0.0547
DEBUG - 2022-07-03 05:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:33:50 --> Total execution time: 0.1177
DEBUG - 2022-07-03 05:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:33:59 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:03:59 --> Total execution time: 0.0540
DEBUG - 2022-07-03 05:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:34:08 --> Total execution time: 0.0472
DEBUG - 2022-07-03 05:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:34:09 --> Total execution time: 0.0530
DEBUG - 2022-07-03 05:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:34:09 --> Total execution time: 0.1099
DEBUG - 2022-07-03 05:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:35:05 --> Total execution time: 0.0478
DEBUG - 2022-07-03 05:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:35:07 --> Total execution time: 0.0542
DEBUG - 2022-07-03 05:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:35:07 --> Total execution time: 0.1015
DEBUG - 2022-07-03 05:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:36:01 --> Total execution time: 0.0478
DEBUG - 2022-07-03 05:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:36:02 --> Total execution time: 0.0491
DEBUG - 2022-07-03 05:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:36:02 --> Total execution time: 0.1146
DEBUG - 2022-07-03 05:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:36:54 --> Total execution time: 0.0575
DEBUG - 2022-07-03 05:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:36:55 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:06:55 --> Total execution time: 0.0288
DEBUG - 2022-07-03 05:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:36:56 --> Total execution time: 0.0595
DEBUG - 2022-07-03 05:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:36:56 --> Total execution time: 0.1223
DEBUG - 2022-07-03 05:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:06:58 --> Total execution time: 0.0371
DEBUG - 2022-07-03 05:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:37:03 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:07:03 --> Total execution time: 0.0500
DEBUG - 2022-07-03 05:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:37:07 --> Total execution time: 0.0678
DEBUG - 2022-07-03 05:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:37:08 --> Total execution time: 0.0563
DEBUG - 2022-07-03 05:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:37:08 --> Total execution time: 0.0610
DEBUG - 2022-07-03 05:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:37:20 --> Total execution time: 0.0461
DEBUG - 2022-07-03 05:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:07:21 --> Total execution time: 0.0641
DEBUG - 2022-07-03 05:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:07:28 --> Total execution time: 0.0619
DEBUG - 2022-07-03 05:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:07:29 --> Total execution time: 0.0540
DEBUG - 2022-07-03 05:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:07:38 --> Total execution time: 0.0612
DEBUG - 2022-07-03 05:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:38:01 --> Total execution time: 0.0441
DEBUG - 2022-07-03 05:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:38:02 --> Total execution time: 0.0465
DEBUG - 2022-07-03 05:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:38:02 --> Total execution time: 0.0982
DEBUG - 2022-07-03 05:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:38:05 --> Total execution time: 0.0496
DEBUG - 2022-07-03 05:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:38:06 --> Total execution time: 0.0594
DEBUG - 2022-07-03 05:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:38:07 --> Total execution time: 0.1039
DEBUG - 2022-07-03 05:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:38:37 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:08:37 --> Total execution time: 0.1208
DEBUG - 2022-07-03 05:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:08:45 --> Total execution time: 0.0482
DEBUG - 2022-07-03 05:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:38:49 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:08:49 --> Total execution time: 0.0555
DEBUG - 2022-07-03 05:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:38:51 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:08:51 --> Total execution time: 0.1207
DEBUG - 2022-07-03 05:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:38:58 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:08:58 --> Total execution time: 0.0485
DEBUG - 2022-07-03 05:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:39:08 --> Total execution time: 0.0577
DEBUG - 2022-07-03 05:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:39:09 --> Total execution time: 0.0654
DEBUG - 2022-07-03 05:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:39:09 --> Total execution time: 0.0932
DEBUG - 2022-07-03 05:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:39:22 --> Total execution time: 0.0518
DEBUG - 2022-07-03 05:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:39:24 --> Total execution time: 0.0383
DEBUG - 2022-07-03 05:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:39:24 --> Total execution time: 0.0422
DEBUG - 2022-07-03 05:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:39:40 --> Total execution time: 0.0464
DEBUG - 2022-07-03 05:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:39:41 --> Total execution time: 0.0514
DEBUG - 2022-07-03 05:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:39:41 --> Total execution time: 0.1001
DEBUG - 2022-07-03 05:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:39:50 --> Total execution time: 0.0637
DEBUG - 2022-07-03 05:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:39:50 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:09:50 --> Total execution time: 0.0607
DEBUG - 2022-07-03 05:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:40:05 --> Total execution time: 0.1297
DEBUG - 2022-07-03 05:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:40:06 --> Total execution time: 0.0619
DEBUG - 2022-07-03 05:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:40:06 --> Total execution time: 0.0699
DEBUG - 2022-07-03 05:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:40:08 --> Total execution time: 0.0514
DEBUG - 2022-07-03 05:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:40:09 --> Total execution time: 0.0479
DEBUG - 2022-07-03 05:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:40:09 --> Total execution time: 0.1205
DEBUG - 2022-07-03 05:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:10:18 --> Total execution time: 0.0531
DEBUG - 2022-07-03 05:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:41:12 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:11:12 --> Total execution time: 0.0508
DEBUG - 2022-07-03 05:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:11:16 --> Total execution time: 0.0551
DEBUG - 2022-07-03 05:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:41:37 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:11:37 --> Total execution time: 0.0450
DEBUG - 2022-07-03 05:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:41:52 --> Total execution time: 0.0469
DEBUG - 2022-07-03 05:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:42:00 --> Total execution time: 0.0661
DEBUG - 2022-07-03 05:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:42:00 --> Total execution time: 0.1162
DEBUG - 2022-07-03 05:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:42:38 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:12:38 --> Total execution time: 0.0359
DEBUG - 2022-07-03 05:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:42:40 --> Total execution time: 0.0544
DEBUG - 2022-07-03 05:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:42:42 --> Total execution time: 0.0518
DEBUG - 2022-07-03 05:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:42:42 --> Total execution time: 0.1136
DEBUG - 2022-07-03 05:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:43:33 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:13:33 --> Total execution time: 0.1249
DEBUG - 2022-07-03 05:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:13:36 --> Total execution time: 0.0823
DEBUG - 2022-07-03 05:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:13:47 --> Total execution time: 0.0545
DEBUG - 2022-07-03 05:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:13:49 --> Total execution time: 0.0680
DEBUG - 2022-07-03 05:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:13:56 --> Total execution time: 0.0576
DEBUG - 2022-07-03 05:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:44:03 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:14:03 --> Total execution time: 0.0488
DEBUG - 2022-07-03 05:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:44:09 --> Total execution time: 0.0475
DEBUG - 2022-07-03 05:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:44:12 --> Total execution time: 0.0679
DEBUG - 2022-07-03 05:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:44:12 --> Total execution time: 0.1357
DEBUG - 2022-07-03 05:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:44:40 --> Total execution time: 0.0477
DEBUG - 2022-07-03 05:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:44:41 --> Total execution time: 0.0586
DEBUG - 2022-07-03 05:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:44:41 --> Total execution time: 0.1377
DEBUG - 2022-07-03 05:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:14:56 --> Total execution time: 0.0606
DEBUG - 2022-07-03 05:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:15:34 --> Total execution time: 0.0584
DEBUG - 2022-07-03 05:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:15:44 --> Total execution time: 0.0466
DEBUG - 2022-07-03 05:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:45:46 --> Total execution time: 0.0580
DEBUG - 2022-07-03 05:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:45:47 --> Total execution time: 0.0556
DEBUG - 2022-07-03 05:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:45:47 --> Total execution time: 0.0468
DEBUG - 2022-07-03 05:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:45:47 --> Total execution time: 0.0602
DEBUG - 2022-07-03 05:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:45:48 --> Total execution time: 0.0484
DEBUG - 2022-07-03 05:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:45:48 --> Total execution time: 0.1131
DEBUG - 2022-07-03 05:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:45:48 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:15:48 --> Total execution time: 0.0493
DEBUG - 2022-07-03 05:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:45:57 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:15:57 --> Total execution time: 0.1276
DEBUG - 2022-07-03 05:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:18:51 --> Total execution time: 0.1182
DEBUG - 2022-07-03 05:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:49:07 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:19:07 --> Total execution time: 0.0344
DEBUG - 2022-07-03 05:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:49:35 --> Total execution time: 0.0552
DEBUG - 2022-07-03 05:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:49:37 --> Total execution time: 0.0540
DEBUG - 2022-07-03 05:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:49:37 --> Total execution time: 0.1203
DEBUG - 2022-07-03 05:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:49:44 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:19:44 --> Total execution time: 0.0592
DEBUG - 2022-07-03 05:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:50:51 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:20:51 --> Total execution time: 0.0343
DEBUG - 2022-07-03 05:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:51:01 --> Total execution time: 0.0618
DEBUG - 2022-07-03 05:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:51:08 --> Total execution time: 0.0591
DEBUG - 2022-07-03 05:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:51:08 --> Total execution time: 0.1150
DEBUG - 2022-07-03 05:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:52:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 05:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:22:22 --> Total execution time: 1.5622
DEBUG - 2022-07-03 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 05:52:26 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 05:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:23:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 05:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:23:42 --> Total execution time: 0.0539
DEBUG - 2022-07-03 05:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:23:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 16:23:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 16:23:45 --> Total execution time: 0.2453
DEBUG - 2022-07-03 05:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:54:04 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:24:04 --> Total execution time: 0.0383
DEBUG - 2022-07-03 05:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:24:21 --> Total execution time: 1.5457
DEBUG - 2022-07-03 05:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:24:34 --> Total execution time: 0.0590
DEBUG - 2022-07-03 05:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:54:37 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:24:37 --> Total execution time: 0.0491
DEBUG - 2022-07-03 05:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:54:46 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:24:46 --> Total execution time: 0.1139
DEBUG - 2022-07-03 05:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:24:49 --> Total execution time: 0.1470
DEBUG - 2022-07-03 05:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:25:14 --> Total execution time: 0.0385
DEBUG - 2022-07-03 05:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:25:23 --> Total execution time: 0.0743
DEBUG - 2022-07-03 05:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:25:31 --> Total execution time: 0.0527
DEBUG - 2022-07-03 05:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:55:32 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:25:32 --> Total execution time: 0.0358
DEBUG - 2022-07-03 05:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:25:36 --> Total execution time: 0.0655
DEBUG - 2022-07-03 05:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:25:41 --> Total execution time: 0.0522
DEBUG - 2022-07-03 05:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:25:47 --> Total execution time: 0.0900
DEBUG - 2022-07-03 05:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:26:22 --> Total execution time: 0.0791
DEBUG - 2022-07-03 05:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:26:38 --> Total execution time: 0.0471
DEBUG - 2022-07-03 05:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:56:48 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:26:48 --> Total execution time: 0.0652
DEBUG - 2022-07-03 05:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:26:52 --> Total execution time: 0.0482
DEBUG - 2022-07-03 05:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:26:54 --> Total execution time: 0.0768
DEBUG - 2022-07-03 05:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:27:09 --> Total execution time: 0.0612
DEBUG - 2022-07-03 05:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:27:25 --> Total execution time: 0.0538
DEBUG - 2022-07-03 05:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:28:11 --> Total execution time: 0.0521
DEBUG - 2022-07-03 05:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:58:34 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:28:34 --> Total execution time: 0.0516
DEBUG - 2022-07-03 05:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:28:37 --> Total execution time: 0.0519
DEBUG - 2022-07-03 05:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 05:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:28:38 --> Total execution time: 0.0506
DEBUG - 2022-07-03 05:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:58:47 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:28:47 --> Total execution time: 0.0715
DEBUG - 2022-07-03 05:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:59:02 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:29:02 --> Total execution time: 0.0491
DEBUG - 2022-07-03 05:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:29:15 --> Total execution time: 0.0661
DEBUG - 2022-07-03 05:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 05:59:56 --> No URI present. Default controller set.
DEBUG - 2022-07-03 05:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 05:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:29:56 --> Total execution time: 0.0348
DEBUG - 2022-07-03 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:30:02 --> Total execution time: 0.0641
DEBUG - 2022-07-03 06:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:00:08 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:30:08 --> Total execution time: 0.2339
DEBUG - 2022-07-03 06:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:31:14 --> Total execution time: 0.1302
DEBUG - 2022-07-03 06:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:31:22 --> Total execution time: 0.0503
DEBUG - 2022-07-03 06:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:31:28 --> Total execution time: 0.0572
DEBUG - 2022-07-03 06:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:31:38 --> Total execution time: 0.0654
DEBUG - 2022-07-03 06:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:32:06 --> Total execution time: 0.0547
DEBUG - 2022-07-03 06:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:32:06 --> Total execution time: 0.0450
DEBUG - 2022-07-03 06:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 16:32:06 --> Total execution time: 0.0778
DEBUG - 2022-07-03 06:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:07 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:32:07 --> Total execution time: 0.1665
DEBUG - 2022-07-03 06:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:07 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:32:07 --> Total execution time: 0.1332
DEBUG - 2022-07-03 06:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:02:08 --> Total execution time: 0.0784
DEBUG - 2022-07-03 06:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:32:16 --> Total execution time: 0.0542
DEBUG - 2022-07-03 06:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:32:21 --> Total execution time: 0.0702
DEBUG - 2022-07-03 06:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:32:22 --> Total execution time: 0.0791
DEBUG - 2022-07-03 06:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:32:27 --> Total execution time: 0.0746
DEBUG - 2022-07-03 06:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:32:28 --> Total execution time: 0.0861
DEBUG - 2022-07-03 06:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:32:28 --> Total execution time: 0.0737
DEBUG - 2022-07-03 06:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:32:46 --> Total execution time: 0.0732
DEBUG - 2022-07-03 06:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:32:46 --> Total execution time: 0.1389
DEBUG - 2022-07-03 06:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:32:46 --> Total execution time: 0.0673
DEBUG - 2022-07-03 06:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:32:50 --> Total execution time: 0.0975
DEBUG - 2022-07-03 06:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:33:07 --> Total execution time: 0.0575
DEBUG - 2022-07-03 06:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:33:16 --> Total execution time: 0.0844
DEBUG - 2022-07-03 06:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:04:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:34:11 --> Total execution time: 0.1220
DEBUG - 2022-07-03 06:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:34:38 --> Total execution time: 0.0415
DEBUG - 2022-07-03 06:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:34:41 --> Total execution time: 0.0837
DEBUG - 2022-07-03 06:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:34:45 --> Total execution time: 0.0579
DEBUG - 2022-07-03 06:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:34:47 --> Total execution time: 0.0651
DEBUG - 2022-07-03 06:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:34:52 --> Total execution time: 0.1241
DEBUG - 2022-07-03 06:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:34:57 --> Total execution time: 0.0796
DEBUG - 2022-07-03 06:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:35:02 --> Total execution time: 0.0794
DEBUG - 2022-07-03 06:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:05:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:35:11 --> Total execution time: 0.0395
DEBUG - 2022-07-03 06:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:05:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:35:11 --> Total execution time: 0.0336
DEBUG - 2022-07-03 06:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:05:14 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:35:14 --> Total execution time: 0.0349
DEBUG - 2022-07-03 06:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:05:14 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:35:14 --> Total execution time: 0.0351
DEBUG - 2022-07-03 06:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:35:15 --> Total execution time: 0.0348
DEBUG - 2022-07-03 06:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:35:16 --> Total execution time: 0.0348
DEBUG - 2022-07-03 06:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:05:20 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:35:20 --> Total execution time: 0.0330
DEBUG - 2022-07-03 06:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:35:33 --> Total execution time: 0.0943
DEBUG - 2022-07-03 06:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 06:06:10 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-03 06:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 06:06:19 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-03 06:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:06:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 06:06:26 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-03 06:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:06:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 06:06:37 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-03 06:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:08 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:37:08 --> Total execution time: 0.1287
DEBUG - 2022-07-03 06:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:37:14 --> Total execution time: 0.0489
DEBUG - 2022-07-03 06:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:15 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:37:15 --> Total execution time: 0.1144
DEBUG - 2022-07-03 06:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:37:17 --> Total execution time: 0.0615
DEBUG - 2022-07-03 06:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:37:23 --> Total execution time: 0.0651
DEBUG - 2022-07-03 06:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:37:23 --> Total execution time: 0.1435
DEBUG - 2022-07-03 06:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:37:28 --> Total execution time: 0.0735
DEBUG - 2022-07-03 06:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:37:30 --> Total execution time: 0.0771
DEBUG - 2022-07-03 06:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:36 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:37:36 --> Total execution time: 0.0435
DEBUG - 2022-07-03 06:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:37:37 --> Total execution time: 0.0790
DEBUG - 2022-07-03 06:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:37:40 --> Total execution time: 0.0807
DEBUG - 2022-07-03 06:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:37:41 --> Total execution time: 0.0659
DEBUG - 2022-07-03 06:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:41 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:37:41 --> Total execution time: 0.0500
DEBUG - 2022-07-03 06:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:37:59 --> Total execution time: 0.0522
DEBUG - 2022-07-03 06:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:38:06 --> Total execution time: 0.0880
DEBUG - 2022-07-03 06:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:38:12 --> Total execution time: 0.0689
DEBUG - 2022-07-03 06:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:38:18 --> Total execution time: 0.0520
DEBUG - 2022-07-03 06:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:08:19 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:38:20 --> Total execution time: 0.0613
DEBUG - 2022-07-03 06:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:08:32 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:38:32 --> Total execution time: 0.0515
DEBUG - 2022-07-03 06:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:38:46 --> Total execution time: 0.0488
DEBUG - 2022-07-03 06:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:39:15 --> Total execution time: 0.0478
DEBUG - 2022-07-03 06:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:39:36 --> Total execution time: 0.0731
DEBUG - 2022-07-03 06:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:39:36 --> Total execution time: 0.1348
DEBUG - 2022-07-03 06:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:39:43 --> Total execution time: 0.0672
DEBUG - 2022-07-03 06:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:39:51 --> Total execution time: 0.0663
DEBUG - 2022-07-03 06:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:40:03 --> Total execution time: 0.0635
DEBUG - 2022-07-03 06:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:40:09 --> Total execution time: 0.0536
DEBUG - 2022-07-03 06:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:40:16 --> Total execution time: 0.0487
DEBUG - 2022-07-03 06:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:40:19 --> Total execution time: 0.0519
DEBUG - 2022-07-03 06:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:40:25 --> Total execution time: 0.0648
DEBUG - 2022-07-03 06:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:40:30 --> Total execution time: 0.0636
DEBUG - 2022-07-03 06:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:40:34 --> Total execution time: 0.0567
DEBUG - 2022-07-03 06:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:40:35 --> Total execution time: 0.0528
DEBUG - 2022-07-03 06:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:40:39 --> Total execution time: 0.0938
DEBUG - 2022-07-03 06:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:40:46 --> Total execution time: 0.0729
DEBUG - 2022-07-03 06:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:41:39 --> Total execution time: 0.0469
DEBUG - 2022-07-03 06:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:41:42 --> Total execution time: 0.0469
DEBUG - 2022-07-03 06:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:41:42 --> Total execution time: 0.0352
DEBUG - 2022-07-03 06:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:41:58 --> Total execution time: 0.0609
DEBUG - 2022-07-03 06:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:42:01 --> Total execution time: 0.0802
DEBUG - 2022-07-03 06:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:12:06 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:42:06 --> Total execution time: 0.0626
DEBUG - 2022-07-03 06:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:12:09 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:42:09 --> Total execution time: 0.0369
DEBUG - 2022-07-03 06:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:12:09 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:42:09 --> Total execution time: 0.0368
DEBUG - 2022-07-03 06:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:42:17 --> Total execution time: 0.0326
DEBUG - 2022-07-03 06:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:42:26 --> Total execution time: 0.0499
DEBUG - 2022-07-03 06:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:42:35 --> Total execution time: 0.0458
DEBUG - 2022-07-03 06:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:42:39 --> Total execution time: 0.0494
DEBUG - 2022-07-03 06:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:42:40 --> Total execution time: 0.0404
DEBUG - 2022-07-03 06:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:42:51 --> Total execution time: 0.0500
DEBUG - 2022-07-03 06:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:12:58 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:42:58 --> Total execution time: 0.0533
DEBUG - 2022-07-03 06:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:13:20 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:43:20 --> Total execution time: 0.0357
DEBUG - 2022-07-03 06:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:13:22 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:43:22 --> Total execution time: 0.1156
DEBUG - 2022-07-03 06:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:43:58 --> Total execution time: 0.0546
DEBUG - 2022-07-03 06:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:14:03 --> Total execution time: 0.0547
DEBUG - 2022-07-03 06:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:44:09 --> Total execution time: 0.0479
DEBUG - 2022-07-03 06:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:44:20 --> Total execution time: 0.0520
DEBUG - 2022-07-03 06:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 06:14:36 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-03 06:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:44:38 --> Total execution time: 0.0531
DEBUG - 2022-07-03 06:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:44:56 --> Total execution time: 0.0549
DEBUG - 2022-07-03 06:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:45:17 --> Total execution time: 0.0600
DEBUG - 2022-07-03 06:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:45:43 --> Total execution time: 0.0604
DEBUG - 2022-07-03 06:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:45:58 --> Total execution time: 0.0578
DEBUG - 2022-07-03 06:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:46:17 --> Total execution time: 0.0557
DEBUG - 2022-07-03 06:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 06:17:05 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 06:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:18:40 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:48:40 --> Total execution time: 0.0391
DEBUG - 2022-07-03 06:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:19:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 06:19:04 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-03 06:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:21:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 06:21:48 --> 404 Page Not Found: Home-page/index
DEBUG - 2022-07-03 06:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:52:45 --> Total execution time: 0.1894
DEBUG - 2022-07-03 06:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:52:46 --> Total execution time: 0.0563
DEBUG - 2022-07-03 06:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:52:47 --> Total execution time: 0.0470
DEBUG - 2022-07-03 06:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:52:56 --> Total execution time: 0.0652
DEBUG - 2022-07-03 06:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:22:59 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:52:59 --> Total execution time: 0.0406
DEBUG - 2022-07-03 06:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:53:47 --> Total execution time: 0.0464
DEBUG - 2022-07-03 06:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:24:54 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:54:54 --> Total execution time: 0.0402
DEBUG - 2022-07-03 06:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:25:00 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:55:00 --> Total execution time: 0.0515
DEBUG - 2022-07-03 06:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:25:05 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:55:05 --> Total execution time: 0.0617
DEBUG - 2022-07-03 06:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:26:06 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:56:06 --> Total execution time: 0.0343
DEBUG - 2022-07-03 06:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:26:36 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:56:37 --> Total execution time: 0.1184
DEBUG - 2022-07-03 06:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:28:18 --> Total execution time: 0.0531
DEBUG - 2022-07-03 06:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:28:26 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:58:26 --> Total execution time: 0.1286
DEBUG - 2022-07-03 06:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:28:34 --> Total execution time: 0.0873
DEBUG - 2022-07-03 06:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:59:08 --> Total execution time: 0.0804
DEBUG - 2022-07-03 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:59:56 --> Total execution time: 0.0826
DEBUG - 2022-07-03 06:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:00:16 --> Total execution time: 0.0569
DEBUG - 2022-07-03 06:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:00:32 --> Total execution time: 0.1004
DEBUG - 2022-07-03 06:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:01:12 --> Total execution time: 0.0607
DEBUG - 2022-07-03 06:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:01:33 --> Total execution time: 0.0524
DEBUG - 2022-07-03 06:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:01:57 --> Total execution time: 0.0534
DEBUG - 2022-07-03 06:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:01:59 --> Total execution time: 0.0598
DEBUG - 2022-07-03 06:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:01:59 --> Total execution time: 0.0678
DEBUG - 2022-07-03 06:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:01:59 --> Total execution time: 0.1013
DEBUG - 2022-07-03 06:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:02:00 --> Total execution time: 0.0964
DEBUG - 2022-07-03 06:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:02:04 --> Total execution time: 0.0552
DEBUG - 2022-07-03 06:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:02:09 --> Total execution time: 0.0650
DEBUG - 2022-07-03 06:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:32:20 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:02:20 --> Total execution time: 0.0540
DEBUG - 2022-07-03 06:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:02:37 --> Total execution time: 1.4951
DEBUG - 2022-07-03 06:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:32:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 06:32:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 06:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:32:51 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:02:51 --> Total execution time: 0.0403
DEBUG - 2022-07-03 06:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:33:24 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:03:24 --> Total execution time: 0.0570
DEBUG - 2022-07-03 06:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:03:57 --> Total execution time: 0.0478
DEBUG - 2022-07-03 06:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:04:16 --> Total execution time: 0.0498
DEBUG - 2022-07-03 06:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:05:39 --> Total execution time: 0.0920
DEBUG - 2022-07-03 06:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:06:03 --> Total execution time: 0.0818
DEBUG - 2022-07-03 06:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:36:09 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:06:09 --> Total execution time: 0.1207
DEBUG - 2022-07-03 06:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:06:11 --> Total execution time: 0.0452
DEBUG - 2022-07-03 06:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:06:15 --> Total execution time: 0.0401
DEBUG - 2022-07-03 06:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:06:18 --> Total execution time: 0.0456
DEBUG - 2022-07-03 06:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:06:24 --> Total execution time: 0.0525
DEBUG - 2022-07-03 06:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:06:27 --> Total execution time: 0.0550
DEBUG - 2022-07-03 06:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:06:30 --> Total execution time: 0.0471
DEBUG - 2022-07-03 06:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:06:38 --> Total execution time: 0.1222
DEBUG - 2022-07-03 06:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:06:41 --> Total execution time: 0.0465
DEBUG - 2022-07-03 06:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:06:53 --> Total execution time: 0.0515
DEBUG - 2022-07-03 06:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:07:02 --> Total execution time: 0.0508
DEBUG - 2022-07-03 06:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:07:13 --> Total execution time: 0.0684
DEBUG - 2022-07-03 06:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:07:15 --> Total execution time: 0.0500
DEBUG - 2022-07-03 06:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:07:18 --> Total execution time: 0.0718
DEBUG - 2022-07-03 06:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:07:24 --> Total execution time: 0.0952
DEBUG - 2022-07-03 06:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:07:39 --> Total execution time: 0.0525
DEBUG - 2022-07-03 06:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:07:42 --> Total execution time: 0.0566
DEBUG - 2022-07-03 06:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:07:53 --> Total execution time: 0.0507
DEBUG - 2022-07-03 06:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:08:05 --> Total execution time: 0.0542
DEBUG - 2022-07-03 06:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:08:09 --> Total execution time: 0.0517
DEBUG - 2022-07-03 06:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:08:10 --> Total execution time: 0.0982
DEBUG - 2022-07-03 06:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:08:12 --> Total execution time: 0.0734
DEBUG - 2022-07-03 06:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:08:14 --> Total execution time: 0.0537
DEBUG - 2022-07-03 06:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:08:16 --> Total execution time: 0.0552
DEBUG - 2022-07-03 06:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:08:20 --> Total execution time: 0.0720
DEBUG - 2022-07-03 06:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:08:21 --> Total execution time: 0.0546
DEBUG - 2022-07-03 06:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:08:23 --> Total execution time: 0.0554
DEBUG - 2022-07-03 06:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:08:26 --> Total execution time: 0.0617
DEBUG - 2022-07-03 06:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:27 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:08:27 --> Total execution time: 0.0611
DEBUG - 2022-07-03 06:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:29 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:08:29 --> Total execution time: 0.1264
DEBUG - 2022-07-03 06:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:08:34 --> Total execution time: 0.0600
DEBUG - 2022-07-03 06:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:08:45 --> Total execution time: 0.0721
DEBUG - 2022-07-03 06:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:08:52 --> Total execution time: 0.0537
DEBUG - 2022-07-03 06:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:09:01 --> Total execution time: 0.0567
DEBUG - 2022-07-03 06:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:09:05 --> Total execution time: 0.0547
DEBUG - 2022-07-03 06:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:40:42 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:10:42 --> Total execution time: 0.0350
DEBUG - 2022-07-03 06:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:10:45 --> Total execution time: 0.1139
DEBUG - 2022-07-03 06:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:42:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 06:42:02 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-03 06:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:16:31 --> Total execution time: 0.1128
DEBUG - 2022-07-03 06:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:46:45 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:16:45 --> Total execution time: 0.0440
DEBUG - 2022-07-03 06:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:17:03 --> Total execution time: 0.0651
DEBUG - 2022-07-03 06:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:17:08 --> Total execution time: 0.0679
DEBUG - 2022-07-03 06:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:17:12 --> Total execution time: 0.0470
DEBUG - 2022-07-03 06:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:47:43 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:17:43 --> Total execution time: 0.0685
DEBUG - 2022-07-03 06:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:47:52 --> Total execution time: 0.0493
DEBUG - 2022-07-03 06:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:47:54 --> Total execution time: 0.0538
DEBUG - 2022-07-03 06:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:47:54 --> Total execution time: 0.0980
DEBUG - 2022-07-03 06:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:49:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 06:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:19:18 --> Total execution time: 1.5857
DEBUG - 2022-07-03 06:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 06:49:38 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 06:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:52:09 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:22:09 --> Total execution time: 0.1523
DEBUG - 2022-07-03 06:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:54:42 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:24:43 --> Total execution time: 0.0935
DEBUG - 2022-07-03 06:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:54:43 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:24:43 --> Total execution time: 0.0370
DEBUG - 2022-07-03 06:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:24:45 --> Total execution time: 0.0391
DEBUG - 2022-07-03 06:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:25:01 --> Total execution time: 0.0816
DEBUG - 2022-07-03 06:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:25:14 --> Total execution time: 0.0903
DEBUG - 2022-07-03 06:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:25:28 --> Total execution time: 0.0739
DEBUG - 2022-07-03 06:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:25:32 --> Total execution time: 0.0509
DEBUG - 2022-07-03 06:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:25:35 --> Total execution time: 0.0725
DEBUG - 2022-07-03 06:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:25:46 --> Total execution time: 0.0893
DEBUG - 2022-07-03 06:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:25:50 --> Total execution time: 0.0792
DEBUG - 2022-07-03 06:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:25:53 --> Total execution time: 0.0725
DEBUG - 2022-07-03 06:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:26:04 --> Total execution time: 0.0757
DEBUG - 2022-07-03 06:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:26:10 --> Total execution time: 0.0482
DEBUG - 2022-07-03 06:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:26:59 --> Total execution time: 0.0517
DEBUG - 2022-07-03 06:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 06:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:27:59 --> Total execution time: 0.0497
DEBUG - 2022-07-03 06:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 06:59:21 --> No URI present. Default controller set.
DEBUG - 2022-07-03 06:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 06:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:29:21 --> Total execution time: 0.1182
DEBUG - 2022-07-03 07:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:30:05 --> Total execution time: 0.0666
DEBUG - 2022-07-03 07:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:31:58 --> Total execution time: 0.1195
DEBUG - 2022-07-03 07:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:32:14 --> Total execution time: 0.0944
DEBUG - 2022-07-03 07:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:32:19 --> Total execution time: 0.0893
DEBUG - 2022-07-03 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:32:26 --> Total execution time: 0.0315
DEBUG - 2022-07-03 07:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:32:36 --> Total execution time: 0.0562
DEBUG - 2022-07-03 07:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:33:20 --> Total execution time: 0.0351
DEBUG - 2022-07-03 07:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:08:01 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:38:01 --> Total execution time: 0.2454
DEBUG - 2022-07-03 07:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:38:11 --> Total execution time: 1.5566
DEBUG - 2022-07-03 07:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:08:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 07:08:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 07:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:38:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 07:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:38:48 --> Total execution time: 0.0559
DEBUG - 2022-07-03 07:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:38:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 17:38:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 17:38:49 --> Total execution time: 0.1932
DEBUG - 2022-07-03 07:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:38:52 --> Total execution time: 0.0559
DEBUG - 2022-07-03 07:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:38:56 --> Total execution time: 0.0610
DEBUG - 2022-07-03 07:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:39:04 --> Total execution time: 0.0502
DEBUG - 2022-07-03 07:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:39:08 --> Total execution time: 0.0756
DEBUG - 2022-07-03 07:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:39:17 --> Total execution time: 0.0526
DEBUG - 2022-07-03 07:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:39:50 --> Total execution time: 0.0591
DEBUG - 2022-07-03 07:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:39:52 --> Total execution time: 0.0475
DEBUG - 2022-07-03 07:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:40:07 --> Total execution time: 0.0651
DEBUG - 2022-07-03 07:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:40:11 --> Total execution time: 0.2453
DEBUG - 2022-07-03 07:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:40:18 --> Total execution time: 0.0489
DEBUG - 2022-07-03 07:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:40:21 --> Total execution time: 0.0460
DEBUG - 2022-07-03 07:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:40:23 --> Total execution time: 0.0469
DEBUG - 2022-07-03 07:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:12:37 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:42:37 --> Total execution time: 0.2469
DEBUG - 2022-07-03 07:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:42:52 --> Total execution time: 0.0798
DEBUG - 2022-07-03 07:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:42:54 --> Total execution time: 0.0634
DEBUG - 2022-07-03 07:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:43:03 --> Total execution time: 0.0805
DEBUG - 2022-07-03 07:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:43:07 --> Total execution time: 0.0779
DEBUG - 2022-07-03 07:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:43:12 --> Total execution time: 0.0713
DEBUG - 2022-07-03 07:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:47:52 --> Total execution time: 0.1311
DEBUG - 2022-07-03 07:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:48:28 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 07:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:48:28 --> Total execution time: 0.1003
DEBUG - 2022-07-03 07:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:48:34 --> Total execution time: 0.0714
DEBUG - 2022-07-03 07:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:18:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 07:18:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 07:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:49:04 --> Total execution time: 0.0590
DEBUG - 2022-07-03 07:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:49:10 --> Total execution time: 0.0497
DEBUG - 2022-07-03 07:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:49:15 --> Total execution time: 0.0736
DEBUG - 2022-07-03 07:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:49:16 --> Total execution time: 0.0760
DEBUG - 2022-07-03 07:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:50:49 --> Total execution time: 0.0560
DEBUG - 2022-07-03 07:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:21:49 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:51:49 --> Total execution time: 0.0429
DEBUG - 2022-07-03 07:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:51:59 --> Total execution time: 0.0467
DEBUG - 2022-07-03 07:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:52:23 --> Total execution time: 0.0527
DEBUG - 2022-07-03 07:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:52:23 --> Total execution time: 0.0510
DEBUG - 2022-07-03 07:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:52:35 --> Total execution time: 0.0611
DEBUG - 2022-07-03 07:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:52:44 --> Total execution time: 0.0606
DEBUG - 2022-07-03 07:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:53:01 --> Total execution time: 0.0711
DEBUG - 2022-07-03 07:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:53:21 --> Total execution time: 0.0468
DEBUG - 2022-07-03 07:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:53:24 --> Total execution time: 0.0679
DEBUG - 2022-07-03 07:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:53:25 --> Total execution time: 0.0772
DEBUG - 2022-07-03 07:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:53:32 --> Total execution time: 0.0515
DEBUG - 2022-07-03 07:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:53:33 --> Total execution time: 0.0519
DEBUG - 2022-07-03 07:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:53:50 --> Total execution time: 0.0592
DEBUG - 2022-07-03 07:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:53:53 --> Total execution time: 0.0792
DEBUG - 2022-07-03 07:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:54:14 --> Total execution time: 0.1782
DEBUG - 2022-07-03 07:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:24:32 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:54:32 --> Total execution time: 0.0357
DEBUG - 2022-07-03 07:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:54:41 --> Total execution time: 0.0507
DEBUG - 2022-07-03 07:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:54:51 --> Total execution time: 0.1066
DEBUG - 2022-07-03 07:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:54:53 --> Total execution time: 0.0761
DEBUG - 2022-07-03 07:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:24:58 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:54:58 --> Total execution time: 0.0347
DEBUG - 2022-07-03 07:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:55:08 --> Total execution time: 0.0681
DEBUG - 2022-07-03 07:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:55:13 --> Total execution time: 0.1426
DEBUG - 2022-07-03 07:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:25:43 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:55:44 --> Total execution time: 0.0578
DEBUG - 2022-07-03 07:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:55:45 --> Total execution time: 0.0737
DEBUG - 2022-07-03 07:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:55:51 --> Total execution time: 0.0434
DEBUG - 2022-07-03 07:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:56:07 --> Total execution time: 0.0721
DEBUG - 2022-07-03 07:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:56:08 --> Total execution time: 0.1026
DEBUG - 2022-07-03 07:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:56:16 --> Total execution time: 0.0676
DEBUG - 2022-07-03 07:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:56:20 --> Total execution time: 0.6888
DEBUG - 2022-07-03 07:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:56:22 --> Total execution time: 0.0426
DEBUG - 2022-07-03 07:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:56:33 --> Total execution time: 0.0592
DEBUG - 2022-07-03 07:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:56:47 --> Total execution time: 0.0589
DEBUG - 2022-07-03 07:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:56:48 --> Total execution time: 0.0453
DEBUG - 2022-07-03 07:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:56:52 --> Total execution time: 0.0851
DEBUG - 2022-07-03 07:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:57:03 --> Total execution time: 0.1841
DEBUG - 2022-07-03 07:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:57:35 --> Total execution time: 0.0697
DEBUG - 2022-07-03 07:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:57:39 --> Total execution time: 0.0494
DEBUG - 2022-07-03 07:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:41 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:57:41 --> Total execution time: 0.0353
DEBUG - 2022-07-03 07:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:57:42 --> Total execution time: 0.0312
DEBUG - 2022-07-03 07:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:57:45 --> Total execution time: 0.0326
DEBUG - 2022-07-03 07:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:57:45 --> Total execution time: 0.0646
DEBUG - 2022-07-03 07:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:45 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:57:45 --> Total execution time: 0.0363
DEBUG - 2022-07-03 07:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:57:49 --> Total execution time: 0.0517
DEBUG - 2022-07-03 07:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:57:51 --> Total execution time: 0.0503
DEBUG - 2022-07-03 07:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:57:53 --> Total execution time: 0.0366
DEBUG - 2022-07-03 07:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:57:54 --> Total execution time: 0.0599
DEBUG - 2022-07-03 07:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:57:57 --> Total execution time: 0.0719
DEBUG - 2022-07-03 07:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:58:02 --> Total execution time: 0.0874
DEBUG - 2022-07-03 07:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:58:06 --> Total execution time: 0.0515
DEBUG - 2022-07-03 07:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:58:06 --> Total execution time: 0.0764
DEBUG - 2022-07-03 07:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:58:10 --> Total execution time: 0.0520
DEBUG - 2022-07-03 07:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:58:14 --> Total execution time: 0.0454
DEBUG - 2022-07-03 07:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:58:17 --> Total execution time: 0.0478
DEBUG - 2022-07-03 07:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:37 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:58:37 --> Total execution time: 0.0535
DEBUG - 2022-07-03 07:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:40 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:58:40 --> Total execution time: 0.0340
DEBUG - 2022-07-03 07:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:42 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:58:42 --> Total execution time: 0.0355
DEBUG - 2022-07-03 07:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:28:50 --> Total execution time: 0.0488
DEBUG - 2022-07-03 07:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:28:50 --> Total execution time: 0.0470
DEBUG - 2022-07-03 07:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:28:51 --> Total execution time: 0.0523
DEBUG - 2022-07-03 07:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:28:51 --> Total execution time: 0.0645
DEBUG - 2022-07-03 07:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:28:51 --> Total execution time: 0.0889
DEBUG - 2022-07-03 07:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:28:51 --> Total execution time: 0.0847
DEBUG - 2022-07-03 07:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:59:16 --> Total execution time: 0.1222
DEBUG - 2022-07-03 07:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:00:16 --> Total execution time: 0.0481
DEBUG - 2022-07-03 07:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:00:37 --> Total execution time: 0.0712
DEBUG - 2022-07-03 07:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:00:38 --> Total execution time: 0.0850
DEBUG - 2022-07-03 07:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:00:51 --> Total execution time: 0.0499
DEBUG - 2022-07-03 07:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:00:52 --> Total execution time: 0.0594
DEBUG - 2022-07-03 07:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:01:29 --> Total execution time: 0.0549
DEBUG - 2022-07-03 07:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:01:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 07:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:01:58 --> Total execution time: 0.0441
DEBUG - 2022-07-03 07:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:01:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 18:01:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 18:01:59 --> Total execution time: 0.1828
DEBUG - 2022-07-03 07:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:33:18 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:03:18 --> Total execution time: 0.0516
DEBUG - 2022-07-03 07:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:03:30 --> Total execution time: 0.0488
DEBUG - 2022-07-03 07:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:03:36 --> Total execution time: 0.0573
DEBUG - 2022-07-03 07:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:03:40 --> Total execution time: 0.0526
DEBUG - 2022-07-03 07:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:03:46 --> Total execution time: 0.0496
DEBUG - 2022-07-03 07:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:33:47 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:03:47 --> Total execution time: 0.1323
DEBUG - 2022-07-03 07:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:03:50 --> Total execution time: 0.0501
DEBUG - 2022-07-03 07:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:03:55 --> Total execution time: 0.0480
DEBUG - 2022-07-03 07:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:04:02 --> Total execution time: 0.0715
DEBUG - 2022-07-03 07:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:04:05 --> Total execution time: 0.0566
DEBUG - 2022-07-03 07:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:04:06 --> Total execution time: 0.0546
DEBUG - 2022-07-03 07:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:04:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 07:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:04:07 --> Total execution time: 0.0475
DEBUG - 2022-07-03 07:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:04:12 --> Total execution time: 0.0475
DEBUG - 2022-07-03 07:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:04:58 --> Total execution time: 0.0505
DEBUG - 2022-07-03 07:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:35:07 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:05:07 --> Total execution time: 0.0748
DEBUG - 2022-07-03 07:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:35:48 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:05:48 --> Total execution time: 0.0364
DEBUG - 2022-07-03 07:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:35:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:05:53 --> Total execution time: 0.0641
DEBUG - 2022-07-03 07:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:36:18 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:06:18 --> Total execution time: 0.0348
DEBUG - 2022-07-03 07:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:06:24 --> Total execution time: 0.0389
DEBUG - 2022-07-03 07:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:06:27 --> Total execution time: 0.1323
DEBUG - 2022-07-03 07:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:06:52 --> Total execution time: 0.0661
DEBUG - 2022-07-03 07:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:06:53 --> Total execution time: 0.0779
DEBUG - 2022-07-03 07:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:06:58 --> Total execution time: 0.0756
DEBUG - 2022-07-03 07:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:06:58 --> Total execution time: 0.1552
DEBUG - 2022-07-03 07:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:06:59 --> Total execution time: 0.0836
DEBUG - 2022-07-03 07:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:06:59 --> Total execution time: 0.0691
DEBUG - 2022-07-03 07:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:07:00 --> Total execution time: 0.0599
DEBUG - 2022-07-03 07:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:07:00 --> Total execution time: 0.1133
DEBUG - 2022-07-03 07:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:07:09 --> Total execution time: 0.7081
DEBUG - 2022-07-03 07:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:07:17 --> Total execution time: 0.0542
DEBUG - 2022-07-03 07:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:07:49 --> Total execution time: 0.0985
DEBUG - 2022-07-03 07:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:08:08 --> Total execution time: 0.0521
DEBUG - 2022-07-03 07:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:08:08 --> Total execution time: 0.0490
DEBUG - 2022-07-03 07:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:38:08 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:08:08 --> Total execution time: 0.0528
DEBUG - 2022-07-03 07:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:08:12 --> Total execution time: 0.0717
DEBUG - 2022-07-03 07:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:08:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 07:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:08:20 --> Total execution time: 0.0687
DEBUG - 2022-07-03 07:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:08:33 --> Total execution time: 0.1384
DEBUG - 2022-07-03 07:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:08:34 --> Total execution time: 0.0476
DEBUG - 2022-07-03 07:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:08:48 --> Total execution time: 0.0607
DEBUG - 2022-07-03 07:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:08:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 07:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:08:49 --> Total execution time: 0.0514
DEBUG - 2022-07-03 07:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:09:31 --> Total execution time: 0.0532
DEBUG - 2022-07-03 07:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:41:26 --> Total execution time: 0.0564
DEBUG - 2022-07-03 07:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:12:07 --> Total execution time: 0.0540
DEBUG - 2022-07-03 07:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:42:11 --> Total execution time: 0.0667
DEBUG - 2022-07-03 07:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:12:16 --> Total execution time: 0.0581
DEBUG - 2022-07-03 07:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:12:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 07:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:12:17 --> Total execution time: 0.0467
DEBUG - 2022-07-03 07:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:12:40 --> Total execution time: 0.1008
DEBUG - 2022-07-03 07:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:12:58 --> Total execution time: 0.0617
DEBUG - 2022-07-03 07:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:14:29 --> Total execution time: 0.0569
DEBUG - 2022-07-03 07:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:14:47 --> Total execution time: 0.0612
DEBUG - 2022-07-03 07:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:14:54 --> Total execution time: 0.0686
DEBUG - 2022-07-03 07:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:15:18 --> Total execution time: 0.0703
DEBUG - 2022-07-03 07:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:15:19 --> Total execution time: 0.0508
DEBUG - 2022-07-03 07:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:50:14 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:20:14 --> Total execution time: 0.1169
DEBUG - 2022-07-03 07:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:20:15 --> Total execution time: 0.1219
DEBUG - 2022-07-03 07:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:20:23 --> Total execution time: 0.0533
DEBUG - 2022-07-03 07:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:50:24 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:20:24 --> Total execution time: 0.0343
DEBUG - 2022-07-03 07:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:20:30 --> Total execution time: 0.0606
DEBUG - 2022-07-03 07:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:20:38 --> Total execution time: 0.1048
DEBUG - 2022-07-03 07:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:20:51 --> Total execution time: 0.0990
DEBUG - 2022-07-03 07:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:50:58 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:20:58 --> Total execution time: 0.0292
DEBUG - 2022-07-03 07:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:21:12 --> Total execution time: 0.0536
DEBUG - 2022-07-03 07:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:21:14 --> Total execution time: 0.0556
DEBUG - 2022-07-03 07:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:51:18 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:21:18 --> Total execution time: 0.0445
DEBUG - 2022-07-03 07:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:21:22 --> Total execution time: 0.0528
DEBUG - 2022-07-03 07:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:21:41 --> Total execution time: 0.0617
DEBUG - 2022-07-03 07:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:21:53 --> Total execution time: 0.0502
DEBUG - 2022-07-03 07:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:21:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 07:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:21:54 --> Total execution time: 0.0498
DEBUG - 2022-07-03 07:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 07:52:34 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-03 07:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:22:58 --> Total execution time: 0.1326
DEBUG - 2022-07-03 07:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:24:16 --> Total execution time: 0.7597
DEBUG - 2022-07-03 07:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 07:55:04 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 07:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:25:31 --> Total execution time: 0.0584
DEBUG - 2022-07-03 07:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:25:37 --> Total execution time: 0.0528
DEBUG - 2022-07-03 07:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:25:38 --> Total execution time: 0.0535
DEBUG - 2022-07-03 07:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:56:56 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:26:56 --> Total execution time: 0.0447
DEBUG - 2022-07-03 07:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:56:57 --> No URI present. Default controller set.
DEBUG - 2022-07-03 07:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:26:57 --> Total execution time: 0.0490
DEBUG - 2022-07-03 07:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:27:00 --> Total execution time: 0.1400
DEBUG - 2022-07-03 07:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:27:05 --> Total execution time: 0.0766
DEBUG - 2022-07-03 07:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:57:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 07:57:06 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-03 07:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:27:07 --> Total execution time: 0.0466
DEBUG - 2022-07-03 07:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:27:36 --> Total execution time: 0.0560
DEBUG - 2022-07-03 07:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:27:40 --> Total execution time: 0.0586
DEBUG - 2022-07-03 07:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:27:48 --> Total execution time: 0.0758
DEBUG - 2022-07-03 07:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 07:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:27:59 --> Total execution time: 0.0513
DEBUG - 2022-07-03 07:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:28:02 --> Total execution time: 0.1189
DEBUG - 2022-07-03 07:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 07:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 07:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:28:06 --> Total execution time: 0.0548
DEBUG - 2022-07-03 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:30:02 --> Total execution time: 0.0415
DEBUG - 2022-07-03 08:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:00:05 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:30:05 --> Total execution time: 0.0597
DEBUG - 2022-07-03 08:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:30:08 --> Total execution time: 0.0675
DEBUG - 2022-07-03 08:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:30:19 --> Total execution time: 0.0540
DEBUG - 2022-07-03 08:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:30:25 --> Total execution time: 0.0523
DEBUG - 2022-07-03 08:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:30:37 --> Total execution time: 0.0489
DEBUG - 2022-07-03 08:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:30:42 --> Total execution time: 0.0509
DEBUG - 2022-07-03 08:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:30:50 --> Total execution time: 0.0654
DEBUG - 2022-07-03 08:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:30:53 --> Total execution time: 0.0505
DEBUG - 2022-07-03 08:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:30:56 --> Total execution time: 0.0548
DEBUG - 2022-07-03 08:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:30:58 --> Total execution time: 0.0475
DEBUG - 2022-07-03 08:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:30:59 --> Total execution time: 0.0519
DEBUG - 2022-07-03 08:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:01:01 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:31:01 --> Total execution time: 0.0904
DEBUG - 2022-07-03 08:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:31:05 --> Total execution time: 0.0495
DEBUG - 2022-07-03 08:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:31:09 --> Total execution time: 0.0475
DEBUG - 2022-07-03 08:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:01:10 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:31:10 --> Total execution time: 0.0513
DEBUG - 2022-07-03 08:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:31:16 --> Total execution time: 0.1165
DEBUG - 2022-07-03 08:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:31:17 --> Total execution time: 0.0459
DEBUG - 2022-07-03 08:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:31:32 --> Total execution time: 0.0596
DEBUG - 2022-07-03 08:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:02:03 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:32:03 --> Total execution time: 0.0619
DEBUG - 2022-07-03 08:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:02:05 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:32:05 --> Total execution time: 0.0364
DEBUG - 2022-07-03 08:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:02:06 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:32:06 --> Total execution time: 0.0340
DEBUG - 2022-07-03 08:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:32:06 --> Total execution time: 0.0692
DEBUG - 2022-07-03 08:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:32:10 --> Total execution time: 0.0607
DEBUG - 2022-07-03 08:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:32:13 --> Total execution time: 0.0490
DEBUG - 2022-07-03 08:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:33:03 --> Total execution time: 0.0558
DEBUG - 2022-07-03 08:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:03:15 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:33:15 --> Total execution time: 0.0477
DEBUG - 2022-07-03 08:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:03:16 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:33:16 --> Total execution time: 0.1364
DEBUG - 2022-07-03 08:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:03:23 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:33:23 --> Total execution time: 0.0522
DEBUG - 2022-07-03 08:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:33:29 --> Total execution time: 0.0514
DEBUG - 2022-07-03 08:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:33:30 --> Total execution time: 0.0478
DEBUG - 2022-07-03 08:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:33:32 --> Total execution time: 0.0711
DEBUG - 2022-07-03 08:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:33:37 --> Total execution time: 0.0556
DEBUG - 2022-07-03 08:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:33:40 --> Total execution time: 0.0580
DEBUG - 2022-07-03 08:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:33:56 --> Total execution time: 0.0565
DEBUG - 2022-07-03 08:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:04:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:34:11 --> Total execution time: 0.0608
DEBUG - 2022-07-03 08:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:34:40 --> Total execution time: 0.0528
DEBUG - 2022-07-03 08:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:34:47 --> Total execution time: 0.0507
DEBUG - 2022-07-03 08:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:34:49 --> Total execution time: 0.0510
DEBUG - 2022-07-03 08:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:35:02 --> Total execution time: 0.0610
DEBUG - 2022-07-03 08:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:05:29 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:35:29 --> Total execution time: 0.0353
DEBUG - 2022-07-03 08:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:35:33 --> Total execution time: 0.1182
DEBUG - 2022-07-03 08:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:35:41 --> Total execution time: 0.0505
DEBUG - 2022-07-03 08:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:35:48 --> Total execution time: 0.0601
DEBUG - 2022-07-03 08:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:35:52 --> Total execution time: 0.0616
DEBUG - 2022-07-03 08:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:36:04 --> Total execution time: 0.0561
DEBUG - 2022-07-03 08:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:36:08 --> Total execution time: 0.0503
DEBUG - 2022-07-03 08:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:36:26 --> Total execution time: 0.1447
DEBUG - 2022-07-03 08:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:36:34 --> Total execution time: 0.0589
DEBUG - 2022-07-03 08:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:36:37 --> Total execution time: 0.0593
DEBUG - 2022-07-03 08:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:36:45 --> Total execution time: 0.0484
DEBUG - 2022-07-03 08:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:37:45 --> Total execution time: 0.0517
DEBUG - 2022-07-03 08:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:37:52 --> Total execution time: 0.0474
DEBUG - 2022-07-03 08:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:38:04 --> Total execution time: 0.0525
DEBUG - 2022-07-03 08:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:38:10 --> Total execution time: 0.0745
DEBUG - 2022-07-03 08:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:38:22 --> Total execution time: 0.0555
DEBUG - 2022-07-03 08:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:38:32 --> Total execution time: 0.0896
DEBUG - 2022-07-03 08:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:38:33 --> Total execution time: 0.0542
DEBUG - 2022-07-03 08:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:38:39 --> Total execution time: 0.0510
DEBUG - 2022-07-03 08:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:08:42 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:38:42 --> Total execution time: 0.0641
DEBUG - 2022-07-03 08:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:38:46 --> Total execution time: 0.0501
DEBUG - 2022-07-03 08:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:39:06 --> Total execution time: 0.0734
DEBUG - 2022-07-03 08:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:39:25 --> Total execution time: 0.0750
DEBUG - 2022-07-03 08:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:09:35 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:39:35 --> Total execution time: 0.1253
DEBUG - 2022-07-03 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:09:38 --> Total execution time: 0.0472
DEBUG - 2022-07-03 08:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:09:43 --> Total execution time: 0.0798
DEBUG - 2022-07-03 08:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:09:50 --> Total execution time: 0.0461
DEBUG - 2022-07-03 08:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:10:04 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:40:04 --> Total execution time: 0.0498
DEBUG - 2022-07-03 08:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:40:13 --> Total execution time: 0.0787
DEBUG - 2022-07-03 08:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:40:23 --> Total execution time: 0.0594
DEBUG - 2022-07-03 08:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:10:38 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:40:38 --> Total execution time: 0.0337
DEBUG - 2022-07-03 08:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:40:42 --> Total execution time: 0.0494
DEBUG - 2022-07-03 08:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:10:48 --> Total execution time: 0.0471
DEBUG - 2022-07-03 08:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:10:53 --> Total execution time: 0.0499
DEBUG - 2022-07-03 08:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:11:12 --> Total execution time: 0.0517
DEBUG - 2022-07-03 08:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:11:12 --> Total execution time: 0.1157
DEBUG - 2022-07-03 08:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:12:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 08:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:42:49 --> Total execution time: 1.5119
DEBUG - 2022-07-03 08:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:12:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 08:12:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 08:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:43:20 --> Total execution time: 0.1434
DEBUG - 2022-07-03 08:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:43:22 --> Total execution time: 0.0748
DEBUG - 2022-07-03 08:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:43:48 --> Total execution time: 0.1271
DEBUG - 2022-07-03 08:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:13:50 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:43:50 --> Total execution time: 0.0528
DEBUG - 2022-07-03 08:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:43:50 --> Total execution time: 0.0532
DEBUG - 2022-07-03 08:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:43:59 --> Total execution time: 0.0514
DEBUG - 2022-07-03 08:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:44:03 --> Total execution time: 0.0727
DEBUG - 2022-07-03 08:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:44:14 --> Total execution time: 0.0459
DEBUG - 2022-07-03 08:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:15 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:44:15 --> Total execution time: 0.0526
DEBUG - 2022-07-03 08:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:44:17 --> Total execution time: 0.0409
DEBUG - 2022-07-03 08:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:39 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:44:40 --> Total execution time: 0.0500
DEBUG - 2022-07-03 08:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:44:43 --> Total execution time: 0.0458
DEBUG - 2022-07-03 08:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:44:44 --> Total execution time: 0.0487
DEBUG - 2022-07-03 08:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:44:45 --> Total execution time: 0.0523
DEBUG - 2022-07-03 08:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:44:46 --> Total execution time: 0.0467
DEBUG - 2022-07-03 08:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:44:52 --> Total execution time: 0.0586
DEBUG - 2022-07-03 08:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:44:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 08:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:44:54 --> Total execution time: 0.0574
DEBUG - 2022-07-03 08:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:44:54 --> Total execution time: 0.0528
DEBUG - 2022-07-03 08:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:44:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 18:44:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 18:44:56 --> Total execution time: 0.2021
DEBUG - 2022-07-03 08:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:45:04 --> Total execution time: 0.0561
DEBUG - 2022-07-03 08:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:45:32 --> Total execution time: 0.0899
DEBUG - 2022-07-03 08:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:45:51 --> Total execution time: 0.0698
DEBUG - 2022-07-03 08:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:16:20 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:46:20 --> Total execution time: 0.0529
DEBUG - 2022-07-03 08:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:46:36 --> Total execution time: 0.0531
DEBUG - 2022-07-03 08:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:16:50 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:46:50 --> Total execution time: 0.0561
DEBUG - 2022-07-03 08:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:46:54 --> Total execution time: 0.0494
DEBUG - 2022-07-03 08:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:47:09 --> Total execution time: 0.0454
DEBUG - 2022-07-03 08:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:47:43 --> Total execution time: 0.0466
DEBUG - 2022-07-03 08:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:48:17 --> Total execution time: 0.0536
DEBUG - 2022-07-03 08:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:48:40 --> Total execution time: 0.0458
DEBUG - 2022-07-03 08:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:18:40 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:48:40 --> Total execution time: 0.1181
DEBUG - 2022-07-03 08:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:48:44 --> Total execution time: 0.0469
DEBUG - 2022-07-03 08:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:48:54 --> Total execution time: 0.0640
DEBUG - 2022-07-03 08:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:48:59 --> Total execution time: 0.0658
DEBUG - 2022-07-03 08:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:49:03 --> Total execution time: 0.0486
DEBUG - 2022-07-03 08:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:49:06 --> Total execution time: 0.0467
DEBUG - 2022-07-03 08:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:49:22 --> Total execution time: 0.0528
DEBUG - 2022-07-03 08:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:19:25 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:49:26 --> Total execution time: 0.1618
DEBUG - 2022-07-03 08:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:49:27 --> Total execution time: 0.0583
DEBUG - 2022-07-03 08:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:49:30 --> Total execution time: 0.0792
DEBUG - 2022-07-03 08:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:49:46 --> Total execution time: 0.0548
DEBUG - 2022-07-03 08:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:49:47 --> Total execution time: 0.0613
DEBUG - 2022-07-03 08:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:49:50 --> Total execution time: 0.0539
DEBUG - 2022-07-03 08:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:50:04 --> Total execution time: 0.0500
DEBUG - 2022-07-03 08:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:50:15 --> Total execution time: 0.0620
DEBUG - 2022-07-03 08:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 08:20:24 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-03 08:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:50:29 --> Total execution time: 0.0567
DEBUG - 2022-07-03 08:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:50:41 --> Total execution time: 0.0535
DEBUG - 2022-07-03 08:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:51:05 --> Total execution time: 0.0550
DEBUG - 2022-07-03 08:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:51:06 --> Total execution time: 0.0599
DEBUG - 2022-07-03 08:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:51:07 --> Total execution time: 0.0677
DEBUG - 2022-07-03 08:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:22:44 --> Total execution time: 0.0610
DEBUG - 2022-07-03 08:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:22:51 --> Total execution time: 0.1124
DEBUG - 2022-07-03 08:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:53:58 --> Total execution time: 0.1224
DEBUG - 2022-07-03 08:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:54:20 --> Total execution time: 0.0718
DEBUG - 2022-07-03 08:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:55:55 --> Total execution time: 0.0504
DEBUG - 2022-07-03 08:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:56:11 --> Total execution time: 0.0747
DEBUG - 2022-07-03 08:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:56:21 --> Total execution time: 0.0524
DEBUG - 2022-07-03 08:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:56:34 --> Total execution time: 0.0846
DEBUG - 2022-07-03 08:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:56:56 --> Total execution time: 0.1204
DEBUG - 2022-07-03 08:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:59:02 --> Total execution time: 0.1150
DEBUG - 2022-07-03 08:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:59:11 --> Total execution time: 0.1277
DEBUG - 2022-07-03 08:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:59:13 --> Total execution time: 0.0529
DEBUG - 2022-07-03 08:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:59:16 --> Total execution time: 0.0677
DEBUG - 2022-07-03 08:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:59:24 --> Total execution time: 0.0553
DEBUG - 2022-07-03 08:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:02:17 --> Total execution time: 0.2266
DEBUG - 2022-07-03 08:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:06:32 --> Total execution time: 0.0842
DEBUG - 2022-07-03 08:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:13:08 --> Total execution time: 0.1162
DEBUG - 2022-07-03 08:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:13:50 --> Total execution time: 0.0551
DEBUG - 2022-07-03 08:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:47:34 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:17:34 --> Total execution time: 0.1100
DEBUG - 2022-07-03 08:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:50:02 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:20:02 --> Total execution time: 0.0901
DEBUG - 2022-07-03 08:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:50:26 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:20:26 --> Total execution time: 0.0505
DEBUG - 2022-07-03 08:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:20:31 --> Total execution time: 0.0476
DEBUG - 2022-07-03 08:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:20:34 --> Total execution time: 0.0476
DEBUG - 2022-07-03 08:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:20:41 --> Total execution time: 0.0471
DEBUG - 2022-07-03 08:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:20:51 --> Total execution time: 0.0618
DEBUG - 2022-07-03 08:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:21:02 --> Total execution time: 0.0518
DEBUG - 2022-07-03 08:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:51:49 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:21:49 --> Total execution time: 0.0362
DEBUG - 2022-07-03 08:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:21:53 --> Total execution time: 0.0349
DEBUG - 2022-07-03 08:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:22:01 --> Total execution time: 0.0668
DEBUG - 2022-07-03 08:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:22:05 --> Total execution time: 0.0610
DEBUG - 2022-07-03 08:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:22:16 --> Total execution time: 0.0806
DEBUG - 2022-07-03 08:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:22:23 --> Total execution time: 0.1225
DEBUG - 2022-07-03 08:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:22:25 --> Total execution time: 0.0483
DEBUG - 2022-07-03 08:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:22:38 --> Total execution time: 0.0536
DEBUG - 2022-07-03 08:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:22:39 --> Total execution time: 0.0452
DEBUG - 2022-07-03 08:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:22:42 --> Total execution time: 0.0465
DEBUG - 2022-07-03 08:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:22:49 --> Total execution time: 0.0311
DEBUG - 2022-07-03 08:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:22:49 --> Total execution time: 0.0480
DEBUG - 2022-07-03 08:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:23:01 --> Total execution time: 0.0601
DEBUG - 2022-07-03 08:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:23:06 --> Total execution time: 0.0547
DEBUG - 2022-07-03 08:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:23:10 --> Total execution time: 0.0545
DEBUG - 2022-07-03 08:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:23:11 --> Total execution time: 0.0570
DEBUG - 2022-07-03 08:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:53:19 --> Total execution time: 0.0713
DEBUG - 2022-07-03 08:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:23:21 --> Total execution time: 0.0496
DEBUG - 2022-07-03 08:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:53:21 --> Total execution time: 0.0501
DEBUG - 2022-07-03 08:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:53:21 --> Total execution time: 0.1087
DEBUG - 2022-07-03 08:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:23:24 --> Total execution time: 0.0548
DEBUG - 2022-07-03 08:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:53:24 --> Total execution time: 0.0661
DEBUG - 2022-07-03 08:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:23:25 --> Total execution time: 0.0614
DEBUG - 2022-07-03 08:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:53:25 --> Total execution time: 0.0732
DEBUG - 2022-07-03 08:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:53:26 --> Total execution time: 0.1292
DEBUG - 2022-07-03 19:23:26 --> Total execution time: 0.0738
DEBUG - 2022-07-03 08:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:34 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:23:34 --> Total execution time: 0.0646
DEBUG - 2022-07-03 08:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:39 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:23:39 --> Total execution time: 0.0343
DEBUG - 2022-07-03 08:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:39 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:23:39 --> Total execution time: 0.0366
DEBUG - 2022-07-03 08:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:53:42 --> Total execution time: 0.0576
DEBUG - 2022-07-03 08:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:53:43 --> Total execution time: 0.0967
DEBUG - 2022-07-03 08:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:53:43 --> Total execution time: 0.1270
DEBUG - 2022-07-03 08:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:23:48 --> Total execution time: 0.1460
DEBUG - 2022-07-03 08:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:53:48 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:23:48 --> Total execution time: 0.0669
DEBUG - 2022-07-03 08:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:24:45 --> Total execution time: 0.0410
DEBUG - 2022-07-03 08:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:24:54 --> Total execution time: 0.0528
DEBUG - 2022-07-03 08:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:26:09 --> Total execution time: 0.0589
DEBUG - 2022-07-03 08:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:27:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 08:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:27:07 --> Total execution time: 0.0856
DEBUG - 2022-07-03 08:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:57:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 08:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:27:22 --> Total execution time: 1.5855
DEBUG - 2022-07-03 08:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 08:57:25 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 08:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:27:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 08:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:27:58 --> Total execution time: 0.0598
DEBUG - 2022-07-03 08:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:27:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 19:27:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 19:27:59 --> Total execution time: 0.2078
DEBUG - 2022-07-03 08:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:59:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:29:11 --> Total execution time: 0.1258
DEBUG - 2022-07-03 08:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:59:12 --> No URI present. Default controller set.
DEBUG - 2022-07-03 08:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:29:12 --> Total execution time: 0.0488
DEBUG - 2022-07-03 08:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:29:15 --> Total execution time: 0.0785
DEBUG - 2022-07-03 08:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:29:19 --> Total execution time: 0.0796
DEBUG - 2022-07-03 08:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:29:24 --> Total execution time: 0.0513
DEBUG - 2022-07-03 08:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:29:26 --> Total execution time: 0.0717
DEBUG - 2022-07-03 08:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:29:35 --> Total execution time: 0.0666
DEBUG - 2022-07-03 08:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:29:43 --> Total execution time: 0.0686
DEBUG - 2022-07-03 08:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:29:46 --> Total execution time: 0.0680
DEBUG - 2022-07-03 08:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:29:52 --> Total execution time: 0.0509
DEBUG - 2022-07-03 08:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 08:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:29:55 --> Total execution time: 0.0471
DEBUG - 2022-07-03 08:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 08:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 08:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:29:59 --> Total execution time: 0.0501
DEBUG - 2022-07-03 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:30:02 --> Total execution time: 0.0462
DEBUG - 2022-07-03 09:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:30:07 --> Total execution time: 0.0979
DEBUG - 2022-07-03 09:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:30:10 --> Total execution time: 0.0583
DEBUG - 2022-07-03 09:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:30:18 --> Total execution time: 0.1126
DEBUG - 2022-07-03 09:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:30:21 --> Total execution time: 0.0680
DEBUG - 2022-07-03 09:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:31:07 --> Total execution time: 0.0508
DEBUG - 2022-07-03 09:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:01:28 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:31:28 --> Total execution time: 0.0615
DEBUG - 2022-07-03 09:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:01:37 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:31:37 --> Total execution time: 0.0535
DEBUG - 2022-07-03 09:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:01:59 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:31:59 --> Total execution time: 0.0362
DEBUG - 2022-07-03 09:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:33:55 --> Total execution time: 0.0487
DEBUG - 2022-07-03 09:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:34:21 --> Total execution time: 0.1349
DEBUG - 2022-07-03 09:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:34:43 --> Total execution time: 0.0709
DEBUG - 2022-07-03 09:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:34:43 --> Total execution time: 0.0517
DEBUG - 2022-07-03 09:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:06:15 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:36:15 --> Total execution time: 0.0330
DEBUG - 2022-07-03 09:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:42:29 --> Total execution time: 0.2115
DEBUG - 2022-07-03 09:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:43:02 --> Total execution time: 0.0486
DEBUG - 2022-07-03 09:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:43:07 --> Total execution time: 0.0606
DEBUG - 2022-07-03 09:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:43:11 --> Total execution time: 0.0788
DEBUG - 2022-07-03 09:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:43:20 --> Total execution time: 0.0783
DEBUG - 2022-07-03 09:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:44:37 --> Total execution time: 0.0590
DEBUG - 2022-07-03 09:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:44:41 --> Total execution time: 0.0648
DEBUG - 2022-07-03 09:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:44:48 --> Total execution time: 0.0592
DEBUG - 2022-07-03 09:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:19:24 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:49:24 --> Total execution time: 0.2256
DEBUG - 2022-07-03 09:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:49:29 --> Total execution time: 0.1197
DEBUG - 2022-07-03 09:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:49:34 --> Total execution time: 0.0580
DEBUG - 2022-07-03 09:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:49:38 --> Total execution time: 0.0589
DEBUG - 2022-07-03 09:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:49:40 --> Total execution time: 0.0847
DEBUG - 2022-07-03 09:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:50:29 --> Total execution time: 0.0360
DEBUG - 2022-07-03 09:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:50:29 --> Total execution time: 0.1142
DEBUG - 2022-07-03 09:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:20:30 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:50:30 --> Total execution time: 0.0307
DEBUG - 2022-07-03 09:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:51:13 --> Total execution time: 0.1225
DEBUG - 2022-07-03 09:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:51:49 --> Total execution time: 0.0350
DEBUG - 2022-07-03 09:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:52:07 --> Total execution time: 0.0600
DEBUG - 2022-07-03 09:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:52:23 --> Total execution time: 0.0553
DEBUG - 2022-07-03 09:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:22:38 --> Total execution time: 0.0525
DEBUG - 2022-07-03 09:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:22:40 --> Total execution time: 0.0731
DEBUG - 2022-07-03 09:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:22:40 --> Total execution time: 0.0705
DEBUG - 2022-07-03 09:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:24:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 09:24:15 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-03 09:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:24:15 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:54:15 --> Total execution time: 0.0371
DEBUG - 2022-07-03 09:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:54:46 --> Total execution time: 0.0518
DEBUG - 2022-07-03 09:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:26:23 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:56:23 --> Total execution time: 0.0338
DEBUG - 2022-07-03 09:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:26:44 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:56:44 --> Total execution time: 0.0501
DEBUG - 2022-07-03 09:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:28:09 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:58:10 --> Total execution time: 0.0720
DEBUG - 2022-07-03 09:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:59:39 --> Total execution time: 0.0510
DEBUG - 2022-07-03 09:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:32:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 09:32:06 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-03 09:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:04:25 --> Total execution time: 0.0645
DEBUG - 2022-07-03 09:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:04:28 --> Total execution time: 0.0608
DEBUG - 2022-07-03 09:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:34:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 09:34:40 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 09:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:05:02 --> Total execution time: 0.0720
DEBUG - 2022-07-03 09:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:05:08 --> Total execution time: 0.0638
DEBUG - 2022-07-03 09:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:05:15 --> Total execution time: 0.0583
DEBUG - 2022-07-03 09:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:05:19 --> Total execution time: 0.0536
DEBUG - 2022-07-03 09:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:05:22 --> Total execution time: 0.0770
DEBUG - 2022-07-03 09:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:05:29 --> Total execution time: 0.0535
DEBUG - 2022-07-03 09:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:05:57 --> Total execution time: 0.0768
DEBUG - 2022-07-03 09:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:05:57 --> Total execution time: 0.0630
DEBUG - 2022-07-03 09:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:36:16 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:06:16 --> Total execution time: 0.0434
DEBUG - 2022-07-03 09:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:36:17 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:06:17 --> Total execution time: 0.0346
DEBUG - 2022-07-03 09:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:36:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 09:36:43 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-03 09:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:36:48 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:06:48 --> Total execution time: 0.0459
DEBUG - 2022-07-03 09:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:37:20 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:07:20 --> Total execution time: 0.0706
DEBUG - 2022-07-03 09:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:07:30 --> Total execution time: 0.0465
DEBUG - 2022-07-03 09:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:07:38 --> Total execution time: 0.0495
DEBUG - 2022-07-03 09:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:07:52 --> Total execution time: 0.0334
DEBUG - 2022-07-03 09:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:09:43 --> Total execution time: 0.0319
DEBUG - 2022-07-03 09:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:09:44 --> Total execution time: 0.0534
DEBUG - 2022-07-03 09:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:09:50 --> Total execution time: 0.0530
DEBUG - 2022-07-03 09:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:40:05 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:10:05 --> Total execution time: 0.1262
DEBUG - 2022-07-03 09:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:10:32 --> Total execution time: 0.0530
DEBUG - 2022-07-03 09:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:10:39 --> Total execution time: 0.0471
DEBUG - 2022-07-03 09:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:40:43 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:10:43 --> Total execution time: 0.0623
DEBUG - 2022-07-03 09:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:12:17 --> Total execution time: 0.0491
DEBUG - 2022-07-03 09:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:12:22 --> Total execution time: 0.1312
DEBUG - 2022-07-03 09:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:12:33 --> Total execution time: 0.0549
DEBUG - 2022-07-03 09:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:12:39 --> Total execution time: 0.0535
DEBUG - 2022-07-03 09:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:12:58 --> Total execution time: 0.0540
DEBUG - 2022-07-03 09:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:12:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 09:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:12:59 --> Total execution time: 0.0529
DEBUG - 2022-07-03 09:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:15:40 --> Total execution time: 0.1156
DEBUG - 2022-07-03 09:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:46:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 09:46:48 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-03 09:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:48:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:18:11 --> Total execution time: 0.1185
DEBUG - 2022-07-03 09:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:48:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 09:48:12 --> 404 Page Not Found: Test_404_page/index
DEBUG - 2022-07-03 09:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:51:38 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:21:39 --> Total execution time: 0.1233
DEBUG - 2022-07-03 09:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:52:18 --> No URI present. Default controller set.
DEBUG - 2022-07-03 09:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:22:18 --> Total execution time: 0.0354
DEBUG - 2022-07-03 09:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 09:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 09:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 09:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:29:31 --> Total execution time: 0.0493
DEBUG - 2022-07-03 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:30:02 --> Total execution time: 0.0428
DEBUG - 2022-07-03 10:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:00:40 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:30:40 --> Total execution time: 0.1218
DEBUG - 2022-07-03 10:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:00:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 10:00:42 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-03 10:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:03:37 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:33:37 --> Total execution time: 0.1051
DEBUG - 2022-07-03 10:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:33:41 --> Total execution time: 0.0388
DEBUG - 2022-07-03 10:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:33:50 --> Total execution time: 0.0788
DEBUG - 2022-07-03 10:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:33:56 --> Total execution time: 0.0724
DEBUG - 2022-07-03 10:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:34:04 --> Total execution time: 0.0621
DEBUG - 2022-07-03 10:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:34:31 --> Total execution time: 0.0565
DEBUG - 2022-07-03 10:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:05:07 --> Total execution time: 0.0338
DEBUG - 2022-07-03 10:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:05:41 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:35:41 --> Total execution time: 0.0406
DEBUG - 2022-07-03 10:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:36:13 --> Total execution time: 0.1205
DEBUG - 2022-07-03 10:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:15:45 --> Total execution time: 0.0634
DEBUG - 2022-07-03 10:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:18:07 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:48:07 --> Total execution time: 0.1125
DEBUG - 2022-07-03 10:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:18:12 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:48:12 --> Total execution time: 0.0337
DEBUG - 2022-07-03 10:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:30:09 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:00:10 --> Total execution time: 0.1167
DEBUG - 2022-07-03 10:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:00:19 --> Total execution time: 0.0527
DEBUG - 2022-07-03 10:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:01:12 --> Total execution time: 0.0785
DEBUG - 2022-07-03 10:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:01:26 --> Total execution time: 0.0768
DEBUG - 2022-07-03 10:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:01:31 --> Total execution time: 0.0654
DEBUG - 2022-07-03 10:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:01:36 --> Total execution time: 0.0501
DEBUG - 2022-07-03 10:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:33:21 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:03:21 --> Total execution time: 0.0351
DEBUG - 2022-07-03 10:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:03:31 --> Total execution time: 0.0532
DEBUG - 2022-07-03 10:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:04:22 --> Total execution time: 0.0560
DEBUG - 2022-07-03 10:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:34:41 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:04:41 --> Total execution time: 0.0346
DEBUG - 2022-07-03 10:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:34:42 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:04:42 --> Total execution time: 0.0382
DEBUG - 2022-07-03 10:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:04:46 --> Total execution time: 0.0631
DEBUG - 2022-07-03 10:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:04:49 --> Total execution time: 0.0508
DEBUG - 2022-07-03 10:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:04:58 --> Total execution time: 0.0568
DEBUG - 2022-07-03 10:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:35:02 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:05:02 --> Total execution time: 0.0578
DEBUG - 2022-07-03 10:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:05:13 --> Total execution time: 0.0344
DEBUG - 2022-07-03 10:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:05:17 --> Total execution time: 0.0486
DEBUG - 2022-07-03 10:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:05:26 --> Total execution time: 0.0456
DEBUG - 2022-07-03 10:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:05:42 --> Total execution time: 0.0363
DEBUG - 2022-07-03 10:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:37:35 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:07:36 --> Total execution time: 0.0541
DEBUG - 2022-07-03 10:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:37:36 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:07:36 --> Total execution time: 0.0331
DEBUG - 2022-07-03 10:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 10:37:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 10:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:40:17 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:10:17 --> Total execution time: 0.1972
DEBUG - 2022-07-03 10:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:40:29 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:10:29 --> Total execution time: 0.0343
DEBUG - 2022-07-03 10:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:40:37 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:10:37 --> Total execution time: 0.0553
DEBUG - 2022-07-03 10:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:10:37 --> Total execution time: 0.0525
DEBUG - 2022-07-03 10:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:10:41 --> Total execution time: 0.0480
DEBUG - 2022-07-03 10:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:10:48 --> Total execution time: 0.0666
DEBUG - 2022-07-03 10:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:10:51 --> Total execution time: 0.0520
DEBUG - 2022-07-03 10:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:11:14 --> Total execution time: 0.0513
DEBUG - 2022-07-03 10:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:41:16 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:11:16 --> Total execution time: 0.0705
DEBUG - 2022-07-03 10:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:41:24 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:11:24 --> Total execution time: 0.0543
DEBUG - 2022-07-03 10:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:11:25 --> Total execution time: 0.0725
DEBUG - 2022-07-03 10:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:11:33 --> Total execution time: 0.0567
DEBUG - 2022-07-03 10:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:11:36 --> Total execution time: 0.1696
DEBUG - 2022-07-03 10:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:12:00 --> Total execution time: 0.0498
DEBUG - 2022-07-03 10:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:12:14 --> Total execution time: 0.0565
DEBUG - 2022-07-03 10:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:42:14 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:12:14 --> Total execution time: 0.0711
DEBUG - 2022-07-03 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:42:18 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:12:18 --> Total execution time: 0.0501
DEBUG - 2022-07-03 10:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:12:25 --> Total execution time: 0.0490
DEBUG - 2022-07-03 10:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:12:39 --> Total execution time: 0.0595
DEBUG - 2022-07-03 10:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:12:43 --> Total execution time: 0.0664
DEBUG - 2022-07-03 10:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:42:48 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:12:48 --> Total execution time: 0.1152
DEBUG - 2022-07-03 10:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:12:51 --> Total execution time: 0.0511
DEBUG - 2022-07-03 10:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:42:53 --> Total execution time: 0.0402
DEBUG - 2022-07-03 10:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:42:55 --> Total execution time: 0.0485
DEBUG - 2022-07-03 10:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:42:55 --> Total execution time: 0.0925
DEBUG - 2022-07-03 10:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:12:56 --> Total execution time: 0.0501
DEBUG - 2022-07-03 10:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:43:00 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:00 --> Total execution time: 0.0522
DEBUG - 2022-07-03 10:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:04 --> Total execution time: 0.1227
DEBUG - 2022-07-03 10:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:05 --> Total execution time: 0.0521
DEBUG - 2022-07-03 10:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:06 --> Total execution time: 0.0412
DEBUG - 2022-07-03 10:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:08 --> Total execution time: 0.0648
DEBUG - 2022-07-03 10:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:43:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:11 --> Total execution time: 0.0647
DEBUG - 2022-07-03 10:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:21 --> Total execution time: 0.0527
DEBUG - 2022-07-03 10:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:43:31 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:31 --> Total execution time: 0.0637
DEBUG - 2022-07-03 10:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:31 --> Total execution time: 0.0480
DEBUG - 2022-07-03 10:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:49 --> Total execution time: 0.0706
DEBUG - 2022-07-03 10:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:43:54 --> Total execution time: 0.0847
DEBUG - 2022-07-03 10:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:43:55 --> Total execution time: 0.0442
DEBUG - 2022-07-03 10:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:43:55 --> Total execution time: 0.0642
DEBUG - 2022-07-03 10:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:43:57 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:57 --> Total execution time: 0.0465
DEBUG - 2022-07-03 10:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:15:03 --> Total execution time: 0.1335
DEBUG - 2022-07-03 10:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:47:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 10:47:26 --> 404 Page Not Found: Category/sports
DEBUG - 2022-07-03 10:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:18:01 --> Total execution time: 0.1940
DEBUG - 2022-07-03 10:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:19:13 --> Total execution time: 0.0552
DEBUG - 2022-07-03 10:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:19:22 --> Total execution time: 0.0532
DEBUG - 2022-07-03 10:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:19:46 --> Total execution time: 0.0634
DEBUG - 2022-07-03 10:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:50:14 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:20:14 --> Total execution time: 0.0515
DEBUG - 2022-07-03 10:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:50:24 --> Total execution time: 0.0576
DEBUG - 2022-07-03 10:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:50:29 --> Total execution time: 0.0469
DEBUG - 2022-07-03 10:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:50:29 --> Total execution time: 0.1036
DEBUG - 2022-07-03 10:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:20:49 --> Total execution time: 0.0492
DEBUG - 2022-07-03 10:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:21:01 --> Total execution time: 0.0565
DEBUG - 2022-07-03 10:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:21:20 --> Total execution time: 0.0606
DEBUG - 2022-07-03 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:51:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:21:53 --> Total execution time: 1.5621
DEBUG - 2022-07-03 10:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:51:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 10:51:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 10:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:52:51 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:22:51 --> Total execution time: 0.1571
DEBUG - 2022-07-03 10:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:53:17 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:23:18 --> Total execution time: 0.0562
DEBUG - 2022-07-03 10:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:23:43 --> Total execution time: 0.0482
DEBUG - 2022-07-03 10:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:23:45 --> Total execution time: 0.0338
DEBUG - 2022-07-03 10:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:23:47 --> Total execution time: 0.0473
DEBUG - 2022-07-03 10:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:23:47 --> Total execution time: 0.0646
DEBUG - 2022-07-03 10:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:23:57 --> Total execution time: 0.0466
DEBUG - 2022-07-03 10:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:24:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 10:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:24:01 --> Total execution time: 0.0623
DEBUG - 2022-07-03 10:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:24:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 21:24:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 21:24:03 --> Total execution time: 0.2080
DEBUG - 2022-07-03 10:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:24:24 --> Total execution time: 0.0799
DEBUG - 2022-07-03 10:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:24:25 --> Total execution time: 0.1120
DEBUG - 2022-07-03 10:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:24:25 --> Total execution time: 0.0847
DEBUG - 2022-07-03 10:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:24:25 --> Total execution time: 0.0991
DEBUG - 2022-07-03 10:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:24:26 --> Total execution time: 0.1021
DEBUG - 2022-07-03 10:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:24:33 --> Total execution time: 0.1127
DEBUG - 2022-07-03 10:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:24:38 --> Total execution time: 0.0680
DEBUG - 2022-07-03 10:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:24:49 --> Total execution time: 0.0462
DEBUG - 2022-07-03 10:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:26:32 --> Total execution time: 0.0534
DEBUG - 2022-07-03 10:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:26:52 --> Total execution time: 0.0693
DEBUG - 2022-07-03 10:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:56:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:26:53 --> Total execution time: 0.0387
DEBUG - 2022-07-03 10:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:26:55 --> Total execution time: 0.0400
DEBUG - 2022-07-03 10:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:27:01 --> Total execution time: 0.0698
DEBUG - 2022-07-03 10:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:27:03 --> Total execution time: 0.0693
DEBUG - 2022-07-03 10:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:57:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:27:11 --> Total execution time: 0.1205
DEBUG - 2022-07-03 10:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:57:17 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:27:17 --> Total execution time: 0.0489
DEBUG - 2022-07-03 10:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:27:33 --> Total execution time: 0.0394
DEBUG - 2022-07-03 10:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:57:50 --> Total execution time: 0.0489
DEBUG - 2022-07-03 10:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:57:51 --> Total execution time: 0.0623
DEBUG - 2022-07-03 10:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:57:51 --> Total execution time: 0.1246
DEBUG - 2022-07-03 10:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:57:57 --> No URI present. Default controller set.
DEBUG - 2022-07-03 10:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:27:57 --> Total execution time: 0.0567
DEBUG - 2022-07-03 10:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:28:21 --> Total execution time: 0.1308
DEBUG - 2022-07-03 10:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:28:28 --> Total execution time: 0.0501
DEBUG - 2022-07-03 10:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 10:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 10:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 10:59:48 --> Total execution time: 0.0556
DEBUG - 2022-07-03 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:30:03 --> Total execution time: 0.0474
DEBUG - 2022-07-03 11:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:00:05 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:30:05 --> Total execution time: 0.0679
DEBUG - 2022-07-03 11:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:31:37 --> Total execution time: 0.0515
DEBUG - 2022-07-03 11:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:04:18 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:34:18 --> Total execution time: 0.1085
DEBUG - 2022-07-03 11:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:34:18 --> Total execution time: 0.1279
DEBUG - 2022-07-03 11:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:34:26 --> Total execution time: 0.0465
DEBUG - 2022-07-03 11:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:05:51 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:35:52 --> Total execution time: 0.0409
DEBUG - 2022-07-03 11:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:35:56 --> Total execution time: 0.0485
DEBUG - 2022-07-03 11:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:36:03 --> Total execution time: 0.0583
DEBUG - 2022-07-03 11:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:36:03 --> Total execution time: 0.0510
DEBUG - 2022-07-03 11:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:36:08 --> Total execution time: 0.0600
DEBUG - 2022-07-03 11:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:36:15 --> Total execution time: 0.0643
DEBUG - 2022-07-03 11:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:36:18 --> Total execution time: 0.0819
DEBUG - 2022-07-03 11:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:36:22 --> Total execution time: 0.0526
DEBUG - 2022-07-03 11:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:36:26 --> Total execution time: 0.0498
DEBUG - 2022-07-03 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:06:38 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:36:38 --> Total execution time: 0.0341
DEBUG - 2022-07-03 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:06:38 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:36:38 --> Total execution time: 0.0296
DEBUG - 2022-07-03 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:36:38 --> Total execution time: 0.0463
DEBUG - 2022-07-03 11:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:36:47 --> Total execution time: 0.0470
DEBUG - 2022-07-03 11:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:37:14 --> Total execution time: 0.0470
DEBUG - 2022-07-03 11:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:37:19 --> Total execution time: 0.0806
DEBUG - 2022-07-03 11:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:37:19 --> Total execution time: 0.0751
DEBUG - 2022-07-03 11:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:37:22 --> Total execution time: 0.0477
DEBUG - 2022-07-03 11:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:37:37 --> Total execution time: 0.0559
DEBUG - 2022-07-03 11:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:08:03 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:38:03 --> Total execution time: 0.0352
DEBUG - 2022-07-03 11:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:38:37 --> Total execution time: 0.0464
DEBUG - 2022-07-03 11:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:10:05 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:40:05 --> Total execution time: 0.0419
DEBUG - 2022-07-03 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:11:13 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:41:13 --> Total execution time: 0.0416
DEBUG - 2022-07-03 11:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 11:12:20 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-03 11:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:42:41 --> Total execution time: 0.0554
DEBUG - 2022-07-03 11:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:44:12 --> Total execution time: 0.0484
DEBUG - 2022-07-03 11:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:44:26 --> Total execution time: 0.0489
DEBUG - 2022-07-03 11:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:44:34 --> Total execution time: 0.0566
DEBUG - 2022-07-03 11:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:14:48 --> Total execution time: 0.1129
DEBUG - 2022-07-03 11:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 11:14:48 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 11:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:44:50 --> Total execution time: 0.1130
DEBUG - 2022-07-03 11:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:45:34 --> Total execution time: 0.0544
DEBUG - 2022-07-03 11:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:46:24 --> Total execution time: 0.1214
DEBUG - 2022-07-03 11:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:16:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 11:16:25 --> 404 Page Not Found: Update-profile-basic-info/index
DEBUG - 2022-07-03 11:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:16:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 11:16:26 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 11:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:16:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 11:16:29 --> 404 Page Not Found: Update-profile-basic-info/index
DEBUG - 2022-07-03 11:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:46:32 --> Total execution time: 0.0810
DEBUG - 2022-07-03 11:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:16:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 11:16:53 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-03 11:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:46:53 --> Total execution time: 0.0459
DEBUG - 2022-07-03 11:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:47:23 --> Total execution time: 0.0996
DEBUG - 2022-07-03 11:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:47:23 --> Total execution time: 0.0926
DEBUG - 2022-07-03 11:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:47:37 --> Total execution time: 0.0949
DEBUG - 2022-07-03 11:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:47:52 --> Total execution time: 0.0806
DEBUG - 2022-07-03 11:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:47:56 --> Total execution time: 0.0813
DEBUG - 2022-07-03 11:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:47:57 --> Total execution time: 0.0589
DEBUG - 2022-07-03 11:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:17:58 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:47:58 --> Total execution time: 0.0385
DEBUG - 2022-07-03 11:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:48:04 --> Total execution time: 0.0498
DEBUG - 2022-07-03 11:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:48:07 --> Total execution time: 0.0608
DEBUG - 2022-07-03 11:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:48:09 --> Total execution time: 0.0513
DEBUG - 2022-07-03 11:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:48:10 --> Total execution time: 0.0470
DEBUG - 2022-07-03 11:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:48:12 --> Total execution time: 0.0458
DEBUG - 2022-07-03 11:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:48:15 --> Total execution time: 0.0627
DEBUG - 2022-07-03 11:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:48:22 --> Total execution time: 0.0533
DEBUG - 2022-07-03 11:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:18:24 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:48:24 --> Total execution time: 0.1222
DEBUG - 2022-07-03 11:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:48:50 --> Total execution time: 0.0477
DEBUG - 2022-07-03 11:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:18:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:48:53 --> Total execution time: 0.0484
DEBUG - 2022-07-03 11:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:48:59 --> Total execution time: 0.0482
DEBUG - 2022-07-03 11:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:48:59 --> Total execution time: 0.0491
DEBUG - 2022-07-03 11:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:49:21 --> Total execution time: 0.0467
DEBUG - 2022-07-03 11:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:49:35 --> Total execution time: 0.0475
DEBUG - 2022-07-03 11:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:49:56 --> Total execution time: 0.0552
DEBUG - 2022-07-03 11:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:20:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:50:11 --> Total execution time: 0.1139
DEBUG - 2022-07-03 11:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:20:22 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:50:22 --> Total execution time: 0.0469
DEBUG - 2022-07-03 11:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:20:40 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:50:40 --> Total execution time: 0.0491
DEBUG - 2022-07-03 11:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:50:49 --> Total execution time: 0.0441
DEBUG - 2022-07-03 11:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:50:51 --> Total execution time: 0.0725
DEBUG - 2022-07-03 11:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:50:57 --> Total execution time: 0.0595
DEBUG - 2022-07-03 11:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:51:06 --> Total execution time: 0.0452
DEBUG - 2022-07-03 11:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:51:15 --> Total execution time: 0.0478
DEBUG - 2022-07-03 11:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:51:19 --> Total execution time: 0.0702
DEBUG - 2022-07-03 11:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:51:24 --> Total execution time: 0.0430
DEBUG - 2022-07-03 11:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:21:25 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:51:25 --> Total execution time: 0.0308
DEBUG - 2022-07-03 11:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:24:42 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:54:42 --> Total execution time: 0.1318
DEBUG - 2022-07-03 11:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:25:21 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:55:21 --> Total execution time: 0.1178
DEBUG - 2022-07-03 11:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:55:21 --> Total execution time: 0.1149
DEBUG - 2022-07-03 11:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:28:20 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:58:20 --> Total execution time: 0.2182
DEBUG - 2022-07-03 11:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:28:35 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:58:35 --> Total execution time: 0.1369
DEBUG - 2022-07-03 11:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:28:46 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:58:46 --> Total execution time: 0.0442
DEBUG - 2022-07-03 11:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:59:15 --> Total execution time: 0.0527
DEBUG - 2022-07-03 11:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:59:58 --> Total execution time: 0.0560
DEBUG - 2022-07-03 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:00:03 --> Total execution time: 0.0985
DEBUG - 2022-07-03 11:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:30:21 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:00:21 --> Total execution time: 0.0352
DEBUG - 2022-07-03 11:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:00:30 --> Total execution time: 0.1200
DEBUG - 2022-07-03 11:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:01:11 --> Total execution time: 0.0506
DEBUG - 2022-07-03 11:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:01:42 --> Total execution time: 0.0488
DEBUG - 2022-07-03 11:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:32:59 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:02:59 --> Total execution time: 0.1325
DEBUG - 2022-07-03 11:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:35:29 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:05:29 --> Total execution time: 0.2317
DEBUG - 2022-07-03 11:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:05:41 --> Total execution time: 0.1227
DEBUG - 2022-07-03 11:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:05:43 --> Total execution time: 0.0514
DEBUG - 2022-07-03 11:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:05:46 --> Total execution time: 0.0520
DEBUG - 2022-07-03 11:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:05:46 --> Total execution time: 0.0463
DEBUG - 2022-07-03 11:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:05:46 --> Total execution time: 0.0512
DEBUG - 2022-07-03 11:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:06:30 --> Total execution time: 0.0480
DEBUG - 2022-07-03 11:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:07:11 --> Total execution time: 0.0519
DEBUG - 2022-07-03 11:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:39:34 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:09:34 --> Total execution time: 0.0843
DEBUG - 2022-07-03 11:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:10:06 --> Total execution time: 0.0354
DEBUG - 2022-07-03 11:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:40:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 11:40:09 --> 404 Page Not Found: Sports/feed
DEBUG - 2022-07-03 11:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:40:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 11:40:19 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-03 11:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:10:23 --> Total execution time: 0.0669
DEBUG - 2022-07-03 11:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:10:43 --> Total execution time: 0.0522
DEBUG - 2022-07-03 11:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:10:51 --> Total execution time: 0.0621
DEBUG - 2022-07-03 11:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:41:51 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:11:51 --> Total execution time: 0.0407
DEBUG - 2022-07-03 11:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:11:58 --> Total execution time: 0.0517
DEBUG - 2022-07-03 11:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:42:03 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:12:03 --> Total execution time: 0.1179
DEBUG - 2022-07-03 11:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:12:04 --> Total execution time: 0.0530
DEBUG - 2022-07-03 11:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:12:07 --> Total execution time: 0.0813
DEBUG - 2022-07-03 11:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:42:08 --> Total execution time: 0.0662
DEBUG - 2022-07-03 11:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:12:08 --> Total execution time: 0.0580
DEBUG - 2022-07-03 11:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:42:10 --> Total execution time: 0.0537
DEBUG - 2022-07-03 11:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:42:10 --> Total execution time: 0.0950
DEBUG - 2022-07-03 11:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:12:13 --> Total execution time: 0.0954
DEBUG - 2022-07-03 11:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:12:19 --> Total execution time: 0.0626
DEBUG - 2022-07-03 11:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:12:35 --> Total execution time: 0.0490
DEBUG - 2022-07-03 11:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:12:42 --> Total execution time: 0.0543
DEBUG - 2022-07-03 11:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:43:12 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:13:12 --> Total execution time: 0.0490
DEBUG - 2022-07-03 11:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:43:22 --> Total execution time: 0.0466
DEBUG - 2022-07-03 11:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:43:23 --> Total execution time: 0.0507
DEBUG - 2022-07-03 11:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:43:23 --> Total execution time: 0.0956
DEBUG - 2022-07-03 11:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:43:37 --> Total execution time: 0.0576
DEBUG - 2022-07-03 11:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:43:38 --> Total execution time: 0.0720
DEBUG - 2022-07-03 11:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:43:38 --> Total execution time: 0.1186
DEBUG - 2022-07-03 11:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:13:41 --> Total execution time: 0.0489
DEBUG - 2022-07-03 11:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:14:18 --> Total execution time: 0.0597
DEBUG - 2022-07-03 11:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:14:30 --> Total execution time: 0.1412
DEBUG - 2022-07-03 11:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:14:39 --> Total execution time: 0.0563
DEBUG - 2022-07-03 11:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:14:50 --> Total execution time: 0.0335
DEBUG - 2022-07-03 11:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:14:57 --> Total execution time: 0.1432
DEBUG - 2022-07-03 11:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:15:06 --> Total execution time: 0.0639
DEBUG - 2022-07-03 11:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:15:20 --> Total execution time: 0.0532
DEBUG - 2022-07-03 11:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:15:44 --> Total execution time: 0.1497
DEBUG - 2022-07-03 11:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:16:45 --> Total execution time: 0.0844
DEBUG - 2022-07-03 11:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:17:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 11:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:17:13 --> Total execution time: 0.0862
DEBUG - 2022-07-03 11:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:17:17 --> Total execution time: 0.0917
DEBUG - 2022-07-03 11:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:17:22 --> Total execution time: 0.0481
DEBUG - 2022-07-03 11:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:22:02 --> Total execution time: 0.0874
DEBUG - 2022-07-03 11:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:22:14 --> Total execution time: 0.0653
DEBUG - 2022-07-03 11:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:52:23 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:22:23 --> Total execution time: 0.0469
DEBUG - 2022-07-03 11:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:22:31 --> Total execution time: 0.0594
DEBUG - 2022-07-03 11:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:22:33 --> Total execution time: 0.0845
DEBUG - 2022-07-03 11:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:52:37 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:22:37 --> Total execution time: 0.0472
DEBUG - 2022-07-03 11:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:52:37 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:22:37 --> Total execution time: 0.0505
DEBUG - 2022-07-03 11:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:22:38 --> Total execution time: 0.0970
DEBUG - 2022-07-03 11:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:22:51 --> Total execution time: 0.0518
DEBUG - 2022-07-03 11:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:52:56 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:22:56 --> Total execution time: 0.0630
DEBUG - 2022-07-03 11:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:22:57 --> Total execution time: 0.0508
DEBUG - 2022-07-03 11:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:23:00 --> Total execution time: 0.0497
DEBUG - 2022-07-03 11:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:03 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:23:03 --> Total execution time: 0.0528
DEBUG - 2022-07-03 11:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:04 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:23:04 --> Total execution time: 0.0561
DEBUG - 2022-07-03 11:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:23:13 --> Total execution time: 0.0408
DEBUG - 2022-07-03 11:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:23:19 --> Total execution time: 0.0857
DEBUG - 2022-07-03 11:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:23:20 --> Total execution time: 0.0519
DEBUG - 2022-07-03 11:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:24 --> No URI present. Default controller set.
DEBUG - 2022-07-03 11:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:23:24 --> Total execution time: 0.0381
DEBUG - 2022-07-03 11:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:23:26 --> Total execution time: 0.0774
DEBUG - 2022-07-03 11:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:23:28 --> Total execution time: 0.0628
DEBUG - 2022-07-03 11:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:23:33 --> Total execution time: 0.1061
DEBUG - 2022-07-03 11:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:23:40 --> Total execution time: 0.0565
DEBUG - 2022-07-03 11:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:23:41 --> Total execution time: 0.0507
DEBUG - 2022-07-03 11:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:23:44 --> Total execution time: 0.0684
DEBUG - 2022-07-03 11:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:24:03 --> Total execution time: 0.0589
DEBUG - 2022-07-03 11:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:24:03 --> Total execution time: 0.1047
DEBUG - 2022-07-03 11:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:24:30 --> Total execution time: 0.0559
DEBUG - 2022-07-03 11:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:24:33 --> Total execution time: 0.0598
DEBUG - 2022-07-03 11:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:24:34 --> Total execution time: 0.0510
DEBUG - 2022-07-03 11:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:24:36 --> Total execution time: 0.0579
DEBUG - 2022-07-03 11:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:27:47 --> Total execution time: 0.0493
DEBUG - 2022-07-03 11:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:28:53 --> Total execution time: 0.0617
DEBUG - 2022-07-03 11:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:29:02 --> Total execution time: 0.0636
DEBUG - 2022-07-03 11:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 11:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 11:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 11:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:29:21 --> Total execution time: 0.0472
DEBUG - 2022-07-03 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:30:03 --> Total execution time: 0.0520
DEBUG - 2022-07-03 12:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 12:02:01 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-03 12:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:04:00 --> No URI present. Default controller set.
DEBUG - 2022-07-03 12:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:34:00 --> Total execution time: 0.1208
DEBUG - 2022-07-03 12:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:04:03 --> Total execution time: 0.0516
DEBUG - 2022-07-03 12:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:04:04 --> Total execution time: 0.0572
DEBUG - 2022-07-03 12:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:04:04 --> Total execution time: 0.1008
DEBUG - 2022-07-03 12:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:34:08 --> Total execution time: 0.0443
DEBUG - 2022-07-03 12:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:34:21 --> Total execution time: 0.0416
DEBUG - 2022-07-03 12:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:34:58 --> Total execution time: 0.0484
DEBUG - 2022-07-03 12:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:35:11 --> Total execution time: 0.0543
DEBUG - 2022-07-03 12:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:35:14 --> Total execution time: 0.0396
DEBUG - 2022-07-03 12:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:35:20 --> Total execution time: 0.0645
DEBUG - 2022-07-03 12:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:35:24 --> Total execution time: 0.0664
DEBUG - 2022-07-03 12:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:35:24 --> Total execution time: 0.0537
DEBUG - 2022-07-03 12:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:35:49 --> Total execution time: 0.0512
DEBUG - 2022-07-03 12:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:37:21 --> Total execution time: 0.0623
DEBUG - 2022-07-03 12:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:11:11 --> No URI present. Default controller set.
DEBUG - 2022-07-03 12:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:41:11 --> Total execution time: 0.1595
DEBUG - 2022-07-03 12:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:43:55 --> Total execution time: 0.1701
DEBUG - 2022-07-03 12:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:14:48 --> No URI present. Default controller set.
DEBUG - 2022-07-03 12:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:44:49 --> Total execution time: 0.0381
DEBUG - 2022-07-03 12:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:46:39 --> Total execution time: 0.1338
DEBUG - 2022-07-03 12:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:46:42 --> Total execution time: 0.0544
DEBUG - 2022-07-03 12:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:47:11 --> Total execution time: 0.1242
DEBUG - 2022-07-03 12:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:47:16 --> Total execution time: 0.0994
DEBUG - 2022-07-03 12:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:47:19 --> Total execution time: 0.0719
DEBUG - 2022-07-03 12:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:47:29 --> Total execution time: 0.0508
DEBUG - 2022-07-03 12:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:47:31 --> Total execution time: 0.0560
DEBUG - 2022-07-03 12:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:47:38 --> Total execution time: 0.0567
DEBUG - 2022-07-03 12:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:47:41 --> Total execution time: 0.0580
DEBUG - 2022-07-03 12:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:47:48 --> Total execution time: 0.0465
DEBUG - 2022-07-03 12:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:48:31 --> Total execution time: 0.0500
DEBUG - 2022-07-03 12:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:48:31 --> Total execution time: 0.1174
DEBUG - 2022-07-03 12:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:48:44 --> Total execution time: 0.0502
DEBUG - 2022-07-03 12:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:48:47 --> Total execution time: 0.0658
DEBUG - 2022-07-03 12:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:49:00 --> Total execution time: 0.0514
DEBUG - 2022-07-03 12:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:50:00 --> Total execution time: 0.0467
DEBUG - 2022-07-03 12:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:50:45 --> Total execution time: 0.1300
DEBUG - 2022-07-03 12:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:21:52 --> No URI present. Default controller set.
DEBUG - 2022-07-03 12:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:52 --> Total execution time: 0.0608
DEBUG - 2022-07-03 12:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:53:16 --> Total execution time: 0.1205
DEBUG - 2022-07-03 12:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:54:58 --> Total execution time: 0.0403
DEBUG - 2022-07-03 12:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:55:09 --> Total execution time: 0.0553
DEBUG - 2022-07-03 12:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:56:04 --> Total execution time: 0.0500
DEBUG - 2022-07-03 12:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:56:16 --> Total execution time: 0.0516
DEBUG - 2022-07-03 12:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:56:31 --> Total execution time: 0.0646
DEBUG - 2022-07-03 12:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:56:37 --> Total execution time: 0.1358
DEBUG - 2022-07-03 12:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:57:24 --> Total execution time: 0.0841
DEBUG - 2022-07-03 12:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:27:43 --> No URI present. Default controller set.
DEBUG - 2022-07-03 12:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:57:43 --> Total execution time: 0.1210
DEBUG - 2022-07-03 12:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:58:49 --> Total execution time: 0.0470
DEBUG - 2022-07-03 12:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:59:25 --> Total execution time: 0.0591
DEBUG - 2022-07-03 12:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:59:40 --> Total execution time: 0.0858
DEBUG - 2022-07-03 12:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:59:43 --> Total execution time: 0.0827
DEBUG - 2022-07-03 12:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:59:52 --> Total execution time: 0.0495
DEBUG - 2022-07-03 12:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:18 --> Total execution time: 0.0560
DEBUG - 2022-07-03 12:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:21 --> Total execution time: 0.0540
DEBUG - 2022-07-03 12:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 12:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:45 --> Total execution time: 0.1080
DEBUG - 2022-07-03 12:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:57 --> Total execution time: 0.0824
DEBUG - 2022-07-03 12:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:58 --> Total execution time: 0.0595
DEBUG - 2022-07-03 12:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:01:02 --> Total execution time: 0.0626
DEBUG - 2022-07-03 12:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:01:04 --> Total execution time: 0.0857
DEBUG - 2022-07-03 12:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:31:09 --> No URI present. Default controller set.
DEBUG - 2022-07-03 12:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:01:09 --> Total execution time: 0.0357
DEBUG - 2022-07-03 12:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:01:20 --> Total execution time: 0.0455
DEBUG - 2022-07-03 12:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:32:00 --> No URI present. Default controller set.
DEBUG - 2022-07-03 12:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:02:00 --> Total execution time: 0.0521
DEBUG - 2022-07-03 12:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:02:02 --> Total execution time: 0.1579
DEBUG - 2022-07-03 12:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:32:13 --> Total execution time: 0.0442
DEBUG - 2022-07-03 12:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:32:15 --> Total execution time: 0.0582
DEBUG - 2022-07-03 12:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:32:15 --> Total execution time: 0.1142
DEBUG - 2022-07-03 12:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:32:33 --> No URI present. Default controller set.
DEBUG - 2022-07-03 12:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:02:33 --> Total execution time: 0.0508
DEBUG - 2022-07-03 12:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:03:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 12:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:03:45 --> Total execution time: 0.0997
DEBUG - 2022-07-03 12:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:04:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 12:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:04:44 --> Total execution time: 0.0816
DEBUG - 2022-07-03 12:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:07:14 --> Total execution time: 0.2610
DEBUG - 2022-07-03 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:07:24 --> Total execution time: 0.0832
DEBUG - 2022-07-03 12:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:08:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 12:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:08:41 --> Total execution time: 0.0903
DEBUG - 2022-07-03 12:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:39:23 --> Total execution time: 0.1217
DEBUG - 2022-07-03 12:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:39:24 --> Total execution time: 0.0602
DEBUG - 2022-07-03 12:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:39:24 --> Total execution time: 0.1007
DEBUG - 2022-07-03 12:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:39:25 --> Total execution time: 0.0714
DEBUG - 2022-07-03 12:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:39:26 --> Total execution time: 0.0522
DEBUG - 2022-07-03 12:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:39:26 --> Total execution time: 0.0968
DEBUG - 2022-07-03 12:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:39:41 --> No URI present. Default controller set.
DEBUG - 2022-07-03 12:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:09:41 --> Total execution time: 0.0427
DEBUG - 2022-07-03 12:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:39:43 --> No URI present. Default controller set.
DEBUG - 2022-07-03 12:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:09:43 --> Total execution time: 0.0330
DEBUG - 2022-07-03 12:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:39:44 --> Total execution time: 0.0523
DEBUG - 2022-07-03 12:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:39:45 --> Total execution time: 0.0600
DEBUG - 2022-07-03 12:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:39:45 --> Total execution time: 0.1473
DEBUG - 2022-07-03 12:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:39:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 12:39:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 12:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:39:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 12:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:09:53 --> Total execution time: 0.0654
DEBUG - 2022-07-03 12:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:10:17 --> Total execution time: 0.1234
DEBUG - 2022-07-03 12:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:10:56 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 12:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:10:56 --> Total execution time: 0.0900
DEBUG - 2022-07-03 12:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:12:34 --> Total execution time: 0.0789
DEBUG - 2022-07-03 12:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:13:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 12:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:13:11 --> Total execution time: 0.1107
DEBUG - 2022-07-03 12:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:13:16 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-03 12:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:13:18 --> Total execution time: 0.1264
DEBUG - 2022-07-03 12:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:13:26 --> Total execution time: 0.0893
DEBUG - 2022-07-03 12:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:13:31 --> Total execution time: 0.1514
DEBUG - 2022-07-03 12:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:13:48 --> Total execution time: 0.1199
DEBUG - 2022-07-03 12:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:14:15 --> Total execution time: 0.1004
DEBUG - 2022-07-03 12:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:16:01 --> Total execution time: 0.0887
DEBUG - 2022-07-03 12:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:17:21 --> Total execution time: 0.0497
DEBUG - 2022-07-03 12:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:17:30 --> Total execution time: 0.0543
DEBUG - 2022-07-03 12:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:17:48 --> Total execution time: 0.0516
DEBUG - 2022-07-03 12:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:51:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 12:51:46 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-03 12:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:53:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 12:53:29 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-03 12:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:56:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 12:56:00 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 12:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:58:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 12:58:11 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-03 12:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:28:40 --> Total execution time: 0.2001
DEBUG - 2022-07-03 12:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:28:42 --> Total execution time: 0.0558
DEBUG - 2022-07-03 12:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:28:42 --> Total execution time: 0.0447
DEBUG - 2022-07-03 12:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:28:42 --> Total execution time: 0.0453
DEBUG - 2022-07-03 12:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:28:43 --> Total execution time: 0.0441
DEBUG - 2022-07-03 12:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 12:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 12:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 12:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:28:44 --> Total execution time: 0.0457
DEBUG - 2022-07-03 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:30:02 --> Total execution time: 0.0830
DEBUG - 2022-07-03 13:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:37:17 --> Total execution time: 0.1080
DEBUG - 2022-07-03 13:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:37:19 --> Total execution time: 0.0760
DEBUG - 2022-07-03 13:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:50:20 --> Total execution time: 0.0472
DEBUG - 2022-07-03 13:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:21:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 13:21:32 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-03 13:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:25:45 --> No URI present. Default controller set.
DEBUG - 2022-07-03 13:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:55:45 --> Total execution time: 0.1037
DEBUG - 2022-07-03 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:32:58 --> No URI present. Default controller set.
DEBUG - 2022-07-03 13:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:52:06 --> No URI present. Default controller set.
DEBUG - 2022-07-03 13:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:52:06 --> No URI present. Default controller set.
DEBUG - 2022-07-03 13:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:52:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 13:52:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 13:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 13:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 13:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 13:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:07:26 --> No URI present. Default controller set.
DEBUG - 2022-07-03 14:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:09:23 --> No URI present. Default controller set.
DEBUG - 2022-07-03 14:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:10:16 --> No URI present. Default controller set.
DEBUG - 2022-07-03 14:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:10:17 --> No URI present. Default controller set.
DEBUG - 2022-07-03 14:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:14:45 --> No URI present. Default controller set.
DEBUG - 2022-07-03 14:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:32:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 14:32:19 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-03 14:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:34:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 14:34:50 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 14:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:36:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 14:36:56 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-03 14:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:53:19 --> No URI present. Default controller set.
DEBUG - 2022-07-03 14:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 14:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 14:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 14:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:00:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 15:00:25 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-03 15:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:06:32 --> No URI present. Default controller set.
DEBUG - 2022-07-03 15:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:06:33 --> No URI present. Default controller set.
DEBUG - 2022-07-03 15:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:08:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 15:08:24 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-03 15:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:16:28 --> No URI present. Default controller set.
DEBUG - 2022-07-03 15:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:22:06 --> Total execution time: 0.0573
DEBUG - 2022-07-03 15:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:22:16 --> Total execution time: 0.1107
DEBUG - 2022-07-03 15:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:33:55 --> No URI present. Default controller set.
DEBUG - 2022-07-03 15:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:33:56 --> No URI present. Default controller set.
DEBUG - 2022-07-03 15:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:33:59 --> Total execution time: 0.0563
DEBUG - 2022-07-03 15:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:34:07 --> Total execution time: 0.1014
DEBUG - 2022-07-03 15:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:35:27 --> No URI present. Default controller set.
DEBUG - 2022-07-03 15:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:35:27 --> No URI present. Default controller set.
DEBUG - 2022-07-03 15:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:35:40 --> No URI present. Default controller set.
DEBUG - 2022-07-03 15:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 15:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 15:58:33 --> No URI present. Default controller set.
DEBUG - 2022-07-03 15:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 15:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 16:11:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 16:11:30 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-03 16:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 16:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 16:14:00 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 16:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 16:16:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 16:16:04 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-03 16:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 16:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 16:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 16:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 16:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 16:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 16:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 16:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 16:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 16:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 16:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 16:39:56 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-03 16:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 16:53:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 16:53:16 --> 404 Page Not Found: Contact/index
DEBUG - 2022-07-03 16:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 16:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 16:53:17 --> 404 Page Not Found: Contact/index
DEBUG - 2022-07-03 16:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 16:53:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 16:53:19 --> 404 Page Not Found: Contact/index
DEBUG - 2022-07-03 16:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 16:53:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 16:53:20 --> 404 Page Not Found: Contact/index
DEBUG - 2022-07-03 16:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 16:57:37 --> No URI present. Default controller set.
DEBUG - 2022-07-03 16:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 16:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:02:37 --> No URI present. Default controller set.
DEBUG - 2022-07-03 17:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:02:42 --> No URI present. Default controller set.
DEBUG - 2022-07-03 17:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:02:57 --> No URI present. Default controller set.
DEBUG - 2022-07-03 17:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:03:01 --> No URI present. Default controller set.
DEBUG - 2022-07-03 17:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:03:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 17:03:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 17:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:03:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 17:03:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 17:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:10:50 --> No URI present. Default controller set.
DEBUG - 2022-07-03 17:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:10:54 --> No URI present. Default controller set.
DEBUG - 2022-07-03 17:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 17:11:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 17:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:15:23 --> No URI present. Default controller set.
DEBUG - 2022-07-03 17:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:15:25 --> No URI present. Default controller set.
DEBUG - 2022-07-03 17:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:32:00 --> No URI present. Default controller set.
DEBUG - 2022-07-03 17:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 17:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 17:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:54:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 17:54:00 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-03 17:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:56:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 17:56:38 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 17:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 17:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 17:58:57 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-03 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:10:00 --> No URI present. Default controller set.
DEBUG - 2022-07-03 18:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:10:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 18:10:45 --> 404 Page Not Found: Events/page
DEBUG - 2022-07-03 18:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 18:15:28 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-03 18:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:16:34 --> No URI present. Default controller set.
DEBUG - 2022-07-03 18:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:21:40 --> No URI present. Default controller set.
DEBUG - 2022-07-03 18:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:23:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 18:23:10 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-03 18:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:38:27 --> No URI present. Default controller set.
DEBUG - 2022-07-03 18:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:39:00 --> No URI present. Default controller set.
DEBUG - 2022-07-03 18:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 18:40:43 --> 404 Page Not Found: Events/page
DEBUG - 2022-07-03 18:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:49:02 --> No URI present. Default controller set.
DEBUG - 2022-07-03 18:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 18:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 18:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 18:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 19:13:13 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-03 19:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:27:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 19:27:11 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-03 19:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 19:35:48 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-03 19:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:38:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 19:38:26 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 19:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:38:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 19:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:40:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 19:40:38 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-03 19:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:50:00 --> No URI present. Default controller set.
DEBUG - 2022-07-03 19:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 19:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:54:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 19:54:45 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-03 19:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 19:55:45 --> No URI present. Default controller set.
DEBUG - 2022-07-03 19:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 19:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 20:02:40 --> 404 Page Not Found: Environments/.credentials
DEBUG - 2022-07-03 20:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:03:30 --> No URI present. Default controller set.
DEBUG - 2022-07-03 20:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:04:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 20:04:14 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-03 20:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:06:29 --> No URI present. Default controller set.
DEBUG - 2022-07-03 20:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:07:40 --> No URI present. Default controller set.
DEBUG - 2022-07-03 20:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:10:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 20:10:01 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-03 20:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:20:04 --> No URI present. Default controller set.
DEBUG - 2022-07-03 20:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:20:04 --> No URI present. Default controller set.
DEBUG - 2022-07-03 20:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:20:49 --> No URI present. Default controller set.
DEBUG - 2022-07-03 20:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:25:03 --> No URI present. Default controller set.
DEBUG - 2022-07-03 20:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:25:27 --> No URI present. Default controller set.
DEBUG - 2022-07-03 20:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:25:49 --> No URI present. Default controller set.
DEBUG - 2022-07-03 20:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:25:59 --> No URI present. Default controller set.
DEBUG - 2022-07-03 20:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:31:17 --> No URI present. Default controller set.
DEBUG - 2022-07-03 20:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 20:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:43:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 20:43:02 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-03 20:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:43:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 20:43:26 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-03 20:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 20:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 20:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:07:47 --> No URI present. Default controller set.
DEBUG - 2022-07-03 21:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:07:49 --> No URI present. Default controller set.
DEBUG - 2022-07-03 21:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:08:05 --> No URI present. Default controller set.
DEBUG - 2022-07-03 21:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 21:15:06 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-03 21:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 21:17:36 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 21:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:19:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 21:19:39 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-03 21:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:25:02 --> No URI present. Default controller set.
DEBUG - 2022-07-03 21:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:31:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 21:31:51 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-07-03 21:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:40:45 --> No URI present. Default controller set.
DEBUG - 2022-07-03 21:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:42:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 21:42:58 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-03 21:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:51:25 --> No URI present. Default controller set.
DEBUG - 2022-07-03 21:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:52:04 --> No URI present. Default controller set.
DEBUG - 2022-07-03 21:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:59:51 --> No URI present. Default controller set.
DEBUG - 2022-07-03 21:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 21:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 21:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 21:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:00:39 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:03:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 22:03:15 --> 404 Page Not Found: Shop/feed
DEBUG - 2022-07-03 22:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:03:54 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:06:24 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:07:03 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:07:04 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:07:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 22:07:45 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-03 22:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:08:29 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:11:01 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:12:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 22:12:19 --> 404 Page Not Found: Category/health
DEBUG - 2022-07-03 22:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:14:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 22:14:23 --> 404 Page Not Found: Category/culture
DEBUG - 2022-07-03 22:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:21:13 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:24:31 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:24:40 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:28:54 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 22:28:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 22:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:29:50 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:30:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 22:30:18 --> 404 Page Not Found: Category/reviews
DEBUG - 2022-07-03 22:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:33:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 22:33:55 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-03 22:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:34:19 --> Total execution time: 0.0925
DEBUG - 2022-07-03 22:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:34:38 --> Total execution time: 0.0477
DEBUG - 2022-07-03 22:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:36:10 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:38:13 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:41:04 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:41:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 22:41:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 22:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 22:41:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 22:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:41:50 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:44:21 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:44:22 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:48:01 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:50:36 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:46 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:49 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:51 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:51 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:52 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:52 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:53:05 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:54:16 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:54:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 22:54:39 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-03 22:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:55:01 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:55:15 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:56:08 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:56:26 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:56:41 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:56:51 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:56:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:57:04 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:57:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 22:57:19 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-03 22:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:57:41 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:57:44 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:58:04 --> No URI present. Default controller set.
DEBUG - 2022-07-03 22:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:59:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 22:59:25 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-03 22:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 22:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 22:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 22:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:46 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:53 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:18:45 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:19:15 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:19:50 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:22:33 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:22:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 23:22:54 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-03 23:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:23:00 --> Total execution time: 0.0591
DEBUG - 2022-07-03 23:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:23:06 --> Total execution time: 0.1568
DEBUG - 2022-07-03 23:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:23:18 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:23:31 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:23:54 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:24:14 --> Total execution time: 0.0638
DEBUG - 2022-07-03 23:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:24:16 --> Total execution time: 0.0559
DEBUG - 2022-07-03 23:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:24:16 --> Total execution time: 0.1510
DEBUG - 2022-07-03 23:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:27:34 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:28:45 --> Total execution time: 0.0520
DEBUG - 2022-07-03 23:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:28:50 --> Total execution time: 0.0879
DEBUG - 2022-07-03 23:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:29:17 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:30:14 --> Total execution time: 0.0620
DEBUG - 2022-07-03 23:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:30:21 --> Total execution time: 0.0943
DEBUG - 2022-07-03 23:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:31:16 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:31:17 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:31:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 23:31:19 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-03 23:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:31:51 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:31:59 --> Total execution time: 0.0475
DEBUG - 2022-07-03 23:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:32:25 --> Total execution time: 0.0658
DEBUG - 2022-07-03 23:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:32:39 --> Total execution time: 0.0469
DEBUG - 2022-07-03 23:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:32:41 --> Total execution time: 0.0596
DEBUG - 2022-07-03 23:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:32:43 --> Total execution time: 0.0449
DEBUG - 2022-07-03 23:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:32:49 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:33:15 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:35:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 23:35:57 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-03 23:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:36:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 23:36:02 --> 404 Page Not Found: Summer-course-starts-from-june/esalestrix.in
DEBUG - 2022-07-03 23:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:40:17 --> Total execution time: 0.1218
DEBUG - 2022-07-03 23:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:40:20 --> Total execution time: 0.0621
DEBUG - 2022-07-03 23:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:40:20 --> Total execution time: 0.1165
DEBUG - 2022-07-03 23:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:41:36 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:56:21 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:56:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-03 23:56:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-03 23:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:57:29 --> No URI present. Default controller set.
DEBUG - 2022-07-03 23:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:57:38 --> Total execution time: 0.0651
DEBUG - 2022-07-03 23:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-03 23:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-03 23:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:57:40 --> Total execution time: 0.0520
DEBUG - 2022-07-03 23:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-03 23:57:40 --> Total execution time: 0.1001
