<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-01-09 11:46:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-09 11:46:37 --> No URI present. Default controller set.
DEBUG - 2023-01-09 11:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-09 11:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-09 11:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-09 16:16:38 --> Total execution time: 0.5942
